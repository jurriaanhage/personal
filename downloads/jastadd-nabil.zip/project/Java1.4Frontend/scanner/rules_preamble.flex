%state STRING

%%

