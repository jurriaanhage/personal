
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


public class TypeVariable extends ReferenceType implements Cloneable {
    public void flushCache() {
        super.flushCache();
        erasure_computed = false;
        erasure_value = null;
        fullName_computed = false;
        fullName_value = null;
        lubType_computed = false;
        lubType_value = null;
        usesTypeVariable_computed = false;
        usesTypeVariable_initialized = false;
        accessibleFrom_TypeDecl_values = null;
        instanceOf_TypeDecl_values = null;
        typeDescriptor_computed = false;
        typeDescriptor_value = null;
        constantPoolName_computed = false;
        constantPoolName_value = null;
        needsSignatureAttribute_computed = false;
        fieldTypeSignature_computed = false;
        fieldTypeSignature_value = null;
        classTypeSignature_computed = false;
        classTypeSignature_value = null;
        getTypeVariables_computed = false;
        getTypeVariables_value = null;
        wideErasure_computed = false;
        wideErasure_value = null;
        hasInBounds_TypeVariable_values = null;
        boundTypeVariables_computed = false;
        boundTypeVariables_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        TypeVariable node = (TypeVariable)super.clone();
        node.erasure_computed = false;
        node.erasure_value = null;
        node.fullName_computed = false;
        node.fullName_value = null;
        node.lubType_computed = false;
        node.lubType_value = null;
        node.usesTypeVariable_computed = false;
        node.usesTypeVariable_initialized = false;
        node.accessibleFrom_TypeDecl_values = null;
        node.instanceOf_TypeDecl_values = null;
        node.typeDescriptor_computed = false;
        node.typeDescriptor_value = null;
        node.constantPoolName_computed = false;
        node.constantPoolName_value = null;
        node.needsSignatureAttribute_computed = false;
        node.fieldTypeSignature_computed = false;
        node.fieldTypeSignature_value = null;
        node.classTypeSignature_computed = false;
        node.classTypeSignature_value = null;
        node.getTypeVariables_computed = false;
        node.getTypeVariables_value = null;
        node.wideErasure_computed = false;
        node.wideErasure_value = null;
        node.hasInBounds_TypeVariable_values = null;
        node.boundTypeVariables_computed = false;
        node.boundTypeVariables_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          TypeVariable node = (TypeVariable)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        TypeVariable res = (TypeVariable)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in GenericTypeVariables.jrag at line 19
    

  public void nameCheck() {
    if(extractSingleType(lookupType(name())) != this)
      error("*** Semantic Error: type variable " + name() + " is multiply declared");
  }

    // Declared in GenericTypeVariables.jrag at line 57


  public void typeCheck() {
    if(getTypeBound(0).type().isTypeVariable()) {
      if(getNumTypeBound() > 1)
        error("a type variable may not be followed by other bounds");
    }
    else {
      if(!getTypeBound(0).type().isClassDecl() && !getTypeBound(0).type().isInterfaceDecl()) {
      error("the first type bound must be a class or interface type which " + 
        getTypeBound(0).type().fullName() + " is not");
      }
      for(int i = 1; i < getNumTypeBound(); i++) {
        if(!getTypeBound(i).type().isInterfaceDecl()) {
          error("type bound " + i + " must be an interface type which " + 
            getTypeBound(i).type().fullName() + " is not");
        }
      }
    }
    HashSet typeSet = new HashSet();
    for(int i = 0; i < getNumTypeBound(); i++) {
      TypeDecl type = getTypeBound(i).type();
      TypeDecl erasure = type.erasure();
      if(typeSet.contains(erasure)) {
        if(type != erasure) {
          error("the erasure " + erasure.fullName() + " of typebound " + getTypeBound(i) + " is multiply declared in " + this);
        }
        else {
          error(type.fullName() + " is multiply declared");
        }
      }
      typeSet.add(erasure);
    }

    for(int i = 0; i < getNumTypeBound(); i++) {
      TypeDecl type = getTypeBound(i).type();
      for(Iterator iter = type.methodsIterator(); iter.hasNext(); ) {
        MethodDecl m = (MethodDecl)iter.next();
        for(int j = i+1; j < getNumTypeBound(); j++) {
          TypeDecl destType = getTypeBound(j).type();
          for(Iterator destIter = destType.memberMethods(m.name()).iterator(); destIter.hasNext(); ) {
            MethodDecl n = (MethodDecl)destIter.next();
            if(m.sameSignature(n) && m.type() != n.type()) {
              error("the two bounds, " + type.name() + " and " + destType.name() + ", in type variable " + name() + 
                " have a method " + m.signature() + " with conflicting return types " + m.type().name() + " and " + n.type().name());
            }
          }
        }
      }
    }

    
  }

    // Declared in Generics.jrag at line 621

  public Access substitute(Parameterization parTypeDecl) {
    if(parTypeDecl.isRawType())
      return erasure().createBoundAccess();
    return parTypeDecl.substitute(this).createBoundAccess();
  }

    // Declared in Generics.jrag at line 666


  public Access substituteReturnType(Parameterization parTypeDecl) {
    if(parTypeDecl.isRawType())
      return erasure().createBoundAccess();
    TypeDecl typeDecl = parTypeDecl.substitute(this);
    if(typeDecl instanceof WildcardType) {
      // the bound of this type variable
      return createBoundAccess();
      //return lubType().createBoundAccess();
      //return typeObject().createBoundAccess();
    }
    else if(typeDecl instanceof WildcardExtendsType) {
      if(typeDecl.instanceOf(this))
        return ((WildcardExtendsType)typeDecl).extendsType().createBoundAccess();
      else 
        return createBoundAccess();

      // the bound of this type variable of the bound of the wild card if it is more specific
      //return ((WildcardExtendsType)typeDecl).extendsType().createBoundAccess();
    }
    else if(typeDecl instanceof WildcardSuperType) {
      // the bound of this type variable 
      return createBoundAccess();
      //return typeObject().createBoundAccess();
    }
    return typeDecl.createBoundAccess();
  }

    // Declared in Generics.jrag at line 700

  public Access substituteParameterType(Parameterization parTypeDecl) {
    if(parTypeDecl.isRawType())
      return erasure().createBoundAccess();
    TypeDecl typeDecl = parTypeDecl.substitute(this);
    if(typeDecl instanceof WildcardType)
      return typeNull().createQualifiedAccess();
    else if(typeDecl instanceof WildcardExtendsType)
      return typeNull().createQualifiedAccess();
    else if(typeDecl instanceof WildcardSuperType)
      return ((WildcardSuperType)typeDecl).superType().createBoundAccess();
    return typeDecl.createBoundAccess();
  }

    // Declared in Generics.jrag at line 1112


  public Access createQualifiedAccess() {
    return createBoundAccess();
  }

    // Declared in GenericsPrettyPrint.jrag at line 2

  public void toString(StringBuffer s) {
    s.append(name());
    if(getNumTypeBound() > 0) {
      s.append(" extends ");
      s.append(getTypeBound(0).type().fullName());
      for(int i = 1; i < getNumTypeBound(); i++) {
        s.append(" & ");
        s.append(getTypeBound(i).type().fullName());
      }
    }
  }

    // Declared in TypeConstraints.jrag at line 9

    // ------------------------------------------------------------------------
    // Ordering type variables
    // ------------------------------------------------------------------------

    /**
     * Importance index used to order type parameters.
     */
    private int order = 0;

    // Declared in TypeConstraints.jrag at line 10

    public int getOrder(){
        return order;
    }

    // Declared in TypeConstraints.jrag at line 16

    /**
     * Increase order field of this type parameter and that of its bounds.
     */
    public void updateOrder(){
        order++;
        for (int i = 0; i < getNumTypeBound(); i++) {
            TypeDecl bound = getTypeBound(i).type();
            if(bound instanceof TypeVariable && !equals(bound)){
                ((TypeVariable)bound).updateOrder();
            }
            else if (!bound.isObject()) {
                Set nested_bounds = bound.getTypeVariables();
                //Set nested_bounds = new HashSet();
                //bound.getTypeVariables(nested_bounds);
                for (Iterator nested_vars = nested_bounds.iterator(); nested_vars
                        .hasNext();) {
                    TypeVariable nested_var = ((TypeVariable) nested_vars.next());
                    if(!equals(nested_var))
                        nested_var.updateOrder();
                }
            }
        }
    }

    // Declared in TypeConstraints.jrag at line 82

    // ------------------------------------------------------------------------
    // Convert a type variable to an interface
    // ------------------------------------------------------------------------
    private InterfaceDecl iface;

    // Declared in TypeConstraints.jrag at line 84


    public InterfaceDecl toInterface() {
        if (iface == null) {
            iface = new VarInterfaceDecl(this);
            iface.setID("$I" + getID() + "j_" + hashCode());
            iface.setModifiers((Modifiers) getModifiers().fullCopy());
            // I'm assuming that TypeVariable has no members of it's own.
            for (int i = 0; i < getNumTypeBound(); i++) {
                TypeDecl bound = getTypeBound(i).type();
                if(bound instanceof ClassDecl){
                    // add interface members                    
                    java.util.List ifaceList = new LinkedList();
                    ifaceList.addAll(bound.implementedInterfaces());
                    inference.solvers.BasicSolver.greatestLowerBounds(ifaceList);
                    for(Iterator iter = ifaceList.iterator(); iter.hasNext();){
                        iface.addSuperInterfaceId(((InterfaceDecl)iter.next()).createBoundAccess());
                    }
                }else if(bound instanceof TypeVariable){
                    TypeVariable vbound = (TypeVariable) bound;
                    iface.addSuperInterfaceId(vbound.toInterface().createBoundAccess());
                }else if(bound instanceof InterfaceDecl){
                    iface.addSuperInterfaceId(bound.createBoundAccess());
                }
            }
            compilationUnit().addTypeDecl(iface);
        }
        return iface;
    }

    // Declared in TypeConstraints.jrag at line 125

    // ------------------------------------------------------------------------
    // Return the set of type variables thas have this type variable in their bounds
    // ------------------------------------------------------------------------
    public Set dependingTypeVariables(Collection vars){
        HashSet set = new HashSet();
        for(Iterator iter = vars.iterator(); iter.hasNext(); ){
            TypeVariable var = (TypeVariable) iter.next();
            if(var.hasInBounds(this))
                set.add(var);
        }
        return set;
    }

    // Declared in TypeConstraints.jrag at line 137

    // ------------------------------------------------------------------------
    // Return the group of type variables that this type variable is a member of.
    // ------------------------------------------------------------------------
    private boolean group_visited = false;

    // Declared in TypeConstraints.jrag at line 139


    private Set typeVariableGroup;

    // Declared in TypeConstraints.jrag at line 141


    public Set typeVariableGroup(final Collection vars) {
        if (group_visited) {
            for (Iterator iter = vars.iterator(); iter.hasNext();) {
                TypeVariable var = (TypeVariable) iter.next();
                if (var.typeVariableGroup.contains(this)) {
                    typeVariableGroup = var.typeVariableGroup;
                    break;
                }
            }
        } else {
            typeVariableGroup = new HashSet();
            followPath(vars, typeVariableGroup);
        }

        return typeVariableGroup;
    }

    // Declared in TypeConstraints.jrag at line 158


    private void followPath(final Collection vars, Set grp) {
        for (Iterator iter = vars.iterator(); iter.hasNext();) {
            TypeVariable var = (TypeVariable) iter.next();
            if (var == this) {
                grp.add(this);
                this.group_visited = true;
                for (Iterator itera = boundTypeVariables().iterator(); itera
                        .hasNext();) {
                    TypeVariable dpvar = (TypeVariable) itera.next();
                    if (!dpvar.group_visited)
                        dpvar.followPath(vars, grp);
                }
            } else {
                for (Iterator itera = var.boundTypeVariables().iterator(); itera
                        .hasNext();) {
                    TypeVariable dpvar = (TypeVariable) itera.next();
                    if (dpvar == this) {
                        grp.add(this);
                        this.group_visited = true;
                        if (!var.group_visited)
                            var.followPath(vars, grp);
                    }
                }

            }
        }
    }

    // Declared in TypeVariableSubstitution.jrag at line 74



    // instantiate the type variable only once.
    private VarTypeDecl instance_decl = null;

    // Declared in Generics.ast at line 3
    // Declared in Generics.ast line 15

    public TypeVariable() {
        super();

        setChild(null, 0);
        setChild(new List(), 1);
        setChild(new List(), 2);

    }

    // Declared in Generics.ast at line 13


    // Declared in Generics.ast line 15
    public TypeVariable(Modifiers p0, String p1, List p2, List p3) {
        setChild(p0, 0);
        setID(p1);
        setChild(p2, 1);
        setChild(p3, 2);
    }

    // Declared in Generics.ast at line 20


  protected int numChildren() {
    return 3;
  }

    // Declared in Generics.ast at line 23

  public boolean mayHaveRewrite() { return true; }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 15
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in Generics.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in Generics.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 15
    private String tokenString_ID;

    // Declared in Generics.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in Generics.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 15
    public void setBodyDeclList(List list) {
        setChild(list, 1);
    }

    // Declared in Generics.ast at line 6


    private int getNumBodyDecl = 0;

    // Declared in Generics.ast at line 7

    public int getNumBodyDecl() {
        return getBodyDeclList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public BodyDecl getBodyDecl(int i) {
        return (BodyDecl)getBodyDeclList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addBodyDecl(BodyDecl node) {
        List list = getBodyDeclList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setBodyDecl(BodyDecl node, int i) {
        List list = getBodyDeclList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getBodyDeclList() {
        return (List)getChild(1);
    }

    // Declared in Generics.ast at line 28


    public List getBodyDeclListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 15
    public void setTypeBoundList(List list) {
        setChild(list, 2);
    }

    // Declared in Generics.ast at line 6


    private int getNumTypeBound = 0;

    // Declared in Generics.ast at line 7

    public int getNumTypeBound() {
        return getTypeBoundList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public Access getTypeBound(int i) {
        return (Access)getTypeBoundList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addTypeBound(Access node) {
        List list = getTypeBoundList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setTypeBound(Access node, int i) {
        List list = getTypeBoundList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getTypeBoundList() {
        return (List)getChild(2);
    }

    // Declared in Generics.ast at line 28


    public List getTypeBoundListNoTransform() {
        return (List)getChildNoTransform(2);
    }

    protected boolean involvesTypeParameters_visited = false;
    protected boolean involvesTypeParameters_computed = false;
    protected boolean involvesTypeParameters_initialized = false;
    protected boolean involvesTypeParameters_value;
    public boolean involvesTypeParameters() {
        if(involvesTypeParameters_computed)
            return involvesTypeParameters_value;
        if (!involvesTypeParameters_initialized) {
            involvesTypeParameters_initialized = true;
            involvesTypeParameters_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            involvesTypeParameters_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
                if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                    CHANGE = true;
                involvesTypeParameters_value = new_involvesTypeParameters_value; 
            } while (CHANGE);
            involvesTypeParameters_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            involvesTypeParameters_computed = true;
            }
            else {
            RESET_CYCLE = true;
            involvesTypeParameters_compute();
            RESET_CYCLE = false;
              involvesTypeParameters_computed = false;
              involvesTypeParameters_initialized = false;
            }
            IN_CIRCLE = false; 
            return involvesTypeParameters_value;
        }
        if(!involvesTypeParameters_visited) {
            if (RESET_CYCLE) {
                involvesTypeParameters_computed = false;
                involvesTypeParameters_initialized = false;
                return involvesTypeParameters_value;
            }
            involvesTypeParameters_visited = true;
            boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
            if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                CHANGE = true;
            involvesTypeParameters_value = new_involvesTypeParameters_value; 
            involvesTypeParameters_visited = false;
            return involvesTypeParameters_value;
        }
        return involvesTypeParameters_value;
    }

    private boolean involvesTypeParameters_compute() {  return  true;  }

    // Declared in GenericTypeVariables.jrag at line 24
    public TypeDecl lowerBound() {
        TypeDecl lowerBound_value = lowerBound_compute();
        return lowerBound_value;
    }

    private TypeDecl lowerBound_compute() {  return  getTypeBound(0).type();  }

    // Declared in GenericTypeVariables.jrag at line 29
    public Collection memberMethods(String name) {
        Collection memberMethods_String_value = memberMethods_compute(name);
        return memberMethods_String_value;
    }

    private Collection memberMethods_compute(String name)  {
    Collection list = new HashSet();
    for(int i = 0; i < getNumTypeBound(); i++) {
      for(Iterator iter = getTypeBound(i).type().memberMethods(name).iterator(); iter.hasNext(); ) {
        MethodDecl decl = (MethodDecl)iter.next();
        if(!decl.isPrivate())
          list.add(decl);
      }
    }
    return list;
  }

    // Declared in GenericTypeVariables.jrag at line 41
    public SimpleSet fields(String name) {
        SimpleSet fields_String_value = fields_compute(name);
        return fields_String_value;
    }

    private SimpleSet fields_compute(String name)  {
    SimpleSet set = SimpleSet.emptySet;
    for(int i = 0; i < getNumTypeBound(); i++) {
      for(Iterator iter = getTypeBound(i).type().fields(name).iterator(); iter.hasNext(); ) {
        FieldDeclaration decl = (FieldDeclaration)iter.next();
        if(!decl.isPrivate())
          set = set.add(decl);
      }
    }
    return set;
  }

    // Declared in Generics.jrag at line 69
    public boolean isNestedType() {
        boolean isNestedType_value = isNestedType_compute();
        return isNestedType_value;
    }

    private boolean isNestedType_compute() {  return  false;  }

    // Declared in Generics.jrag at line 235
    public TypeDecl erasure() {
        if(erasure_computed)
            return erasure_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        erasure_value = erasure_compute();
        if(isFinal && num == boundariesCrossed)
            erasure_computed = true;
        return erasure_value;
    }

    private TypeDecl erasure_compute() {  return  getTypeBound(0).type().erasure();  }

    // Declared in Generics.jrag at line 437
    public String fullName() {
        if(fullName_computed)
            return fullName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        fullName_value = fullName_compute();
        if(isFinal && num == boundariesCrossed)
            fullName_computed = true;
        return fullName_value;
    }

    private String fullName_compute()  {
    if(getParent().getParent() instanceof TypeDecl) {
      TypeDecl typeDecl = (TypeDecl)getParent().getParent();
      return typeDecl.fullName() + "@" + name();
    }
    return super.fullName();
  }

    // Declared in Generics.jrag at line 450
    public boolean sameSignature(Access a) {
        boolean sameSignature_Access_value = sameSignature_compute(a);
        return sameSignature_Access_value;
    }

    private boolean sameSignature_compute(Access a) {  return  a.type() == this;  }

    protected boolean lubType_computed = false;
    protected TypeDecl lubType_value;
    // Declared in Generics.jrag at line 659
    public TypeDecl lubType() {
        if(lubType_computed)
            return lubType_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        lubType_value = lubType_compute();
        if(isFinal && num == boundariesCrossed)
            lubType_computed = true;
        return lubType_value;
    }

    private TypeDecl lubType_compute()  {
    ArrayList list = new ArrayList();
    for(int i = 0; i < getNumTypeBound(); i++)
      list.add(getTypeBound(i).type());
    return lookupLUBType(list);
  }

    protected boolean usesTypeVariable_visited = false;
    protected boolean usesTypeVariable_computed = false;
    protected boolean usesTypeVariable_initialized = false;
    protected boolean usesTypeVariable_value;
    public boolean usesTypeVariable() {
        if(usesTypeVariable_computed)
            return usesTypeVariable_value;
        if (!usesTypeVariable_initialized) {
            usesTypeVariable_initialized = true;
            usesTypeVariable_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            usesTypeVariable_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_usesTypeVariable_value = usesTypeVariable_compute();
                if (new_usesTypeVariable_value!=usesTypeVariable_value)
                    CHANGE = true;
                usesTypeVariable_value = new_usesTypeVariable_value; 
            } while (CHANGE);
            usesTypeVariable_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            usesTypeVariable_computed = true;
            }
            else {
            RESET_CYCLE = true;
            usesTypeVariable_compute();
            RESET_CYCLE = false;
              usesTypeVariable_computed = false;
              usesTypeVariable_initialized = false;
            }
            IN_CIRCLE = false; 
            return usesTypeVariable_value;
        }
        if(!usesTypeVariable_visited) {
            if (RESET_CYCLE) {
                usesTypeVariable_computed = false;
                usesTypeVariable_initialized = false;
                return usesTypeVariable_value;
            }
            usesTypeVariable_visited = true;
            boolean new_usesTypeVariable_value = usesTypeVariable_compute();
            if (new_usesTypeVariable_value!=usesTypeVariable_value)
                CHANGE = true;
            usesTypeVariable_value = new_usesTypeVariable_value; 
            usesTypeVariable_visited = false;
            return usesTypeVariable_value;
        }
        return usesTypeVariable_value;
    }

    private boolean usesTypeVariable_compute() {  return  true;  }

    // Declared in Generics.jrag at line 1116
    public boolean accessibleFrom(TypeDecl type) {
        Object _parameters = type;
if(accessibleFrom_TypeDecl_values == null) accessibleFrom_TypeDecl_values = new java.util.HashMap(4);
        if(accessibleFrom_TypeDecl_values.containsKey(_parameters))
            return ((Boolean)accessibleFrom_TypeDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean accessibleFrom_TypeDecl_value = accessibleFrom_compute(type);
        if(isFinal && num == boundariesCrossed)
            accessibleFrom_TypeDecl_values.put(_parameters, Boolean.valueOf(accessibleFrom_TypeDecl_value));
        return accessibleFrom_TypeDecl_value;
    }

    private boolean accessibleFrom_compute(TypeDecl type) {  return  true;  }

    // Declared in GenericsParTypeDecl.jrag at line 62
    public boolean isTypeVariable() {
        boolean isTypeVariable_value = isTypeVariable_compute();
        return isTypeVariable_value;
    }

    private boolean isTypeVariable_compute() {  return  true;  }

    // Declared in GenericsSubtype.jrag at line 40
    public boolean supertypeWildcard(WildcardType type) {
        boolean supertypeWildcard_WildcardType_value = supertypeWildcard_compute(type);
        return supertypeWildcard_WildcardType_value;
    }

    private boolean supertypeWildcard_compute(WildcardType type) {  return  
    true;  }

    // Declared in GenericsSubtype.jrag at line 51
    public boolean supertypeWildcardExtends(WildcardExtendsType type) {
        boolean supertypeWildcardExtends_WildcardExtendsType_value = supertypeWildcardExtends_compute(type);
        return supertypeWildcardExtends_WildcardExtendsType_value;
    }

    private boolean supertypeWildcardExtends_compute(WildcardExtendsType type) {  return 
    type.extendsType().subtype(this);  }

    // Declared in GenericsSubtype.jrag at line 60
    public boolean supertypeWildcardSuper(WildcardSuperType type) {
        boolean supertypeWildcardSuper_WildcardSuperType_value = supertypeWildcardSuper_compute(type);
        return supertypeWildcardSuper_WildcardSuperType_value;
    }

    private boolean supertypeWildcardSuper_compute(WildcardSuperType type) {  return 
    type.superType().subtype(this);  }

    protected java.util.Set matchingTypeArgument_TypeDecl_visited;
    protected java.util.Set matchingTypeArgument_TypeDecl_computed = new java.util.HashSet(4);
    protected java.util.Set matchingTypeArgument_TypeDecl_initialized = new java.util.HashSet(4);
    protected java.util.Map matchingTypeArgument_TypeDecl_values = new java.util.HashMap(4);
    public boolean matchingTypeArgument(TypeDecl type) {
        Object _parameters = type;
if(matchingTypeArgument_TypeDecl_visited == null) matchingTypeArgument_TypeDecl_visited = new java.util.HashSet(4);
if(matchingTypeArgument_TypeDecl_values == null) matchingTypeArgument_TypeDecl_values = new java.util.HashMap(4);
        if(matchingTypeArgument_TypeDecl_computed.contains(_parameters))
            return ((Boolean)matchingTypeArgument_TypeDecl_values.get(_parameters)).booleanValue();
        if (!matchingTypeArgument_TypeDecl_initialized.contains(_parameters)) {
            matchingTypeArgument_TypeDecl_initialized.add(_parameters);
            matchingTypeArgument_TypeDecl_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            matchingTypeArgument_TypeDecl_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_matchingTypeArgument_TypeDecl_value;
            do {
                CHANGE = false;
                new_matchingTypeArgument_TypeDecl_value = matchingTypeArgument_compute(type);
                if (new_matchingTypeArgument_TypeDecl_value!=((Boolean)matchingTypeArgument_TypeDecl_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                matchingTypeArgument_TypeDecl_values.put(_parameters, Boolean.valueOf(new_matchingTypeArgument_TypeDecl_value));
            } while (CHANGE);
            matchingTypeArgument_TypeDecl_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            matchingTypeArgument_TypeDecl_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            matchingTypeArgument_compute(type);
            RESET_CYCLE = false;
            matchingTypeArgument_TypeDecl_computed.remove(_parameters);
            matchingTypeArgument_TypeDecl_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_matchingTypeArgument_TypeDecl_value;
        }
        if(!matchingTypeArgument_TypeDecl_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                matchingTypeArgument_TypeDecl_computed.remove(_parameters);
                matchingTypeArgument_TypeDecl_initialized.remove(_parameters);
                return ((Boolean)matchingTypeArgument_TypeDecl_values.get(_parameters)).booleanValue();
            }
            matchingTypeArgument_TypeDecl_visited.add(_parameters);
            boolean new_matchingTypeArgument_TypeDecl_value = matchingTypeArgument_compute(type);
            if (new_matchingTypeArgument_TypeDecl_value!=((Boolean)matchingTypeArgument_TypeDecl_values.get(_parameters)).booleanValue())
                CHANGE = true;
            matchingTypeArgument_TypeDecl_values.put(_parameters, Boolean.valueOf(new_matchingTypeArgument_TypeDecl_value));
            matchingTypeArgument_TypeDecl_visited.remove(_parameters);
            return new_matchingTypeArgument_TypeDecl_value;
        }
        return ((Boolean)matchingTypeArgument_TypeDecl_values.get(_parameters)).booleanValue();
    }

    private boolean matchingTypeArgument_compute(TypeDecl type) {  return  true;  }

    // Declared in GenericsSubtype.jrag at line 178
    public boolean supertypeArrayDecl(ArrayDecl type) {
        boolean supertypeArrayDecl_ArrayDecl_value = supertypeArrayDecl_compute(type);
        return supertypeArrayDecl_ArrayDecl_value;
    }

    private boolean supertypeArrayDecl_compute(ArrayDecl type)  {
    for(int i = 0; i < getNumTypeBound(); i++)
      if(type.subtype(getTypeBound(i).type())) {
        return true;
      }
    return false;
  }

    protected java.util.Set subtype_TypeDecl_visited;
    protected java.util.Set subtype_TypeDecl_computed = new java.util.HashSet(4);
    protected java.util.Set subtype_TypeDecl_initialized = new java.util.HashSet(4);
    protected java.util.Map subtype_TypeDecl_values = new java.util.HashMap(4);
    public boolean subtype(TypeDecl type) {
        Object _parameters = type;
if(subtype_TypeDecl_visited == null) subtype_TypeDecl_visited = new java.util.HashSet(4);
if(subtype_TypeDecl_values == null) subtype_TypeDecl_values = new java.util.HashMap(4);
        if(subtype_TypeDecl_computed.contains(_parameters))
            return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
        if (!subtype_TypeDecl_initialized.contains(_parameters)) {
            subtype_TypeDecl_initialized.add(_parameters);
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            subtype_TypeDecl_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_subtype_TypeDecl_value;
            do {
                CHANGE = false;
                new_subtype_TypeDecl_value = subtype_compute(type);
                if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            } while (CHANGE);
            subtype_TypeDecl_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            subtype_TypeDecl_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            subtype_compute(type);
            RESET_CYCLE = false;
            subtype_TypeDecl_computed.remove(_parameters);
            subtype_TypeDecl_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_subtype_TypeDecl_value;
        }
        if(!subtype_TypeDecl_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                subtype_TypeDecl_computed.remove(_parameters);
                subtype_TypeDecl_initialized.remove(_parameters);
                return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
            }
            subtype_TypeDecl_visited.add(_parameters);
            boolean new_subtype_TypeDecl_value = subtype_compute(type);
            if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                CHANGE = true;
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            subtype_TypeDecl_visited.remove(_parameters);
            return new_subtype_TypeDecl_value;
        }
        return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
    }

    private boolean subtype_compute(TypeDecl type) {  return  type.supertypeTypeVariable(this);  }

    // Declared in GenericsSubtype.jrag at line 195
    public boolean supertypeTypeVariable(TypeVariable type) {
        boolean supertypeTypeVariable_TypeVariable_value = supertypeTypeVariable_compute(type);
        return supertypeTypeVariable_TypeVariable_value;
    }

    private boolean supertypeTypeVariable_compute(TypeVariable type)  {
    if(type == this)
      return true;
    for(int i = 0; i < type.getNumTypeBound(); i++) {
      boolean found = false;
      for(int j = 0; !found && j < getNumTypeBound(); j++) {
        if(type.getTypeBound(i).type().subtype(getTypeBound(j).type()))
          found = true;
      }
      if(!found)
        return false;
    }
    return true;
  }

    // Declared in GenericsSubtype.jrag at line 210
    public boolean supertypeClassDecl(ClassDecl type) {
        boolean supertypeClassDecl_ClassDecl_value = supertypeClassDecl_compute(type);
        return supertypeClassDecl_ClassDecl_value;
    }

    private boolean supertypeClassDecl_compute(ClassDecl type)  {
    for(int i = 0; i < getNumTypeBound(); i++)
      if(!type.subtype(getTypeBound(i).type()))
        return false;
    return true;
  }

    // Declared in GenericsSubtype.jrag at line 216
    public boolean supertypeInterfaceDecl(InterfaceDecl type) {
        boolean supertypeInterfaceDecl_InterfaceDecl_value = supertypeInterfaceDecl_compute(type);
        return supertypeInterfaceDecl_InterfaceDecl_value;
    }

    private boolean supertypeInterfaceDecl_compute(InterfaceDecl type)  {
    for(int i = 0; i < getNumTypeBound(); i++)
      if(!type.subtype(getTypeBound(i).type()))
        return false;
    return true;
  }

    // Declared in GenericsSubtype.jrag at line 250
    public boolean instanceOf(TypeDecl type) {
        Object _parameters = type;
if(instanceOf_TypeDecl_values == null) instanceOf_TypeDecl_values = new java.util.HashMap(4);
        if(instanceOf_TypeDecl_values.containsKey(_parameters))
            return ((Boolean)instanceOf_TypeDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean instanceOf_TypeDecl_value = instanceOf_compute(type);
        if(isFinal && num == boundariesCrossed)
            instanceOf_TypeDecl_values.put(_parameters, Boolean.valueOf(instanceOf_TypeDecl_value));
        return instanceOf_TypeDecl_value;
    }

    private boolean instanceOf_compute(TypeDecl type) {  return  subtype(type);  }

    // Declared in GenericsCodegen.jrag at line 4
    public String typeDescriptor() {
        if(typeDescriptor_computed)
            return typeDescriptor_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        typeDescriptor_value = typeDescriptor_compute();
        if(isFinal && num == boundariesCrossed)
            typeDescriptor_computed = true;
        return typeDescriptor_value;
    }

    private String typeDescriptor_compute() {  return  erasure().typeDescriptor();  }

    // Declared in GenericsCodegen.jrag at line 18
    public String arrayTypeDescriptor() {
        String arrayTypeDescriptor_value = arrayTypeDescriptor_compute();
        return arrayTypeDescriptor_value;
    }

    private String arrayTypeDescriptor_compute() {  return  erasure().arrayTypeDescriptor();  }

    // Declared in GenericsCodegen.jrag at line 153
    public String constantPoolName() {
        if(constantPoolName_computed)
            return constantPoolName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        constantPoolName_value = constantPoolName_compute();
        if(isFinal && num == boundariesCrossed)
            constantPoolName_computed = true;
        return constantPoolName_value;
    }

    private String constantPoolName_compute() {  return  erasure().constantPoolName();  }

    // Declared in GenericsCodegen.jrag at line 367
    public boolean needsSignatureAttribute() {
        if(needsSignatureAttribute_computed)
            return needsSignatureAttribute_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        needsSignatureAttribute_value = needsSignatureAttribute_compute();
        if(isFinal && num == boundariesCrossed)
            needsSignatureAttribute_computed = true;
        return needsSignatureAttribute_value;
    }

    private boolean needsSignatureAttribute_compute() {  return  true;  }

    // Declared in GenericsCodegen.jrag at line 448
    public String formalTypeParameter() {
        String formalTypeParameter_value = formalTypeParameter_compute();
        return formalTypeParameter_value;
    }

    private String formalTypeParameter_compute()  {
    StringBuffer buf = new StringBuffer();
    // Identifier
    buf.append(name());
    buf.append(":");
    if(getNumTypeBound() > 0) {
      // ClassBound InterfaceBound*
      if(getTypeBound(0).type().isClassDecl())
        buf.append(getTypeBound(0).type().fieldTypeSignature());
      else
        buf.append(":" + getTypeBound(0).type().fieldTypeSignature());
      for(int i = 1; i < getNumTypeBound(); i++)
        buf.append(":" + getTypeBound(i).type().fieldTypeSignature());
    }
    return buf.toString();
  }

    // Declared in GenericsCodegen.jrag at line 467
    public String fieldTypeSignature() {
        if(fieldTypeSignature_computed)
            return fieldTypeSignature_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        fieldTypeSignature_value = fieldTypeSignature_compute();
        if(isFinal && num == boundariesCrossed)
            fieldTypeSignature_computed = true;
        return fieldTypeSignature_value;
    }

    private String fieldTypeSignature_compute() {  return  classTypeSignature();  }

    // Declared in GenericsCodegen.jrag at line 476
    public String classTypeSignature() {
        if(classTypeSignature_computed)
            return classTypeSignature_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        classTypeSignature_value = classTypeSignature_compute();
        if(isFinal && num == boundariesCrossed)
            classTypeSignature_computed = true;
        return classTypeSignature_value;
    }

    private String classTypeSignature_compute() {  return  "T" + name() + ";";  }

/**
     * Collect the type variables used in a bound.
     * Example: Type<R,T extends List<Set<R>>> wil return [R,T]
     
    Declared in GenericNamesAndTypes.jrag at line 12
*/
    public Set getTypeVariables() {
        if(getTypeVariables_computed)
            return getTypeVariables_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getTypeVariables_value = getTypeVariables_compute();
        if(isFinal && num == boundariesCrossed)
            getTypeVariables_computed = true;
        return getTypeVariables_value;
    }

    private Set getTypeVariables_compute() {
        HashSet typevars = new HashSet(1);
        typevars.add(this);
        return typevars;
    }

/**
     * Return top-level type.
     
    Declared in GenericNamesAndTypes.jrag at line 87
*/
    public String simpleName() {
        String simpleName_value = simpleName_compute();
        return simpleName_value;
    }

    private String simpleName_compute() {
        StringBuilder s = new StringBuilder();
        s.append(name());
        if(!getTypeBound(0).type().isObject() || getNumTypeBound() > 1)        
            s.append(" extends ");
        for(int i=0; i<getNumTypeBound(); i++){
            if(i > 0)
                s.append(" & ");
            if(!getTypeBound(i).type().isObject())
                s.append(getTypeBound(i).type().shortName());
        }
        return s.toString();
    }

    // Declared in GenericNamesAndTypes.jrag at line 100
    public String shortName() {
        String shortName_value = shortName_compute();
        return shortName_value;
    }

    private String shortName_compute() {  return  name();  }

    // Declared in MethodLookUp.jadd at line 173
    public TypeDecl wideErasure() {
        if(wideErasure_computed)
            return wideErasure_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        wideErasure_value = wideErasure_compute();
        if(isFinal && num == boundariesCrossed)
            wideErasure_computed = true;
        return wideErasure_value;
    }

    private TypeDecl wideErasure_compute() {  return  typeObject();  }

    protected java.util.Map hasInBounds_TypeVariable_values;
    // Declared in TypeConstraints.jrag at line 114
    public boolean hasInBounds(TypeVariable var) {
        Object _parameters = var;
if(hasInBounds_TypeVariable_values == null) hasInBounds_TypeVariable_values = new java.util.HashMap(4);
        if(hasInBounds_TypeVariable_values.containsKey(_parameters))
            return ((Boolean)hasInBounds_TypeVariable_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean hasInBounds_TypeVariable_value = hasInBounds_compute(var);
        if(isFinal && num == boundariesCrossed)
            hasInBounds_TypeVariable_values.put(_parameters, Boolean.valueOf(hasInBounds_TypeVariable_value));
        return hasInBounds_TypeVariable_value;
    }

    private boolean hasInBounds_compute(TypeVariable var) {
        for(int i = 0; i < getNumTypeBound(); i++){
            Set varSet = getTypeBound(i).type().getTypeVariables();
            if (varSet.contains(var))
                return true;
        }
        return false;
    }

    protected boolean boundTypeVariables_computed = false;
    protected Set boundTypeVariables_value;
    // Declared in TypeConstraints.jrag at line 186
    public Set boundTypeVariables() {
        if(boundTypeVariables_computed)
            return boundTypeVariables_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boundTypeVariables_value = boundTypeVariables_compute();
        if(isFinal && num == boundariesCrossed)
            boundTypeVariables_computed = true;
        return boundTypeVariables_value;
    }

    private Set boundTypeVariables_compute()  {
        HashSet ret = new HashSet();
        for (int i = 0; i < getNumTypeBound(); i++) {
            ret.addAll(getTypeBound(i).type().getTypeVariables());
        }
        return ret;
    }

/**
     * Replace type variables with a new type. This is somewhat similar to wildcard capture.
     * @return
     
    Declared in TypeVariableSubstitution.jrag at line 75
*/
    public TypeDecl captureTypeVariables() {
        TypeDecl captureTypeVariables_value = captureTypeVariables_compute();
        return captureTypeVariables_value;
    }

    private TypeDecl captureTypeVariables_compute() {
        if(instance_decl != null)
            return instance_decl;

        instance_decl = new VarTypeDecl(this);
        // set modifiers
        instance_decl.setModifiers((Modifiers) getModifiers().fullCopy());
        // set name
        instance_decl.setID(getID() + "_" + hashCode());
        // set class super types
        TypeDecl fstBound = getTypeBound(0).type().captureTypeVariables();
        if (fstBound.isClassDecl()) {
            //instance_decl.setSuperClassAccessOpt(new Opt(getTypeBound(0)));
            instance_decl.setSuperClassAccessOpt(new Opt(fstBound .createBoundAccess()));
            if(fstBound.isAbstract()){
                instance_decl.getModifiers().addModifier(new Modifier("abstract"));
            }
        }
        // set interface supertypes
        List interfaces = new List();
        for (int i = 0; i < getNumTypeBound(); i++) {
            TypeDecl bound = getTypeBound(i).type();
            if (bound instanceof InterfaceDecl) {
                bound = bound.captureTypeVariables();
                interfaces.add(bound.createBoundAccess());
            }
        }
        instance_decl.setImplementsList(interfaces);
        // set body
        instance_decl.setBodyDeclList(new List());
        // add the type to the type env
        compilationUnit().addTypeDecl(instance_decl);
        return instance_decl;
    }

/**
     * Substitute type variables with types given in subst (Map<TypeVariable, TypeDecl>)
     
    Declared in TypeVariableSubstitution.jrag at line 147
*/
    public TypeDecl instantiateParType(Map subst, boolean useHole) {
        TypeDecl instantiateParType_Map_boolean_value = instantiateParType_compute(subst, useHole);
        return instantiateParType_Map_boolean_value;
    }

    private TypeDecl instantiateParType_compute(Map subst, boolean useHole) {
        return subst.containsKey(this) 
               ? (TypeDecl)subst.get(this) 
               : useHole
                 ? holeType() 
                 : this;
    }

    // Declared in Generics.jrag at line 657
    public TypeDecl typeObject() {
        TypeDecl typeObject_value = getParent().Define_TypeDecl_typeObject(this, null);
        return typeObject_value;
    }

    // Declared in Generics.jrag at line 699
    public TypeDecl typeNull() {
        TypeDecl typeNull_value = getParent().Define_TypeDecl_typeNull(this, null);
        return typeNull_value;
    }

    // Declared in GenericTypeVariables.jrag at line 4
    public NameType Define_NameType_nameType(ASTNode caller, ASTNode child) {
        if(caller == getTypeBoundListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  NameType.TYPE_NAME;
        }
        return super.Define_NameType_nameType(caller, child);
    }

public ASTNode rewriteTo() {
    // Declared in GenericTypeVariables.jrag at line 7
    if(getNumTypeBound() == 0) {
        duringGenericTypeVariables++;
        ASTNode result = rewriteRule0();
        duringGenericTypeVariables--;
        return result;
    }

    return super.rewriteTo();
}

    // Declared in GenericTypeVariables.jrag at line 7
    private TypeVariable rewriteRule0() {
			addTypeBound(
        new TypeAccess(
          "java.lang",
          "Object"
        )
      );
			return this;
		}
}
