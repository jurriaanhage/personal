
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


public class ParMethodDecl extends MethodDecl implements Cloneable,  Parameterization {
    public void flushCache() {
        super.flushCache();
        moreSpecificThan_MethodDecl_values = null;
        genericMethodDecl_computed = false;
        genericMethodDecl_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        ParMethodDecl node = (ParMethodDecl)super.clone();
        node.moreSpecificThan_MethodDecl_values = null;
        node.genericMethodDecl_computed = false;
        node.genericMethodDecl_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          ParMethodDecl node = (ParMethodDecl)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        ParMethodDecl res = (ParMethodDecl)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in GenericMethods.jrag at line 58

  // Disable error checking in instantiated generic methods
  public void collectErrors() {
  }

    // Declared in Generics.jrag at line 591

  public TypeDecl substitute(TypeVariable typeVariable) {
    for(int i = 0; i < numTypeParameter(); i++)
      if(typeParameter(i) == typeVariable)
        return getTypeArgument(i).type();
    return hostType().substitute(typeVariable);
  }

    // Declared in Generics.jrag at line 605

  public boolean isRawType() {
    return false; 
  }

    // Declared in Generics.jrag at line 608

  public int numTypeParameter() {
    return genericMethodDecl().original().getNumTypeParameter();
  }

    // Declared in Generics.jrag at line 611

  public TypeVariable typeParameter(int index) {
    return genericMethodDecl().original().getTypeParameter(index);
  }

    // Declared in GenericsCodegen.jrag at line 245

  public void transformation() { }

    // Declared in GenericMethods.ast at line 3
    // Declared in GenericMethods.ast line 4

    public ParMethodDecl() {
        super();

        setChild(null, 0);
        setChild(null, 1);
        setChild(new List(), 2);
        setChild(new List(), 3);
        setChild(new Opt(), 4);
        setChild(new List(), 5);

    }

    // Declared in GenericMethods.ast at line 16


    // Declared in GenericMethods.ast line 4
    public ParMethodDecl(Modifiers p0, Access p1, String p2, List p3, List p4, Opt p5, List p6) {
        setChild(p0, 0);
        setChild(p1, 1);
        setID(p2);
        setChild(p3, 2);
        setChild(p4, 3);
        setChild(p5, 4);
        setChild(p6, 5);
    }

    // Declared in GenericMethods.ast at line 26


  protected int numChildren() {
    return 6;
  }

    // Declared in GenericMethods.ast at line 29

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in java.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in java.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setTypeAccess(Access node) {
        setChild(node, 1);
    }

    // Declared in java.ast at line 5

    public Access getTypeAccess() {
        return (Access)getChild(1);
    }

    // Declared in java.ast at line 9


    public Access getTypeAccessNoTransform() {
        return (Access)getChildNoTransform(1);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setParameterList(List list) {
        setChild(list, 2);
    }

    // Declared in java.ast at line 6


    private int getNumParameter = 0;

    // Declared in java.ast at line 7

    public int getNumParameter() {
        return getParameterList().getNumChild();
    }

    // Declared in java.ast at line 11


    public ParameterDeclaration getParameter(int i) {
        return (ParameterDeclaration)getParameterList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addParameter(ParameterDeclaration node) {
        List list = getParameterList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setParameter(ParameterDeclaration node, int i) {
        List list = getParameterList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getParameterList() {
        return (List)getChild(2);
    }

    // Declared in java.ast at line 28


    public List getParameterListNoTransform() {
        return (List)getChildNoTransform(2);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setExceptionList(List list) {
        setChild(list, 3);
    }

    // Declared in java.ast at line 6


    private int getNumException = 0;

    // Declared in java.ast at line 7

    public int getNumException() {
        return getExceptionList().getNumChild();
    }

    // Declared in java.ast at line 11


    public Access getException(int i) {
        return (Access)getExceptionList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addException(Access node) {
        List list = getExceptionList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setException(Access node, int i) {
        List list = getExceptionList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getExceptionList() {
        return (List)getChild(3);
    }

    // Declared in java.ast at line 28


    public List getExceptionListNoTransform() {
        return (List)getChildNoTransform(3);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setBlockOpt(Opt opt) {
        setChild(opt, 4);
    }

    // Declared in java.ast at line 6


    public boolean hasBlock() {
        return getBlockOpt().getNumChild() != 0;
    }

    // Declared in java.ast at line 10


    public Block getBlock() {
        return (Block)getBlockOpt().getChild(0);
    }

    // Declared in java.ast at line 14


    public void setBlock(Block node) {
        getBlockOpt().setChild(node, 0);
    }

    // Declared in java.ast at line 17

    public Opt getBlockOpt() {
        return (Opt)getChild(4);
    }

    // Declared in java.ast at line 21


    public Opt getBlockOptNoTransform() {
        return (Opt)getChildNoTransform(4);
    }

    // Declared in GenericMethods.ast at line 2
    // Declared in GenericMethods.ast line 4
    public void setTypeArgumentList(List list) {
        setChild(list, 5);
    }

    // Declared in GenericMethods.ast at line 6


    private int getNumTypeArgument = 0;

    // Declared in GenericMethods.ast at line 7

    public int getNumTypeArgument() {
        return getTypeArgumentList().getNumChild();
    }

    // Declared in GenericMethods.ast at line 11


    public Access getTypeArgument(int i) {
        return (Access)getTypeArgumentList().getChild(i);
    }

    // Declared in GenericMethods.ast at line 15


    public void addTypeArgument(Access node) {
        List list = getTypeArgumentList();
        list.addChild(node);
    }

    // Declared in GenericMethods.ast at line 20


    public void setTypeArgument(Access node, int i) {
        List list = getTypeArgumentList();
        list.setChild(node, i);
    }

    // Declared in GenericMethods.ast at line 24

    public List getTypeArgumentList() {
        return (List)getChild(5);
    }

    // Declared in GenericMethods.ast at line 28


    public List getTypeArgumentListNoTransform() {
        return (List)getChildNoTransform(5);
    }

    // Declared in MethodSignature.jrag at line 120
    public boolean moreSpecificThan(MethodDecl m) {
        Object _parameters = m;
if(moreSpecificThan_MethodDecl_values == null) moreSpecificThan_MethodDecl_values = new java.util.HashMap(4);
        if(moreSpecificThan_MethodDecl_values.containsKey(_parameters))
            return ((Boolean)moreSpecificThan_MethodDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean moreSpecificThan_MethodDecl_value = moreSpecificThan_compute(m);
        if(isFinal && num == boundariesCrossed)
            moreSpecificThan_MethodDecl_values.put(_parameters, Boolean.valueOf(moreSpecificThan_MethodDecl_value));
        return moreSpecificThan_MethodDecl_value;
    }

    private boolean moreSpecificThan_compute(MethodDecl m) {  return 
    genericMethodDecl().moreSpecificThan(m instanceof ParMethodDecl ? ((ParMethodDecl)m).genericMethodDecl() : m );  }

    // Declared in GenericsCodegen.jrag at line 41
    public MethodDecl erasedMethod() {
        MethodDecl erasedMethod_value = erasedMethod_compute();
        return erasedMethod_value;
    }

    private MethodDecl erasedMethod_compute() {  return  genericMethodDecl().erasedMethod();  }

    protected boolean genericMethodDecl_computed = false;
    protected GenericMethodDecl genericMethodDecl_value;
    // Declared in GenericMethods.jrag at line 18
    public GenericMethodDecl genericMethodDecl() {
        if(genericMethodDecl_computed)
            return genericMethodDecl_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        genericMethodDecl_value = getParent().Define_GenericMethodDecl_genericMethodDecl(this, null);
        if(isFinal && num == boundariesCrossed)
            genericMethodDecl_computed = true;
        return genericMethodDecl_value;
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
