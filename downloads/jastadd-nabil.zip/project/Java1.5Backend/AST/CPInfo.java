
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


  public class CPInfo extends java.lang.Object {
    // Declared in ConstantPool.jrag at line 233
    public void emit(DataOutputStream out) throws IOException {
    }

    // Declared in ConstantPool.jrag at line 235
    public int size() {
      return  1;
    }

    // Declared in ConstantPool.jrag at line 238
    public int pos;


}
