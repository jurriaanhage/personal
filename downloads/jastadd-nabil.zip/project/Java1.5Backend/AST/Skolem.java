
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


    /*
     * Used to capture a wildcard in a type varibale.
     */
    public class Skolem extends ReferenceType {
    // Declared in AdditionalAST.jadd at line 79
        private final AbstractWildcardType initialWildcard;

    // Declared in AdditionalAST.jadd at line 80
        private static int counter;

    // Declared in AdditionalAST.jadd at line 82

        public Skolem(AbstractWildcardType wildcard){
            this.initialWildcard = wildcard;
            this.setID("Skolem_<" + wildcard.shortName() + ">_" + counter++);
            this.setModifiers(wildcard.getModifiers());
        }

    // Declared in AdditionalAST.jadd at line 88

        public AbstractWildcardType getWildcard(){
            return initialWildcard;
        }

    // Declared in AdditionalAST.jadd at line 92

        public boolean isWildcard(){
            return true;
        }

    // Declared in AdditionalAST.jadd at line 100

        /*
         * Skolem is a subtype of itself and of the bounds in its
         * initialwildcard. 
         */
        public boolean subtype(TypeDecl type){
            if(type instanceof Skolem)
                return this == type;

            // if captured wildcard is '? extends U', then this skolem is
            // subtype of type if U is subtype of type.
            else if(initialWildcard instanceof WildcardExtendsType)
                return ((WildcardExtendsType)initialWildcard)
                            .extendsType().subtype(type);
                    
            // if captured wildcard is '?' or '? super U', then this skolem
            // is subtype of Object only.
            return type.isObject();
        }

    // Declared in AdditionalAST.jadd at line 116


        public String simpleName(){
            return initialWildcard.simpleName();
        }

    // Declared in AdditionalAST.jadd at line 120

        public String shortName(){
            return initialWildcard.shortName();
        }

    // Declared in AdditionalAST.jadd at line 125

        // delegate subtyping to the undelying wildcard.
        public boolean supertypeClassDecl(ClassDecl type){
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeClassDecl(type);
            return super.supertypeClassDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 131

        public boolean supertypeInterfaceDecl(InterfaceDecl type) {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeInterfaceDecl(type);
            return super.supertypeInterfaceDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 137

        public boolean supertypeParClassDecl(ParClassDecl type) {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeParClassDecl(type);
            return super.supertypeParClassDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 143

        public boolean supertypeParInterfaceDecl(ParInterfaceDecl type)  {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeParInterfaceDecl(type);
            return super.supertypeParInterfaceDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 149

        public boolean supertypeRawClassDecl(RawClassDecl type)  {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeRawClassDecl(type);
            return super.supertypeRawClassDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 155

        public boolean supertypeRawInterfaceDecl(RawInterfaceDecl type)  {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeRawInterfaceDecl(type);
            return super.supertypeRawInterfaceDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 161

        public boolean supertypeTypeVariable(TypeVariable type)  {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeTypeVariable(type);
            return super.supertypeTypeVariable(type);
        }

    // Declared in AdditionalAST.jadd at line 167

        public boolean supertypeArrayDecl(ArrayDecl type) {
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeArrayDecl(type);
            return super.supertypeArrayDecl(type);
        }

    // Declared in AdditionalAST.jadd at line 173

        public boolean supertypeGLBType(GLBType type){
            if(initialWildcard instanceof WildcardSuperType)
                return initialWildcard.supertypeGLBType(type);
            return super.supertypeGLBType(type);
        }


}
