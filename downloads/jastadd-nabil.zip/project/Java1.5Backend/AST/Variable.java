
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;

  public interface Variable {
    // Declared in VariableDeclaration.jrag at line 3

    public String name();

    // Declared in VariableDeclaration.jrag at line 4

    public TypeDecl type();

    // Declared in VariableDeclaration.jrag at line 6

    // 4.5.3
    public boolean isClassVariable();

    // Declared in VariableDeclaration.jrag at line 7

    public boolean isInstanceVariable();

    // Declared in VariableDeclaration.jrag at line 8

    public boolean isMethodParameter();

    // Declared in VariableDeclaration.jrag at line 9

    public boolean isConstructorParameter();

    // Declared in VariableDeclaration.jrag at line 10

    public boolean isExceptionHandlerParameter();

    // Declared in VariableDeclaration.jrag at line 11

    public boolean isLocalVariable();

    // Declared in VariableDeclaration.jrag at line 13

    // 4.5.4
    public boolean isFinal();

    // Declared in VariableDeclaration.jrag at line 15


    public boolean isBlank();

    // Declared in VariableDeclaration.jrag at line 16

    public boolean isStatic();

    // Declared in VariableDeclaration.jrag at line 17

    public boolean isSynthetic();

    // Declared in VariableDeclaration.jrag at line 19


    public TypeDecl hostType();

    // Declared in VariableDeclaration.jrag at line 21


    public Expr getInit();

    // Declared in VariableDeclaration.jrag at line 22

    public boolean hasInit();

    // Declared in VariableDeclaration.jrag at line 24


    public Constant constant();

}
