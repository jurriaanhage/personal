
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;

    /*
     * Replace type variable in call with this.
     */
    public class VarTypeDecl extends ClassDecl {
    // Declared in AdditionalAST.jadd at line 6
        private TypeVariable typeVar;

    // Declared in AdditionalAST.jadd at line 7
        private VarTypeDecl capSuperTypeVar;

    // Declared in AdditionalAST.jadd at line 9

        public VarTypeDecl(TypeVariable var){
            this.typeVar = var;
            setSuperTypeVar();
        }

    // Declared in AdditionalAST.jadd at line 14

        private final void setSuperTypeVar() {
            for (int i = 0; i < originalTypeVariable().getNumTypeBound(); i++) {
                TypeDecl bound = originalTypeVariable().getTypeBound(i).type();
                if(bound instanceof TypeVariable){
                    capSuperTypeVar = (VarTypeDecl) bound.captureTypeVariables();
                    break;
                }
            }
        }

    // Declared in AdditionalAST.jadd at line 24

        public boolean hasSuperTypeVar(){
            return capSuperTypeVar != null;
        }

    // Declared in AdditionalAST.jadd at line 27
        public VarTypeDecl getSuperTypeVar() {
            return capSuperTypeVar;
        }

    // Declared in AdditionalAST.jadd at line 31
        
        public HashSet implementedInterfaces() {
            HashSet ifs = super.implementedInterfaces(); 
            if(hasSuperTypeVar()){
                ifs.addAll(getSuperTypeVar().implementedInterfaces());
            }
            return ifs;
        }

    // Declared in AdditionalAST.jadd at line 40

        // don't compile VarTypeDecl to a class file
        public void generateClassfile(){}

    // Declared in AdditionalAST.jadd at line 43

        // don't perform any type/name analysis on VarTypeDecl
        public void collectErrors(){}

    // Declared in AdditionalAST.jadd at line 46

        // get TypeVaraible that VarTypeDecl was based on.
        public TypeVariable originalTypeVariable(){
            return typeVar;
        }

    // Declared in AdditionalAST.jadd at line 50

        public String simpleName() {
            return typeVar.simpleName();    
        }

    // Declared in AdditionalAST.jadd at line 54

        public String shortName() {
            return typeVar.shortName();
        }


}
