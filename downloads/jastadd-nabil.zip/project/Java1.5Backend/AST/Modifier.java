
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;

public class Modifier extends ASTNode implements Cloneable {
    public void flushCache() {
        super.flushCache();
    }
    public Object clone() throws CloneNotSupportedException {
        Modifier node = (Modifier)super.clone();
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          Modifier node = (Modifier)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        Modifier res = (Modifier)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in PrettyPrint.jadd at line 569

     
  public void toString(StringBuffer s) {
    s.append(getID());
  }

    // Declared in java.ast at line 3
    // Declared in java.ast line 194

    public Modifier() {
        super();


    }

    // Declared in java.ast at line 10


    // Declared in java.ast line 194
    public Modifier(String p0) {
        setID(p0);
    }

    // Declared in java.ast at line 14


  protected int numChildren() {
    return 0;
  }

    // Declared in java.ast at line 17

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 194
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in PrettyPrint.jadd at line 920
    public String dumpString() {
        String dumpString_value = dumpString_compute();
        return dumpString_value;
    }

    private String dumpString_compute() {  return  getClass().getName() + " [" + getID() + "]";  }

    // Declared in AnnotationsCodegen.jrag at line 57
    public boolean isRuntimeVisible() {
        boolean isRuntimeVisible_value = isRuntimeVisible_compute();
        return isRuntimeVisible_value;
    }

    private boolean isRuntimeVisible_compute() {  return  false;  }

    // Declared in AnnotationsCodegen.jrag at line 67
    public boolean isRuntimeInvisible() {
        boolean isRuntimeInvisible_value = isRuntimeInvisible_compute();
        return isRuntimeInvisible_value;
    }

    private boolean isRuntimeInvisible_compute() {  return  false;  }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
