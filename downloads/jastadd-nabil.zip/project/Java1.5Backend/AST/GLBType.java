
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;
// vim: ft=javacc
//IntersectionTypeDecl : ClassDecl;
//VarTypeDecl : ClassDecl;
public class GLBType extends ReferenceType implements Cloneable {
    public void flushCache() {
        super.flushCache();
    }
    public Object clone() throws CloneNotSupportedException {
        GLBType node = (GLBType)super.clone();
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          GLBType node = (GLBType)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        GLBType res = (GLBType)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in GLBLookup.jrag at line 28


    public HashSet implementedInterfaces(){
        HashSet ret = new HashSet();
        for (int i = 0; i < getNumTypeBound(); i++) {
            ret.addAll(getTypeBound(i).type().implementedInterfaces());
        }
        return ret;
    }

    // Declared in inferrence.ast at line 3
    // Declared in inferrence.ast line 4

    public GLBType() {
        super();

        setChild(null, 0);
        setChild(new List(), 1);
        setChild(new List(), 2);

    }

    // Declared in inferrence.ast at line 13


    // Declared in inferrence.ast line 4
    public GLBType(Modifiers p0, String p1, List p2, List p3) {
        setChild(p0, 0);
        setID(p1);
        setChild(p2, 1);
        setChild(p3, 2);
    }

    // Declared in inferrence.ast at line 20


  protected int numChildren() {
    return 3;
  }

    // Declared in inferrence.ast at line 23

  public boolean mayHaveRewrite() { return false; }

    // Declared in inferrence.ast at line 2
    // Declared in inferrence.ast line 4
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in inferrence.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in inferrence.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in inferrence.ast at line 2
    // Declared in inferrence.ast line 4
    private String tokenString_ID;

    // Declared in inferrence.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in inferrence.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in inferrence.ast at line 2
    // Declared in inferrence.ast line 4
    public void setBodyDeclList(List list) {
        setChild(list, 1);
    }

    // Declared in inferrence.ast at line 6


    private int getNumBodyDecl = 0;

    // Declared in inferrence.ast at line 7

    public int getNumBodyDecl() {
        return getBodyDeclList().getNumChild();
    }

    // Declared in inferrence.ast at line 11


    public BodyDecl getBodyDecl(int i) {
        return (BodyDecl)getBodyDeclList().getChild(i);
    }

    // Declared in inferrence.ast at line 15


    public void addBodyDecl(BodyDecl node) {
        List list = getBodyDeclList();
        list.addChild(node);
    }

    // Declared in inferrence.ast at line 20


    public void setBodyDecl(BodyDecl node, int i) {
        List list = getBodyDeclList();
        list.setChild(node, i);
    }

    // Declared in inferrence.ast at line 24

    public List getBodyDeclList() {
        return (List)getChild(1);
    }

    // Declared in inferrence.ast at line 28


    public List getBodyDeclListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in inferrence.ast at line 2
    // Declared in inferrence.ast line 4
    public void setTypeBoundList(List list) {
        setChild(list, 2);
    }

    // Declared in inferrence.ast at line 6


    private int getNumTypeBound = 0;

    // Declared in inferrence.ast at line 7

    public int getNumTypeBound() {
        return getTypeBoundList().getNumChild();
    }

    // Declared in inferrence.ast at line 11


    public Access getTypeBound(int i) {
        return (Access)getTypeBoundList().getChild(i);
    }

    // Declared in inferrence.ast at line 15


    public void addTypeBound(Access node) {
        List list = getTypeBoundList();
        list.addChild(node);
    }

    // Declared in inferrence.ast at line 20


    public void setTypeBound(Access node, int i) {
        List list = getTypeBoundList();
        list.setChild(node, i);
    }

    // Declared in inferrence.ast at line 24

    public List getTypeBoundList() {
        return (List)getChild(2);
    }

    // Declared in inferrence.ast at line 28


    public List getTypeBoundListNoTransform() {
        return (List)getChildNoTransform(2);
    }

    protected java.util.Set subtype_TypeDecl_visited;
    protected java.util.Set subtype_TypeDecl_computed = new java.util.HashSet(4);
    protected java.util.Set subtype_TypeDecl_initialized = new java.util.HashSet(4);
    protected java.util.Map subtype_TypeDecl_values = new java.util.HashMap(4);
    public boolean subtype(TypeDecl type) {
        Object _parameters = type;
if(subtype_TypeDecl_visited == null) subtype_TypeDecl_visited = new java.util.HashSet(4);
if(subtype_TypeDecl_values == null) subtype_TypeDecl_values = new java.util.HashMap(4);
        if(subtype_TypeDecl_computed.contains(_parameters))
            return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
        if (!subtype_TypeDecl_initialized.contains(_parameters)) {
            subtype_TypeDecl_initialized.add(_parameters);
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            subtype_TypeDecl_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_subtype_TypeDecl_value;
            do {
                CHANGE = false;
                new_subtype_TypeDecl_value = subtype_compute(type);
                if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            } while (CHANGE);
            subtype_TypeDecl_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            subtype_TypeDecl_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            subtype_compute(type);
            RESET_CYCLE = false;
            subtype_TypeDecl_computed.remove(_parameters);
            subtype_TypeDecl_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_subtype_TypeDecl_value;
        }
        if(!subtype_TypeDecl_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                subtype_TypeDecl_computed.remove(_parameters);
                subtype_TypeDecl_initialized.remove(_parameters);
                return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
            }
            subtype_TypeDecl_visited.add(_parameters);
            boolean new_subtype_TypeDecl_value = subtype_compute(type);
            if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                CHANGE = true;
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            subtype_TypeDecl_visited.remove(_parameters);
            return new_subtype_TypeDecl_value;
        }
        return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
    }

    private boolean subtype_compute(TypeDecl type) {  return  type.supertypeGLBType(this);  }

    // Declared in GLBLookup.jrag at line 49
    public boolean supertypeGLBType(GLBType type) {
        boolean supertypeGLBType_GLBType_value = supertypeGLBType_compute(type);
        return supertypeGLBType_GLBType_value;
    }

    private boolean supertypeGLBType_compute(GLBType type) {
        return this == type;
    }

    // Declared in GLBLookup.jrag at line 61
    public boolean supertypeLUBType(LUBType type) {
        boolean supertypeLUBType_LUBType_value = supertypeLUBType_compute(type);
        return supertypeLUBType_LUBType_value;
    }

    private boolean supertypeLUBType_compute(LUBType type) {
        ArrayList bounds = new ArrayList(getNumTypeBound());
        for (int i = 0; i < getNumTypeBound(); i++) {
            bounds.add(getTypeBound(i));
        }
        return type == lookupLUBType(bounds);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
