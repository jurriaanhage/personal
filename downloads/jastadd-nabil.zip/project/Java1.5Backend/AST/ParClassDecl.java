
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


// parameterized type declarations
public class ParClassDecl extends ClassDecl implements Cloneable,  ParTypeDecl {
    public void flushCache() {
        super.flushCache();
        erasure_computed = false;
        erasure_value = null;
        getSuperClassAccessOpt_computed = false;
        getSuperClassAccessOpt_value = null;
        getImplementsList_computed = false;
        getImplementsList_value = null;
        getBodyDeclList_computed = false;
        getBodyDeclList_value = null;
        instanceOf_TypeDecl_values = null;
        typeDescriptor_computed = false;
        typeDescriptor_value = null;
        constantPoolName_computed = false;
        constantPoolName_value = null;
        needsSignatureAttribute_computed = false;
        sameSignature_ArrayList_values = null;
        sameSignature_ArrayList_computed = new java.util.HashSet(4);
        sameSignature_ArrayList_initialized = new java.util.HashSet(4);
        usesTypeVariable_computed = false;
        usesTypeVariable_initialized = false;
        localMethodsSignatureMap_computed = false;
        localMethodsSignatureMap_value = null;
        fields_String_values = null;
        memberTypes_String_values = null;
        constructors_computed = false;
        constructors_value = null;
        fullName_computed = false;
        fullName_value = null;
        typeName_computed = false;
        typeName_value = null;
        genericDecl_computed = false;
        genericDecl_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        ParClassDecl node = (ParClassDecl)super.clone();
        node.erasure_computed = false;
        node.erasure_value = null;
        node.getSuperClassAccessOpt_computed = false;
        node.getSuperClassAccessOpt_value = null;
        node.getImplementsList_computed = false;
        node.getImplementsList_value = null;
        node.getBodyDeclList_computed = false;
        node.getBodyDeclList_value = null;
        node.instanceOf_TypeDecl_values = null;
        node.typeDescriptor_computed = false;
        node.typeDescriptor_value = null;
        node.constantPoolName_computed = false;
        node.constantPoolName_value = null;
        node.needsSignatureAttribute_computed = false;
        node.sameSignature_ArrayList_values = null;
        node.sameSignature_ArrayList_computed = new java.util.HashSet(4);
        node.sameSignature_ArrayList_initialized = new java.util.HashSet(4);
        node.usesTypeVariable_computed = false;
        node.usesTypeVariable_initialized = false;
        node.localMethodsSignatureMap_computed = false;
        node.localMethodsSignatureMap_value = null;
        node.fields_String_values = null;
        node.memberTypes_String_values = null;
        node.constructors_computed = false;
        node.constructors_value = null;
        node.fullName_computed = false;
        node.fullName_value = null;
        node.typeName_computed = false;
        node.typeName_value = null;
        node.genericDecl_computed = false;
        node.genericDecl_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          ParClassDecl node = (ParClassDecl)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        ParClassDecl res = (ParClassDecl)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in Generics.jrag at line 428


  public void collectErrors() {
    // Disable error check for ParClassDecl which is an instanciated GenericClassDecl
  }

    // Declared in GenericsPrettyPrint.jrag at line 25


  public void toString(StringBuffer s) {
    /*
		getModifiers().toString(s);
		s.append("class " + getID());
		s.append('<');
  	if (getNumArgument() > 0) {
  		getArgument(0).toString(s);
  		for (int i = 1; i < getNumArgument(); i++) {
  			s.append(", ");
  			getArgument(i).toString(s);
   		}
   	}
   	s.append('>');
		if(hasSuperClassAccess()) {
			s.append(" extends ");
			getSuperClassAccess().toString(s);
		}
		if(getNumImplements() > 0) {
			s.append(" implements ");
			getImplements(0).toString(s);
			for(int i = 1; i < getNumImplements(); i++) {
				s.append(", ");
				getImplements(i).toString(s);
			}
		}
		s.append(" {\n");
		indent++;
		for(int i=0; i < getNumBodyDecl(); i++) {
			getBodyDecl(i).toString(s);
		}
		indent--;
		s.append(indent() + "}\n");
    */
  }

    // Declared in ConstructorLookUp.jadd at line 120

    public Collection genericConstructors() {
        //return genericTypeDecl().constructors();        
        return genericDecl().constructors();        
    }

    // Declared in GenericNamesAndTypes.jrag at line 53

    private boolean visited = false;

    // Declared in GenericNamesAndTypes.jrag at line 490


    public TypeDecl replaceAllTypes(TypeDecl type, Collection posLists) {
        // get the generic class
        GenericClassDecl gcd = (GenericClassDecl) genericDecl();
        // create a new parameterized interface
        ParClassDecl pcd = new ParClassDecl();
        pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
        pcd.setID(gcd.getID());
        // create a list of type arguments.
        List argList = new List();
        Set replacedArgs = new HashSet();
        for (Iterator iter = posLists.iterator(); iter.hasNext();) {
            java.util.List posList = (java.util.List) iter.next();
            int i = (Integer) posList.get(0);
            if (i < getNumArgument()) {
                TypeDecl fstArg = getArgument(i).type();
                if (fstArg instanceof ParTypeDecl) {
                    posList.remove(0);
                    argList.add(fstArg.replaceSingleType(type, posList)
                            .createBoundAccess());
                } else {
                    argList.add(type.createBoundAccess());
                }
            }
            replacedArgs.add(i);
        }
        for (int i = 0; i < getNumArgument(); i++)
            if (!replacedArgs.contains(i))
                argList.insertChild(getArgument(i), i);

        pcd.setArgumentList(argList);
        // add the parameterized class to the generic parent
        gcd.addParTypeDecl(pcd);

        return pcd;
    }

    // Declared in GenericNamesAndTypes.jrag at line 526


    public TypeDecl replaceSingleType(TypeDecl type, java.util.List posList) {
        if (posList.isEmpty()) {
            return this;
        } else {
            GenericClassDecl gcd = (GenericClassDecl) genericDecl();
            // create a new parameterized interface
            ParClassDecl pcd = new ParClassDecl();
            pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
            pcd.setID(gcd.getID());
            // create a list of type arguments.
            List argList = new List();
            int i = (Integer) posList.get(0);
            for (int j = 0; j < getNumArgument(); j++) {
                if (j == i) {
                    TypeDecl fstArg = getArgument(i).type();
                    if (fstArg instanceof ParTypeDecl) {
                        posList.remove(0);
                        argList.add(fstArg.replaceSingleType(type, posList)
                                .createBoundAccess());
                    } else {
                        argList.add(type.createBoundAccess());
                    }
                } else {
                    argList.add(getArgument(j));
                }
            }
            pcd.setArgumentList(argList);
            // add the parameterized interface to the generic parent
            gcd.addParTypeDecl(pcd);
            return pcd;
        }
    }

    // Declared in WildcardsHeuristics.jrag at line 6


    public TypeDecl flipAllWildcards(final Class heur) {
        List bounds = new List();
        for (int i = 0; i < getNumArgument(); i++) {
            TypeDecl bound = getArgument(i).type().flipAllWildcards(heur);            
            bounds.add(bound.createBoundAccess());            
        }    
        
        // get the generic class
        //GenericClassDecl gcd = (GenericClassDecl) genericTypeDecl();
        GenericClassDecl gcd = (GenericClassDecl) genericDecl();
        // create an new paramterized class
        ParClassDecl pcd = new ParClassDecl();
        pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
        pcd.setID(gcd.getID());
        // create a list of arguments
        pcd.setArgumentList(bounds);
        // add the paramterized class to the genreic parent
        gcd.addParTypeDecl(pcd);

        return pcd;
    }

    // Declared in Generics.ast at line 3
    // Declared in Generics.ast line 6

    public ParClassDecl() {
        super();
        setChild(new Opt(), 0);
        setChild(null, 1);
        setChild(null, 2);

        setChild(null, 0);
        setChild(new List(), 1);
        setChild(new Opt(), 2);
        setChild(new List(), 3);
        setChild(new List(), 4);

    }

    // Declared in Generics.ast at line 18


    // Declared in Generics.ast line 6
    public ParClassDecl(Modifiers p0, String p1, List p2) {
        setChild(p0, 0);
        setID(p1);
        setChild(p2, 1);
        setChild(new Opt(), 2);
        setChild(new List(), 3);
        setChild(new List(), 4);
    }

    // Declared in Generics.ast at line 27


  protected int numChildren() {
    return 2;
  }

    // Declared in Generics.ast at line 30

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 63
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in java.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in java.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 63
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 6
    public void setArgumentList(List list) {
        setChild(list, 1);
    }

    // Declared in Generics.ast at line 6


    private int getNumArgument = 0;

    // Declared in Generics.ast at line 7

    public int getNumArgument() {
        return getArgumentList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public Access getArgument(int i) {
        return (Access)getArgumentList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addArgument(Access node) {
        List list = getArgumentList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setArgument(Access node, int i) {
        List list = getArgumentList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getArgumentList() {
        return (List)getChild(1);
    }

    // Declared in Generics.ast at line 28


    public List getArgumentListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 6
    public void setSuperClassAccessOpt(Opt opt) {
        setChild(opt, 2);
    }

    // Declared in Generics.ast at line 6


    public boolean hasSuperClassAccess() {
        return getSuperClassAccessOpt().getNumChild() != 0;
    }

    // Declared in Generics.ast at line 10


    public Access getSuperClassAccess() {
        return (Access)getSuperClassAccessOpt().getChild(0);
    }

    // Declared in Generics.ast at line 14


    public void setSuperClassAccess(Access node) {
        getSuperClassAccessOpt().setChild(node, 0);
    }

    // Declared in Generics.ast at line 17

    public Opt getSuperClassAccessOptNoTransform() {
        return (Opt)getChildNoTransform(2);
    }

    // Declared in Generics.ast at line 21


    protected int getSuperClassAccessOptChildPosition() {
        return 2;
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 6
    public void setImplementsList(List list) {
        setChild(list, 3);
    }

    // Declared in Generics.ast at line 6


    private int getNumImplements = 0;

    // Declared in Generics.ast at line 7

    public int getNumImplements() {
        return getImplementsList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public Access getImplements(int i) {
        return (Access)getImplementsList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addImplements(Access node) {
        List list = getImplementsList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setImplements(Access node, int i) {
        List list = getImplementsList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getImplementsListNoTransform() {
        return (List)getChildNoTransform(3);
    }

    // Declared in Generics.ast at line 28


    protected int getImplementsListChildPosition() {
        return 3;
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 6
    public void setBodyDeclList(List list) {
        setChild(list, 4);
    }

    // Declared in Generics.ast at line 6


    private int getNumBodyDecl = 0;

    // Declared in Generics.ast at line 7

    public int getNumBodyDecl() {
        return getBodyDeclList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public BodyDecl getBodyDecl(int i) {
        return (BodyDecl)getBodyDeclList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addBodyDecl(BodyDecl node) {
        List list = getBodyDeclList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setBodyDecl(BodyDecl node, int i) {
        List list = getBodyDeclList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getBodyDeclListNoTransform() {
        return (List)getChildNoTransform(4);
    }

    // Declared in Generics.ast at line 28


    protected int getBodyDeclListChildPosition() {
        return 4;
    }

    // Declared in Generics.jrag at line 585

  public TypeDecl substitute(TypeVariable typeVariable) {
    for(int i = 0; i < numTypeParameter(); i++)
      if(typeParameter(i) == typeVariable)
        return getArgument(i).type();
    return super.substitute(typeVariable);
  }

    // Declared in Generics.jrag at line 598


  public int numTypeParameter() {
    return ((GenericTypeDecl)genericDecl().original()).getNumTypeParameter(); 
  }

    // Declared in Generics.jrag at line 601

  public TypeVariable typeParameter(int index) {
    return ((GenericTypeDecl)genericDecl().original()).getTypeParameter(index);
  }

    // Declared in Generics.jrag at line 626

  public Access substitute(Parameterization parTypeDecl) {
    if(parTypeDecl.isRawType())
      return ((GenericTypeDecl)genericDecl()).rawType().createBoundAccess();
      //return erasure().createBoundAccess();
    if(!usesTypeVariable())
      return super.substitute(parTypeDecl);
    List list = new List();
    for(int i = 0; i < getNumArgument(); i++)
      list.add(getArgument(i).type().substitute(parTypeDecl));
    return new ParTypeAccess(genericDecl().createQualifiedAccess(), list);
  }

    // Declared in GenericsParTypeDecl.jrag at line 76

  
  public Access createQualifiedAccess() {
    List typeArgumentList = (List)getArgumentList().fullCopy();
    if(!isTopLevelType()) {
      return enclosingType().createQualifiedAccess().qualifiesAccess(
        new ParTypeAccess(new TypeAccess("", getID()), typeArgumentList)
      );
    }
    else {
      return new ParTypeAccess(new TypeAccess(packageName(), getID()), typeArgumentList);
    }
  }

    // Declared in GenericsCodegen.jrag at line 322


  public void transformation() {
  }

    // Declared in GenericNamesAndTypes.jrag at line 178


    public String nameWithFlippedWildcards(final Class heur) {
        StringBuilder s = new StringBuilder();
        s.append(name());
        s.append("<");
        for (int i = 0; i < getNumArgument(); i++) {
            if (i != 0)
                s.append(", ");
            s.append(getArgument(i).type().nameWithFlippedWildcards(heur));
        }
        s.append(">");
        return s.toString();
    }

    // Declared in SuperObjectHeuristic.jrag at line 44

    
    public boolean containedIn(ParTypeDecl type, ArrayList indices, ArrayList excList) 
    {
        if (type.genericDecl() == genericDecl()
                && type.getNumArgument() == getNumArgument()) {
            for (int i = 0; i < getNumArgument(); i++) {
                if (!type.getArgument(i).type()
                        .matchingTypeArgument(getArgument(i).type())) {
                    
                    if (excList == null || !excList.contains(i))
                        indices.add(i);
                }
            }
            return true;
        }
        return false;
    }

    // Declared in TypeVariableSubstitution.jrag at line 54


    /**
     * Create new argument list for a ParTypeDecl
     * @param a
     * @return
     */
    public List createNewArgumentList()
    {
        List bounds = new List();
        for (int i = 0; i < getNumArgument(); i++) {
            TypeDecl bound = getArgument(i).type();
            if(bound instanceof TypeVariable || bound instanceof ParTypeDecl 
                || bound instanceof AbstractWildcardType )
            {
                bounds.add(bound.captureTypeVariables().createBoundAccess());
            }
            else {            
                // add this to the list
                bounds.add(getArgument(i));
            }
        }
        return bounds;
    }

    // Declared in TypeVariableSubstitution.jrag at line 219


    public AST.List createNewArgumentList(Map subst,boolean useHole) 
    {
        AST.List argList = new AST.List();
        for (int i = 0; i < getNumArgument(); i++) {
            TypeDecl typeArg = getArgument(i).type();
            // if typeArg is a type var then use it's inferred type.
            if (typeArg instanceof TypeVariable) {
                if (subst.containsKey(typeArg))
                    argList.add(((TypeDecl)subst.get(typeArg)).createBoundAccess());
                else if(useHole)
                    argList.add(holeType().createBoundAccess());
                else
                    argList.add(getArgument(i));
            }
            // if typeArg is a param type then replace it with a new param type
            // where type vars are replaced with thier inffered type
            //else if (typeArg.isParameterizedType()) {
            else{
                //TypeDecl new_typeArg = typeArg.instantiateParType(subst);
                //argList.add(new_typeArg.createBoundAccess());
                argList.add(typeArg.instantiateParType(subst, useHole).createBoundAccess());
            }
        }
        return argList;
    }

    protected boolean involvesTypeParameters_visited = false;
    protected boolean involvesTypeParameters_computed = false;
    protected boolean involvesTypeParameters_initialized = false;
    protected boolean involvesTypeParameters_value;
    public boolean involvesTypeParameters() {
        if(involvesTypeParameters_computed)
            return involvesTypeParameters_value;
        if (!involvesTypeParameters_initialized) {
            involvesTypeParameters_initialized = true;
            involvesTypeParameters_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            involvesTypeParameters_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
                if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                    CHANGE = true;
                involvesTypeParameters_value = new_involvesTypeParameters_value; 
            } while (CHANGE);
            involvesTypeParameters_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            involvesTypeParameters_computed = true;
            }
            else {
            RESET_CYCLE = true;
            involvesTypeParameters_compute();
            RESET_CYCLE = false;
              involvesTypeParameters_computed = false;
              involvesTypeParameters_initialized = false;
            }
            IN_CIRCLE = false; 
            return involvesTypeParameters_value;
        }
        if(!involvesTypeParameters_visited) {
            if (RESET_CYCLE) {
                involvesTypeParameters_computed = false;
                involvesTypeParameters_initialized = false;
                return involvesTypeParameters_value;
            }
            involvesTypeParameters_visited = true;
            boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
            if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                CHANGE = true;
            involvesTypeParameters_value = new_involvesTypeParameters_value; 
            involvesTypeParameters_visited = false;
            return involvesTypeParameters_value;
        }
        return involvesTypeParameters_value;
    }

    private boolean involvesTypeParameters_compute()  {
    for(int i = 0; i < getNumArgument(); i++)
      if(getArgument(i).type().involvesTypeParameters())
        return true;
    return false;
  }

    // Declared in Generics.jrag at line 75
    public TypeDecl topLevelType() {
        TypeDecl topLevelType_value = topLevelType_compute();
        return topLevelType_value;
    }

    private TypeDecl topLevelType_compute() {  return  erasure().topLevelType();  }

    // Declared in Generics.jrag at line 173
    public boolean isRawType() {
        boolean isRawType_value = isRawType_compute();
        return isRawType_value;
    }

    private boolean isRawType_compute() {  return  false;  }

    // Declared in Generics.jrag at line 233
    public TypeDecl erasure() {
        if(erasure_computed)
            return erasure_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        erasure_value = erasure_compute();
        if(isFinal && num == boundariesCrossed)
            erasure_computed = true;
        return erasure_value;
    }

    private TypeDecl erasure_compute() {  return  genericDecl();  }

    protected boolean getSuperClassAccessOpt_computed = false;
    protected Opt getSuperClassAccessOpt_value;
    // Declared in Generics.jrag at line 751
    public Opt getSuperClassAccessOpt() {
        if(getSuperClassAccessOpt_computed)
            return (Opt)ASTNode.getChild(this, getSuperClassAccessOptChildPosition());
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getSuperClassAccessOpt_value = getSuperClassAccessOpt_compute();
        setSuperClassAccessOpt(getSuperClassAccessOpt_value);
        if(isFinal && num == boundariesCrossed)
            getSuperClassAccessOpt_computed = true;
        return (Opt)ASTNode.getChild(this, getSuperClassAccessOptChildPosition());
    }

    private Opt getSuperClassAccessOpt_compute()  {
    GenericClassDecl decl = (GenericClassDecl)genericDecl();
    Opt opt;
    //System.err.println("Begin substituting extends clause");
    if(decl.hasSuperClassAccess())
      opt = new Opt((decl.getSuperClassAccess().type().substitute(this)));
    else
      opt = new Opt();
    //System.err.println("End substituting extends clause");
    return opt;
  }

    protected boolean getImplementsList_computed = false;
    protected List getImplementsList_value;
    // Declared in Generics.jrag at line 762
    public List getImplementsList() {
        if(getImplementsList_computed)
            return (List)ASTNode.getChild(this, getImplementsListChildPosition());
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getImplementsList_value = getImplementsList_compute();
        setImplementsList(getImplementsList_value);
        if(isFinal && num == boundariesCrossed)
            getImplementsList_computed = true;
        return (List)ASTNode.getChild(this, getImplementsListChildPosition());
    }

    private List getImplementsList_compute()  {
    GenericClassDecl decl = (GenericClassDecl)genericDecl();
    //System.err.println("Begin substituting implements list");
    List list = decl.getImplementsList().substitute(this);
    //System.err.println("End substituting implements list");
    return list;
  }

    protected boolean getBodyDeclList_computed = false;
    protected List getBodyDeclList_value;
    // Declared in Generics.jrag at line 769
    public List getBodyDeclList() {
        if(getBodyDeclList_computed)
            return (List)ASTNode.getChild(this, getBodyDeclListChildPosition());
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getBodyDeclList_value = getBodyDeclList_compute();
        setBodyDeclList(getBodyDeclList_value);
        if(isFinal && num == boundariesCrossed)
            getBodyDeclList_computed = true;
        return (List)ASTNode.getChild(this, getBodyDeclListChildPosition());
    }

    private List getBodyDeclList_compute() {  return  new List();  }

    // Declared in GenericsParTypeDecl.jrag at line 63
    public boolean isTypeVariable() {
        boolean isTypeVariable_value = isTypeVariable_compute();
        return isTypeVariable_value;
    }

    private boolean isTypeVariable_compute()  {
    for(int i = 0; i < getNumArgument(); i++)
      if(getArgument(i).type().isTypeVariable())
        return true;
    return false;
  }

    // Declared in GenericsSubtype.jrag at line 25
    public boolean supertypeGenericClassDecl(GenericClassDecl type) {
        boolean supertypeGenericClassDecl_GenericClassDecl_value = supertypeGenericClassDecl_compute(type);
        return supertypeGenericClassDecl_GenericClassDecl_value;
    }

    private boolean supertypeGenericClassDecl_compute(GenericClassDecl type) {  return 
    type.subtype(genericDecl());  }

    // Declared in GenericsSubtype.jrag at line 96
    public boolean supertypeClassDecl(ClassDecl type) {
        boolean supertypeClassDecl_ClassDecl_value = supertypeClassDecl_compute(type);
        return supertypeClassDecl_ClassDecl_value;
    }

    private boolean supertypeClassDecl_compute(ClassDecl type) {  return 
    super.supertypeClassDecl(type);  }

    protected java.util.Set subtype_TypeDecl_visited;
    protected java.util.Set subtype_TypeDecl_computed = new java.util.HashSet(4);
    protected java.util.Set subtype_TypeDecl_initialized = new java.util.HashSet(4);
    protected java.util.Map subtype_TypeDecl_values = new java.util.HashMap(4);
    public boolean subtype(TypeDecl type) {
        Object _parameters = type;
if(subtype_TypeDecl_visited == null) subtype_TypeDecl_visited = new java.util.HashSet(4);
if(subtype_TypeDecl_values == null) subtype_TypeDecl_values = new java.util.HashMap(4);
        if(subtype_TypeDecl_computed.contains(_parameters))
            return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
        if (!subtype_TypeDecl_initialized.contains(_parameters)) {
            subtype_TypeDecl_initialized.add(_parameters);
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            subtype_TypeDecl_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_subtype_TypeDecl_value;
            do {
                CHANGE = false;
                new_subtype_TypeDecl_value = subtype_compute(type);
                if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            } while (CHANGE);
            subtype_TypeDecl_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            subtype_TypeDecl_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            subtype_compute(type);
            RESET_CYCLE = false;
            subtype_TypeDecl_computed.remove(_parameters);
            subtype_TypeDecl_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_subtype_TypeDecl_value;
        }
        if(!subtype_TypeDecl_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                subtype_TypeDecl_computed.remove(_parameters);
                subtype_TypeDecl_initialized.remove(_parameters);
                return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
            }
            subtype_TypeDecl_visited.add(_parameters);
            boolean new_subtype_TypeDecl_value = subtype_compute(type);
            if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                CHANGE = true;
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            subtype_TypeDecl_visited.remove(_parameters);
            return new_subtype_TypeDecl_value;
        }
        return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
    }

    private boolean subtype_compute(TypeDecl type) {  return  type.supertypeParClassDecl(this);  }

    // Declared in GenericsSubtype.jrag at line 123
    public boolean supertypeRawClassDecl(RawClassDecl type) {
        boolean supertypeRawClassDecl_RawClassDecl_value = supertypeRawClassDecl_compute(type);
        return supertypeRawClassDecl_RawClassDecl_value;
    }

    private boolean supertypeRawClassDecl_compute(RawClassDecl type) {  return 
    type.genericDecl().subtype(genericDecl());  }

    // Declared in GenericsSubtype.jrag at line 125
    public boolean supertypeRawInterfaceDecl(RawInterfaceDecl type) {
        boolean supertypeRawInterfaceDecl_RawInterfaceDecl_value = supertypeRawInterfaceDecl_compute(type);
        return supertypeRawInterfaceDecl_RawInterfaceDecl_value;
    }

    private boolean supertypeRawInterfaceDecl_compute(RawInterfaceDecl type) {  return 
    type.genericDecl().subtype(genericDecl());  }

    // Declared in GenericsSubtype.jrag at line 136
    public boolean supertypeParClassDecl(ParClassDecl type) {
        boolean supertypeParClassDecl_ParClassDecl_value = supertypeParClassDecl_compute(type);
        return supertypeParClassDecl_ParClassDecl_value;
    }

    private boolean supertypeParClassDecl_compute(ParClassDecl type)  {
    if(type.genericDecl() == genericDecl() &&
       type.getNumArgument() == getNumArgument()) {
      for(int i = 0; i < getNumArgument(); i++)
        if(!getArgument(i).type().matchingTypeArgument(type.getArgument(i).type()))
          return false;
      return true;
    }
    return supertypeClassDecl(type);
  }

    // Declared in GenericsSubtype.jrag at line 146
    public boolean supertypeParInterfaceDecl(ParInterfaceDecl type) {
        boolean supertypeParInterfaceDecl_ParInterfaceDecl_value = supertypeParInterfaceDecl_compute(type);
        return supertypeParInterfaceDecl_ParInterfaceDecl_value;
    }

    private boolean supertypeParInterfaceDecl_compute(ParInterfaceDecl type) {  return  false;  }

    // Declared in GenericsSubtype.jrag at line 246
    public boolean instanceOf(TypeDecl type) {
        Object _parameters = type;
if(instanceOf_TypeDecl_values == null) instanceOf_TypeDecl_values = new java.util.HashMap(4);
        if(instanceOf_TypeDecl_values.containsKey(_parameters))
            return ((Boolean)instanceOf_TypeDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean instanceOf_TypeDecl_value = instanceOf_compute(type);
        if(isFinal && num == boundariesCrossed)
            instanceOf_TypeDecl_values.put(_parameters, Boolean.valueOf(instanceOf_TypeDecl_value));
        return instanceOf_TypeDecl_value;
    }

    private boolean instanceOf_compute(TypeDecl type) {  return  subtype(type);  }

    // Declared in GenericsCodegen.jrag at line 5
    public String typeDescriptor() {
        if(typeDescriptor_computed)
            return typeDescriptor_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        typeDescriptor_value = typeDescriptor_compute();
        if(isFinal && num == boundariesCrossed)
            typeDescriptor_computed = true;
        return typeDescriptor_value;
    }

    private String typeDescriptor_compute() {  return  erasure().typeDescriptor();  }

    // Declared in GenericsCodegen.jrag at line 19
    public String arrayTypeDescriptor() {
        String arrayTypeDescriptor_value = arrayTypeDescriptor_compute();
        return arrayTypeDescriptor_value;
    }

    private String arrayTypeDescriptor_compute() {  return  erasure().arrayTypeDescriptor();  }

    // Declared in GenericsCodegen.jrag at line 154
    public String constantPoolName() {
        if(constantPoolName_computed)
            return constantPoolName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        constantPoolName_value = constantPoolName_compute();
        if(isFinal && num == boundariesCrossed)
            constantPoolName_computed = true;
        return constantPoolName_value;
    }

    private String constantPoolName_compute() {  return  genericDecl().constantPoolName();  }

    // Declared in GenericsCodegen.jrag at line 364
    public boolean needsSignatureAttribute() {
        if(needsSignatureAttribute_computed)
            return needsSignatureAttribute_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        needsSignatureAttribute_value = needsSignatureAttribute_compute();
        if(isFinal && num == boundariesCrossed)
            needsSignatureAttribute_computed = true;
        return needsSignatureAttribute_value;
    }

    private boolean needsSignatureAttribute_compute() {  return  true;  }

    // Declared in ParSubtyping.jrag at line 17
    public boolean parSubtype(TypeDecl type) {
        boolean parSubtype_TypeDecl_value = parSubtype_compute(type);
        return parSubtype_TypeDecl_value;
    }

    private boolean parSubtype_compute(TypeDecl type) {  return  type.parSuperTypeParClass(this);  }

    // Declared in ParSubtyping.jrag at line 33
    public boolean parSuperTypeParClass(ParClassDecl type) {
        boolean parSuperTypeParClass_ParClassDecl_value = parSuperTypeParClass_compute(type);
        return parSuperTypeParClass_ParClassDecl_value;
    }

    private boolean parSuperTypeParClass_compute(ParClassDecl type) {
        if(genericDecl() == type.genericDecl()){
            for(int i = 0; i < getNumArgument(); i++)
                if(!getArgument(i).type().parContains(type.getArgument(i).type()))
                    return false;
            return true;
        }
        return parSuperClassDecl(type);
    }

    // Declared in ParSubtyping.jrag at line 58
    public boolean parSuperClassDecl(ClassDecl type) {
        boolean parSuperClassDecl_ClassDecl_value = parSuperClassDecl_compute(type);
        return parSuperClassDecl_ClassDecl_value;
    }

    private boolean parSuperClassDecl_compute(ClassDecl type)  {         
        return type.hasSuperclass() && 
                type.superclass() != null && 
                type.superclass().parSubtype(this);
    }

/**
     * Replace type variables with a new type. This is somewhat similar to wildcard capture.
     * @return
     
    Declared in TypeVariableSubstitution.jrag at line 29
*/
    public TypeDecl captureTypeVariables() {
        TypeDecl captureTypeVariables_value = captureTypeVariables_compute();
        return captureTypeVariables_value;
    }

    private TypeDecl captureTypeVariables_compute() {
        //if(getTypeVariables().isEmpty()) 
        if(!involvesTypeParameters())
            return this;
        // get the generic class
        //GenericClassDecl gcd = (GenericClassDecl) genericTypeDecl();
        GenericClassDecl gcd = (GenericClassDecl) genericDecl();
        // create an new paramterized class
        ParClassDecl pcd = new ParClassDecl();
        // set modifiers
        pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
        // set name
        pcd.setID(gcd.getID());
        // create a list of arguments
        pcd.setArgumentList(createNewArgumentList());
        // add the paramterized class to the genreic parent
        gcd.addParTypeDecl(pcd);
        return pcd;
    }

/**
     * Substitute type variables with types given in subst (Map<TypeVariable, TypeDecl>)
     
    Declared in TypeVariableSubstitution.jrag at line 155
*/
    public TypeDecl instantiateParType(Map subst, boolean useHole) {
        TypeDecl instantiateParType_Map_boolean_value = instantiateParType_compute(subst, useHole);
        return instantiateParType_Map_boolean_value;
    }

    private TypeDecl instantiateParType_compute(Map subst, boolean useHole) {
        // Already instantiated
        if (!involvesTypeParameters())
            return this;
        // get the generic class
        //GenericClassDecl gcd = (GenericClassDecl) genericTypeDecl();
        GenericClassDecl gcd = (GenericClassDecl) genericDecl();
        // create an new paramterized class
        ParClassDecl pcd = new ParClassDecl();
        pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
        pcd.setID(gcd.getID());
        // create a list of arguments
        pcd.setArgumentList(createNewArgumentList(subst, useHole));
        // add the paramterized class to the genreic parent
        gcd.addParTypeDecl(pcd);

        return pcd;
    }

    // Declared in WildcardsHeuristics.jrag at line 138
    public TypeDecl typeWithFlippedWilds(Class heur) {
        TypeDecl typeWithFlippedWilds_Class_value = typeWithFlippedWilds_compute(heur);
        return typeWithFlippedWilds_Class_value;
    }

    private TypeDecl typeWithFlippedWilds_compute(Class heur) {
        List bounds = new List();
        for (int i = 0; i < getNumArgument(); i++) {
            bounds.add(getArgument(i).typeWithFlippedWilds(heur));      
        }    
        
        // get the generic class
        GenericClassDecl gcd = (GenericClassDecl) genericDecl();
        // create an new paramterized class
        ParClassDecl pcd = new ParClassDecl();
        pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
        pcd.setID(gcd.getID());
        // create a list of arguments
        pcd.setArgumentList(bounds);
        // add the paramterized class to the genreic parent
        gcd.addParTypeDecl(pcd);

        return pcd;
    }

    // Declared in Generics.jrag at line 170
    public boolean isParameterizedType() {
        boolean isParameterizedType_value = isParameterizedType_compute();
        return isParameterizedType_value;
    }

    private boolean isParameterizedType_compute() {  return  true;  }

    // Declared in Generics.jrag at line 263
    public boolean sameArgument(ParTypeDecl decl) {
        boolean sameArgument_ParTypeDecl_value = sameArgument_compute(decl);
        return sameArgument_ParTypeDecl_value;
    }

    private boolean sameArgument_compute(ParTypeDecl decl)  {
    if(this == decl) return true;
    if(genericDecl() != decl.genericDecl())
      return false;
    for(int i = 0; i < getNumArgument(); i++) {
      TypeDecl t1 = getArgument(i).type();
      TypeDecl t2 = decl.getArgument(i).type();
      if(t1 instanceof ParTypeDecl && t2 instanceof ParTypeDecl) {
        if(!((ParTypeDecl)t1).sameArgument((ParTypeDecl)t2))
          return false;
      }
      else {
        if(t1 != t2)
          return false;
      }
    }
    return true;
  }

    // Declared in Generics.jrag at line 451
    public boolean sameSignature(Access a) {
        boolean sameSignature_Access_value = sameSignature_compute(a);
        return sameSignature_Access_value;
    }

    private boolean sameSignature_compute(Access a) {
    if(a instanceof ParTypeAccess) {
      ParTypeAccess ta = (ParTypeAccess)a;
      if(genericDecl() != ta.genericDecl())
        return false;
      if(getNumArgument() != ta.getNumTypeArgument())
        return false;
      for(int i = 0; i < getNumArgument(); i++)
        if(!getArgument(i).type().sameSignature(ta.getTypeArgument(i)))
          return false;
      return true;
    }
    else if(a instanceof TypeAccess && ((TypeAccess)a).isRaw())
      return false;
    return super.sameSignature(a);
  }

    protected java.util.Set sameSignature_ArrayList_visited;
    protected java.util.Set sameSignature_ArrayList_computed = new java.util.HashSet(4);
    protected java.util.Set sameSignature_ArrayList_initialized = new java.util.HashSet(4);
    protected java.util.Map sameSignature_ArrayList_values = new java.util.HashMap(4);
    public boolean sameSignature(ArrayList list) {
        Object _parameters = list;
if(sameSignature_ArrayList_visited == null) sameSignature_ArrayList_visited = new java.util.HashSet(4);
if(sameSignature_ArrayList_values == null) sameSignature_ArrayList_values = new java.util.HashMap(4);
        if(sameSignature_ArrayList_computed.contains(_parameters))
            return ((Boolean)sameSignature_ArrayList_values.get(_parameters)).booleanValue();
        if (!sameSignature_ArrayList_initialized.contains(_parameters)) {
            sameSignature_ArrayList_initialized.add(_parameters);
            sameSignature_ArrayList_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            sameSignature_ArrayList_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_sameSignature_ArrayList_value;
            do {
                CHANGE = false;
                new_sameSignature_ArrayList_value = sameSignature_compute(list);
                if (new_sameSignature_ArrayList_value!=((Boolean)sameSignature_ArrayList_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                sameSignature_ArrayList_values.put(_parameters, Boolean.valueOf(new_sameSignature_ArrayList_value));
            } while (CHANGE);
            sameSignature_ArrayList_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            sameSignature_ArrayList_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            sameSignature_compute(list);
            RESET_CYCLE = false;
            sameSignature_ArrayList_computed.remove(_parameters);
            sameSignature_ArrayList_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_sameSignature_ArrayList_value;
        }
        if(!sameSignature_ArrayList_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                sameSignature_ArrayList_computed.remove(_parameters);
                sameSignature_ArrayList_initialized.remove(_parameters);
                return ((Boolean)sameSignature_ArrayList_values.get(_parameters)).booleanValue();
            }
            sameSignature_ArrayList_visited.add(_parameters);
            boolean new_sameSignature_ArrayList_value = sameSignature_compute(list);
            if (new_sameSignature_ArrayList_value!=((Boolean)sameSignature_ArrayList_values.get(_parameters)).booleanValue())
                CHANGE = true;
            sameSignature_ArrayList_values.put(_parameters, Boolean.valueOf(new_sameSignature_ArrayList_value));
            sameSignature_ArrayList_visited.remove(_parameters);
            return new_sameSignature_ArrayList_value;
        }
        return ((Boolean)sameSignature_ArrayList_values.get(_parameters)).booleanValue();
    }

    private boolean sameSignature_compute(ArrayList list)  {
    if(getNumArgument() != list.size())
      return false;
    for(int i = 0; i < list.size(); i++)
      if(getArgument(i).type() != list.get(i))
        return false;
    return true;
  }

    protected boolean usesTypeVariable_visited = false;
    protected boolean usesTypeVariable_computed = false;
    protected boolean usesTypeVariable_initialized = false;
    protected boolean usesTypeVariable_value;
    public boolean usesTypeVariable() {
        if(usesTypeVariable_computed)
            return usesTypeVariable_value;
        if (!usesTypeVariable_initialized) {
            usesTypeVariable_initialized = true;
            usesTypeVariable_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            usesTypeVariable_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_usesTypeVariable_value = usesTypeVariable_compute();
                if (new_usesTypeVariable_value!=usesTypeVariable_value)
                    CHANGE = true;
                usesTypeVariable_value = new_usesTypeVariable_value; 
            } while (CHANGE);
            usesTypeVariable_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            usesTypeVariable_computed = true;
            }
            else {
            RESET_CYCLE = true;
            usesTypeVariable_compute();
            RESET_CYCLE = false;
              usesTypeVariable_computed = false;
              usesTypeVariable_initialized = false;
            }
            IN_CIRCLE = false; 
            return usesTypeVariable_value;
        }
        if(!usesTypeVariable_visited) {
            if (RESET_CYCLE) {
                usesTypeVariable_computed = false;
                usesTypeVariable_initialized = false;
                return usesTypeVariable_value;
            }
            usesTypeVariable_visited = true;
            boolean new_usesTypeVariable_value = usesTypeVariable_compute();
            if (new_usesTypeVariable_value!=usesTypeVariable_value)
                CHANGE = true;
            usesTypeVariable_value = new_usesTypeVariable_value; 
            usesTypeVariable_visited = false;
            return usesTypeVariable_value;
        }
        return usesTypeVariable_value;
    }

    private boolean usesTypeVariable_compute()  {
    for(int i = 0; i < getNumArgument(); i++)
      if(getArgument(i).type().usesTypeVariable())
        return true;
    return false;
  }

    // Declared in Generics.jrag at line 803
    public HashMap localMethodsSignatureMap() {
        if(localMethodsSignatureMap_computed)
            return localMethodsSignatureMap_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        localMethodsSignatureMap_value = localMethodsSignatureMap_compute();
        if(isFinal && num == boundariesCrossed)
            localMethodsSignatureMap_computed = true;
        return localMethodsSignatureMap_value;
    }

    private HashMap localMethodsSignatureMap_compute()  {
    HashMap map = new HashMap(getNumBodyDecl());
    for(Iterator iter = genericDecl().localMethodsIterator(); iter.hasNext(); ) {
      MethodDecl decl = (MethodDecl)iter.next();
      if(decl.usesTypeVariable()) {
        BodyDecl b = decl.p(this);
        b.is$Final = true;
        addBodyDecl(b);
        decl = (MethodDecl)b;
      }
      map.put(decl.signature(), decl);
    }
    return map;
  }

    protected java.util.Map fields_String_values;
    // Declared in Generics.jrag at line 818
    public SimpleSet fields(String name) {
        Object _parameters = name;
if(fields_String_values == null) fields_String_values = new java.util.HashMap(4);
        if(fields_String_values.containsKey(_parameters))
            return (SimpleSet)fields_String_values.get(_parameters);
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        SimpleSet fields_String_value = fields_compute(name);
        if(isFinal && num == boundariesCrossed)
            fields_String_values.put(_parameters, fields_String_value);
        return fields_String_value;
    }

    private SimpleSet fields_compute(String name)  {
    SimpleSet set = SimpleSet.emptySet;
    for(Iterator iter = genericDecl().fields(name).iterator(); iter.hasNext(); ) {
      FieldDeclaration f = (FieldDeclaration)iter.next();
      if(f.usesTypeVariable()) {
        BodyDecl b = f.p(this);
        b.is$Final = true;
        addBodyDecl(b);
        f = (FieldDeclaration)b;
      }
      set = set.add(f);
    }
    return set;
  }

    // Declared in Generics.jrag at line 833
    public SimpleSet memberTypes(String name) {
        Object _parameters = name;
if(memberTypes_String_values == null) memberTypes_String_values = new java.util.HashMap(4);
        if(memberTypes_String_values.containsKey(_parameters))
            return (SimpleSet)memberTypes_String_values.get(_parameters);
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        SimpleSet memberTypes_String_value = memberTypes_compute(name);
        if(isFinal && num == boundariesCrossed)
            memberTypes_String_values.put(_parameters, memberTypes_String_value);
        return memberTypes_String_value;
    }

    private SimpleSet memberTypes_compute(String name)  {
    SimpleSet set = SimpleSet.emptySet;
    for(int i = 0; i < getNumBodyDecl(); i++) {
      if(getBodyDecl(i) instanceof MemberTypeDecl) {
        MemberTypeDecl d = (MemberTypeDecl)getBodyDecl(i);
        if(d.typeDecl().name().equals(name))
          set = set.add(d.typeDecl());
      }
    }
    if(!set.isEmpty())
      return set;
    for(Iterator iter = genericDecl().memberTypes(name).iterator(); iter.hasNext(); ) {
      TypeDecl t = (TypeDecl)iter.next();
      if(t.isStatic())
        set = set.add(t);
      else {
        BodyDecl b;
        TypeDecl typeDecl;
        if(t instanceof ClassDecl) {
          ClassDecl classDecl = (ClassDecl)t;
          typeDecl = classDecl.p(this);
          b = new MemberClassDecl((ClassDecl)typeDecl);
          b.is$Final = true;
          addBodyDecl(b);
          set = set.add(typeDecl);
        }
        else if(t instanceof InterfaceDecl) {
          InterfaceDecl interfaceDecl = (InterfaceDecl)t;
          typeDecl = interfaceDecl.p(this);
          b = new MemberInterfaceDecl((InterfaceDecl)typeDecl);
          b.is$Final = true;
          addBodyDecl(b);
          set = set.add(typeDecl);
        }
      }
    }
    return set;
  }

    // Declared in Generics.jrag at line 872
    public Collection constructors() {
        if(constructors_computed)
            return constructors_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        constructors_value = constructors_compute();
        if(isFinal && num == boundariesCrossed)
            constructors_computed = true;
        return constructors_value;
    }

    private Collection constructors_compute()  {
    Collection set = new ArrayList();
    for(Iterator iter = genericDecl().constructors().iterator(); iter.hasNext(); ) {
      ConstructorDecl c = (ConstructorDecl)iter.next();
      BodyDecl b = c.p(this);
      b.is$Final = true;
      addBodyDecl(b);
      set.add(b);
    }
    return set;
  }

    // Declared in GenericsParTypeDecl.jrag at line 3
    public String fullName() {
        if(fullName_computed)
            return fullName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        fullName_value = fullName_compute();
        if(isFinal && num == boundariesCrossed)
            fullName_computed = true;
        return fullName_value;
    }

    private String fullName_compute()  {
    if(isNestedType())
      return enclosingType().fullName() + "." + nameWithArgs();
    String packageName = packageName();
    if(packageName.equals(""))
      return nameWithArgs();
    return packageName + "." + nameWithArgs();
  }

    // Declared in GenericsParTypeDecl.jrag at line 12
    public String typeName() {
        if(typeName_computed)
            return typeName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        typeName_value = typeName_compute();
        if(isFinal && num == boundariesCrossed)
            typeName_computed = true;
        return typeName_value;
    }

    private String typeName_compute()  {
    if(isNestedType())
      return enclosingType().typeName() + "." + nameWithArgs();
    String packageName = packageName();
    if(packageName.equals("") || packageName.equals(PRIMITIVE_PACKAGE_NAME))
      return nameWithArgs();
    return packageName + "." + nameWithArgs();
  }

    // Declared in GenericsParTypeDecl.jrag at line 21
    public String nameWithArgs() {
        String nameWithArgs_value = nameWithArgs_compute();
        return nameWithArgs_value;
    }

    private String nameWithArgs_compute()  {
    StringBuffer s = new StringBuffer();
    s.append(name());
    s.append("<");
    for(int i = 0; i < getNumArgument(); i++) {
      if(i != 0)
        s.append(", ");
      s.append(getArgument(i).type().fullName());
    }
    s.append(">");
    return s.toString();
  }

    // Declared in GenericsCodegen.jrag at line 493
    public String typeArgumentsOpt() {
        String typeArgumentsOpt_value = typeArgumentsOpt_compute();
        return typeArgumentsOpt_value;
    }

    private String typeArgumentsOpt_compute()  {
    StringBuffer buf = new StringBuffer();
    buf.append("<");
    for(int i = 0; i < getNumArgument(); i++)
      buf.append(getArgument(i).type().fieldTypeSignature());
    buf.append(">");
    return buf.toString();
  }

    // Declared in GenericNamesAndTypes.jrag at line 18
    public Set getTypeVariables() {
        Set getTypeVariables_value = getTypeVariables_compute();
        return getTypeVariables_value;
    }

    private Set getTypeVariables_compute() {
        Set typevars = new HashSet();
        for(int i=0; i < getNumArgument(); i++){
            typevars.addAll(getArgument(i).getTypeVariables());
            //getArgument(i).getTypeVariables(typevars);
        }
        return typevars;
    }

    // Declared in GenericNamesAndTypes.jrag at line 54
    public String simpleName() {
        String simpleName_value = simpleName_compute();
        return simpleName_value;
    }

    private String simpleName_compute() {
        StringBuilder s = new StringBuilder();
        s.append(name());
        s.append("<");
        for(int i = 0; i < getNumArgument(); i++) {
            if(i != 0)
                s.append(", ");
            if(!visited){
                visited = true;
                //s.append(getArgument(i).type().simpleName());
                s.append(getArgument(i).type().shortName());
                visited = false;
            }else{
                s.append(getArgument(i).type().name());
            }
        }
        s.append(">");
        return s.toString();
    }

    // Declared in SimpleTypeEdit.jrag at line 21
    public LinkedList flatten() {
        LinkedList flatten_value = flatten_compute();
        return flatten_value;
    }

    private LinkedList flatten_compute()  {
        LinkedList flatType = new LinkedList();
        flatType.add(erasure().fullName());
        for (int i = 0; i < getNumArgument(); i++) {
            flatType.addAll(getArgument(i).type().flatten());
        }
        return flatType;
    }

/**
     * Return a list of indices for type arguments that do not match. For
     * example:
     * <p>
     * {@code Map<String, Object> <: List<String, Number>} gives a single list
     * containing the index 1, because Object does not match Number.
     * 
     * @param type
     *            a parameter that is a supertype of this type.
     * @param excList
     *            a parameter that containt indices of type argument that 
     *            don't have to be checked.
     * @return a list of indices for which the type argumuments at these
     *         specific indices in this type do not match the type arguments in
     *         the paramter type.
     
    Declared in SuperObjectHeuristic.jrag at line 30
*/
    public ArrayList containedIn(ParTypeDecl type, ArrayList excList) {
        ArrayList containedIn_ParTypeDecl_ArrayList_value = containedIn_compute(type, excList);
        return containedIn_ParTypeDecl_ArrayList_value;
    }

    private ArrayList containedIn_compute(ParTypeDecl type, ArrayList excList) {
        ArrayList indices = new ArrayList(type.getNumArgument());
        if (!containedIn(type, indices, excList)) {
            for (Iterator iter =
                    ConstraintsMapBuilder.parameterizedSupertypes(this)
                            .iterator(); iter.hasNext();) {
                if(((ParTypeDecl) iter.next()).containedIn(type, indices, excList))
                    break;

            }
        }
        return indices;
    }

    protected boolean genericDecl_computed = false;
    protected TypeDecl genericDecl_value;
    // Declared in GenericsParTypeDecl.jrag at line 36
    public TypeDecl genericDecl() {
        if(genericDecl_computed)
            return genericDecl_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        genericDecl_value = getParent().Define_TypeDecl_genericDecl(this, null);
        if(isFinal && num == boundariesCrossed)
            genericDecl_computed = true;
        return genericDecl_value;
    }

    // Declared in Generics.jrag at line 350
    public NameType Define_NameType_nameType(ASTNode caller, ASTNode child) {
        if(caller == getArgumentListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  NameType.TYPE_NAME;
        }
        return super.Define_NameType_nameType(caller, child);
    }

    // Declared in GenericsParTypeDecl.jrag at line 40
    public TypeDecl Define_TypeDecl_genericDecl(ASTNode caller, ASTNode child) {
        if(caller == getBodyDeclListNoTransform()) { 
   int index = caller.getIndexOfChild(child);
 {
    if(getBodyDecl(index) instanceof MemberTypeDecl) {
      MemberTypeDecl m = (MemberTypeDecl)getBodyDecl(index);
      return extractSingleType(genericDecl().memberTypes(m.typeDecl().name()));
    }
    return genericDecl();
  }
}
        return getParent().Define_TypeDecl_genericDecl(this, caller);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
