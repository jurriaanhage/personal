
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


public class ParMethodAccess extends MethodAccess implements Cloneable {
    public void flushCache() {
        super.flushCache();
        typeArguments_MethodDecl_values = null;
    }
    public Object clone() throws CloneNotSupportedException {
        ParMethodAccess node = (ParMethodAccess)super.clone();
        node.typeArguments_MethodDecl_values = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          ParMethodAccess node = (ParMethodAccess)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        ParMethodAccess res = (ParMethodAccess)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in GenericMethods.jrag at line 103


  public void toString(StringBuffer s) {
    s.append("<");
    for(int i = 0; i < getNumTypeArgument(); i++) {
      if(i != 0) s.append(", ");
      getTypeArgument(i).toString(s);
    }
    s.append(">");
    
    s.append(name());
    //s.append(getDecl().getID());
    s.append("(");
    if(getNumArg() > 0) {
      getArg(0).toString(s);
      for(int i = 1; i < getNumArg(); i++) {
        s.append(", ");
        getArg(i).toString(s);
      }
    }
    s.append(")");
  }

    // Declared in Inference.jrag at line 274


    // replacement for super.typeCheck
    private void super_typeCheck(){
        if(isQualified() && decl().isAbstract() && qualifier().isSuperAccess())
            error("may not access abstract methods in superclass");
        if(!decl().isVariableArity() || invokesVariableArityAsArray()) {
            for(int i = 0; i < decl().getNumParameter(); i++) {
                TypeDecl exprType = getArg(i).type();
                TypeDecl parmType = decl().getParameter(i).type();
                if(!exprType.methodInvocationConversionTo(parmType) && !exprType.isUnknown() &&
                    !parmType.isUnknown()) {
                    error("#The type " + exprType.typeName() + " of expr " +
                        getArg(i) + " is not compatible with the method parameter " +
                        decl().getParameter(i));
                }
            }
        }
    }

    // Declared in Inference.jrag at line 291


    private boolean typeCheckMethod(GenericMethodDecl decl,
            ArrayList typeArgList, StringBuilder buf) 
    {
        ConstraintsMapBuilder cBuilder = new ConstraintsMapBuilder();
        ParMethodSolver solver = new ParMethodSolver(cBuilder, this, decl,
                typeArgList);
        if (setupConstraints(decl, cBuilder)) {
            if (solver.checkTypeArgumentBoundErrors()) {
                // infer the types to make sure that only the annotation is wrong.
                solver.inferTypes();

                // report the found errors and hints in case inference succeeded.
                printErrorHeader(decl, buf);
                buf.append(", because:\n");
                solver.getCheckErrors(buf);
                buf.append("\n");
            } else {
                if (solver.checkTypes()) {
                    // infer the types to make sure that only the annotation is
                    // in conflict with the parameters.
                    solver.inferTypes();                    

                    // report the found errors and hints in case inference succeeded.
                    printErrorHeader(decl, buf);                                           
                    buf.append(", because:\n");
                    solver.getCheckErrors(buf);
                    buf.append("\n");
                } else{                
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    // Declared in Inference.jrag at line 329

    /*
     * Override the argumentsSimpleName in MethodAccess to add the method call type arguments also.
     */
    protected void argumentsSimpleName(StringBuilder buf) {
        buf.append("<");
        for (int i = 0; i < getNumTypeArgument(); i++) {
            if(i > 0)
                buf.append(", ");
            buf.append(getTypeArgument(i).simpleName());
        }
        buf.append(">(");
        super.argumentsSimpleName(buf, false);
        buf.append(")");
    }

    // Declared in MethodLookUp.jadd at line 179


    /*
     * Override potentiallyApplicable_excl_tvar to also compare the number of type parameters of a
     * generic method.
     */
    protected boolean potentiallyApplicable_excl_tvar(MethodDecl m) {
        GenericMethodDecl gm = (GenericMethodDecl) m;
        return super.potentiallyApplicable_excl_tvar(m) ? gm
                                .getNumTypeParameter() == getNumTypeArgument() : false;
    }

    // Declared in GenericMethods.ast at line 3
    // Declared in GenericMethods.ast line 7

    public ParMethodAccess() {
        super();

        setChild(new List(), 0);
        setChild(new List(), 1);

    }

    // Declared in GenericMethods.ast at line 12


    // Declared in GenericMethods.ast line 7
    public ParMethodAccess(String p0, List p1, List p2) {
        setID(p0);
        setChild(p1, 0);
        setChild(p2, 1);
    }

    // Declared in GenericMethods.ast at line 18


  protected int numChildren() {
    return 2;
  }

    // Declared in GenericMethods.ast at line 21

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 17
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 17
    public void setArgList(List list) {
        setChild(list, 0);
    }

    // Declared in java.ast at line 6


    private int getNumArg = 0;

    // Declared in java.ast at line 7

    public int getNumArg() {
        return getArgList().getNumChild();
    }

    // Declared in java.ast at line 11


    public Expr getArg(int i) {
        return (Expr)getArgList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addArg(Expr node) {
        List list = getArgList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setArg(Expr node, int i) {
        List list = getArgList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getArgList() {
        return (List)getChild(0);
    }

    // Declared in java.ast at line 28


    public List getArgListNoTransform() {
        return (List)getChildNoTransform(0);
    }

    // Declared in GenericMethods.ast at line 2
    // Declared in GenericMethods.ast line 7
    public void setTypeArgumentList(List list) {
        setChild(list, 1);
    }

    // Declared in GenericMethods.ast at line 6


    private int getNumTypeArgument = 0;

    // Declared in GenericMethods.ast at line 7

    public int getNumTypeArgument() {
        return getTypeArgumentList().getNumChild();
    }

    // Declared in GenericMethods.ast at line 11


    public Access getTypeArgument(int i) {
        return (Access)getTypeArgumentList().getChild(i);
    }

    // Declared in GenericMethods.ast at line 15


    public void addTypeArgument(Access node) {
        List list = getTypeArgumentList();
        list.addChild(node);
    }

    // Declared in GenericMethods.ast at line 20


    public void setTypeArgument(Access node, int i) {
        List list = getTypeArgumentList();
        list.setChild(node, i);
    }

    // Declared in GenericMethods.ast at line 24

    public List getTypeArgumentList() {
        return (List)getChild(1);
    }

    // Declared in GenericMethods.ast at line 28


    public List getTypeArgumentListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Inference.jrag at line 247

    // ------------------------------------------------------------------------
    // Override type-checking for ParMethodAccess
    // ------------------------------------------------------------------------
    //public void ParMethodAccess.typeCheck(){
      public void typeCheck(){
        super_typeCheck();
        if(!decl().hostType().isUnknown()) {
            if(!(decl() instanceof ParMethodDecl))
                error("can not have type parameters on a non generic method");
            else {
                ParMethodDecl m = (ParMethodDecl)decl();
                if(m.numTypeParameter() != getNumTypeArgument())
                    error("generic method " + m.signature() + " requires " + m.numTypeParameter() 
                        + " type arguments");
            }
        }        
        // perform my check after all other checks were performed.
        SimpleSet decls = getMethodDeclarations();
        StringBuilder buf = new StringBuilder(); 
        boolean dontReportErrors = false;
        for (Iterator iter = decls.iterator(); iter.hasNext();) {
            GenericMethodDecl decl = (GenericMethodDecl) iter.next();
            ArrayList typeArgList = typeArguments(decl);
            if(typeCheckMethod(decl, typeArgList, buf))
                dontReportErrors = true;
        }
        if(!dontReportErrors)
            addTypeError(buf.toString());
    }

    // Declared in Inference.jrag at line 342
    public ArrayList typeArguments(MethodDecl m) {
        Object _parameters = m;
if(typeArguments_MethodDecl_values == null) typeArguments_MethodDecl_values = new java.util.HashMap(4);
        if(typeArguments_MethodDecl_values.containsKey(_parameters))
            return (ArrayList)typeArguments_MethodDecl_values.get(_parameters);
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        ArrayList typeArguments_MethodDecl_value = typeArguments_compute(m);
        if(isFinal && num == boundariesCrossed)
            typeArguments_MethodDecl_values.put(_parameters, typeArguments_MethodDecl_value);
        return typeArguments_MethodDecl_value;
    }

    private ArrayList typeArguments_compute(MethodDecl m)  {
        ArrayList typeArguments = new ArrayList();
        for (int i = 0; i < getNumTypeArgument(); i++) {
            Access arg = getTypeArgument(i);
            TypeDecl argType = arg.type();
            argType.setSourceExpr(arg);
            typeArguments.add(argType);
        }
        return typeArguments;

    }

    // Declared in GenericMethods.jrag at line 66
    public NameType Define_NameType_nameType(ASTNode caller, ASTNode child) {
        if(caller == getTypeArgumentListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  NameType.TYPE_NAME;
        }
        return super.Define_NameType_nameType(caller, child);
    }

    // Declared in GenericMethods.jrag at line 67
    public SimpleSet Define_SimpleSet_lookupType(ASTNode caller, ASTNode child, String name) {
        if(caller == getTypeArgumentListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  unqualifiedScope().lookupType(name);
        }
        return super.Define_SimpleSet_lookupType(caller, child, name);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
