
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;



  public interface GenericTypeDecl {
    // Declared in Generics.jrag at line 80

    TypeDecl original();

    // Declared in Generics.jrag at line 81

    int getNumTypeParameter();

    // Declared in Generics.jrag at line 82

    TypeVariable getTypeParameter(int index);

    // Declared in Generics.jrag at line 83

    List getTypeParameterList();

    // Declared in Generics.jrag at line 85

    public String fullName();

    // Declared in Generics.jrag at line 86

    public String typeName();

    // Declared in Generics.jrag at line 153

  public TypeDecl makeGeneric(Signatures.ClassSignature s);


    // Declared in Generics.jrag at line 363


  public SimpleSet addTypeVariables(SimpleSet c, String name);


    // Declared in Generics.jrag at line 562

  public List createArgumentList(ArrayList params);


    // Declared in Generics.jrag at line 79
    public boolean isGenericType();
    // Declared in Generics.jrag at line 84
    public TypeDecl rawType();
    // Declared in Generics.jrag at line 496
    public TypeDecl lookupParTypeDecl(ParTypeAccess p);
    // Declared in Generics.jrag at line 533
    public TypeDecl lookupParTypeDecl(ArrayList list);
    // Declared in GenericNamesAndTypes.jrag at line 74
    public String simpleName();
}
