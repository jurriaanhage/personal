
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;

public class WildcardSuperType extends AbstractWildcardType implements Cloneable {
    public void flushCache() {
        super.flushCache();
        usesTypeVariable_computed = false;
        usesTypeVariable_initialized = false;
        instanceOf_TypeDecl_values = null;
        fieldTypeSignature_computed = false;
        fieldTypeSignature_value = null;
        getTypeVariables_computed = false;
        getTypeVariables_value = null;
        parContains_TypeDecl_values = null;
    }
    public Object clone() throws CloneNotSupportedException {
        WildcardSuperType node = (WildcardSuperType)super.clone();
        node.usesTypeVariable_computed = false;
        node.usesTypeVariable_initialized = false;
        node.instanceOf_TypeDecl_values = null;
        node.fieldTypeSignature_computed = false;
        node.fieldTypeSignature_value = null;
        node.getTypeVariables_computed = false;
        node.getTypeVariables_value = null;
        node.parContains_TypeDecl_values = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          WildcardSuperType node = (WildcardSuperType)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        WildcardSuperType res = (WildcardSuperType)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in Generics.jrag at line 645

  public Access substitute(Parameterization parTypeDecl) {
    if(!usesTypeVariable())
      return super.substitute(parTypeDecl);
    return new WildcardSuper(getAccess().type().substitute(parTypeDecl));
  }

    // Declared in GenericNamesAndTypes.jrag at line 197


    public String nameWithFlippedWildcards(final Class heur){
        if(isOpposite_heur_reversible(heur))
            return "? extends " + getAccess().type().nameWithFlippedWildcards(heur);
        return "? super " + getAccess().type().nameWithFlippedWildcards(heur);
    }

    // Declared in GenericNamesAndTypes.jrag at line 208

    public String simpleFlippedName(){
        return "? extends " + getAccess().type().simpleName();
    }

    // Declared in WildcardsHeuristics.jrag at line 74


    public TypeDecl flipAllWildcards(final Class heur){
        if (isOpposite_heur_reversible(heur)){
            WildcardExtendsType ex = new WildcardExtendsType();
            ex.setModifiers((Modifiers) getModifiers().fullCopy());
            ex.setBodyDeclList(new List());
            ex.setAccess(getAccess().type().flipAllWildcards(heur).createBoundAccess());
            ex.setID(ex.simpleName());
            // required to be able to print fullname.
            ex.setParent(getParent());
            return ex;
        }
        else {
            WildcardSuperType su = new WildcardSuperType();
            su.setModifiers((Modifiers) getModifiers().fullCopy());
            su.setBodyDeclList(new List());
            su.setAccess(getAccess().type().flipAllWildcards(heur).createBoundAccess());
            su.setID(su.simpleName());
            // required to be able to print fullname.
            su.setParent(getParent());
            return su;
        }
        //return this;
    }

    // Declared in WildcardsHeuristics.jrag at line 202


    public Access wildBoundFlip(Class heur){
        WildcardExtendsType ex = new WildcardExtendsType();
        ex.setModifiers((Modifiers) getModifiers().fullCopy());
        ex.setBodyDeclList(new List());
        ex.setAccess(getAccess().typeWithFlippedWilds(heur));
        ex.setID(ex.simpleName());    
        ex.setParent(getParent());
        // required to be able to print fullname.
        ex.setParent(getParent());
        return ex.createBoundAccess();
    }

    // Declared in Generics.ast at line 3
    // Declared in Generics.ast line 25

    public WildcardSuperType() {
        super();

        setChild(null, 0);
        setChild(new List(), 1);
        setChild(null, 2);

    }

    // Declared in Generics.ast at line 13


    // Declared in Generics.ast line 25
    public WildcardSuperType(Modifiers p0, String p1, List p2, Access p3) {
        setChild(p0, 0);
        setID(p1);
        setChild(p2, 1);
        setChild(p3, 2);
    }

    // Declared in Generics.ast at line 20


  protected int numChildren() {
    return 3;
  }

    // Declared in Generics.ast at line 23

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 38
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in java.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in java.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 38
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 38
    public void setBodyDeclList(List list) {
        setChild(list, 1);
    }

    // Declared in java.ast at line 6


    private int getNumBodyDecl = 0;

    // Declared in java.ast at line 7

    public int getNumBodyDecl() {
        return getBodyDeclList().getNumChild();
    }

    // Declared in java.ast at line 11


    public BodyDecl getBodyDecl(int i) {
        return (BodyDecl)getBodyDeclList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addBodyDecl(BodyDecl node) {
        List list = getBodyDeclList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setBodyDecl(BodyDecl node, int i) {
        List list = getBodyDeclList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getBodyDeclList() {
        return (List)getChild(1);
    }

    // Declared in java.ast at line 28


    public List getBodyDeclListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 25
    public void setAccess(Access node) {
        setChild(node, 2);
    }

    // Declared in Generics.ast at line 5

    public Access getAccess() {
        return (Access)getChild(2);
    }

    // Declared in Generics.ast at line 9


    public Access getAccessNoTransform() {
        return (Access)getChildNoTransform(2);
    }

    protected boolean involvesTypeParameters_visited = false;
    protected boolean involvesTypeParameters_computed = false;
    protected boolean involvesTypeParameters_initialized = false;
    protected boolean involvesTypeParameters_value;
    public boolean involvesTypeParameters() {
        if(involvesTypeParameters_computed)
            return involvesTypeParameters_value;
        if (!involvesTypeParameters_initialized) {
            involvesTypeParameters_initialized = true;
            involvesTypeParameters_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            involvesTypeParameters_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
                if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                    CHANGE = true;
                involvesTypeParameters_value = new_involvesTypeParameters_value; 
            } while (CHANGE);
            involvesTypeParameters_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            involvesTypeParameters_computed = true;
            }
            else {
            RESET_CYCLE = true;
            involvesTypeParameters_compute();
            RESET_CYCLE = false;
              involvesTypeParameters_computed = false;
              involvesTypeParameters_initialized = false;
            }
            IN_CIRCLE = false; 
            return involvesTypeParameters_value;
        }
        if(!involvesTypeParameters_visited) {
            if (RESET_CYCLE) {
                involvesTypeParameters_computed = false;
                involvesTypeParameters_initialized = false;
                return involvesTypeParameters_value;
            }
            involvesTypeParameters_visited = true;
            boolean new_involvesTypeParameters_value = involvesTypeParameters_compute();
            if (new_involvesTypeParameters_value!=involvesTypeParameters_value)
                CHANGE = true;
            involvesTypeParameters_value = new_involvesTypeParameters_value; 
            involvesTypeParameters_visited = false;
            return involvesTypeParameters_value;
        }
        return involvesTypeParameters_value;
    }

    private boolean involvesTypeParameters_compute() {  return  superType().involvesTypeParameters();  }

    // Declared in Generics.jrag at line 480
    public boolean sameSignature(Access a) {
        boolean sameSignature_Access_value = sameSignature_compute(a);
        return sameSignature_Access_value;
    }

    private boolean sameSignature_compute(Access a)  {
    if(a instanceof WildcardSuper)
      return getAccess().type().sameSignature(((WildcardSuper)a).getAccess());
    return super.sameSignature(a);
  }

    protected boolean usesTypeVariable_visited = false;
    protected boolean usesTypeVariable_computed = false;
    protected boolean usesTypeVariable_initialized = false;
    protected boolean usesTypeVariable_value;
    public boolean usesTypeVariable() {
        if(usesTypeVariable_computed)
            return usesTypeVariable_value;
        if (!usesTypeVariable_initialized) {
            usesTypeVariable_initialized = true;
            usesTypeVariable_value = false;
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            usesTypeVariable_visited = true;
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            do {
                CHANGE = false;
                boolean new_usesTypeVariable_value = usesTypeVariable_compute();
                if (new_usesTypeVariable_value!=usesTypeVariable_value)
                    CHANGE = true;
                usesTypeVariable_value = new_usesTypeVariable_value; 
            } while (CHANGE);
            usesTypeVariable_visited = false;
            if(isFinal && num == boundariesCrossed)
{
            usesTypeVariable_computed = true;
            }
            else {
            RESET_CYCLE = true;
            usesTypeVariable_compute();
            RESET_CYCLE = false;
              usesTypeVariable_computed = false;
              usesTypeVariable_initialized = false;
            }
            IN_CIRCLE = false; 
            return usesTypeVariable_value;
        }
        if(!usesTypeVariable_visited) {
            if (RESET_CYCLE) {
                usesTypeVariable_computed = false;
                usesTypeVariable_initialized = false;
                return usesTypeVariable_value;
            }
            usesTypeVariable_visited = true;
            boolean new_usesTypeVariable_value = usesTypeVariable_compute();
            if (new_usesTypeVariable_value!=usesTypeVariable_value)
                CHANGE = true;
            usesTypeVariable_value = new_usesTypeVariable_value; 
            usesTypeVariable_visited = false;
            return usesTypeVariable_value;
        }
        return usesTypeVariable_value;
    }

    private boolean usesTypeVariable_compute() {  return  getAccess().type().usesTypeVariable();  }

    // Declared in Generics.jrag at line 1032
    public TypeDecl superType() {
        TypeDecl superType_value = superType_compute();
        return superType_value;
    }

    private TypeDecl superType_compute() {  return  getAccess().type();  }

    // Declared in GenericsSubtype.jrag at line 44
    public boolean supertypeWildcard(WildcardType type) {
        boolean supertypeWildcard_WildcardType_value = supertypeWildcard_compute(type);
        return supertypeWildcard_WildcardType_value;
    }

    private boolean supertypeWildcard_compute(WildcardType type) {  return 
    superType().subtype(typeObject());  }

    protected java.util.Set subtype_TypeDecl_visited;
    protected java.util.Set subtype_TypeDecl_computed = new java.util.HashSet(4);
    protected java.util.Set subtype_TypeDecl_initialized = new java.util.HashSet(4);
    protected java.util.Map subtype_TypeDecl_values = new java.util.HashMap(4);
    public boolean subtype(TypeDecl type) {
        Object _parameters = type;
if(subtype_TypeDecl_visited == null) subtype_TypeDecl_visited = new java.util.HashSet(4);
if(subtype_TypeDecl_values == null) subtype_TypeDecl_values = new java.util.HashMap(4);
        if(subtype_TypeDecl_computed.contains(_parameters))
            return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
        if (!subtype_TypeDecl_initialized.contains(_parameters)) {
            subtype_TypeDecl_initialized.add(_parameters);
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(true));
        }
        if (!IN_CIRCLE) {
            IN_CIRCLE = true;
            subtype_TypeDecl_visited.add(_parameters);
            int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
            boolean new_subtype_TypeDecl_value;
            do {
                CHANGE = false;
                new_subtype_TypeDecl_value = subtype_compute(type);
                if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                    CHANGE = true;
                subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            } while (CHANGE);
            subtype_TypeDecl_visited.remove(_parameters);
            if(isFinal && num == boundariesCrossed)
{
            subtype_TypeDecl_computed.add(_parameters);
            }
            else {
            RESET_CYCLE = true;
            subtype_compute(type);
            RESET_CYCLE = false;
            subtype_TypeDecl_computed.remove(_parameters);
            subtype_TypeDecl_initialized.remove(_parameters);
            }
            IN_CIRCLE = false; 
            return new_subtype_TypeDecl_value;
        }
        if(!subtype_TypeDecl_visited.contains(_parameters)) {
            if (RESET_CYCLE) {
                subtype_TypeDecl_computed.remove(_parameters);
                subtype_TypeDecl_initialized.remove(_parameters);
                return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
            }
            subtype_TypeDecl_visited.add(_parameters);
            boolean new_subtype_TypeDecl_value = subtype_compute(type);
            if (new_subtype_TypeDecl_value!=((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue())
                CHANGE = true;
            subtype_TypeDecl_values.put(_parameters, Boolean.valueOf(new_subtype_TypeDecl_value));
            subtype_TypeDecl_visited.remove(_parameters);
            return new_subtype_TypeDecl_value;
        }
        return ((Boolean)subtype_TypeDecl_values.get(_parameters)).booleanValue();
    }

    private boolean subtype_compute(TypeDecl type) {  return  type.supertypeWildcardSuper(this);  }

    // Declared in GenericsSubtype.jrag at line 62
    public boolean supertypeWildcardSuper(WildcardSuperType type) {
        boolean supertypeWildcardSuper_WildcardSuperType_value = supertypeWildcardSuper_compute(type);
        return supertypeWildcardSuper_WildcardSuperType_value;
    }

    private boolean supertypeWildcardSuper_compute(WildcardSuperType type) {  return 
    type.superType().subtype(superType());  }

    // Declared in GenericsSubtype.jrag at line 84
    public boolean supertypeClassDecl(ClassDecl type) {
        boolean supertypeClassDecl_ClassDecl_value = supertypeClassDecl_compute(type);
        return supertypeClassDecl_ClassDecl_value;
    }

    private boolean supertypeClassDecl_compute(ClassDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 85
    public boolean supertypeInterfaceDecl(InterfaceDecl type) {
        boolean supertypeInterfaceDecl_InterfaceDecl_value = supertypeInterfaceDecl_compute(type);
        return supertypeInterfaceDecl_InterfaceDecl_value;
    }

    private boolean supertypeInterfaceDecl_compute(InterfaceDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 86
    public boolean supertypeParClassDecl(ParClassDecl type) {
        boolean supertypeParClassDecl_ParClassDecl_value = supertypeParClassDecl_compute(type);
        return supertypeParClassDecl_ParClassDecl_value;
    }

    private boolean supertypeParClassDecl_compute(ParClassDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 87
    public boolean supertypeParInterfaceDecl(ParInterfaceDecl type) {
        boolean supertypeParInterfaceDecl_ParInterfaceDecl_value = supertypeParInterfaceDecl_compute(type);
        return supertypeParInterfaceDecl_ParInterfaceDecl_value;
    }

    private boolean supertypeParInterfaceDecl_compute(ParInterfaceDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 88
    public boolean supertypeRawClassDecl(RawClassDecl type) {
        boolean supertypeRawClassDecl_RawClassDecl_value = supertypeRawClassDecl_compute(type);
        return supertypeRawClassDecl_RawClassDecl_value;
    }

    private boolean supertypeRawClassDecl_compute(RawClassDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 89
    public boolean supertypeRawInterfaceDecl(RawInterfaceDecl type) {
        boolean supertypeRawInterfaceDecl_RawInterfaceDecl_value = supertypeRawInterfaceDecl_compute(type);
        return supertypeRawInterfaceDecl_RawInterfaceDecl_value;
    }

    private boolean supertypeRawInterfaceDecl_compute(RawInterfaceDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 90
    public boolean supertypeTypeVariable(TypeVariable type) {
        boolean supertypeTypeVariable_TypeVariable_value = supertypeTypeVariable_compute(type);
        return supertypeTypeVariable_TypeVariable_value;
    }

    private boolean supertypeTypeVariable_compute(TypeVariable type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 91
    public boolean supertypeArrayDecl(ArrayDecl type) {
        boolean supertypeArrayDecl_ArrayDecl_value = supertypeArrayDecl_compute(type);
        return supertypeArrayDecl_ArrayDecl_value;
    }

    private boolean supertypeArrayDecl_compute(ArrayDecl type) {  return  superType().subtype(type);  }

    // Declared in GenericsSubtype.jrag at line 253
    public boolean instanceOf(TypeDecl type) {
        Object _parameters = type;
if(instanceOf_TypeDecl_values == null) instanceOf_TypeDecl_values = new java.util.HashMap(4);
        if(instanceOf_TypeDecl_values.containsKey(_parameters))
            return ((Boolean)instanceOf_TypeDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean instanceOf_TypeDecl_value = instanceOf_compute(type);
        if(isFinal && num == boundariesCrossed)
            instanceOf_TypeDecl_values.put(_parameters, Boolean.valueOf(instanceOf_TypeDecl_value));
        return instanceOf_TypeDecl_value;
    }

    private boolean instanceOf_compute(TypeDecl type) {  return  subtype(type);  }

    // Declared in GenericsCodegen.jrag at line 470
    public String fieldTypeSignature() {
        if(fieldTypeSignature_computed)
            return fieldTypeSignature_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        fieldTypeSignature_value = fieldTypeSignature_compute();
        if(isFinal && num == boundariesCrossed)
            fieldTypeSignature_computed = true;
        return fieldTypeSignature_value;
    }

    private String fieldTypeSignature_compute() {  return  "-" + superType().fieldTypeSignature();  }

/**
     * Collect the type variables used in a bound.
     * Example: Type<R,T extends List<Set<R>>> wil return [R,T]
     
    Declared in GenericNamesAndTypes.jrag at line 28
*/
    public Set getTypeVariables() {
        if(getTypeVariables_computed)
            return getTypeVariables_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getTypeVariables_value = getTypeVariables_compute();
        if(isFinal && num == boundariesCrossed)
            getTypeVariables_computed = true;
        return getTypeVariables_value;
    }

    private Set getTypeVariables_compute() {  return  getAccess().getTypeVariables();  }

    // Declared in GenericNamesAndTypes.jrag at line 166
    public String simpleName() {
        String simpleName_value = simpleName_compute();
        return simpleName_value;
    }

    private String simpleName_compute() {  return  "? super " + getAccess().shortName();  }

    // Declared in ParSubtyping.jrag at line 96
    public boolean parContains(TypeDecl type) {
        Object _parameters = type;
if(parContains_TypeDecl_values == null) parContains_TypeDecl_values = new java.util.HashMap(4);
        if(parContains_TypeDecl_values.containsKey(_parameters))
            return ((Boolean)parContains_TypeDecl_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean parContains_TypeDecl_value = parContains_compute(type);
        if(isFinal && num == boundariesCrossed)
            parContains_TypeDecl_values.put(_parameters, Boolean.valueOf(parContains_TypeDecl_value));
        return parContains_TypeDecl_value;
    }

    private boolean parContains_compute(TypeDecl type)  {
        //? super T <= ? super S if S <: T
        if(type instanceof WildcardSuperType){
            WildcardSuperType otherType = (WildcardSuperType) type;
            return superType().parSubtype(otherType.superType());            
        }
        // T <= ? extends T
        return !(type instanceof WildcardExtendsType) &&
                superType().parSubtype(type);            
    }

    // Declared in SimpleTypeEdit.jrag at line 14
    public LinkedList flatten() {
        LinkedList flatten_value = flatten_compute();
        return flatten_value;
    }

    private LinkedList flatten_compute() {
        LinkedList list = superType().flatten();
		list.add("@super@"); 
		return list;
    }

/**
     * Replace type variables with a new type. This is somewhat similar to wildcard capture.
     * @return
     
    Declared in TypeVariableSubstitution.jrag at line 123
*/
    public TypeDecl captureTypeVariables() {
        TypeDecl captureTypeVariables_value = captureTypeVariables_compute();
        return captureTypeVariables_value;
    }

    private TypeDecl captureTypeVariables_compute()  {
        WildcardSuperType ret = new WildcardSuperType();
        // set modifiers
        ret.setModifiers((Modifiers) getModifiers().fullCopy());
        // set body
        ret.setBodyDeclList(new List());
        // set bound
        ret.setAccess(getAccess().type().captureTypeVariables().createBoundAccess());
        // set name
        ret.setID(ret.simpleName());
        return ret;
    }

/**
     * Substitute type variables with types given in subst (Map<TypeVariable, TypeDecl>)
     
    Declared in TypeVariableSubstitution.jrag at line 206
*/
    public TypeDecl instantiateParType(Map subst, boolean useHole) {
        TypeDecl instantiateParType_Map_boolean_value = instantiateParType_compute(subst, useHole);
        return instantiateParType_Map_boolean_value;
    }

    private TypeDecl instantiateParType_compute(Map subst, boolean useHole)  {
        WildcardSuperType ret = new WildcardSuperType();
        // set modifiers
        ret.setModifiers((Modifiers) getModifiers().fullCopy());
        // set body
        ret.setBodyDeclList(new List());
        // set bound
        ret.setAccess(getAccess().type().instantiateParType(subst, useHole).createBoundAccess());
        // set name
        ret.setID(ret.simpleName());
        return ret;
    }

    // Declared in WildcardsHeuristics.jrag at line 180
    public TypeDecl typeWithFlippedWilds(Class heur) {
        TypeDecl typeWithFlippedWilds_Class_value = typeWithFlippedWilds_compute(heur);
        return typeWithFlippedWilds_Class_value;
    }

    private TypeDecl typeWithFlippedWilds_compute(Class heur) {
        WildcardSuperType su = new WildcardSuperType();
        su.setModifiers((Modifiers) getModifiers().fullCopy());
        su.setBodyDeclList(new List());
        su.setAccess(getAccess().typeWithFlippedWilds(heur));
        su.setID(su.simpleName());
        // required to be able to print fullname.
        su.setParent(getParent());
        return su;
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
