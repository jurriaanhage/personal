
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


public class AbstractDot extends Access implements Cloneable {
    public void flushCache() {
        super.flushCache();
        isDAafter_Variable_values = null;
        isDUafter_Variable_values = null;
        type_computed = false;
        type_value = null;
        isDUbefore_Variable_values = null;
    }
    public Object clone() throws CloneNotSupportedException {
        AbstractDot node = (AbstractDot)super.clone();
        node.isDAafter_Variable_values = null;
        node.isDUafter_Variable_values = null;
        node.type_computed = false;
        node.type_value = null;
        node.isDUbefore_Variable_values = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          AbstractDot node = (AbstractDot)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        AbstractDot res = (AbstractDot)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in PrettyPrint.jadd at line 573


  public void toString(StringBuffer s) {
    getLeft().toString(s);
    if(!getRight().isArrayAccess())
      s.append(".");
    getRight().toString(s);
  }

    // Declared in ResolveAmbiguousNames.jrag at line 122



  // These are used by the parser to extract the last name which
  // will be replaced by a method name
  public Access extractLast() {
    return getRightNoTransform();
 }

    // Declared in ResolveAmbiguousNames.jrag at line 125

  public void replaceLast(Access access) {
    setRight(access);
  }

    // Declared in CodeGeneration.jrag at line 693

  public void emitStore(CodeGeneration gen) { lastAccess().emitStore(gen); }

    // Declared in CreateBCode.jrag at line 326

  public void createAssignSimpleLoadDest(CodeGeneration gen) {
    lastAccess().createAssignSimpleLoadDest(gen);
  }

    // Declared in CreateBCode.jrag at line 340

  public void createPushAssignmentResult(CodeGeneration gen) {
    lastAccess().createPushAssignmentResult(gen);
  }

    // Declared in CreateBCode.jrag at line 358

  public void createAssignLoadDest(CodeGeneration gen) {
    lastAccess().createAssignLoadDest(gen);
  }

    // Declared in CreateBCode.jrag at line 406


  public void createBCode(CodeGeneration gen) {
    lastAccess().createBCode(gen);
  }

    // Declared in CreateBCode.jrag at line 1118

  public void emitEvalBranch(CodeGeneration gen) { lastAccess().emitEvalBranch(gen); }

    // Declared in java.ast at line 3
    // Declared in java.ast line 13

    public AbstractDot() {
        super();

        setChild(null, 0);
        setChild(null, 1);

    }

    // Declared in java.ast at line 12


    // Declared in java.ast line 13
    public AbstractDot(Expr p0, Access p1) {
        setChild(p0, 0);
        setChild(p1, 1);
    }

    // Declared in java.ast at line 17


  protected int numChildren() {
    return 2;
  }

    // Declared in java.ast at line 20

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 13
    public void setLeft(Expr node) {
        setChild(node, 0);
    }

    // Declared in java.ast at line 5

    public Expr getLeft() {
        return (Expr)getChild(0);
    }

    // Declared in java.ast at line 9


    public Expr getLeftNoTransform() {
        return (Expr)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 13
    public void setRight(Access node) {
        setChild(node, 1);
    }

    // Declared in java.ast at line 5

    public Access getRight() {
        return (Access)getChild(1);
    }

    // Declared in java.ast at line 9


    public Access getRightNoTransform() {
        return (Access)getChildNoTransform(1);
    }

    // Declared in ConstantExpression.jrag at line 100
    public Constant constant() {
        Constant constant_value = constant_compute();
        return constant_value;
    }

    private Constant constant_compute() {  return  lastAccess().constant();  }

    // Declared in ConstantExpression.jrag at line 470
    public boolean isConstant() {
        boolean isConstant_value = isConstant_compute();
        return isConstant_value;
    }

    private boolean isConstant_compute() {  return  lastAccess().isConstant();  }

    // Declared in DefiniteAssignment.jrag at line 50
    public Variable varDecl() {
        Variable varDecl_value = varDecl_compute();
        return varDecl_value;
    }

    private Variable varDecl_compute() {  return  lastAccess().varDecl();  }

    // Declared in DefiniteAssignment.jrag at line 328
    public boolean isDAafterTrue(Variable v) {
        boolean isDAafterTrue_Variable_value = isDAafterTrue_compute(v);
        return isDAafterTrue_Variable_value;
    }

    private boolean isDAafterTrue_compute(Variable v) {  return  isDAafter(v);  }

    // Declared in DefiniteAssignment.jrag at line 329
    public boolean isDAafterFalse(Variable v) {
        boolean isDAafterFalse_Variable_value = isDAafterFalse_compute(v);
        return isDAafterFalse_Variable_value;
    }

    private boolean isDAafterFalse_compute(Variable v) {  return  isDAafter(v);  }

    protected java.util.Map isDAafter_Variable_values;
    // Declared in DefiniteAssignment.jrag at line 348
    public boolean isDAafter(Variable v) {
        Object _parameters = v;
if(isDAafter_Variable_values == null) isDAafter_Variable_values = new java.util.HashMap(4);
        if(isDAafter_Variable_values.containsKey(_parameters))
            return ((Boolean)isDAafter_Variable_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean isDAafter_Variable_value = isDAafter_compute(v);
        if(isFinal && num == boundariesCrossed)
            isDAafter_Variable_values.put(_parameters, Boolean.valueOf(isDAafter_Variable_value));
        return isDAafter_Variable_value;
    }

    private boolean isDAafter_compute(Variable v) {  return  lastAccess().isDAafter(v);  }

    // Declared in DefiniteAssignment.jrag at line 783
    public boolean isDUafterTrue(Variable v) {
        boolean isDUafterTrue_Variable_value = isDUafterTrue_compute(v);
        return isDUafterTrue_Variable_value;
    }

    private boolean isDUafterTrue_compute(Variable v) {  return  isDUafter(v);  }

    // Declared in DefiniteAssignment.jrag at line 784
    public boolean isDUafterFalse(Variable v) {
        boolean isDUafterFalse_Variable_value = isDUafterFalse_compute(v);
        return isDUafterFalse_Variable_value;
    }

    private boolean isDUafterFalse_compute(Variable v) {  return  isDUafter(v);  }

    protected java.util.Map isDUafter_Variable_values;
    // Declared in DefiniteAssignment.jrag at line 828
    public boolean isDUafter(Variable v) {
        Object _parameters = v;
if(isDUafter_Variable_values == null) isDUafter_Variable_values = new java.util.HashMap(4);
        if(isDUafter_Variable_values.containsKey(_parameters))
            return ((Boolean)isDUafter_Variable_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean isDUafter_Variable_value = isDUafter_compute(v);
        if(isFinal && num == boundariesCrossed)
            isDUafter_Variable_values.put(_parameters, Boolean.valueOf(isDUafter_Variable_value));
        return isDUafter_Variable_value;
    }

    private boolean isDUafter_compute(Variable v) {  return  lastAccess().isDUafter(v);  }

    // Declared in QualifiedNames.jrag at line 54
    public String typeName() {
        String typeName_value = typeName_compute();
        return typeName_value;
    }

    private String typeName_compute() {  return  lastAccess().typeName();  }

    // Declared in ResolveAmbiguousNames.jrag at line 6
    public boolean isTypeAccess() {
        boolean isTypeAccess_value = isTypeAccess_compute();
        return isTypeAccess_value;
    }

    private boolean isTypeAccess_compute() {  return  getRight().isTypeAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 9
    public boolean isMethodAccess() {
        boolean isMethodAccess_value = isMethodAccess_compute();
        return isMethodAccess_value;
    }

    private boolean isMethodAccess_compute() {  return  getRight().isMethodAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 13
    public boolean isFieldAccess() {
        boolean isFieldAccess_value = isFieldAccess_compute();
        return isFieldAccess_value;
    }

    private boolean isFieldAccess_compute() {  return  getRight().isFieldAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 17
    public boolean isSuperAccess() {
        boolean isSuperAccess_value = isSuperAccess_compute();
        return isSuperAccess_value;
    }

    private boolean isSuperAccess_compute() {  return  getRight().isSuperAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 23
    public boolean isThisAccess() {
        boolean isThisAccess_value = isThisAccess_compute();
        return isThisAccess_value;
    }

    private boolean isThisAccess_compute() {  return  getRight().isThisAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 29
    public boolean isPackageAccess() {
        boolean isPackageAccess_value = isPackageAccess_compute();
        return isPackageAccess_value;
    }

    private boolean isPackageAccess_compute() {  return  getRight().isPackageAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 33
    public boolean isArrayAccess() {
        boolean isArrayAccess_value = isArrayAccess_compute();
        return isArrayAccess_value;
    }

    private boolean isArrayAccess_compute() {  return  getRight().isArrayAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 37
    public boolean isClassAccess() {
        boolean isClassAccess_value = isClassAccess_compute();
        return isClassAccess_value;
    }

    private boolean isClassAccess_compute() {  return  getRight().isClassAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 41
    public boolean isSuperConstructorAccess() {
        boolean isSuperConstructorAccess_value = isSuperConstructorAccess_compute();
        return isSuperConstructorAccess_value;
    }

    private boolean isSuperConstructorAccess_compute() {  return  getRight().isSuperConstructorAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 50
    public boolean isQualified() {
        boolean isQualified_value = isQualified_compute();
        return isQualified_value;
    }

    private boolean isQualified_compute() {  return  hasParentDot();  }

    // Declared in ResolveAmbiguousNames.jrag at line 54
    public Expr leftSide() {
        Expr leftSide_value = leftSide_compute();
        return leftSide_value;
    }

    private Expr leftSide_compute() {  return  getLeft();  }

    // Declared in ResolveAmbiguousNames.jrag at line 55
    public Access rightSide() {
        Access rightSide_value = rightSide_compute();
        return rightSide_value;
    }

    private Access rightSide_compute() {  return  getRight/*NoTransform*/() instanceof AbstractDot ? (Access)((AbstractDot)getRight/*NoTransform*/()).getLeft() : (Access)getRight();  }

    // Declared in ResolveAmbiguousNames.jrag at line 58
    public Access lastAccess() {
        Access lastAccess_value = lastAccess_compute();
        return lastAccess_value;
    }

    private Access lastAccess_compute() {  return  getRight().lastAccess();  }

    // Declared in ResolveAmbiguousNames.jrag at line 66
    public Access nextAccess() {
        Access nextAccess_value = nextAccess_compute();
        return nextAccess_value;
    }

    private Access nextAccess_compute() {  return  rightSide();  }

    // Declared in ResolveAmbiguousNames.jrag at line 68
    public Expr prevExpr() {
        Expr prevExpr_value = prevExpr_compute();
        return prevExpr_value;
    }

    private Expr prevExpr_compute() {  return  leftSide();  }

    // Declared in ResolveAmbiguousNames.jrag at line 79
    public boolean hasPrevExpr() {
        boolean hasPrevExpr_value = hasPrevExpr_compute();
        return hasPrevExpr_value;
    }

    private boolean hasPrevExpr_compute() {  return  true;  }

    // Declared in SyntacticClassification.jrag at line 50
    public NameType predNameType() {
        NameType predNameType_value = predNameType_compute();
        return predNameType_value;
    }

    private NameType predNameType_compute() {  return  getLeft() instanceof Access ? ((Access)getLeft()).predNameType() : NameType.NO_NAME;  }

    // Declared in TypeAnalysis.jrag at line 241
    public TypeDecl type() {
        if(type_computed)
            return type_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        type_value = type_compute();
        if(isFinal && num == boundariesCrossed)
            type_computed = true;
        return type_value;
    }

    private TypeDecl type_compute() {  return  lastAccess().type();  }

    // Declared in TypeCheck.jrag at line 7
    public boolean isVariable() {
        boolean isVariable_value = isVariable_compute();
        return isVariable_value;
    }

    private boolean isVariable_compute() {  return  lastAccess().isVariable();  }

    // Declared in TypeHierarchyCheck.jrag at line 144
    public boolean staticContextQualifier() {
        boolean staticContextQualifier_value = staticContextQualifier_compute();
        return staticContextQualifier_value;
    }

    private boolean staticContextQualifier_compute() {  return  lastAccess().staticContextQualifier();  }

    // Declared in CreateBCode.jrag at line 201
    public boolean needsPop() {
        boolean needsPop_value = needsPop_compute();
        return needsPop_value;
    }

    private boolean needsPop_compute() {  return  lastAccess().needsPop();  }

    // Declared in CreateBCode.jrag at line 984
    public boolean definesLabel() {
        boolean definesLabel_value = definesLabel_compute();
        return definesLabel_value;
    }

    private boolean definesLabel_compute() {  return  getParent().definesLabel();  }

    // Declared in CreateBCode.jrag at line 1044
    public boolean canBeTrue() {
        boolean canBeTrue_value = canBeTrue_compute();
        return canBeTrue_value;
    }

    private boolean canBeTrue_compute() {  return  lastAccess().canBeTrue();  }

    // Declared in CreateBCode.jrag at line 1054
    public boolean canBeFalse() {
        boolean canBeFalse_value = canBeFalse_compute();
        return canBeFalse_value;
    }

    private boolean canBeFalse_compute() {  return  lastAccess().canBeFalse();  }

    protected java.util.Map isDUbefore_Variable_values;
    // Declared in DefiniteAssignment.jrag at line 687
    public boolean isDUbefore(Variable v) {
        Object _parameters = v;
if(isDUbefore_Variable_values == null) isDUbefore_Variable_values = new java.util.HashMap(4);
        if(isDUbefore_Variable_values.containsKey(_parameters))
            return ((Boolean)isDUbefore_Variable_values.get(_parameters)).booleanValue();
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        boolean isDUbefore_Variable_value = getParent().Define_boolean_isDUbefore(this, null, v);
        if(isFinal && num == boundariesCrossed)
            isDUbefore_Variable_values.put(_parameters, Boolean.valueOf(isDUbefore_Variable_value));
        return isDUbefore_Variable_value;
    }

    // Declared in DefiniteAssignment.jrag at line 347
    public boolean Define_boolean_isDAbefore(ASTNode caller, ASTNode child, Variable v) {
        if(caller == getRightNoTransform()) {
            return  getLeft().isDAafter(v);
        }
        return getParent().Define_boolean_isDAbefore(this, caller, v);
    }

    // Declared in LookupMethod.jrag at line 11
    public Expr Define_Expr_nestedScope(ASTNode caller, ASTNode child) {
        if(caller == getLeftNoTransform()) {
            return  isQualified() ? nestedScope() : this;
        }
        if(caller == getRightNoTransform()) {
            return  isQualified() ? nestedScope() : this;
        }
        return getParent().Define_Expr_nestedScope(this, caller);
    }

    // Declared in SyntacticClassification.jrag at line 49
    public NameType Define_NameType_nameType(ASTNode caller, ASTNode child) {
        if(caller == getLeftNoTransform()) {
            return  getRight().predNameType();
        }
        return getParent().Define_NameType_nameType(this, caller);
    }

    // Declared in LookupVariable.jrag at line 140
    public SimpleSet Define_SimpleSet_lookupVariable(ASTNode caller, ASTNode child, String name) {
        if(caller == getRightNoTransform()) {
            return  getLeft().qualifiedLookupVariable(name);
        }
        return getParent().Define_SimpleSet_lookupVariable(this, caller, name);
    }

    // Declared in LookupConstructor.jrag at line 16
    public Collection Define_Collection_lookupSuperConstructor(ASTNode caller, ASTNode child) {
        if(caller == getRightNoTransform()) {
            return  getLeft().type().lookupSuperConstructor();
        }
        return getParent().Define_Collection_lookupSuperConstructor(this, caller);
    }

    // Declared in TypeHierarchyCheck.jrag at line 4
    public String Define_String_methodHost(ASTNode caller, ASTNode child) {
        if(caller == getRightNoTransform()) {
            return  getLeft().type().typeName();
        }
        return getParent().Define_String_methodHost(this, caller);
    }

    // Declared in DefiniteAssignment.jrag at line 827
    public boolean Define_boolean_isDUbefore(ASTNode caller, ASTNode child, Variable v) {
        if(caller == getRightNoTransform()) {
            return  getLeft().isDUafter(v);
        }
        return getParent().Define_boolean_isDUbefore(this, caller, v);
    }

    // Declared in TypeCheck.jrag at line 436
    public TypeDecl Define_TypeDecl_enclosingInstance(ASTNode caller, ASTNode child) {
        if(caller == getRightNoTransform()) {
            return  getLeft().type();
        }
        return getParent().Define_TypeDecl_enclosingInstance(this, caller);
    }

    // Declared in LookupType.jrag at line 73
    public boolean Define_boolean_hasPackage(ASTNode caller, ASTNode child, String packageName) {
        if(caller == getRightNoTransform()) {
            return  getLeft().hasQualifiedPackage(packageName);
        }
        return getParent().Define_boolean_hasPackage(this, caller, packageName);
    }

    // Declared in LookupType.jrag at line 280
    public SimpleSet Define_SimpleSet_lookupType(ASTNode caller, ASTNode child, String name) {
        if(caller == getRightNoTransform()) {
            return  getLeft().qualifiedLookupType(name);
        }
        return getParent().Define_SimpleSet_lookupType(this, caller, name);
    }

    // Declared in DefiniteAssignment.jrag at line 22
    public boolean Define_boolean_isSource(ASTNode caller, ASTNode child) {
        if(caller == getLeftNoTransform()) {
            return  true;
        }
        return getParent().Define_boolean_isSource(this, caller);
    }

    // Declared in LookupConstructor.jrag at line 8
    public Collection Define_Collection_lookupConstructor(ASTNode caller, ASTNode child) {
        if(caller == getRightNoTransform()) {
            return  getLeft().type().constructors();
        }
        return getParent().Define_Collection_lookupConstructor(this, caller);
    }

    // Declared in LookupMethod.jrag at line 51
    public Collection Define_Collection_lookupMethod(ASTNode caller, ASTNode child, String name) {
        if(caller == getRightNoTransform()) {
            return  getLeft().type().memberMethods(name);
        }
        return getParent().Define_Collection_lookupMethod(this, caller, name);
    }

    // Declared in DefiniteAssignment.jrag at line 12
    public boolean Define_boolean_isDest(ASTNode caller, ASTNode child) {
        if(caller == getLeftNoTransform()) {
            return  false;
        }
        return getParent().Define_boolean_isDest(this, caller);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
