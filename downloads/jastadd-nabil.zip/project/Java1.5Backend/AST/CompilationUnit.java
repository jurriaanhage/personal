
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


// 7.3 Compilation Units
public class CompilationUnit extends ASTNode implements Cloneable {
    public void flushCache() {
        super.flushCache();
        localLookupType_String_values = null;
        packageName_computed = false;
        packageName_value = null;
        destinationPath_computed = false;
        destinationPath_value = null;
        lookupType_String_values = null;
    }
    public Object clone() throws CloneNotSupportedException {
        CompilationUnit node = (CompilationUnit)super.clone();
        node.localLookupType_String_values = null;
        node.packageName_computed = false;
        node.packageName_value = null;
        node.destinationPath_computed = false;
        node.destinationPath_value = null;
        node.lookupType_String_values = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          CompilationUnit node = (CompilationUnit)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        CompilationUnit res = (CompilationUnit)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in ClassPath.jrag at line 136


  private String relativeName;

    // Declared in ClassPath.jrag at line 137

  private String pathName;

    // Declared in ClassPath.jrag at line 138

  private boolean fromSource;

    // Declared in ClassPath.jrag at line 140


  public void setRelativeName(String name) {
    relativeName = name;
  }

    // Declared in ClassPath.jrag at line 143

  public void setPathName(String name) {
    pathName = name;
  }

    // Declared in ClassPath.jrag at line 146

  public void setFromSource(boolean value) {
    fromSource = value;
  }

    // Declared in ErrorCheck.jrag at line 63


  protected java.util.ArrayList errors = new java.util.ArrayList();

    // Declared in ErrorCheck.jrag at line 64

  protected java.util.ArrayList warnings = new java.util.ArrayList();

    // Declared in ErrorCheck.jrag at line 66


  public Collection parseErrors() { return parseErrors; }

    // Declared in ErrorCheck.jrag at line 67

  public void addParseError(Problem msg) { parseErrors.add(msg); }

    // Declared in ErrorCheck.jrag at line 68

  protected Collection parseErrors = new ArrayList();

    // Declared in ErrorCheck.jrag at line 226


  public void errorCheck(Collection collection) {
    collectErrors();
    collection.addAll(errors);
  }

    // Declared in ErrorCheck.jrag at line 230

  public void refined_ErrorCheck_errorCheck(Collection err, Collection warn) {
    collectErrors();
    err.addAll(errors);
    warn.addAll(warnings);
  }

    // Declared in NameCheck.jrag at line 23


  public void refined_NameCheck_nameCheck() {
    for(int i = 0; i < getNumImportDecl(); i++) {
      ImportDecl decl = getImportDecl(i);
      if(decl instanceof SingleTypeImportDecl) {
        if(!localLookupType(decl.getAccess().type().name()).contains(decl.getAccess().type()))
          error("" + decl + " is conflicting with visible type");
      }
    }
  }

    // Declared in PrettyPrint.jadd at line 34

        
  public void toString(StringBuffer s) {
    try {
      if(!getPackageDecl().equals("")) {
        s.append("package " + getPackageDecl() + ";\n");
      }
      for(int i = 0; i < getNumImportDecl(); i++) {
        getImportDecl(i).toString(s);
        s.append("\n");
      }
      for(int i = 0; i < getNumTypeDecl(); i++) {
        getTypeDecl(i).toString(s);
        s.append("\n");
      }
    } catch (NullPointerException e) {
      System.out.print("Error in compilation unit hosting " + getTypeDecl(0).typeName());
      throw e;
    }
  }

    // Declared in GenerateClassfile.jrag at line 9


  public void generateClassfile() {
    if(fromSource()) {
      for(int i = 0; i < getNumTypeDecl(); i++) {
        getTypeDecl(i).generateClassfile();
        getTypeDecl(i).clear();
      }
    }
  }

    // Declared in Transformations.jrag at line 9

  
  public void transformation() {
    if(fromSource()) {
      for(int i = 0; i < getNumTypeDecl(); i++) {
        getTypeDecl(i).transformation();
      }
    }
  }

    // Declared in Inference.jrag at line 491


    //-------------------------------------------------------------------------
    // Error collection
    //-------------------------------------------------------------------------
    private LinkedList typeErrorList = new LinkedList();

    // Declared in Inference.jrag at line 492

    protected void addTypeError(String msg){
        typeErrorList.add(msg);
    }

    // Declared in Testing.jadd at line 56



    private Map typeErrorMap;

    // Declared in Testing.jadd at line 58


    public void addErrorSet(String typeDecl, String prefix, ErrorSet set) {
       if (typeErrorMap == null) {
            typeErrorMap = new HashMap/*<String, Map<String, ErrorSet>>*/(3);
        }
        
        if (typeErrorMap.containsKey(typeDecl)) {            
            ((Map) typeErrorMap.get(typeDecl)).put(prefix, set);
        } else {
            //Map<String, ErrorSet> errorMap = new HashMap<String, ErrorSet>();
            Map errorMap = new HashMap(8);
            errorMap.put(prefix, set);
            typeErrorMap.put(typeDecl, errorMap);
        }
    }

    // Declared in Testing.jadd at line 73


    public Map getErrorMap() {
        return typeErrorMap;
    }

    // Declared in Testing.jadd at line 76

    private Map checkErrorMap;

    // Declared in Testing.jadd at line 78


    public void addCheckErrors(String shortName,
            Collection checkErrorList) {
        if (checkErrorMap == null) {
            checkErrorMap = new HashMap(3);
        }
        checkErrorMap.put(shortName, checkErrorList);
    }

    // Declared in Testing.jadd at line 86


    public Map getCheckErrorMap() {
        return checkErrorMap;
    }

    // Declared in Testing.jadd at line 90


	private Map extensions;

    // Declared in Testing.jadd at line 92


	public void addExtensions(String key, Map value) {
		if (extensions == null) {
			extensions = new HashMap(5);
		}
		extensions.put(key, value);
	}

    // Declared in Testing.jadd at line 99

	
	public Map getExtension(){
		return extensions;
	}

    // Declared in java.ast at line 3
    // Declared in java.ast line 4

    public CompilationUnit() {
        super();

        setChild(new List(), 0);
        setChild(new List(), 1);

    }

    // Declared in java.ast at line 12


    // Declared in java.ast line 4
    public CompilationUnit(String p0, List p1, List p2) {
        setPackageDecl(p0);
        setChild(p1, 0);
        setChild(p2, 1);
    }

    // Declared in java.ast at line 18


  protected int numChildren() {
    return 2;
  }

    // Declared in java.ast at line 21

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 4
    private String tokenString_PackageDecl;

    // Declared in java.ast at line 3

    public void setPackageDecl(String value) {
        tokenString_PackageDecl = value;
    }

    // Declared in java.ast at line 6

    public String getPackageDecl() {
        return tokenString_PackageDecl != null ? tokenString_PackageDecl : "";
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 4
    public void setImportDeclList(List list) {
        setChild(list, 0);
    }

    // Declared in java.ast at line 6


    private int getNumImportDecl = 0;

    // Declared in java.ast at line 7

    public int getNumImportDecl() {
        return getImportDeclList().getNumChild();
    }

    // Declared in java.ast at line 11


    public ImportDecl getImportDecl(int i) {
        return (ImportDecl)getImportDeclList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addImportDecl(ImportDecl node) {
        List list = getImportDeclList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setImportDecl(ImportDecl node, int i) {
        List list = getImportDeclList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getImportDeclList() {
        return (List)getChild(0);
    }

    // Declared in java.ast at line 28


    public List getImportDeclListNoTransform() {
        return (List)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 4
    public void setTypeDeclList(List list) {
        setChild(list, 1);
    }

    // Declared in java.ast at line 6


    private int getNumTypeDecl = 0;

    // Declared in java.ast at line 7

    public int getNumTypeDecl() {
        return getTypeDeclList().getNumChild();
    }

    // Declared in java.ast at line 11


    public TypeDecl getTypeDecl(int i) {
        return (TypeDecl)getTypeDeclList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addTypeDecl(TypeDecl node) {
        List list = getTypeDeclList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setTypeDecl(TypeDecl node, int i) {
        List list = getTypeDeclList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getTypeDeclList() {
        return (List)getChild(1);
    }

    // Declared in java.ast at line 28


    public List getTypeDeclListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Inference.jrag at line 504


      public void errorCheck(Collection err, Collection warn) {
        //collectTypeErrors();
        refined_ErrorCheck_errorCheck(err, warn);        
        if(typeErrorList.size() > 0)
            System.out.println("======================================");
        for(Iterator iter = typeErrorList.iterator(); iter.hasNext();)
            System.out.println(iter.next());
        if(typeErrorList.size() > 0)
            System.out.println("======================================");
    }

    // Declared in StaticImports.jrag at line 158


  /* A single-static-import declaration d in a compilation unit c of package p that
  imports a type named n shadows the declarations of:
    * any static type named n imported by a static-import-on-demand declaration in c.
    * any top level type (\u00df7.6) named n declared in another compilation unit (\u00df7.3) of p.
    * any type named n imported by a type-import-on-demand declaration (\u00df7.5.2) in c. 
  throughout c.
  Comment: already implemented by original type lookup
  */

  /* Note that it is permissable for one single-static-import declaration to import
  several fields or types with the same name, or several methods with the same
  name and signature.
  Comment: Name analysis already deals with sets*/

  /* If a compilation unit contains both a single-static-import (\u00df7.5.3) declaration
  that imports a type whose simple name is n, and a single-type-import
  declaration (\u00df7.5.1) that imports a type whose simple name is n, a compile-time
  error occurs.
  Comment: javac6 interprets this as "another" type whose simple name is n. Then
  nothing needs to be done.
  */

  /* If a single-static-import declaration imports a type whose simple name is n,
  and the compilation unit also declares a top level type (\u00df7.6) whose simple
  name is n, a compile-time error occurs.*/
    public void nameCheck() {
    refined_NameCheck_nameCheck();
    for(int i = 0; i < getNumImportDecl(); i++) {
      if(getImportDecl(i) instanceof SingleStaticImportDecl) {
        SingleStaticImportDecl decl = (SingleStaticImportDecl)getImportDecl(i);
        String name = decl.name();
        if(!decl.importedTypes(name).isEmpty()) {
          TypeDecl type = (TypeDecl)decl.importedTypes(name).iterator().next();
          if(!localLookupType(name).contains(type))
            decl.error(packageName() + "." + name + " is already defined in this compilation unit");
        }
      }
    }
  }

    // Declared in LookupType.jrag at line 179
private SimpleSet refined_LookupType_TypeDecl_lookupType_String(int childIndex, String name)
 {
    SimpleSet set = SimpleSet.emptySet;
    for(Iterator iter = localLookupType(name).iterator(); iter.hasNext(); ) {
      TypeDecl t = (TypeDecl)iter.next();
      if(t.accessibleFromPackage(packageName()))
        set = set.add(t);
    }
    return set;
  }

    // Declared in ClassPath.jrag at line 18
    public String relativeName() {
        String relativeName_value = relativeName_compute();
        return relativeName_value;
    }

    private String relativeName_compute() {  return  relativeName;  }

    // Declared in ClassPath.jrag at line 19
    public String pathName() {
        String pathName_value = pathName_compute();
        return pathName_value;
    }

    private String pathName_compute() {  return  pathName;  }

    // Declared in ClassPath.jrag at line 20
    public boolean fromSource() {
        boolean fromSource_value = fromSource_compute();
        return fromSource_value;
    }

    private boolean fromSource_compute() {  return  fromSource;  }

    protected java.util.Map localLookupType_String_values;
    // Declared in LookupType.jrag at line 386
    public SimpleSet localLookupType(String name) {
        Object _parameters = name;
if(localLookupType_String_values == null) localLookupType_String_values = new java.util.HashMap(4);
        if(localLookupType_String_values.containsKey(_parameters))
            return (SimpleSet)localLookupType_String_values.get(_parameters);
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        SimpleSet localLookupType_String_value = localLookupType_compute(name);
        if(isFinal && num == boundariesCrossed)
            localLookupType_String_values.put(_parameters, localLookupType_String_value);
        return localLookupType_String_value;
    }

    private SimpleSet localLookupType_compute(String name)  {
    for(int i = 0; i < getNumTypeDecl(); i++) {
      if(getTypeDecl(i).name().equals(name))
        return SimpleSet.emptySet.add(getTypeDecl(i));
    }
  
    SimpleSet set = SimpleSet.emptySet;
    // The scope of a type imported by a single-type-import declaration
    for(int i = 0; i < getNumImportDecl(); i++) {
      if(!getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedTypes(name).iterator(); iter.hasNext(); )
          set = set.add(iter.next());
    }
    if(!set.isEmpty()) return set;
    
    TypeDecl result = lookupType(packageName(), name);
    if(result != null)
      return SimpleSet.emptySet.add(result);
    
    // The scope of a type imported by a type-import-on-demand declaration
    for(int i = 0; i < getNumImportDecl(); i++) {
      if(getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedTypes(name).iterator(); iter.hasNext(); )
          set = set.add(iter.next());
    }
    if(!set.isEmpty()) return set;
    
    result = lookupType(PRIMITIVE_PACKAGE_NAME, name);
    if(result != null) {
      set = set.add(result);
      //throw new Error("Found an unexpected lookup for primitive type " + name);
      return set;
    }
    
    // 7.5.5 Automatic Imports
    result = lookupType("java.lang", name);
    if(result != null) {
      set = set.add(result);
      return set;
    }
    return set;
  }

    // Declared in PrettyPrint.jadd at line 906
    public String dumpString() {
        String dumpString_value = dumpString_compute();
        return dumpString_value;
    }

    private String dumpString_compute() {  return  getClass().getName() + " [" + getPackageDecl() + "]";  }

    protected boolean packageName_computed = false;
    protected String packageName_value;
    // Declared in QualifiedNames.jrag at line 83
    public String packageName() {
        if(packageName_computed)
            return packageName_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        packageName_value = packageName_compute();
        if(isFinal && num == boundariesCrossed)
            packageName_computed = true;
        return packageName_value;
    }

    private String packageName_compute() {  return  getPackageDecl();  }

    protected boolean destinationPath_computed = false;
    protected String destinationPath_value;
    // Declared in ConstantPoolNames.jrag at line 59
    public String destinationPath() {
        if(destinationPath_computed)
            return destinationPath_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        destinationPath_value = destinationPath_compute();
        if(isFinal && num == boundariesCrossed)
            destinationPath_computed = true;
        return destinationPath_value;
    }

    private String destinationPath_compute()  {
    if(Program.hasValueForOption("-d")) {
      return Program.getValueForOption("-d");
    }
    else {
      if(fromSource()) {
        // /home/torbjorn/sandbox/JavaCompiler/JCK/javasoft/sqe/tests/lang/icls045/icls04591m11/icls04591m11_c.java
        // package javasoft.sqe.tests.lang.icls045.icls04591m11_p class icls04591m11_c
        // /home/torbjorn/sandbox/JavaCompiler/JCK/javasoft/sqe/tests/lang/icls045/icls04591m11/icls04591m11.java
        // package javasoft.sqe.tests.lang.icls045.icls04591m11 class icls04591m11

        // ta paketnamnet p och om det har fler \u2030n 3 delar s\u00c2 kontrollera om det finns som substring i pathen
        // anv\u2030nd i s\u00c2 fall den delen av pathen
        // forts\u2030tt genom att ta bort sista delen i paketnamnet och g\u02c6r om proceduren
        // sluta n\u2030r namnet \u2030r mindre \u2030r 3 eller mindre
        
        String sourceName = pathName(); //relativeName();         // ex AST/Defines_AST_hello
        // extract source path including package directories
        String sourcePath = null;
        if(sourceName.lastIndexOf(java.io.File.separator) == -1)
          sourcePath = ".";
        else
          sourcePath = sourceName.substring(0, sourceName.lastIndexOf(java.io.File.separator));
        String sourcePathPattern = sourcePath.replace(java.io.File.separatorChar, '.');
        String[] parts = packageName().split("\\.");
        int num = parts.length;
        while(num > 3) {
          StringBuffer packagePattern = new StringBuffer();
          for(int i = 0; i < num; i++) {
            if(i != 0) packagePattern.append(".");
            packagePattern.append(parts[i]);
          }
          int index = sourcePathPattern.lastIndexOf(packagePattern.toString());
          if(index > 0) {
            return sourcePath.substring(0, index-1);
          }
          num--;
        }
          
        //System.err.println("SourcePath: " + sourcePath);
        //String[] parts = packageName().split("\\.");
        int k = parts.length - 1;
        while(k >= 0 && !sourcePath.endsWith(parts[k])) {
          //System.err.println(sourcePath + " does not end with " + parts[k]);
          k--;
        }
        if(k >= 0) {
          for(int i = k; i >= 0; i--) {
            sourcePath = sourcePath.substring(0, sourcePath.lastIndexOf(parts[i]));
            //System.err.println("new candidate is " + sourcePath);
          }
        }
        if(sourcePath.equals(""))
          sourcePath = ".";
        //System.err.println("SourcePath after: " + sourcePath);
        return sourcePath;
        /*
        // extract first part of package name
        String prefix;
        int pos = packageName().indexOf('.');       // AST
        if(pos != -1)
          prefix = packageName().substring(0, pos-1);
        else
          prefix = packageName();
        // add separator
        prefix = prefix + java.io.File.separator;
        // find last occurance
        pos = sourceName.lastIndexOf(prefix);
        if(pos > 0 && !packageName().equals(""))
          return sourceName.substring(0, pos-1);
        */
      }
      if(pathName != null)
        return pathName;
      else
        return ".";
    }
  }

    // Declared in LookupType.jrag at line 90
    public TypeDecl lookupType(String packageName, String typeName) {
        TypeDecl lookupType_String_String_value = getParent().Define_TypeDecl_lookupType(this, null, packageName, typeName);
        return lookupType_String_String_value;
    }

    protected java.util.Map lookupType_String_values;
    // Declared in LookupType.jrag at line 170
    public SimpleSet lookupType(String name) {
        Object _parameters = name;
if(lookupType_String_values == null) lookupType_String_values = new java.util.HashMap(4);
        if(lookupType_String_values.containsKey(_parameters))
            return (SimpleSet)lookupType_String_values.get(_parameters);
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        SimpleSet lookupType_String_value = getParent().Define_SimpleSet_lookupType(this, null, name);
        if(isFinal && num == boundariesCrossed)
            lookupType_String_values.put(_parameters, lookupType_String_value);
        return lookupType_String_value;
    }

    // Declared in StaticImports.jrag at line 111
    public SimpleSet lookupVariable(String name) {
        SimpleSet lookupVariable_String_value = getParent().Define_SimpleSet_lookupVariable(this, null, name);
        return lookupVariable_String_value;
    }

    // Declared in StaticImports.jrag at line 131
    public Collection lookupMethod(String name) {
        Collection lookupMethod_String_value = getParent().Define_Collection_lookupMethod(this, null, name);
        return lookupMethod_String_value;
    }

    // Declared in SyntacticClassification.jrag at line 59
    public NameType Define_NameType_nameType(ASTNode caller, ASTNode child) {
        if(caller == getImportDeclListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  NameType.PACKAGE_NAME;
        }
        return getParent().Define_NameType_nameType(this, caller);
    }

    // Declared in StaticImports.jrag at line 95
    public SimpleSet Define_SimpleSet_lookupVariable(ASTNode caller, ASTNode child, String name) {
        if(caller == getTypeDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    SimpleSet set = SimpleSet.emptySet;
    for(int i = 0; i < getNumImportDecl(); i++)
      if(!getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedFields(name).iterator(); iter.hasNext(); )
          set = set.add(iter.next());
    if(!set.isEmpty())
      return set;
    for(int i = 0; i < getNumImportDecl(); i++)
      if(getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedFields(name).iterator(); iter.hasNext(); )
          set = set.add(iter.next());
    if(!set.isEmpty())
      return set;
    return lookupVariable(name);
  }
}
        return getParent().Define_SimpleSet_lookupVariable(this, caller, name);
    }

    // Declared in TypeAnalysis.jrag at line 558
    public TypeDecl Define_TypeDecl_hostType(ASTNode caller, ASTNode child) {
        if(caller == getImportDeclListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  null;
        }
        return getParent().Define_TypeDecl_hostType(this, caller);
    }

    // Declared in StaticImports.jrag at line 175
    public boolean Define_boolean_handlesException(ASTNode caller, ASTNode child, TypeDecl exceptionType) {
        if(caller == getImportDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    return !exceptionType.isUncheckedException();
  }
}
        if(caller == getTypeDeclListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return 
    !exceptionType.isUncheckedException();
        }
        return getParent().Define_boolean_handlesException(this, caller, exceptionType);
    }

    // Declared in TypeAnalysis.jrag at line 520
    public boolean Define_boolean_isLocalClass(ASTNode caller, ASTNode child) {
        if(true) {
      int childIndex = this.getIndexOfChild(caller);
            return  false;
        }
        return getParent().Define_boolean_isLocalClass(this, caller);
    }

    // Declared in TypeAnalysis.jrag at line 498
    public boolean Define_boolean_isNestedType(ASTNode caller, ASTNode child) {
        if(true) {
      int childIndex = this.getIndexOfChild(caller);
            return  false;
        }
        return getParent().Define_boolean_isNestedType(this, caller);
    }

    // Declared in Attributes.jrag at line 157
    public CompilationUnit Define_CompilationUnit_compilationUnit(ASTNode caller, ASTNode child) {
        if(caller == getImportDeclListNoTransform()) {
      int i = caller.getIndexOfChild(child);
            return  this;
        }
        if(caller == getTypeDeclListNoTransform()) {
      int i = caller.getIndexOfChild(child);
            return  this;
        }
        return getParent().Define_CompilationUnit_compilationUnit(this, caller);
    }

    // Declared in LookupType.jrag at line 190
    public SimpleSet Define_SimpleSet_lookupType(ASTNode caller, ASTNode child, String name) {
        if(caller == getImportDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    /*
    for(int i = 0; i < getNumImportDecl(); i++)
      if(!getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedTypes(name).iterator(); iter.hasNext(); )
          return SimpleSet.emptySet.add(iter.next());
    */
    return lookupType(name);
  }
}
        if(caller == getTypeDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    SimpleSet result = SimpleSet.emptySet;
    for(Iterator iter = refined_LookupType_TypeDecl_lookupType_String(childIndex, name).iterator(); iter.hasNext(); ) {
      TypeDecl typeDecl = (TypeDecl)iter.next();
      if(typeDecl instanceof ParTypeDecl)
        result = result.add(((ParTypeDecl)typeDecl).genericDecl());
      else
        result = result.add(typeDecl);
    }
    return result;
  }
}
        return getParent().Define_SimpleSet_lookupType(this, caller, name);
    }

    // Declared in QualifiedNames.jrag at line 81
    public String Define_String_packageName(ASTNode caller, ASTNode child) {
        if(true) {
      int childIndex = this.getIndexOfChild(caller);
            return  packageName();
        }
        return getParent().Define_String_packageName(this, caller);
    }

    // Declared in TypeAnalysis.jrag at line 508
    public boolean Define_boolean_isMemberType(ASTNode caller, ASTNode child) {
        if(caller == getTypeDeclListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  false;
        }
        return getParent().Define_boolean_isMemberType(this, caller);
    }

    // Declared in TypeAnalysis.jrag at line 542
    public String Define_String_hostPackage(ASTNode caller, ASTNode child) {
        if(true) {
      int childIndex = this.getIndexOfChild(caller);
            return  packageName();
        }
        return getParent().Define_String_hostPackage(this, caller);
    }

    // Declared in LookupType.jrag at line 201
    public SimpleSet Define_SimpleSet_lookupImport(ASTNode caller, ASTNode child, String name) {
        if(caller == getImportDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    for(int i = 0; i < getNumImportDecl(); i++)
      if(!getImportDecl(i).isOnDemand())
        for(Iterator iter = getImportDecl(i).importedTypes(name).iterator(); iter.hasNext(); )
          return SimpleSet.emptySet.add(iter.next());
    return SimpleSet.emptySet;
  }
}
        return getParent().Define_SimpleSet_lookupImport(this, caller, name);
    }

    // Declared in DefiniteAssignment.jrag at line 42
    public boolean Define_boolean_isIncOrDec(ASTNode caller, ASTNode child) {
        if(caller == getTypeDeclListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  false;
        }
        return getParent().Define_boolean_isIncOrDec(this, caller);
    }

    // Declared in StaticImports.jrag at line 117
    public Collection Define_Collection_lookupMethod(ASTNode caller, ASTNode child, String name) {
        if(caller == getTypeDeclListNoTransform()) { 
   int childIndex = caller.getIndexOfChild(child);
 {
    Collection list = new ArrayList();
    for(int i = 0; i < getNumImportDecl(); i++)
      if(!getImportDecl(i).isOnDemand())
        list.addAll(getImportDecl(i).importedMethods(name));
    if(!list.isEmpty()) 
      return list;
    for(int i = 0; i < getNumImportDecl(); i++)
      if(getImportDecl(i).isOnDemand())
        list.addAll(getImportDecl(i).importedMethods(name));
    if(!list.isEmpty())
      return list;
    return lookupMethod(name);
  }
}
        return getParent().Define_Collection_lookupMethod(this, caller, name);
    }

    // Declared in TypeAnalysis.jrag at line 477
    public TypeDecl Define_TypeDecl_enclosingType(ASTNode caller, ASTNode child) {
        if(true) {
      int childIndex = this.getIndexOfChild(caller);
            return  null;
        }
        return getParent().Define_TypeDecl_enclosingType(this, caller);
    }

    // Declared in ConstantPoolNames.jrag at line 57
    public String Define_String_destinationPath(ASTNode caller, ASTNode child) {
        if(caller == getImportDeclListNoTransform()) {
      int index = caller.getIndexOfChild(child);
            return  destinationPath();
        }
        if(caller == getTypeDeclListNoTransform()) {
      int index = caller.getIndexOfChild(child);
            return  destinationPath();
        }
        return getParent().Define_String_destinationPath(this, caller);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
