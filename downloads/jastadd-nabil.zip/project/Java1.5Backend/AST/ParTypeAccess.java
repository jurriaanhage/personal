
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


// parameterized type access
public class ParTypeAccess extends Access implements Cloneable {
    public void flushCache() {
        super.flushCache();
        type_computed = false;
        type_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        ParTypeAccess node = (ParTypeAccess)super.clone();
        node.type_computed = false;
        node.type_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          ParTypeAccess node = (ParTypeAccess)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        ParTypeAccess res = (ParTypeAccess)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in Generics.jrag at line 220

  public boolean isRaw() {
    return false;
  }

    // Declared in Generics.jrag at line 321


  public void typeCheck() {
    super.typeCheck();
    if(!genericDecl().isUnknown()) {
      if(!genericDecl().isGenericType()) {
        error(genericDecl().typeName() + " is not a generic type but used as one in " + this);
      }
      else {
        GenericTypeDecl decl = (GenericTypeDecl)genericDecl();
        GenericTypeDecl original = (GenericTypeDecl)decl.original();
        if(original.getNumTypeParameter() != getNumTypeArgument()) {
          error(decl.typeName() + " takes " + original.getNumTypeParameter() + " type parameters, not " + getNumTypeArgument() + " as used in " + this);
        }
        else {
          ParTypeDecl typeDecl = (ParTypeDecl)type();
          for(int i = 0; i < getNumTypeArgument(); i++) {
            if(!getTypeArgument(i).type().instanceOf(original.getTypeParameter(i))) {
              error("type argument " + i + " is of type " + getTypeArgument(i).type().typeName() 
                  + " which is not a subtype of " + original.getTypeParameter(i).typeName());
            }
          }
        }
      }
    }
  }

    // Declared in GenericsPrettyPrint.jrag at line 14


  public void toString(StringBuffer s) {
    getTypeAccess().toString(s);
    s.append("<");
    for(int i = 0; i < getNumTypeArgument(); i++) {
      if(i != 0)
        s.append(", ");
      getTypeArgument(i).toString(s);
    }
    s.append(">");
  }

    // Declared in Generics.ast at line 3
    // Declared in Generics.ast line 13

    public ParTypeAccess() {
        super();

        setChild(null, 0);
        setChild(new List(), 1);

    }

    // Declared in Generics.ast at line 12


    // Declared in Generics.ast line 13
    public ParTypeAccess(Access p0, List p1) {
        setChild(p0, 0);
        setChild(p1, 1);
    }

    // Declared in Generics.ast at line 17


  protected int numChildren() {
    return 2;
  }

    // Declared in Generics.ast at line 20

  public boolean mayHaveRewrite() { return false; }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 13
    public void setTypeAccess(Access node) {
        setChild(node, 0);
    }

    // Declared in Generics.ast at line 5

    public Access getTypeAccess() {
        return (Access)getChild(0);
    }

    // Declared in Generics.ast at line 9


    public Access getTypeAccessNoTransform() {
        return (Access)getChildNoTransform(0);
    }

    // Declared in Generics.ast at line 2
    // Declared in Generics.ast line 13
    public void setTypeArgumentList(List list) {
        setChild(list, 1);
    }

    // Declared in Generics.ast at line 6


    private int getNumTypeArgument = 0;

    // Declared in Generics.ast at line 7

    public int getNumTypeArgument() {
        return getTypeArgumentList().getNumChild();
    }

    // Declared in Generics.ast at line 11


    public Access getTypeArgument(int i) {
        return (Access)getTypeArgumentList().getChild(i);
    }

    // Declared in Generics.ast at line 15


    public void addTypeArgument(Access node) {
        List list = getTypeArgumentList();
        list.addChild(node);
    }

    // Declared in Generics.ast at line 20


    public void setTypeArgument(Access node, int i) {
        List list = getTypeArgumentList();
        list.setChild(node, i);
    }

    // Declared in Generics.ast at line 24

    public List getTypeArgumentList() {
        return (List)getChild(1);
    }

    // Declared in Generics.ast at line 28


    public List getTypeArgumentListNoTransform() {
        return (List)getChildNoTransform(1);
    }

    // Declared in Generics.jrag at line 180
    public Expr unqualifiedScope() {
        Expr unqualifiedScope_value = unqualifiedScope_compute();
        return unqualifiedScope_value;
    }

    private Expr unqualifiedScope_compute() {  return  getParent() instanceof Access ? ((Access)getParent()).unqualifiedScope() : super.unqualifiedScope();  }

    // Declared in Generics.jrag at line 183
    public TypeDecl type() {
        if(type_computed)
            return type_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        type_value = type_compute();
        if(isFinal && num == boundariesCrossed)
            type_computed = true;
        return type_value;
    }

    private TypeDecl type_compute()  {
    TypeDecl typeDecl = genericDecl();
    if(typeDecl instanceof GenericTypeDecl) {
      // use signature in lookup for types that are used in extends and implements clauses
      if(unqualifiedScope().getParent().getParent() instanceof TypeDecl)
        return ((GenericTypeDecl)typeDecl).lookupParTypeDecl(this);
      ArrayList args = new ArrayList();
      for(int i = 0; i < getNumTypeArgument(); i++)
        args.add(getTypeArgument(i).type());
      return ((GenericTypeDecl)typeDecl).lookupParTypeDecl(args);
    }
    return typeDecl;
  }

    // Declared in Generics.jrag at line 196
    public TypeDecl genericDecl() {
        TypeDecl genericDecl_value = genericDecl_compute();
        return genericDecl_value;
    }

    private TypeDecl genericDecl_compute() {  return  getTypeAccess().type();  }

    // Declared in Generics.jrag at line 197
    public boolean isTypeAccess() {
        boolean isTypeAccess_value = isTypeAccess_compute();
        return isTypeAccess_value;
    }

    private boolean isTypeAccess_compute() {  return  true;  }

    // Declared in GenericNamesAndTypes.jrag at line 311
    public String sourceLocation(LinkedList posList) {
        String sourceLocation_LinkedList_value = sourceLocation_compute(posList);
        return sourceLocation_LinkedList_value;
    }

    private String sourceLocation_compute(LinkedList posList) {
        ParTypeAccess cur = this;
        Access last = cur;
        for(int i=0; i < posList.size(); i++){
            int idx = ((Integer) posList.get(i)).intValue();
            if (idx < getNumTypeArgument()
                    && cur.getTypeArgument(idx) instanceof ParTypeAccess)
                cur = (ParTypeAccess) cur.getTypeArgument(idx);
            else{
                last = cur.getTypeArgument(idx);
                break;
            }
        }

        return last.location() + ":" + getColumn(last.getStart());
    }

    // Declared in Generics.jrag at line 181
    public SimpleSet Define_SimpleSet_lookupType(ASTNode caller, ASTNode child, String name) {
        if(caller == getTypeArgumentListNoTransform()) {
      int childIndex = caller.getIndexOfChild(child);
            return  unqualifiedScope().lookupType(name);
        }
        return getParent().Define_SimpleSet_lookupType(this, caller, name);
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
