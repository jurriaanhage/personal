
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;

public class AnnotationMethodDecl extends MethodDecl implements Cloneable {
    public void flushCache() {
        super.flushCache();
        attributes_computed = false;
        attributes_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        AnnotationMethodDecl node = (AnnotationMethodDecl)super.clone();
        node.attributes_computed = false;
        node.attributes_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    public ASTNode copy() {
      try {
          AnnotationMethodDecl node = (AnnotationMethodDecl)clone();
          if(children != null) node.children = (ASTNode[])children.clone();
          return node;
      } catch (CloneNotSupportedException e) {
      }
      System.err.println("Error: Could not clone node of type " + getClass().getName() + "!");
      return null;
    }
    public ASTNode fullCopy() {
        AnnotationMethodDecl res = (AnnotationMethodDecl)copy();
        for(int i = 0; i < getNumChildNoTransform(); i++) {
          ASTNode node = getChildNoTransform(i);
          if(node != null) node = node.fullCopy();
          res.setChild(node, i);
        }
        return res;
    }
    // Declared in Annotations.jrag at line 150


  /* An ElementValue is used to specify a default value. It is a compile-time error
  if the type of the element is not commensurate (\u00df9.7) with the default value
  specified. An ElementValue is always FP-strict (\u00df15.4).*/
  public void typeCheck() {
    super.typeCheck();
    if(hasDefaultValue() && !type().commensurateWith(getDefaultValue()))
      error(type().typeName() + " is not commensurate with " + getDefaultValue().type().typeName());
  }

    // Declared in Annotations.ast at line 3
    // Declared in Annotations.ast line 3

    public AnnotationMethodDecl() {
        super();

        setChild(null, 0);
        setChild(null, 1);
        setChild(new List(), 2);
        setChild(new List(), 3);
        setChild(new Opt(), 4);
        setChild(new Opt(), 5);

    }

    // Declared in Annotations.ast at line 16


    // Declared in Annotations.ast line 3
    public AnnotationMethodDecl(Modifiers p0, Access p1, String p2, List p3, List p4, Opt p5, Opt p6) {
        setChild(p0, 0);
        setChild(p1, 1);
        setID(p2);
        setChild(p3, 2);
        setChild(p4, 3);
        setChild(p5, 4);
        setChild(p6, 5);
    }

    // Declared in Annotations.ast at line 26


  protected int numChildren() {
    return 6;
  }

    // Declared in Annotations.ast at line 29

  public boolean mayHaveRewrite() { return false; }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setModifiers(Modifiers node) {
        setChild(node, 0);
    }

    // Declared in java.ast at line 5

    public Modifiers getModifiers() {
        return (Modifiers)getChild(0);
    }

    // Declared in java.ast at line 9


    public Modifiers getModifiersNoTransform() {
        return (Modifiers)getChildNoTransform(0);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setTypeAccess(Access node) {
        setChild(node, 1);
    }

    // Declared in java.ast at line 5

    public Access getTypeAccess() {
        return (Access)getChild(1);
    }

    // Declared in java.ast at line 9


    public Access getTypeAccessNoTransform() {
        return (Access)getChildNoTransform(1);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    private String tokenString_ID;

    // Declared in java.ast at line 3

    public void setID(String value) {
        tokenString_ID = value;
    }

    // Declared in java.ast at line 6

    public String getID() {
        return tokenString_ID != null ? tokenString_ID : "";
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setParameterList(List list) {
        setChild(list, 2);
    }

    // Declared in java.ast at line 6


    private int getNumParameter = 0;

    // Declared in java.ast at line 7

    public int getNumParameter() {
        return getParameterList().getNumChild();
    }

    // Declared in java.ast at line 11


    public ParameterDeclaration getParameter(int i) {
        return (ParameterDeclaration)getParameterList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addParameter(ParameterDeclaration node) {
        List list = getParameterList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setParameter(ParameterDeclaration node, int i) {
        List list = getParameterList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getParameterList() {
        return (List)getChild(2);
    }

    // Declared in java.ast at line 28


    public List getParameterListNoTransform() {
        return (List)getChildNoTransform(2);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setExceptionList(List list) {
        setChild(list, 3);
    }

    // Declared in java.ast at line 6


    private int getNumException = 0;

    // Declared in java.ast at line 7

    public int getNumException() {
        return getExceptionList().getNumChild();
    }

    // Declared in java.ast at line 11


    public Access getException(int i) {
        return (Access)getExceptionList().getChild(i);
    }

    // Declared in java.ast at line 15


    public void addException(Access node) {
        List list = getExceptionList();
        list.addChild(node);
    }

    // Declared in java.ast at line 20


    public void setException(Access node, int i) {
        List list = getExceptionList();
        list.setChild(node, i);
    }

    // Declared in java.ast at line 24

    public List getExceptionList() {
        return (List)getChild(3);
    }

    // Declared in java.ast at line 28


    public List getExceptionListNoTransform() {
        return (List)getChildNoTransform(3);
    }

    // Declared in java.ast at line 2
    // Declared in java.ast line 88
    public void setBlockOpt(Opt opt) {
        setChild(opt, 4);
    }

    // Declared in java.ast at line 6


    public boolean hasBlock() {
        return getBlockOpt().getNumChild() != 0;
    }

    // Declared in java.ast at line 10


    public Block getBlock() {
        return (Block)getBlockOpt().getChild(0);
    }

    // Declared in java.ast at line 14


    public void setBlock(Block node) {
        getBlockOpt().setChild(node, 0);
    }

    // Declared in java.ast at line 17

    public Opt getBlockOpt() {
        return (Opt)getChild(4);
    }

    // Declared in java.ast at line 21


    public Opt getBlockOptNoTransform() {
        return (Opt)getChildNoTransform(4);
    }

    // Declared in Annotations.ast at line 2
    // Declared in Annotations.ast line 3
    public void setDefaultValueOpt(Opt opt) {
        setChild(opt, 5);
    }

    // Declared in Annotations.ast at line 6


    public boolean hasDefaultValue() {
        return getDefaultValueOpt().getNumChild() != 0;
    }

    // Declared in Annotations.ast at line 10


    public ElementValue getDefaultValue() {
        return (ElementValue)getDefaultValueOpt().getChild(0);
    }

    // Declared in Annotations.ast at line 14


    public void setDefaultValue(ElementValue node) {
        getDefaultValueOpt().setChild(node, 0);
    }

    // Declared in Annotations.ast at line 17

    public Opt getDefaultValueOpt() {
        return (Opt)getChild(5);
    }

    // Declared in Annotations.ast at line 21


    public Opt getDefaultValueOptNoTransform() {
        return (Opt)getChildNoTransform(5);
    }

    // Declared in AnnotationsCodegen.jrag at line 136
    public Collection attributes() {
        if(attributes_computed)
            return attributes_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        attributes_value = attributes_compute();
        if(isFinal && num == boundariesCrossed)
            attributes_computed = true;
        return attributes_value;
    }

    private Collection attributes_compute()  {
    Collection c = super.attributes();
    // 4.8.19
    if(hasDefaultValue()) {
      Attribute attribute = new Attribute(hostType().constantPool(), "AnnotationDefault");
      getDefaultValue().appendAsAttributeTo(attribute);
      c.add(attribute);
    }
    return c;
  }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
