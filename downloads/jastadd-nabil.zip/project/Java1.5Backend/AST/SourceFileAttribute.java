
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


  public class SourceFileAttribute extends Attribute {
    // Declared in Attributes.jrag at line 29
    public SourceFileAttribute(ConstantPool p, String sourcefile) {
      super(p, "SourceFile");
      u2(p.addUtf8(sourcefile));
    }


}
