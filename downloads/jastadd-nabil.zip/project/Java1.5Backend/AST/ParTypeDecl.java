
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;



  public interface ParTypeDecl extends  Parameterization {
    // Declared in Generics.jrag at line 160

    //syn String name();
    int getNumArgument();

    // Declared in Generics.jrag at line 161

    Access getArgument(int index);

    // Declared in Generics.jrag at line 164

    public String typeName();

    // Declared in Generics.jrag at line 585

  public TypeDecl substitute(TypeVariable typeVariable);


    // Declared in Generics.jrag at line 598


  public int numTypeParameter();


    // Declared in Generics.jrag at line 601

  public TypeVariable typeParameter(int index);


    // Declared in Generics.jrag at line 626

  public Access substitute(Parameterization parTypeDecl);


    // Declared in GenericsParTypeDecl.jrag at line 76

  
  public Access createQualifiedAccess();


    // Declared in GenericsCodegen.jrag at line 322


  public void transformation();


    // Declared in GenericNamesAndTypes.jrag at line 178


    public String nameWithFlippedWildcards(final Class heur);


    // Declared in SuperObjectHeuristic.jrag at line 44

    
    public boolean containedIn(ParTypeDecl type, ArrayList indices, ArrayList excList);


    // Declared in TypeVariableSubstitution.jrag at line 54


    /**
     * Create new argument list for a ParTypeDecl
     * @param a
     * @return
     */
    public List createNewArgumentList();


    // Declared in TypeVariableSubstitution.jrag at line 219


    public AST.List createNewArgumentList(Map subst,boolean useHole);


    // Declared in Generics.jrag at line 162
    public boolean isParameterizedType();
    // Declared in Generics.jrag at line 163
    public boolean isRawType();
    // Declared in Generics.jrag at line 263
    public boolean sameArgument(ParTypeDecl decl);
    // Declared in Generics.jrag at line 451
    public boolean sameSignature(Access a);
    // Declared in Generics.jrag at line 486
    public boolean sameSignature(ArrayList list);
    // Declared in Generics.jrag at line 803
    public HashMap localMethodsSignatureMap();
    // Declared in Generics.jrag at line 818
    public SimpleSet fields(String name);
    // Declared in Generics.jrag at line 833
    public SimpleSet memberTypes(String name);
    // Declared in Generics.jrag at line 872
    public Collection constructors();
    // Declared in GenericsParTypeDecl.jrag at line 21
    public String nameWithArgs();
    // Declared in GenericNamesAndTypes.jrag at line 18
    public Set getTypeVariables();
    // Declared in GenericNamesAndTypes.jrag at line 54
    public String simpleName();
    // Declared in SimpleTypeEdit.jrag at line 21
    public LinkedList flatten();
/**
     * Return a list of indices for type arguments that do not match. For
     * example:
     * <p>
     * {@code Map<String, Object> <: List<String, Number>} gives a single list
     * containing the index 1, because Object does not match Number.
     * 
     * @param type
     *            a parameter that is a supertype of this type.
     * @param excList
     *            a parameter that containt indices of type argument that 
     *            don't have to be checked.
     * @return a list of indices for which the type argumuments at these
     *         specific indices in this type do not match the type arguments in
     *         the paramter type.
     
    Declared in SuperObjectHeuristic.jrag at line 30
*/
    public ArrayList containedIn(ParTypeDecl type, ArrayList excList);
    // Declared in WildcardsHeuristics.jrag at line 118
    public TypeDecl typeWithFlippedWilds(Class heur);
    // Declared in GenericsParTypeDecl.jrag at line 36
    public TypeDecl genericDecl();
}
