
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


public abstract class Access extends Expr implements Cloneable {
    public void flushCache() {
        super.flushCache();
        prevExpr_computed = false;
        prevExpr_value = null;
        hasPrevExpr_computed = false;
        type_computed = false;
        type_value = null;
        getTypeVariables_computed = false;
        getTypeVariables_value = null;
    }
    public Object clone() throws CloneNotSupportedException {
        Access node = (Access)super.clone();
        node.prevExpr_computed = false;
        node.prevExpr_value = null;
        node.hasPrevExpr_computed = false;
        node.type_computed = false;
        node.type_value = null;
        node.getTypeVariables_computed = false;
        node.getTypeVariables_value = null;
        node.in$Circle(false);
        node.is$Final(false);
    return node;
    }
    // Declared in ResolveAmbiguousNames.jrag at line 135


  public Access addArrayDims(List list) {
    Access a = this;
    for(int i = 0; i < list.getNumChildNoTransform(); i++) {
      Dims dims = (Dims)list.getChildNoTransform(i);
      Opt opt = dims.getExprOpt();
      if(opt.getNumChildNoTransform() == 1)
        a = new ArrayTypeWithSizeAccess(a, (Expr)opt.getChildNoTransform(0));
      else
        a = new ArrayTypeAccess(a);
    }
    return a;
  }

    // Declared in CreateBCode.jrag at line 451

  public void emitLoadLocalInNestedClass(CodeGeneration gen, Variable v) {
    if(inExplicitConstructorInvocation() && enclosingBodyDecl() instanceof ConstructorDecl) {
      ConstructorDecl c = (ConstructorDecl)enclosingBodyDecl();
      v.type().emitLoadLocal(gen, c.localIndexOfEnclosingVariable(v));
    }
    else {
      String classname = hostType().constantPoolName();
      String      desc = v.type().typeDescriptor();
      String      name = "val$" + v.name();
      int index = gen.constantPool().addFieldref(classname, name, desc);
      gen.emit(Bytecode.ALOAD_0);
      gen.emit(Bytecode.GETFIELD, v.type().variableSize() - 1).add2(index);
    }
  }

    // Declared in CreateBCode.jrag at line 605


  // load this where hostType is the target this instance 
  // supporting inner classes and in explicit contructor invocations
  public void emitThis(CodeGeneration gen, TypeDecl targetDecl) {
    if(targetDecl == hostType())
      gen.emit(Bytecode.ALOAD_0);
    else {
      TypeDecl enclosing = hostType();
      if(inExplicitConstructorInvocation()) {
        gen.emit(Bytecode.ALOAD_1);
        enclosing = enclosing.enclosing();
      }
      else {
        gen.emit(Bytecode.ALOAD_0);
      }
      while(enclosing != targetDecl) {
        String classname = enclosing.constantPoolName();
        enclosing = enclosing.enclosingType();
        String desc = enclosing.typeDescriptor();
        int index = gen.constantPool().addFieldref(classname, "this$0", desc);
        gen.emit(Bytecode.GETFIELD, 0).add2(index);
      }
    }
  }

    // Declared in CreateBCode.jrag at line 653

  
  protected TypeDecl superConstructorQualifier(TypeDecl targetEnclosingType) {
    TypeDecl enclosing = hostType();
    while(!enclosing.instanceOf(targetEnclosingType))
      enclosing = enclosing.enclosingType();
    return enclosing;
  }

    // Declared in java.ast at line 3
    // Declared in java.ast line 11

    public Access() {
        super();


    }

    // Declared in java.ast at line 9


  protected int numChildren() {
    return 0;
  }

    // Declared in java.ast at line 12

  public boolean mayHaveRewrite() { return false; }

    // Declared in LookupMethod.jrag at line 8
    public Expr unqualifiedScope() {
        Expr unqualifiedScope_value = unqualifiedScope_compute();
        return unqualifiedScope_value;
    }

    private Expr unqualifiedScope_compute() {  return  isQualified() ? nestedScope() : this;  }

    // Declared in ResolveAmbiguousNames.jrag at line 49
    public boolean isQualified() {
        boolean isQualified_value = isQualified_compute();
        return isQualified_value;
    }

    private boolean isQualified_compute() {  return  hasPrevExpr();  }

    // Declared in ResolveAmbiguousNames.jrag at line 52
    public Expr qualifier() {
        Expr qualifier_value = qualifier_compute();
        return qualifier_value;
    }

    private Expr qualifier_compute() {  return  prevExpr();  }

    // Declared in ResolveAmbiguousNames.jrag at line 57
    public Access lastAccess() {
        Access lastAccess_value = lastAccess_compute();
        return lastAccess_value;
    }

    private Access lastAccess_compute() {  return  this;  }

    protected boolean prevExpr_computed = false;
    protected Expr prevExpr_value;
    // Declared in ResolveAmbiguousNames.jrag at line 69
    public Expr prevExpr() {
        if(prevExpr_computed)
            return prevExpr_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        prevExpr_value = prevExpr_compute();
        if(isFinal && num == boundariesCrossed)
            prevExpr_computed = true;
        return prevExpr_value;
    }

    private Expr prevExpr_compute()  {
    if(isLeftChildOfDot()) {
      if(parentDot().isRightChildOfDot())
        return parentDot().parentDot().leftSide();
    }
    else if(isRightChildOfDot())
      return parentDot().leftSide();
    throw new Error(this + " does not have a previous expression");
  }

    protected boolean hasPrevExpr_computed = false;
    protected boolean hasPrevExpr_value;
    // Declared in ResolveAmbiguousNames.jrag at line 80
    public boolean hasPrevExpr() {
        if(hasPrevExpr_computed)
            return hasPrevExpr_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        hasPrevExpr_value = hasPrevExpr_compute();
        if(isFinal && num == boundariesCrossed)
            hasPrevExpr_computed = true;
        return hasPrevExpr_value;
    }

    private boolean hasPrevExpr_compute()  {
    if(isLeftChildOfDot()) {
      if(parentDot().isRightChildOfDot())
        return true;
    }
    else if(isRightChildOfDot())
      return true;
    return false;
  }

    // Declared in SyntacticClassification.jrag at line 46
    public NameType predNameType() {
        NameType predNameType_value = predNameType_compute();
        return predNameType_value;
    }

    private NameType predNameType_compute() {  return  NameType.NO_NAME;  }

    protected boolean type_computed = false;
    protected TypeDecl type_value;
    // Declared in TypeAnalysis.jrag at line 270
    public TypeDecl type() {
        if(type_computed)
            return type_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        type_value = type_compute();
        if(isFinal && num == boundariesCrossed)
            type_computed = true;
        return type_value;
    }

    private TypeDecl type_compute() {  return  unknownType();  }

    // Declared in CodeGeneration.jrag at line 19
    public int sourceLineNumber() {
        int sourceLineNumber_value = sourceLineNumber_compute();
        return sourceLineNumber_value;
    }

    private int sourceLineNumber_compute() {  return  findFirstSourceLineNumber();  }

    protected boolean getTypeVariables_computed = false;
    protected Set getTypeVariables_value;
/**
     * @see: TypeDecl.getTypeVariables
     
    Declared in GenericNamesAndTypes.jrag at line 32
*/
    public Set getTypeVariables() {
        if(getTypeVariables_computed)
            return getTypeVariables_value;
        int num = boundariesCrossed;
        boolean isFinal = this.is$Final();
        getTypeVariables_value = getTypeVariables_compute();
        if(isFinal && num == boundariesCrossed)
            getTypeVariables_computed = true;
        return getTypeVariables_value;
    }

    private Set getTypeVariables_compute() {
        return Collections.EMPTY_SET;
        //return typevars;
    }

    // Declared in GenericNamesAndTypes.jrag at line 105
    public String simpleName() {
        String simpleName_value = simpleName_compute();
        return simpleName_value;
    }

    private String simpleName_compute() {  return  type().simpleName();  }

    // Declared in GenericNamesAndTypes.jrag at line 106
    public String shortName() {
        String shortName_value = shortName_compute();
        return shortName_value;
    }

    private String shortName_compute() {  return  type().shortName();  }

    // Declared in GenericNamesAndTypes.jrag at line 309
    public String sourceLocation(LinkedList posList) {
        String sourceLocation_LinkedList_value = sourceLocation_compute(posList);
        return sourceLocation_LinkedList_value;
    }

    private String sourceLocation_compute(LinkedList posList) {  return  location() + ":" + getColumn(getStart());  }

    // Declared in WildcardsHeuristics.jrag at line 158
    public Access typeWithFlippedWilds(Class heur) {
        Access typeWithFlippedWilds_Class_value = typeWithFlippedWilds_compute(heur);
        return typeWithFlippedWilds_Class_value;
    }

    private Access typeWithFlippedWilds_compute(Class heur) {  return  this;  }

    // Declared in LookupMethod.jrag at line 9
    public Expr nestedScope() {
        Expr nestedScope_value = getParent().Define_Expr_nestedScope(this, null);
        return nestedScope_value;
    }

    // Declared in LookupType.jrag at line 124
    public TypeDecl unknownType() {
        TypeDecl unknownType_value = getParent().Define_TypeDecl_unknownType(this, null);
        return unknownType_value;
    }

    // Declared in LookupVariable.jrag at line 231
    public Variable unknownField() {
        Variable unknownField_value = getParent().Define_Variable_unknownField(this, null);
        return unknownField_value;
    }

    // Declared in NameCheck.jrag at line 291
    public BodyDecl enclosingBodyDecl() {
        BodyDecl enclosingBodyDecl_value = getParent().Define_BodyDecl_enclosingBodyDecl(this, null);
        return enclosingBodyDecl_value;
    }

    // Declared in CreateBCode.jrag at line 450
    public boolean inExplicitConstructorInvocation() {
        boolean inExplicitConstructorInvocation_value = getParent().Define_boolean_inExplicitConstructorInvocation(this, null);
        return inExplicitConstructorInvocation_value;
    }

    // Declared in Annotations.jrag at line 263
    public boolean withinSuppressWarnings(String s) {
        boolean withinSuppressWarnings_String_value = getParent().Define_boolean_withinSuppressWarnings(this, null, s);
        return withinSuppressWarnings_String_value;
    }

    // Declared in Annotations.jrag at line 367
    public boolean withinDeprecatedAnnotation() {
        boolean withinDeprecatedAnnotation_value = getParent().Define_boolean_withinDeprecatedAnnotation(this, null);
        return withinDeprecatedAnnotation_value;
    }

public ASTNode rewriteTo() {
    return super.rewriteTo();
}

}
