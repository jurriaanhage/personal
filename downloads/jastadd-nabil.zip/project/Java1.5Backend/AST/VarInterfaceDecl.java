
package AST;
import java.util.HashSet;import java.util.LinkedHashSet;import java.io.File;import java.util.*;import beaver.*;import java.util.ArrayList;import java.util.zip.*;import java.io.*;import java.io.FileNotFoundException;import java.util.Collection;import inference.ConstraintsMapBuilder;import inference.solvers.ParMethodSolver;import inference.solvers.MethodSolver;import inference.solvers.ConstructorSolver;import inference.error_managers.TypeErrorManager;import inference.ds.ErrorSet;


    /*
     * Create an interface from a type variable
     */
    public class VarInterfaceDecl extends InterfaceDecl {
    // Declared in AdditionalAST.jadd at line 63
        TypeVariable typeVar;

    // Declared in AdditionalAST.jadd at line 64    
        public VarInterfaceDecl(TypeVariable tvar){
            this.typeVar = tvar;
        }

    // Declared in AdditionalAST.jadd at line 69

        // disable compilation for this type.
        public void generateClassfile(){}

    // Declared in AdditionalAST.jadd at line 72

        // don't perform any type/name analysis on VarTypeDecl
        public void collectErrors(){}


}
