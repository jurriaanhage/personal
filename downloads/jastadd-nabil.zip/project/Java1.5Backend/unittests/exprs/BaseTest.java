/**
 * 
 */
package unittests.exprs;

import junit.framework.TestCase;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class BaseTest extends TestCase {

	boolean disableStdOut = true;
	final static String dir = "exprs/";
	String file, filePath;

	protected void setUp() throws Exception {
		super.setUp();
		filePath = TestConstants.rootdir + dir + file;
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}
}
