/**
 * 
 */
package unittests.exprs;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test1 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test1.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertNotNull(errorMap);
		// --------------------------------------------------------------------
		// first call
		// --------------------------------------------------------------------
		// T has a bound error
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);

		List<PrBoundTypeErrorMsg> boundErrList =
				errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrList.size());

		PrBoundTypeErrorMsg msg = boundErrList.get(0);
		assertEquals("Number", msg.getBound().shortName());
		assertEquals("String", msg.getTypeValue().shortName());
		// Type of the argument was not previously declared.
		assertFalse(msg.isInputTypeDeclared());

		// --------------------------------------------------------------------
		// second calll
		// --------------------------------------------------------------------
		errorSet = errorMap.get("foo2.T");
		assertNotNull(errorSet);

		// T has a supertype error
		List<SupTypeErrorMsg> errList = errorSet.getSupertypeErrorList();
		assertEquals(1, errList.size());

		SupTypeErrorMsg sumsg = errList.get(0);
		assertEquals("String", sumsg.getInferredType());
		assertEquals("Integer", sumsg.getSubType());
		// int was promoted to Integer
		assertFalse(sumsg.getErrorTuple().getTypeSource().isFromDeclaredStmt());

	}
}
