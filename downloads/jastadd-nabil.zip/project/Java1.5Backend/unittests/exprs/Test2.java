/**
 * 
 */
package unittests.exprs;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// T has a bound error
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);

		List<PrBoundTypeErrorMsg> boundErrList =
				errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrList.size());

		PrBoundTypeErrorMsg msg = boundErrList.get(0);
		assertEquals("Byte", msg.getBound().shortName());
		assertEquals("Integer", msg.getTypeValue().shortName());
		// Type of the argument was not previously declared.
		assertFalse(msg.isInputTypeDeclared());
	}
}
