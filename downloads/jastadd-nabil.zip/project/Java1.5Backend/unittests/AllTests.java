package unittests;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Test for unittests");
		// $JUnit-BEGIN$
		// Begin equality
		suite.addTestSuite(unittests.equality.Test1.class);
		suite.addTestSuite(unittests.equality.Test4.class);
		suite.addTestSuite(unittests.equality.Test5.class);
		suite.addTestSuite(unittests.equality.Test6.class);
		suite.addTestSuite(unittests.equality.Test8.class);
		suite.addTestSuite(unittests.equality.Test9.class);
		suite.addTestSuite(unittests.equality.Test10.class);
		// End equality

		// Begin subtype
		suite.addTestSuite(unittests.subtype.Test1.class);
		suite.addTestSuite(unittests.subtype.Test2.class);
		suite.addTestSuite(unittests.subtype.Test4.class);
		suite.addTestSuite(unittests.subtype.Test5.class);
		suite.addTestSuite(unittests.subtype.Test6.class);
		suite.addTestSuite(unittests.subtype.Test11.class);
		suite.addTestSuite(unittests.subtype.Test12.class);
		// End subtype

		// Begin subtype
		suite.addTestSuite(unittests.supertype.Test1.class);
		suite.addTestSuite(unittests.supertype.Test3.class);
		// End supertype

		// Begin exprs
		suite.addTestSuite(unittests.exprs.Test1.class);
		suite.addTestSuite(unittests.exprs.Test2.class);
		// End exprs

		// Begin wildcards
		suite.addTestSuite(unittests.wildcards.Test1.class);
		suite.addTestSuite(unittests.wildcards.Test2.class);
		suite.addTestSuite(unittests.wildcards.Test3.class);
		suite.addTestSuite(unittests.wildcards.Test4.class);
		suite.addTestSuite(unittests.wildcards.Test5.class);
		suite.addTestSuite(unittests.wildcards.Test6.class);
		suite.addTestSuite(unittests.wildcards.Test7.class);
		// End wildcards

		// Begin bounds
		suite.addTestSuite(unittests.bounds.Test2.class);
		suite.addTestSuite(unittests.bounds.Test3.class);
		suite.addTestSuite(unittests.bounds.Test4.class);
		suite.addTestSuite(unittests.bounds.Test6.class);
		suite.addTestSuite(unittests.bounds.Test7.class);
		// End bounds

		// Begin super Object heuristic
		suite.addTestSuite(unittests.super_object.Test1.class);
		suite.addTestSuite(unittests.super_object.Test2.class);
		suite.addTestSuite(unittests.super_object.Test3.class);
		suite.addTestSuite(unittests.super_object.Test4.class);
		suite.addTestSuite(unittests.super_object.Test5.class);
		// End super Object heuristic

		// Begin extends Final heuristic
		suite.addTestSuite(unittests.extends_final.Test1.class);
		suite.addTestSuite(unittests.extends_final.Test2.class);
		suite.addTestSuite(unittests.extends_final.Test3.class);
		suite.addTestSuite(unittests.extends_final.Test4.class);
		// End extends Final heuristic

		// Begin wildcards heuristic
		suite.addTestSuite(unittests.wild_heuristic.Test1.class);
		suite.addTestSuite(unittests.wild_heuristic.Test3.class);
		suite.addTestSuite(unittests.wild_heuristic.Test6.class);
		suite.addTestSuite(unittests.wild_heuristic.Test7.class);
		// End wildcards heuristic

		// Begin context invariance heuristic
		suite.addTestSuite(unittests.cxt_invariance.Test1.class);
		suite.addTestSuite(unittests.cxt_invariance.Test2.class);
		suite.addTestSuite(unittests.cxt_invariance.Test3.class);
		suite.addTestSuite(unittests.cxt_invariance.Test4.class);
		suite.addTestSuite(unittests.cxt_invariance.Test5.class);
		suite.addTestSuite(unittests.cxt_invariance.Test6.class);
		suite.addTestSuite(unittests.cxt_invariance.Test7.class);
		suite.addTestSuite(unittests.cxt_invariance.Test8.class);
		suite.addTestSuite(unittests.cxt_invariance.Test10.class);
		suite.addTestSuite(unittests.cxt_invariance.Test11.class);
		// End context invariance heuristic

		// Begin subtype repair heuristic
		suite.addTestSuite(unittests.sub_repair.Test1.class);
		suite.addTestSuite(unittests.sub_repair.Test2.class);
		suite.addTestSuite(unittests.sub_repair.Test3.class);
		suite.addTestSuite(unittests.sub_repair.Test4.class);
		// End subtype repair heuristic

		// $JUnit-END$
		return suite;
	}

}
