package unittests.extends_final;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has a equal error
		EqTypeErrorMsg equalError = errorSet.getEqualityErrors();
		assertEquals(2, equalError.getEqTypeValues().size());
		assertTrue(equalError.allSameWildcard());
		// no hint, because of T' bound
		List<String> fixCandidates = equalError.getFixCandidates();
		assertEquals(0, fixCandidates.size());
	}
}
