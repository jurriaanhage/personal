package unittests.extends_final;

import inference.ds.ErrorSet;
import inference.error_messages.SupTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test3");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has a super error
		List<SupTypeErrorMsg> superErrors = errorSet.getSupertypeErrorList();
		assertEquals(1, superErrors.size());
		assertEquals("? extends String", superErrors.get(0).getInferredType());
		assertEquals("String", superErrors.get(0).getSubType());
		assertEquals(1, superErrors.get(0).getFixCandidates().size());
		assertEquals("String", superErrors.get(0).getFixCandidates().get(0));
	}
}
