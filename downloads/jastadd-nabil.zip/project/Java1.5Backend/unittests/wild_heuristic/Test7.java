/**
 * 
 */
package unittests.wild_heuristic;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test7 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test7.java";
		super.setUp();
	}
	
	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test7");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		List<PrBoundTypeErrorMsg> errs = errorSet.getPreBoundErrorList();
		assertEquals(1, errs.size());
		assertEquals("? super Integer", errs.get(0).getTypeValue().shortName());
		assertEquals("Number", errs.get(0).getBound().shortName());
		assertEquals(0, errs.get(0).getFixCandidates().size());
	}
}
