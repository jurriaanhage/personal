/**
 * 
 */
package unittests.wild_heuristic;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test1 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test1.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		List<PrBoundTypeErrorMsg> boundErrors = errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrors.size());
		assertEquals("? super Integer", boundErrors.get(0).getTypeValue()
				.shortName());
		assertEquals("Number", boundErrors.get(0).getBound().shortName());
		// has a hint
		assertEquals(1, boundErrors.get(0).getFixCandidates().size());
		assertEquals("? extends Integer", boundErrors.get(0).getFixCandidates()
				.get(0));

		// T in the call to foo is in a conflict
		errorSet = errorMap.get("foo2.T");
		assertNotNull(errorSet);
		boundErrors = errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrors.size());
		assertEquals("? super Comparable<? extends Number>", boundErrors.get(0)
				.getTypeValue().shortName());
		// has no hint
		assertEquals(0, boundErrors.get(0).getFixCandidates().size());
	}

}
