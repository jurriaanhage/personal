/**
 * 
 */
package unittests.sub_repair;

import inference.ds.ErrorSet;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test1 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test1.java";
		super.setUp();
	}

	public void testFooMethod() {
		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------

		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.T"));
		Collection exts = tc.getExtensions("Test1.foo1", "T");
		// HAS A FIX
		assertNotNull(exts);
		TypeChangeExt fix = getTypeChangeExt(exts);
		assertEquals("Number", fix.replacement());

		// --------------------------------------------------------------------
		// Second call
		// --------------------------------------------------------------------

		// class contains errors
		assertNotNull(errorMap.get("foo2.T"));
		// There is NO FIX
		exts = tc.getExtensions("Test10.foo2", "T");
		assertNull(exts);
	}

}
