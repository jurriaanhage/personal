/**
 * 
 */
package unittests.sub_repair;

import inference.ds.ErrorSet;

import java.util.Collection;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test4 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------

		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.T"));
		Collection exts = tc.getExtensions("Test4.foo1", "T");
		// HAS NO FIX, because we have to change the same expr.
		assertNull("There sould be no fix:", exts);
	}

}
