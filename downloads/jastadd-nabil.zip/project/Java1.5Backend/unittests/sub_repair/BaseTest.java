/**
 * 
 */
package unittests.sub_repair;

import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.Iterator;

import junit.framework.TestCase;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class BaseTest extends TestCase {

	boolean disableStdOut = true;
	final static String dir = "sub_repair_heuristic/";
	String file, filePath;

	protected void setUp() throws Exception {
		super.setUp();
		filePath = TestConstants.rootdir + dir + file;
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	protected TypeChangeExt getTypeChangeExt(Collection exts) {
		for (Iterator iter = exts.iterator(); iter.hasNext();) {
			Object ext = iter.next();
			if (ext instanceof TypeChangeExt) {
				return (TypeChangeExt) ext;
			}
		}
		return null;
	}
}
