package unittests.super_object;

import inference.error_messages.SupErrorCheckMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Collection errorSet = tc.getChechErrors("Test2.foo1");
		// T in the call to foo is in a conflict
		assertNotNull("ErrorSet is null", errorSet);
		// T has a super error
		SupErrorCheckMsg msg = (SupErrorCheckMsg) errorSet.iterator().next();
		assertEquals("Map<? extends ? super Object, ? super Object>", msg
				.getInferredFormalType().shortName());
		// Replacing '? super Object' with Object solves the conflict.
		assertTrue(msg.reducedSuperObject());
	}
}
