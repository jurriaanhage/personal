package unittests.super_object;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test3");
		// T in the call to foo is in a conflict
		assertNotNull("ErrorSet is null", errorMap);
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has an equal error
		EqTypeErrorMsg msg = errorSet.getEqualityErrors();
		assertEquals(2, msg.getEqTypeValues().size());
		assertEquals(1, msg.getFixCandidates().size());
		assertEquals("Object", msg.getFixCandidates().get(0));

		// enabling strict bound should disallow printing a hint.

		args =
				new String[] { filePath, TestConstants._TestFlag,
						TestConstants._StrictFlag };
		tc = new TestCompiler();
		tc.compile(args);

		errorMap = tc.getTypeDeclErrors("Test3");
		// T in the call to foo is in a conflict
		assertNotNull("ErrorSet is null", errorMap);
		errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has an equal error
		msg = errorSet.getEqualityErrors();
		assertEquals(2, msg.getEqTypeValues().size());
		assertEquals(0, msg.getFixCandidates().size());

	}
}
