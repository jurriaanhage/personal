package unittests.super_object;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test5 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test5.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test5");
		assertNotNull("ErrorSet is null", errorMap);
		ErrorSet errorSet = errorMap.get("foo1.T");
		// T in the call to foo is in a conflict
		assertNotNull("ErrorSet is null", errorSet);
		// T has an after-check error
		EqTypeErrorMsg msg = errorSet.getEqualityErrors();
		assertEquals(2, msg.getEqTypeValues().size());
		assertTrue(msg.allSameWildcard());
		// No hint, becouse of T's bound
		assertEquals(0, msg.getFixCandidates().size());

		

	}
}
