package unittests.super_object;

import inference.error_messages.SupErrorCheckMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test4 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Collection errorSet = tc.getChechErrors("Test4.foo1");
		// T in the call to foo is in a conflict
		assertNotNull("ErrorSet is null", errorSet);
		// T has an after-check error
		SupErrorCheckMsg msg = (SupErrorCheckMsg) errorSet.iterator().next();
		assertEquals("Map<? extends String, ? extends ? super Object>", msg
				.getInferredFormalType().shortName());
		// Replacing '? super Object' with Object solves the conflict.
		assertTrue(msg.reducedSuperObject());

		// enabling strict bound should disallow printing a hint.

		args =
				new String[] { filePath, TestConstants._TestFlag,
						TestConstants._StrictFlag };
		tc = new TestCompiler();
		tc.compile(args);
		errorSet = tc.getChechErrors("Test4.foo1");
		msg = (SupErrorCheckMsg) errorSet.iterator().next();
		// No hint because of the strict flag
		assertFalse(msg.reducedSuperObject());

	}
}
