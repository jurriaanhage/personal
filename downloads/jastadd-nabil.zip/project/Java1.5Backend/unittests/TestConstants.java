package unittests;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import AST.Program;

public class TestConstants {

	public static final PrintStream stdout = System.out;
	public static final String rootdir;
	public static PrintStream nullStdout;
	public static final String _TestFlag = Program._testing;
	public static final String _DistinctFlag = Program._distinctTypes;
	public static final String _StrictFlag = Program._strictMode;
	public static final String _VeryStrictFlag = Program._veryStrictMode;
	public static final String _TMP_DIR = System.getProperty("java.io.tmpdir");

	static {
		rootdir = System.getProperty("testing.rootdir");
		if (rootdir == null) {
			System.err.println("rootdir was not set!");
			System.err.println("Used -Dtesting.rootdir=<path>");
		}
		try {
			if (System.getProperty("os.name").contains("Windows"))
				nullStdout = new PrintStream(new FileOutputStream("NUL:"));
			else
				nullStdout = new PrintStream(new FileOutputStream("/dev/null"));
		} catch (FileNotFoundException e) {

		}
	}
}
