package unittests.equality;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import unittests.TestCompiler;
import unittests.TestConstants;

public class Test8 extends TestCase {

	private boolean disableStdOut = true;
	private String file;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		file = TestConstants.rootdir + "equality/Test8.java";
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	public void testFooMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include a 3 hints
		// --------------------------------------------------------------------
		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test8");
		// class contains errors
		assertFalse(errorMap == null);

		// T in the first call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertNotNull(equalityError);
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Integer", fixCandidates.get(0));

		// S in the first call to foo is in a conflict
		errorSet = errorMap.get("foo1.S");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Integer", fixCandidates.get(0));

		// S in the first call to foo is in a conflict
		errorSet = errorMap.get("foo1.R");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Integer", fixCandidates.get(0));
	}

}
