package unittests.equality;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;
import junit.framework.TestCase;

public class Test10 extends TestCase {

	private boolean disableStdOut = true;
	private String file;

	protected void setUp() throws Exception {
		super.setUp();
		file = TestConstants.rootdir + "equality/Test10.java";
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	public void testFooMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include no hints
		// --------------------------------------------------------------------
		Map<String, ErrorSet> erroMap = tc.getTypeDeclErrors("Test10");
		// class contains errors
		assertFalse(erroMap == null);

		// T in the call to foo is in a conflict
		ErrorSet errorSet = erroMap.get("foo1.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertNotNull(equalityError);
		// repair hint
		assertTrue("This should be empty", equalityError.getFixCandidates()
				.isEmpty());

		// S in the call to foo is in a conflict
		errorSet = erroMap.get("foo1.S");
		assertNotNull(errorSet);
		equalityError = errorSet.getEqualityErrors();
		assertNotNull(equalityError);
		// repair hint
		assertTrue("This should be empty", equalityError.getFixCandidates()
				.isEmpty());

	}
}
