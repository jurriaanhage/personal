package unittests.equality;

import inference.ds.ErrorSet;
import inference.error_messages.EqTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;
import junit.framework.TestCase;

public class Test9 extends TestCase {

	private boolean disableStdOut = true;
	private String file;

	protected void setUp() throws Exception {
		super.setUp();
		file = TestConstants.rootdir + "equality/Test9.java";
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	public void testFooMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include a hint
		// --------------------------------------------------------------------
		Map<String, ErrorSet> erroMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(erroMap == null);

		// T in the first call to foo is in a conflict
		ErrorSet errorSet = erroMap.get("foo1.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertNotNull(equalityError);
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Number", fixCandidates.get(0));

		// --------------------------------------------------------------------
		// First call with -strict should include no hint
		// --------------------------------------------------------------------
		args =
				new String[] { file, TestConstants._TestFlag,
						TestConstants._StrictFlag };
		tc = new TestCompiler();
		tc.compile(args);

		erroMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(erroMap == null);

		// T in the first call to foo is in a conflict
		errorSet = erroMap.get("foo1.T");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		assertTrue(equalityError.getFixCandidates().isEmpty());
	}

	public void testBarMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include a hint
		// --------------------------------------------------------------------
		Map<String, ErrorSet> erroMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(erroMap == null);
		// T in the first call to foo is in a conflict
		ErrorSet errorSet = erroMap.get("bar1.T");
		assertFalse(errorSet == null);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Number", fixCandidates.get(0));

		// --------------------------------------------------------------------
		// First call with -strict should include no hint
		// --------------------------------------------------------------------
		args =
				new String[] { file, TestConstants._TestFlag,
						TestConstants._StrictFlag };
		tc = new TestCompiler();
		tc.compile(args);

		erroMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(erroMap == null);

		// T in the first call to foo is in a conflict
		errorSet = erroMap.get("bar1.T");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		assertTrue(equalityError.getFixCandidates().isEmpty());
	}

	public void testBazMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include a hint for T only
		// --------------------------------------------------------------------
		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(errorMap == null);

		// T in the first call to baz is in a conflict
		ErrorSet errorSet = errorMap.get("baz1.T");
		assertFalse(errorSet == null);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Number", fixCandidates.get(0));

		// R in the first call to baz is in a conflict
		errorSet = errorMap.get("baz1.R");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		assertTrue(equalityError.getFixCandidates().isEmpty());

		// --------------------------------------------------------------------
		// First call with -strict should include a hint for T and R
		// --------------------------------------------------------------------
		args =
				new String[] { file, TestConstants._TestFlag,
						TestConstants._StrictFlag };
		tc = new TestCompiler();
		tc.compile(args);

		errorMap = tc.getTypeDeclErrors("Test9");
		// class contains errors
		assertFalse(errorMap == null);

		// T in the first call to baz is in a conflict
		errorSet = errorMap.get("baz1.T");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Number", fixCandidates.get(0));

		// R in the first call to baz is in a conflict
		errorSet = errorMap.get("baz1.R");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// repair hint
		fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Object", fixCandidates.get(0));

	}
}
