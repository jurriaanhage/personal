package unittests.equality;

import inference.ds.ErrorSet;
import inference.ds.ErrorTuple;
import inference.error_messages.EqTypeErrorMsg;

import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import unittests.TestCompiler;
import unittests.TestConstants;

public class Test6 extends TestCase {

	private boolean disableStdOut = true;
	private String file;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		file = TestConstants.rootdir + "equality/Test6.java";
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	public void testFooMethod() {
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call should include a hint
		// --------------------------------------------------------------------
		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test6");
		// class contains errors
		assertNotNull(errorMap);
		// T in the first call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// number of types involved in the conflict
		List<ErrorTuple> eqTypeValues = equalityError.getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Integer", fixCandidates.get(0));

		// --------------------------------------------------------------------
		// First call with -distinct should not include a hint
		// --------------------------------------------------------------------
		args =
				new String[] { file, TestConstants._TestFlag,
						TestConstants._DistinctFlag };
		tc = new TestCompiler();
		tc.compile(args);

		errorMap = tc.getTypeDeclErrors("Test6");
		// class contains errors
		assertFalse(errorMap == null);
		// T in the first call to foo is in a conflict
		errorSet = errorMap.get("foo1.T");
		assertFalse(errorSet == null);
		equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// number of types involved in the conflict
		eqTypeValues = equalityError.getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		// no repair hint		
		assertTrue(equalityError.getFixCandidates().isEmpty());
	}

}
