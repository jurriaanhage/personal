package unittests.equality;

import inference.ds.ErrorSet;
import inference.ds.ErrorTuple;
import inference.error_messages.EqTypeErrorMsg;

import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import unittests.TestCompiler;
import unittests.TestConstants;

public class Test4 extends TestCase {

	public boolean disableStdOut = true;
	private String file;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		file = TestConstants.rootdir + "equality/Test4.java";
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	public void testFooMethod() {

		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertNotNull(errorMap);
		// T in the second call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo2.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// number of types involved in the conflict
		List<ErrorTuple> eqTypeValues = equalityError.getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		assertEquals(eqTypeValues.get(0).getType().shortName(),
				"? extends Integer");
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Integer", fixCandidates.get(0));
	}

	public void testBarMethod() {

		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> erroMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertFalse(erroMap == null);
		// T in the second call to bar is in a conflict
		ErrorSet errorSet = erroMap.get("bar2.T");
		assertFalse(errorSet == null);
		EqTypeErrorMsg equalityError = errorSet.getEqualityErrors();
		assertFalse(equalityError == null);
		// number of types involved in the conflict
		List<ErrorTuple> eqTypeValues = equalityError.getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		assertEquals(eqTypeValues.get(0).getType().shortName(),
				"? super Object");
		// repair hint
		List<String> fixCandidates = equalityError.getFixCandidates();
		assertEquals(1, fixCandidates.size());
		assertEquals("Object", fixCandidates.get(0));
	}
}
