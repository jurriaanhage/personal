/**
 * 
 */
package unittests.equality;

import inference.ds.ErrorSet;
import inference.ds.ErrorTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;
import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test1 extends TestCase {

	public static boolean disableStdOut = true;

	public Test1(String name) {
		super(name);
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		}
	}

	/**
	 * 
	 */
	public void testFooMethod() {
		if (TestConstants.rootdir == null || TestConstants.rootdir.equals(""))
			System.exit(1);

		String file = TestConstants.rootdir + "equality/Test1.java";
		String[] args = new String[] { file, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// Call 1
		// --------------------------------------------------------------------

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertNotNull(errorMap);
		// class has 2 calls
		assertEquals(errorMap.size(), 2);
		// T in the first call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		assertFalse(errorSet.getEqualityErrors() == null);
		// number of types involved in the conflict
		List<ErrorTuple> eqTypeValues =
				errorSet.getEqualityErrors().getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		// 
		ArrayList<String> eqTypeStrList = new ArrayList<String>(2);
		ArrayList<String> expectedTypeList = new ArrayList<String>(2);
		expectedTypeList.add("Integer");
		expectedTypeList.add("Number");
		for (ErrorTuple et : eqTypeValues)
			eqTypeStrList.add(et.getType().shortName());
		assertTrue(expectedTypeList.containsAll(eqTypeStrList));

		// --------------------------------------------------------------------
		// Call 2
		// --------------------------------------------------------------------

		errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertFalse(errorMap == null);
		// class has 2 calls
		assertEquals(errorMap.size(), 2);
		// T in the first call foo is in a conflict
		errorSet = errorMap.get("foo1.T");
		assertFalse(errorSet == null);
		assertFalse(errorSet.getEqualityErrors() == null);
		// number of types involved in the conflict
		eqTypeValues = errorSet.getEqualityErrors().getEqTypeValues();
		assertEquals(eqTypeValues.size(), 2);
		// 
		eqTypeStrList.clear();
		expectedTypeList.clear();
		expectedTypeList.add("Integer");
		expectedTypeList.add("Number");
		for (ErrorTuple et : eqTypeValues)
			eqTypeStrList.add(et.getType().shortName());
		assertTrue(expectedTypeList.containsAll(eqTypeStrList));
	}
}
