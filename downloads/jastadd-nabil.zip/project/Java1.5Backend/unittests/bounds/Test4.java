/**
 * 
 */
package unittests.bounds;

import inference.ds.ErrorSet;
import inference.error_messages.PoBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test4 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertNotNull(errorMap);
		// S in the 1st call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.S");
		assertNotNull("ErrorSet is null", errorSet);
		List<PoBoundTypeErrorMsg> boundErrors =
				errorSet.getPostBoundErrorList();
		assertEquals(1, boundErrors.size());
		// S's bound
		assertEquals("Map<List<T>, S>", boundErrors.get(0).getBoundType());
		// inferred type
		assertEquals("Object", boundErrors.get(0).getInferredType());

		// S in the 2nd call to foo is in a conflict
		errorSet = errorMap.get("foo2.S");
		assertNotNull("ErrorSet is null", errorSet);
		boundErrors = errorSet.getPostBoundErrorList();
		assertEquals(1, boundErrors.size());
		// S's bound
		assertEquals("Map<List<T>, S>", boundErrors.get(0).getBoundType());
		// inferred type
		assertEquals("Map<ArrayList<Integer>, Object>", boundErrors.get(0).getInferredType());
	}
}
