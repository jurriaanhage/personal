/**
 * 
 */
package unittests.bounds;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test6 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test6.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test6");
		// class contains errors
		assertNotNull(errorMap);
		// S in the call to foo is not in a conflict
		assertNull(errorMap.get("foo1.S"));

		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull("ErrorSet is null", errorSet);
		List<PrBoundTypeErrorMsg> boundErrors = errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrors.size());
		// T's bound
		assertEquals("Comparable<Integer>", boundErrors.get(0).getBound()
				.shortName());
		// inferred type
		assertEquals("Double", boundErrors.get(0).getTypeValue().shortName());

	}
}
