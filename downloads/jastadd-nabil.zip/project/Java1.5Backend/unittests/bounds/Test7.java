/**
 * 
 */
package unittests.bounds;

import inference.ds.ErrorSet;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test7 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test7.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test7");
		// class contains errors
		assertNotNull(errorMap);

		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull("ErrorSet is null", errorSet);
		List<PrBoundTypeErrorMsg> preBoundErrors =
				errorSet.getPreBoundErrorList();
		assertEquals(1, preBoundErrors.size());
		// T's bound
		assertEquals("Number", preBoundErrors.get(0).getBound().shortName());
		// inferred type
		assertEquals("ArrayList<Integer>", preBoundErrors.get(0).getTypeValue()
				.shortName());

		List<PoBoundTypeErrorMsg> postBoundErrors =
				errorSet.getPostBoundErrorList();
		assertEquals(1, postBoundErrors.size());
		// T's bound
		assertEquals("List<T>", postBoundErrors.get(0).getBoundType());
		// inferred type
		assertEquals("ArrayList<Integer>", postBoundErrors.get(0)
				.getInferredType());

	}
}
