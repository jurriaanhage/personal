/**
 * 
 */
package unittests.bounds;

import inference.ds.ErrorSet;
import inference.error_messages.PoBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// R in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.R");
		assertNotNull("ErrorSet is null", errorSet);
		List<PoBoundTypeErrorMsg> boundErrors =
				errorSet.getPostBoundErrorList();
		assertEquals(1, boundErrors.size());
		// R's bound
		assertEquals("Map<T, R>", boundErrors.get(0)
				.getBoundType());
		// inferred type
		assertEquals("Map<Integer, Number>", boundErrors.get(0)
						.getInferredType());
	}
}
