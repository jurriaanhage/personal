/**
 * 
 */
package unittests.bounds;

import inference.ds.ErrorSet;
import inference.error_messages.PrBoundTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test3");
		// class contains errors
		assertNotNull(errorMap);
		// S in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.S");
		assertNotNull("ErrorSet is null", errorSet);
		List<PrBoundTypeErrorMsg> boundErrors = errorSet.getPreBoundErrorList();
		assertEquals(1, boundErrors.size());
		// S's bound
		assertEquals("List<Integer>", boundErrors.get(0).getBound().shortName());
		// inferred type
		assertEquals("List<Number>", boundErrors.get(0).getTypeValue()
				.shortName());
	}
}
