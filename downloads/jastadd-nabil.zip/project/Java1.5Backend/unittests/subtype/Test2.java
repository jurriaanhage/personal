/**
 * 
 */
package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test2 extends BaseTest {

	@Override
	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has not subtype error, but does have a glb error.
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(subtypeErrorList.size(), 0);
		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(glbErrorList.size(), 1);
		GlbTypeErrorMsg glbTypeErrorMsg = glbErrorList.get(0);
		assertEquals(glbTypeErrorMsg.getFstType().shortName(), "Integer");
		assertEquals(glbTypeErrorMsg.getSndType().shortName(), "String");
	}

}
