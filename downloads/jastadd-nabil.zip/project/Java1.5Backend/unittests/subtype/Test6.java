package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test6 extends BaseTest {

	@Override
	protected void setUp() throws Exception {
		file = "Test6.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test6");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has 0 subtype error and glb error.
		assertTrue(errorSet.getSubtypeErrorList().isEmpty());

		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(glbErrorList.size(), 1);
		GlbTypeErrorMsg glbTypeErrorMsg = glbErrorList.get(0);
		assertEquals(glbTypeErrorMsg.getFstType().shortName(), "Number");
		assertEquals(glbTypeErrorMsg.getSndType().shortName(), "String");
		// String is blame for the conflict.
		assertEquals(glbTypeErrorMsg.getErrorCandidate(), "String");
	}
}
