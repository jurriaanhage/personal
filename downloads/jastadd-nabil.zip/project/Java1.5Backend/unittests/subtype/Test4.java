package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test4 extends BaseTest {

	@Override
	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has 2 subtype error
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(subtypeErrorList.size(), 2);
		// Inferred type is Number
		assertEquals(subtypeErrorList.get(0).getInferredType().shortName(),
						"Number");
		// first param
		assertEquals(
						subtypeErrorList.get(0).getOrigTuple().implied
								.shortName(), "Integer");
		// second param
		assertEquals(
						subtypeErrorList.get(1).getOrigTuple().implied
								.shortName(), "String");
		// T has a glb error too
		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(glbErrorList.size(), 1);
		GlbTypeErrorMsg glbTypeErrorMsg = glbErrorList.get(0);
		assertEquals(glbTypeErrorMsg.getFstType().shortName(), "Integer");
		assertEquals(glbTypeErrorMsg.getSndType().shortName(), "String");
	}
}
