package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test5 extends BaseTest {

	@Override
	protected void setUp() throws Exception {
		file = "Test5.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test5");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has 1 subtype error
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(subtypeErrorList.size(), 1);
		// Inferred type is Number
		assertEquals(subtypeErrorList.get(0).getInferredType().shortName(),
						"Integer");
		// second param
		assertEquals(
						subtypeErrorList.get(0).getOrigTuple().implied
								.shortName(), "String");
		// T has a glb error too
		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(glbErrorList.size(), 1);
		GlbTypeErrorMsg glbTypeErrorMsg = glbErrorList.get(0);
		assertEquals(glbTypeErrorMsg.getFstType().shortName(), "Number");
		assertEquals(glbTypeErrorMsg.getSndType().shortName(), "String");
	}
}
