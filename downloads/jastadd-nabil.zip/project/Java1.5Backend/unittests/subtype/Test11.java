/**
 * 
 */
package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test11 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test11.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test11");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has no subtype errors, 3 glb errors
		assertTrue(errorSet.getSubtypeErrorList().isEmpty());
		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(3, glbErrorList.size());
		// first param
		GlbTypeErrorMsg msg = glbErrorList.get(0);
		assertEquals("String", msg.getFstType().shortName());
		assertEquals("Error", msg.getSndType().shortName());
		// String and bound
		msg = glbErrorList.get(1);
		assertEquals("String", msg.getFstType().shortName());
		assertEquals("Number", msg.getSndType().shortName());
		assertEquals("String", msg.getErrorCandidate());
		// Error and bound
		msg = glbErrorList.get(2);
		assertEquals("Error", msg.getFstType().shortName());
		assertEquals("Number", msg.getSndType().shortName());
		assertEquals("Error", msg.getErrorCandidate());
	}

}
