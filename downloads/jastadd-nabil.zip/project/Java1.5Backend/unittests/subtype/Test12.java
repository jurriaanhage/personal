/**
 * 
 */
package unittests.subtype;

import inference.ds.ErrorSet;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test12 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test12.java";
		super.setUp();
	}

	public void testFooMethod() {
		// --------------------------------------------------------------------
		// First call to foo
		// --------------------------------------------------------------------
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test12");
		// class contains errors
		assertNotNull(errorMap);

		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has 1 subtype errors, 1 glb errors
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(1, subtypeErrorList.size());
		SubTypeErrorMsg smsg = subtypeErrorList.get(0);
		// inferred type is Integer
		assertEquals("Integer", smsg.getInferredType().shortName());
		assertEquals("String", smsg.getOrigTuple().implied.shortName());

		List<GlbTypeErrorMsg> glbErrorList = errorSet.getGlbErrorList();
		assertEquals(1, glbErrorList.size());
		GlbTypeErrorMsg gmsg = glbErrorList.get(0);
		assertEquals("Number", gmsg.getFstType().shortName());
		assertEquals("String", gmsg.getSndType().shortName());
		// no hint
		assertEquals("", gmsg.getErrorCandidate());

		// --------------------------------------------------------------------
		// Second call to foo
		// --------------------------------------------------------------------

		args = new String[] { filePath, TestConstants._TestFlag };
		tc = new TestCompiler();
		tc.compile(args);

		errorMap = tc.getTypeDeclErrors("Test12");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is not in a conflict
		errorSet = errorMap.get("foo2.T");
		assertNull(errorSet);

		// S in the call to foo is in a conflict
		errorSet = errorMap.get("foo2.S");
		assertNotNull(errorSet);
		// S has only one bound error.
		List<PoBoundTypeErrorMsg> postBoundErrorList =
				errorSet.getPostBoundErrorList();
		assertEquals(1, postBoundErrorList.size());
		assertEquals("T", postBoundErrorList.get(0).getBoundType());
	}

}
