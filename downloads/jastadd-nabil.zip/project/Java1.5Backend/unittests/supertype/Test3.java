package unittests.supertype;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// Test3 containts no error at all.
		assertNull(tc.getTypeDeclErrors("Test3"));
	}
}
