package unittests.supertype;

import inference.ds.ErrorSet;
import inference.error_messages.SupTypeErrorMsg;

import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

public class Test1 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test1.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test1");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has a subtype error
		List<SupTypeErrorMsg> supertypeErrorList =
				errorSet.getSupertypeErrorList();
		assertEquals(supertypeErrorList.size(), 1);
		// Inferred type is Number
		SupTypeErrorMsg msg = supertypeErrorList.get(0);
		assertEquals("Integer", msg.getInferredType());
		assertEquals("Number", msg.getSubType());
	}
}
