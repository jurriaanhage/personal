/**
 * 
 */
package unittests.wildcards;

import inference.ds.ErrorSet;
import inference.ds.ErrorTuple;
import inference.error_messages.EqTypeErrorMsg;

import java.util.HashSet;
import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		EqTypeErrorMsg msg = errorSet.getEqualityErrors();
		assertNotNull(msg);
		List<ErrorTuple> eqTypes = msg.getEqTypeValues();
		assertEquals(2, eqTypes.size());
		// wildcards are not the same
		assertFalse(msg.allSameWildcard());
		HashSet<String> actual_wilds = new HashSet<String>(2);
		HashSet<String> expected_wilds = new HashSet<String>(2);
		actual_wilds.add(eqTypes.get(0).getType().shortName());
		actual_wilds.add(eqTypes.get(1).getType().shortName());
		expected_wilds.add("? extends Number");
		expected_wilds.add("? super Integer");
		assertEquals(expected_wilds.size(), actual_wilds.size());
		assertTrue(expected_wilds.containsAll(actual_wilds));
	}
}
