/**
 * 
 */
package unittests.wildcards;

import inference.error_messages.TypeCheckErrorMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test5 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test5_1.java";
		super.setUp();
	}

	public void testAllFooMethods5_1() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo1
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList =
				tc.getChechErrors("Test5_1.foo11");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("List<? extends List<? extends Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? super Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? extends List<? extends Integer>>", msg
				.getReversedWildcard());

		// --------------------------------------------------------------------
		// foo3
		// --------------------------------------------------------------------

		chList = tc.getChechErrors("Test5_1.foo31");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		msg = chList.iterator().next();
		assertEquals("List<? extends List<? extends Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? extends Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? extends List<? extends Integer>>", msg
				.getReversedWildcard());
	}

	public void testAllFooMethods5_2() {
		file = "Test5_2.java";
		filePath = TestConstants.rootdir + dir + file;
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo4
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList =
				tc.getChechErrors("Test5_2.foo41");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("List<? extends List<? super Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? super Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? extends List<? super Integer>>", msg
				.getReversedWildcard());

		// --------------------------------------------------------------------
		// foo6
		// --------------------------------------------------------------------
		chList = tc.getChechErrors("Test5_2.foo61");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		msg = chList.iterator().next();
		assertEquals("List<? extends List<? super Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? extends Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? extends List<? super Integer>>", msg
				.getReversedWildcard());
	}

	public void testAllFooMethods5_3() {
		file = "Test5_3.java";
		filePath = TestConstants.rootdir + dir + file;
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo8
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList =
				tc.getChechErrors("Test5_3.foo81");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("List<? super List<? extends Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? extends List<? super Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? super List<? extends Integer>>", msg
				.getReversedWildcard());

		// --------------------------------------------------------------------
		// foo7
		// --------------------------------------------------------------------
		// TODO uncomment me when JastAdd type system is OK.
		chList = tc.getChechErrors("Test5_3.foo71");

		assertNotNull("This due to an error in JastAdd type system", chList);
		assertEquals(1, chList.size());
		msg = chList.iterator().next();
		assertEquals("List<? super List<? extends Object>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? super Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("List<? super List<? extends Integer>>", msg
				.getReversedWildcard());
	}

}
