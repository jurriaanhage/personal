/**
 * 
 */
package unittests.wildcards;

import inference.error_messages.TypeCheckErrorMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test7 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test7.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo1
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList = tc.getChechErrors("Test7.foo1");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("List<? super List<? extends Integer>>", msg
				.getInferredFormalType().shortName());
		assertEquals("List<? super List<? super Number>>",
				msg.getActualTuple().implied.shortName());
		// TODO fixed the big in JastAdd
		// has a hint
		// assertTrue(msg.isReversible());
		// assertEquals("List<? super List<? extends Number>>", msg
		// .getReversedWildcard());
	}

}
