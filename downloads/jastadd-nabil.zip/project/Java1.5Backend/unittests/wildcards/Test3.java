/**
 * 
 */
package unittests.wildcards;

import inference.error_messages.TypeCheckErrorMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------
		// T in the call to foo not is in conflict, but has an check error
		assertNull(tc.getTypeDeclErrors("Test3"));
		Collection<TypeCheckErrorMsg> chList = tc.getChechErrors("Test3.foo1");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("Map<? extends Integer, Integer>", msg
				.getInferredFormalType().shortName());
		assertEquals("Map<? super Number, Integer>",
				msg.getActualTuple().implied.shortName());
		// has not hint
		assertFalse(msg.isReversible());

		// --------------------------------------------------------------------
		// Second call
		// --------------------------------------------------------------------
		chList = tc.getChechErrors("Test3.foo2");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		msg = chList.iterator().next();
		assertEquals("Map<? extends Number, Number>", msg
				.getInferredFormalType().shortName());
		assertEquals("Map<? super Integer, Number>",
				msg.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
	}

}
