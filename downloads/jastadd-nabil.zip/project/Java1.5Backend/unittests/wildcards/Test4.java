/**
 * 
 */
package unittests.wildcards;

import inference.error_messages.TypeCheckErrorMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test4 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// T in the call to foo not is in conflict, but has an check error
		assertNull(tc.getTypeDeclErrors("Test4"));
		Collection<TypeCheckErrorMsg> chList = tc.getChechErrors("Test4.bar1");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("Map<? super List<Integer>, Integer>", msg
				.getInferredFormalType().shortName());
		assertEquals("Map<? extends List<Integer>, Integer>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("Map<? super List<Integer>, Integer>", msg
				.getReversedWildcard());
	}

}
