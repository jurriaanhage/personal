/**
 * 
 */
package unittests.wildcards;

import inference.error_messages.TypeCheckErrorMsg;

import java.util.Collection;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Drako
 * 
 */
public class Test6 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test6.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo1
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList = tc.getChechErrors("Test6.foo1");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("List<? extends List<? super Number>>", msg
				.getInferredFormalType().shortName());
		assertEquals("ArrayList<? super List<? extends Integer>>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertFalse(msg.isReversible());
	}

	public void testBarMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		// --------------------------------------------------------------------
		// foo1
		// --------------------------------------------------------------------
		Collection<TypeCheckErrorMsg> chList = tc.getChechErrors("Test6.bar1");
		assertNotNull(chList);
		assertEquals(1, chList.size());
		TypeCheckErrorMsg msg = chList.iterator().next();
		assertEquals("Map<? extends Number, ? super Number>", msg
				.getInferredFormalType().shortName());
		assertEquals("HashMap<? super Integer, ? extends Number>", msg
				.getActualTuple().implied.shortName());
		// has a hint
		assertTrue(msg.isReversible());
		assertEquals("HashMap<? extends Integer, ? super Number>", msg
				.getReversedWildcard());
	}
}
