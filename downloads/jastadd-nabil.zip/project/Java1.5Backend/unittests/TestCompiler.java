/**
 * 
 */
package unittests;

import AST.BytecodeParser;
import AST.CompilationUnit;
import AST.Frontend;
import AST.JavaParser;
import AST.MethodAccess;

public class TestCompiler extends Frontend {

	public boolean compile(String args[]) {
		MethodAccess.resetUnitCounter();
		
		return process(args, new BytecodeParser(), new JavaParser() {
			public CompilationUnit parse(java.io.InputStream is, String fileName)
					throws java.io.IOException, beaver.Parser.Exception {
				return new parser.JavaParser().parse(is, fileName);
			}
		});
	}

	protected void processNoErrors(CompilationUnit unit) {
		// unit.transformation();
		// unit.generateClassfile();
	}

	protected String name() {
		return "Java5Compiler";
	}

	protected String version() {
		return "R20071015";
	}
}
