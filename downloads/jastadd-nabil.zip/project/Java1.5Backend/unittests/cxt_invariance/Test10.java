/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;

import java.util.Collection;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test10 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test10.java";
		super.setUp();
	}

	public void testFooMethod() {
		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------

		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test10");
		// class contains errors
		assertNotNull(errorMap);
		// R in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.R"));
		Collection exts = tc.getExtensions("Test10.foo1", "R");
		// NO FIX
		assertNull(exts);

		// --------------------------------------------------------------------
		// Second call
		// --------------------------------------------------------------------

		// class contains errors
		assertNotNull(errorMap.get("foo2.R"));
		// There is a FIX
		exts = tc.getExtensions("Test10.foo2", "R");
		assertNotNull(exts);
		assertNotNull(getMultipleTypeChangeExt(exts));
	}

	public void testBarMethod() {
		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------

		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test10");
		// class contains errors
		assertNotNull(errorMap);
		// R in the call to bar is in a conflict
		assertNotNull(errorMap.get("bar1.R"));
		Collection exts = tc.getExtensions("Test10.bar1", "R");
		// NO FIX
		assertNull(exts);

		// --------------------------------------------------------------------
		// Second call
		// --------------------------------------------------------------------

		// class contains errors
		assertNotNull(errorMap.get("bar2.R"));
		// There is a FIX
		exts = tc.getExtensions("Test10.bar2", "R");
		assertNotNull(exts);
		assertNotNull(getMultipleTypeChangeExt(exts));
	}
}
