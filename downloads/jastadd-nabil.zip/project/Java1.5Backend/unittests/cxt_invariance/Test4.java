/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;

import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test4 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test4.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test4");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.T"));		
		assertNull(tc.getExtensions("Test4.foo1", "T"));		
		
		// S in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.S"));		
		assertNull(tc.getExtensions("Test4.foo1", "S"));
	}
}
