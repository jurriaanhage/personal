/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test2 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test2.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test2");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has a subtype error
		List<SupTypeErrorMsg> supertypeErrorList = errorSet.getSupertypeErrorList();
		assertEquals(supertypeErrorList.size(), 1);
		// Inferred type is Number
		SupTypeErrorMsg superMsg = supertypeErrorList.get(0);
		assertEquals("Integer", superMsg.getInferredType());
		// Source of error is Integer
		assertEquals("Number", superMsg.getSubType());
		Collection exts = tc.getExtensions("Test2.foo1", "T");
		assertNotNull(exts);
		TypeChangeExt msgExt = getTypeChangeExt(exts);
		assertNotNull(msgExt);
		assertEquals("Number", msgExt.replacement());
		
		// Second call
		errorSet = errorMap.get("foo2.T");
		assertNotNull(errorSet);
		// T has a subtype error
		supertypeErrorList = errorSet.getSupertypeErrorList();
		assertEquals(supertypeErrorList.size(), 1);
		// Inferred type is Number
		superMsg = supertypeErrorList.get(0);
		assertEquals("Integer", superMsg.getInferredType());
		// Source of error is Integer
		assertEquals("Number", superMsg.getSubType());
		// no fix
		exts = tc.getExtensions("Test1.foo2", "T");
		assertNull(exts);		
	}
}
