/**
 * 
 */
package unittests.cxt_invariance;

import inference.error_messages.heuristic_messages.MultipleTypeChangeExt;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.Iterator;

import unittests.TestConstants;
import junit.framework.TestCase;

/**
 * @author Osiris
 * 
 */
public class BaseTest extends TestCase {

	boolean disableStdOut = true;
	final static String dir = "cxt_heuristic/";
	String file, filePath;

	protected void setUp() throws Exception {
		super.setUp();
		filePath = TestConstants.rootdir + dir + file;
		if (disableStdOut && TestConstants.nullStdout != null) {
			System.setOut(TestConstants.nullStdout);
		} else if (System.out == TestConstants.nullStdout) {
			System.setOut(TestConstants.stdout);
		}
	}

	protected TypeChangeExt getTypeChangeExt(Collection exts) {
		for (Iterator iter = exts.iterator(); iter.hasNext();) {
			Object ext = iter.next();
			if (ext instanceof TypeChangeExt) {
				return (TypeChangeExt) ext;
			}
		}
		return null;
	}
	
	protected MultipleTypeChangeExt getMultipleTypeChangeExt(Collection exts) {
		for (Iterator iter = exts.iterator(); iter.hasNext();) {
			Object ext = iter.next();
			if (ext instanceof MultipleTypeChangeExt) {
				return (MultipleTypeChangeExt) ext;
			}
		}
		return null;
	}

}
