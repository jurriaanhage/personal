/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test11 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test11.java";
		super.setUp();
	}

	public void testFooMethod() {
		// --------------------------------------------------------------------
		// First call
		// --------------------------------------------------------------------

		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test11");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.T"));
		// S in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.S"));
		Collection exts = tc.getExtensions("Test10.foo1", "T");
		// NO FIX
		assertNull(exts);
		exts = tc.getExtensions("Test10.foo1", "S");
		// NO FIX
		assertNull(exts);

		// --------------------------------------------------------------------
		// Second call
		// --------------------------------------------------------------------

		// class contains errors
		assertNotNull(errorMap.get("foo2.T"));
		assertNotNull(errorMap.get("foo2.S"));
		// There is a FIX for T
		exts = tc.getExtensions("Test11.foo2", "T");
		assertNotNull(exts);
		TypeChangeExt msgEx = getTypeChangeExt(exts);
		assertNotNull(msgEx);
		assertEquals("Double", msgEx.replacement());
		// There is a FIX for S
		exts = tc.getExtensions("Test11.foo2", "S");
		assertNotNull(exts);
		msgEx = getTypeChangeExt(exts);
		assertNotNull(msgEx);
		assertEquals("Integer", msgEx.replacement());
		
	}

}
