/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test3 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test3.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test3");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("foo1.T");
		assertNotNull(errorSet);
		// T has a subtype error
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(subtypeErrorList.size(), 1);
		// Inferred type is Number
		SubTypeErrorMsg subTypeErrorMsg = subtypeErrorList.get(0);
		assertEquals(subTypeErrorMsg.getInferredType().shortName(), "Number");
		// Source of error is Integer
		assertEquals(subTypeErrorMsg.getSuperType(), "Integer");
		Collection exts = tc.getExtensions("Test3.foo1", "T");
		assertNotNull(exts);
		TypeChangeExt msgExt = getTypeChangeExt(exts);
		assertNotNull(msgExt);
		assertEquals("Integer", msgExt.replacement());		
	}
	
	public void testBarMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test3");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		ErrorSet errorSet = errorMap.get("bar1.T");
		assertNotNull(errorSet);
		// T has a subtype error
		List<SubTypeErrorMsg> subtypeErrorList = errorSet.getSubtypeErrorList();
		assertEquals(subtypeErrorList.size(), 1);
		// Inferred type is Number
		SubTypeErrorMsg subTypeErrorMsg = subtypeErrorList.get(0);
		assertEquals(subTypeErrorMsg.getInferredType().shortName(), "Num");
		// Source of error is Integer
		assertEquals(subTypeErrorMsg.getSuperType(), "Int");
		// no fix
		Collection exts = tc.getExtensions("Test3.bar1", "T");
		assertNull(exts);		
	}
}
