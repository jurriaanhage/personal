/**
 * 
 */
package unittests.cxt_invariance;

import inference.ds.ErrorSet;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collection;
import java.util.Map;

import unittests.TestCompiler;
import unittests.TestConstants;

/**
 * @author Osiris
 * 
 */
public class Test5 extends BaseTest {

	protected void setUp() throws Exception {
		file = "Test5.java";
		super.setUp();
	}

	public void testFooMethod() {
		String[] args = new String[] { filePath, TestConstants._TestFlag };
		TestCompiler tc = new TestCompiler();
		tc.compile(args);

		Map<String, ErrorSet> errorMap = tc.getTypeDeclErrors("Test5");
		// class contains errors
		assertNotNull(errorMap);
		// T in the call to foo is in a conflict
		assertNotNull(errorMap.get("foo1.T"));
		Collection exts = tc.getExtensions("Test5.foo1", "T"); 
		assertNotNull(exts);	
		TypeChangeExt msgEx = getTypeChangeExt(exts);
		assertNotNull(msgEx);
		assertEquals("Integer", msgEx.replacement());
	}
}
