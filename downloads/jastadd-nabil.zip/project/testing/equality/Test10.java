import java.util.*;

class Test10 {
    <T extends Number, S extends Integer> void foo(Map<T, T> a, Map<T, T> b, 
                                                   Map<S, S> c, Map<S, S> d){
        Map<String, Float> m = null;
        Map<Integer, Float> m1 = null;
        // S must be Integer, but T must Float, thus no repair.
        foo(m, m1, m, m1);
    }
}
