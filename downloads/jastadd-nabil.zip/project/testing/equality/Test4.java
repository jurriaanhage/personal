import java.util.List;
import java.util.Map;

class Test4{
    <T> void foo(List<T> a, List<T> b){
        List<? extends Number> ln = null;
        foo(ln, ln); // Error
        // test final class
        List<? extends Integer> li = null;
        foo(li, li); // Error
    }

    <T> void bar(Map<T, T> a){
        Map<? super Error, ? super Error> erm = null;
        bar(erm); // Error
        // test TOP
        Map<? super Object, ? super Object> om = null;
        bar(om);  // Error
    }
}
