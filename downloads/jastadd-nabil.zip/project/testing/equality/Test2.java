import java.util.*;

class Test2{
    <T> void foo(Map<T,T> a){
        Map<Object, Number> m = null;
        foo(m);
        /*
         * Map<Object, Number> << Map<T,T>
         * ==>
         * Object =  T and Number = T
         * ==> 
         * Both Object or Number are can make the call legal
         */
    }
}
