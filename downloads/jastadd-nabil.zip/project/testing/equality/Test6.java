import java.util.*;

class Test6{
    <T> void foo(Map<T, T> a, List<T> b, List<T> c, List<T> d) {
        Map<Number, Number> m = null;
        List<Integer> l = null;
        List<Integer> l2 = null;

        foo(m, l, l, l2);
        // Although the number of type changes is the same (Number 2, Integer 2), it preferred to
        // change Number because it's localized in one place.
    }
}
