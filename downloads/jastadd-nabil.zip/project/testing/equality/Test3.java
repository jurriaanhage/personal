import java.util.*;

class Test3{
    <T extends Comparable<Integer>> void foo(Map<T, T> a, Map<T, T> b){
        Map<Double, Comparable<Integer>> n = null;
        Map<Number, Integer> m = null;
        foo(m,n);
        /*
         * Map<Double, Comparable<Integer>> << Map<T, T>  and  Map<Number, Integer> << Map<T, T>
         * ==>
         * Double = T and Comparable<Integer> = T and Number = T and Integer = T
         * ==>
         * Integer or Comparable<Integer> can make the call legal
         */
    }
}
