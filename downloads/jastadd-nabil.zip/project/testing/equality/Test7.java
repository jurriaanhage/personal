import java.util.Map;

class Test7{
    // stop inference at T, because we cannot check the types provided for S against its bound T.
    <T, S extends T> void foo(Map<T, T> a, S b){
        Map<Integer, String> m = null;
        foo(m, "");
    }
}
