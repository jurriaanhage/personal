/*
 * Testing combi solver
 */
import java.util.*;

class Test8{
    // T, S{T}, U{T}, R{S}
    <T, S extends T, R extends S> void foo(Map<T, T> a, Map<S, S> b, Map<R, R> c){
        Map<Integer, Double> m1 = null;
        Map<Integer, Byte> m2 = null;
        Map<Integer, Byte> m3 = null;
        foo(m1, m2, m3);
    }

    //<R, S, T, U extends PI<R> & Map<S, T>> void foo(Map<R, R> a, 
    //                    Map<S, S> b, Map<T, T> c, Map<U, U>   d){
    //    Map<Integer, Number> m = null;
    //    foo(m,m,m,m);
    //}
}
interface PI<T>{}
