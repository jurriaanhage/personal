import java.util.*;

class Test1{
    <T> void foo(Map<T, T> a, T b)
    {
        Map<Integer, Number> min = null;
        Integer i                = null;
        foo(min, i);
        /*
         * Map<Integer, Number> << Map<T,T> and Integer << T
         * Integer = T   and   Number = T   and Integer << T
         * Integer = T   and   Number = T   and Integer <: T
         * Integer = Number                 and Integer <: T
         * ==> BOTTOM
         * Source of error is the Number.
         */
        Number n                = null;
        foo(min, n);
        /*
         * Map<Integer, Number> << Map<T,T> and Number << T
         * Integer = T   and   Number = T   and Number << T
         * Integer = T   and   Number = T   and Number <: T
         * Integer = Number                 and Number <: T
         * ==> BOTTOM
         * Source of error is the Integer.
         */
    }
}
