import java.util.List;

class Test5{
    <T> void foo(List<T> a, List<T> b, List<T> c){
        List<Number> src = null;
        List<Integer> small = null;
        List<Integer> big = null;

        foo(src, small, big); // Number:= 1, Integer:= 2
        foo(src, src, big);   // Number:= 1, Integer:= 1
    }
}
