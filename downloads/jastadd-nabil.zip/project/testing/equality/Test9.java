import java.util.*;
/*
 * Problems caused by after checks.
 */
class Test9{
    // ------------------------------------------------------------------------
    // After-check in the same type group.
    // ------------------------------------------------------------------------

    // The solution for this call should be {T:Number, S:Integer}. However, the
    // type for S does not satisfy it's after-check.
    <T, S extends T> void foo(Map<S, ? extends S> a, Map<T, T> b){
        Map<Integer, ? super Double> sm = null;
        Map<String, Number> tm = null;
        foo(sm, tm);
    }

    // The solution for this call should be {T:Number, S:Integer}. However, the
    // type for T does not satisfy the after-check of S.
    <T, S extends T> void bar(Map<S, ? extends T> a, Map<T, T> b){
        Map<Integer, ? super Double> sm = null;
        Map<String, Number> tm = null;
        bar(sm, tm);
    }

    // ------------------------------------------------------------------------
    // After-check NOT in the same type group.
    // ------------------------------------------------------------------------

    // The solutions for this call should be {T:Number, S:Integer, R:Object} or
    // {T:Number, S:Integer, R:Number}. However, the type Number for R does not
    // satisfy the after-checks of S. The only possible solution is then
    // {T:Number, S:Integer, R:Object}
    <T, S extends T, R> void baz(Map<S, ? extends R> a, Map<T, T> b, Map<R, R> c){
        Map<Integer, ? super Double> sm = null;
        Map<String, Number> tm = null;
        Map<Object, Number> rm = null;
        baz(sm, tm, rm);
    }
}
