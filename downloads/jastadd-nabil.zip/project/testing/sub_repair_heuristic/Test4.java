import java.util.*;

class Test4{
    <T, S> void foo(Map<? super T, ? super T> a, Map<? super S, ? super S> b, T c, S d ){
        Map<? super Double, ? super Double> lt = null;
        Map<? super Integer, ? super Integer> ls = null;
        Number n = null;
        foo(lt, ls, n, n);
    }
}
