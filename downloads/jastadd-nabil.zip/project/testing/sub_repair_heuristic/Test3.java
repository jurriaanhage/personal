import java.util.*;

class Test3{
    /*
     * T <: Num && T <: Int              => T = Int => min-conflict = 2
     * Num <: T && Str <: T              => T = Obj => min-conflict = 2
     * ==>
     * maxLUB = Num because it has less amount of conflicts.
     * Changing the constraints to: T <: Num && Num <: T 
     * type checks an yield the fix: Int :-> Num && Str :-> Num
     */
    <T> void foo(Map<? super T, ? super T> a, Map<? extends T, ? extends T> b/*, T c*/){
        Map<Number, Integer> ma = null;
        Map<Number, String> mb = null;
        foo(ma, mb);
    }

}
