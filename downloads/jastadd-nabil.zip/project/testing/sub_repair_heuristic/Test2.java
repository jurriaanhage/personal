import java.util.*;
import java.awt.AWTEvent;
import java.awt.event.*;

class Test2{
    <T> void foo(T a, T b, Map<? super T, ? super T> c){
        Map<Integer, Double> m = null;
        Number n = null;
        //foo(1, n, m);
        /*
         * Int <: T && Num <: T --> T = Num --> min-conflict = 2
         * T <: Int && T <: Dou --> T = $   --> min-conflict = max_int
         *
         */
    }
    
    <T extends Number> void bar(T a, T b, T c, Map<? super T, ? super T> d, List<? super T> e){
    }
    <T> void foo(T a, T b, T c, Map<? super T, ? super T> d, List<? super T> e){
        //1
        FocusEvent p1 = null;
        //2 
        ComponentEvent p2 = null;
        //3
        AWTEvent p3 = null;
        //4 
        //EventObject p4 = null;

        //Map<FocusEvent, AWTEvent> m = null;
        Map<AWTEvent, FocusEvent> m = null;
        List<String> l = null;
        //List<AWTEvent> l = null;
        
        foo(p2, p3, p1,m, l);
        //bar(p2, p3, p1,m, l);
        /*
         * 1 <: T   && 2 <: T && 3 <: T  ==> T = 3 --> min-conflict
         * T <: Str && T <: 1 && T <: 2  ==> T = $ --> min-conflict = max_int
         *
         * intersect(SUPS, SUBS) = {1, 2}
         * 1 --> min-conflict = 3
         * 2 --> min-conflict = 3
         *
         * 1 <: T   && 2 <: T && 3 <: T  ==> T = 3 --> min-conflict
         * T <: Str && T <: 1 && T <: 3  ==> T = $ --> min-conflict = max_int
         *
         * intersect(SUPS, SUBS) = {1, 3}
         * 1 --> min-conflict = 3
         * 3 --> min-conflict = 2
         */
    }
}
