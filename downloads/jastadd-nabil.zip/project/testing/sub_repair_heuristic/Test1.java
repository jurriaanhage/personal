import java.util.*;

class Test1{
    <T> void foo(T a, T b, Map<? super T, ? super T> c){
        Map<Integer, Number> m = null;
        Number n = null;
        //foo(1, n, m);
    }

    void test(){
        Map<Number, Double> m = null;
        Number n = null;
        foo(1, n, m);
        /*
         * Int <: T && Num <: T ==> T = Num --> min-conflict = 1
         * T <: Dou && T <: Num ==> T = Dou --> min-conflict = 2
         */
        Map<Double, Double> m1 = null;
        foo(1, n, m1);
    }
}
