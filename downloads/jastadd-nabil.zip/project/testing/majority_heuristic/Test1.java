import java.util.*;

class Test1{
    <T> void foo(Map<? super T, ? super T> m, Map<? extends T, ? extends T> n){
        Map<Top, Middle> a = null;
        Map<Bottom,Between> b = null;
        foo(a,b);
        /*
         * Exp:
         *   `Between` in lub cause T to be Top, which cause the an error.
         *
         * Map<Bottom, Between> << Map<Top, Middle>
         * Bottom <: T  and  Between <: T ==> T = lub(Bottom, Between) = Top
         * Map<Top, Middle> << Map<? super T, ? super T>
         * T <: Top  and T <: Middle
         * Top <: Top  and Top </: Middle
         */
    }
}

class Top{}
class Middle extends Top{}
class Between extends Top{}
class Bottom extends Middle{}

/*
Map<Number, Comparable<? extends Number>> a = null;
Map<Integer, Double> b = null;
foo(null,b);
*/
/*
 * Map<Integer, Double> << Map<? extends T, ? extends T>
 * Integer <: T  and Double <: T
 * T = lub(Integer, Double) = Number & lci(Inv(Comparable) 
 *                          = Number & Comparable<? extends Number & Comparable<..>>
 *   where
 *     let EST(Integer) = {Integer, Number, Comparable, ..}
 *     let EST(Double)  = {Double, Number, Comparable, ..}
 *     let EC           = {Number, Comparable}
 *     let MEC          = {Number, Comparable}
 *     let Inv(Comparable)       = {Comparable<Integer>, Comparable<Double>} 
 *     let lci(Comparable<Integer>, Comparable<Double>) =
 *       Comparable<lcta(Integer, Double)>
 *     let lcta(Integer, Double) = ? extends lub(Integer, Double)
 */
