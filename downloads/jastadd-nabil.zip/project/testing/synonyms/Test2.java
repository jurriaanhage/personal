import java.util.*;

class UMAP<U> extends HashMap<Integer, U>{}

class Test2{
    <T> void foo(Map<T, T> a){
        UMAP<String> um = null;
        foo(um);
    }
}
