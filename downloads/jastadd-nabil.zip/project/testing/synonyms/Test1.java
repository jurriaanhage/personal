import java.util.*;

class INMap extends HashMap<Integer, Number>{}

class Test{
    <T> void foo(Map<T, T> a){
        INMap m = null;        
        foo(m);
    }
}
