import java.util.Map;

class Test2<T extends Number>{
    public Test2(Map<? super T, ? super T> b){}

    void test(){
        Map<Object, String> m3 = null;
        Test2<String> t = new Test2<Number>(m3); 
        Test2<String> t2 = new Test2<String>(m3); 
    }
}
