class Test1<T extends Number>{
    public Test1(T a, T b){}

    void test(){
        //new Test1<String, Number>(); 
        new Test1(1, ""); 
        new Object();
    }
}
