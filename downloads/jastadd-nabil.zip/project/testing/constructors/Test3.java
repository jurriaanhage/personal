class Test3<T, S>{
    void test(){
        new Test3<Integer>();
    }
}
