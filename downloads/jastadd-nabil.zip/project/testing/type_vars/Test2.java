import java.util.*;

class TVar{
    public <T extends Number> void foo (T lt){
        Map<List<T>, List<Integer>> a = null;
        bar(a);
        /*
         * Map<List<classT>, List<Integer>> << Map<S, ? extends S>
         * List<classT> = S and List<Integer> <: S
         * List<classT> = S and List<Integer> <: List<classT>
         */
    }

    public <S> void bar(Map<S,? extends S> mtt){
    }
}
