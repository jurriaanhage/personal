import java.util.Map;

class Test3{
    <T> void foo(Map<T,T> a){
        foo(a);
        Map<T, T> m = null;
        foo(m);
    }
}

