import java.util.Map;
import java.util.List;

class Test5{
    <T extends List<T>> void foo(Map<T,T> a){
        foo(a);
        Map<T, T> m = null;
        foo(m);
    }
}

