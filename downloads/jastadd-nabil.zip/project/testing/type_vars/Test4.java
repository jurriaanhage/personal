import java.util.Map;

class Test4{
    <T> void foo(Map<? extends T,T> a){
        Map<? extends T, T> m = null;
        foo(m);
        bar(m);
    }

    <T> void bar(Map<? extends T,T> a){    
        Map<? extends T, T> m = null;
        bar(m);
    }
}
