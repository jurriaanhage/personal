import java.util.*;

class TVar{
    public <T extends Number> void foo (T lt){
        Map<T, Integer> a = null;
        bar(a);
        /*
         * De aanroep van de methode bar is niet geldig, voor de volgende reden:
         *   Map<T, Integer> << Map<S, ? extends S>
         *   ==>
         *   T = S and Integer <: S
         *   ==>
         *   Integer <: T [undecidable]
         *
         * De aanroep in JastAdd compiler wordt ook geweigerd, maar dan voor een andere ongeldige
         * reden. JastAdd concludeert dat S Integer als type moet hebben, aangezien T geen
         * Integer is, is de aanroep fout.
         *
         * In mijn eigen extension wordt zoals verwacht T als type voor S ge-inferreerd, maar
         * aangezien de type-system in JastAdd Integer als subtype is van T, wordt er geen error
         * message gegenereerd. De fout de type-system maakt, is dat hij geen onderscheid maakt
         * tussen een type variabele die als placeholder fungeert en type variabele die als een
         * volwaardige type is. M.a.w als T een in de parameter gedeelte zit van een methode, dan is
         * Integer inderdaad een subtype van T, omdat T Number als upper-bound heeft. Maar in dit
         * geval is een argument voor een method, dus T is een normale type waarvan we alleen weten,
         * dat het een subtype is va Number. Dus het is niet mogelijk om te zeggen of Integer
         * inderdaad een subtype is van T, want het kan in een bepaalde geval Double of Float zijn.
         */        
    }

    public <S> void bar(Map<S,? extends S> mtt){
    }
}
