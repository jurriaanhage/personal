import java.util.*;

class Class3{
    <T> void foo(Set<T> a){}
    <T> void foo(ArrayList<T> a){}

    void test(){
        List<Object> l = null;
        foo(l);
    }
}
