import java.util.*;

class Class2{
    <T extends Number> void foo(List<T> a){}
    <T extends Integer> void foo(ArrayList<T> a){}
    <T extends Integer> void foo(Set<T> a){}

    void test(){
        foo(new ArrayList<Object>());
    }
}
