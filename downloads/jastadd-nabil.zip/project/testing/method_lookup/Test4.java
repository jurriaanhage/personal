import java.util.*;
class Class1{
    <T extends Number> void foo(T a){}
    <T extends Integer> void foo(T a){}
    <T extends String> void foo(T a){}
    <T extends List<String>> void foo(T a){}

    void test(){
        foo(1);
        this.<String>foo(1);
    }
}
