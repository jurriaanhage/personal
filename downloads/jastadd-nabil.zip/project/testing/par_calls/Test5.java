import java.util.Map;

class Test5{
    <T> void foo(Map<? extends T, ? extends T> a){
        Map<Integer, Number> m = null;
        this.<Number>foo(m);
        this.<Integer>foo(m);
    }

    <T> void bar(Map<? super T, ? super T> a){
        Map<Integer, Number> m = null;
        this.<Number>bar(m);
        this.<Integer>bar(m);
    }
}
