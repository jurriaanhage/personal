class Test8{
    <T, S extends T> void foo(T a, S b){
        this.<Integer>foo(1,1.0);
    }
}
