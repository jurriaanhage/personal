import java.util.Map;
import java.util.List;

class Test3{

    <T extends Number, S extends List<T>> T foo(Map<T, S> a){
        Map<Integer, List<Number>> m = null;
        this.<Integer, List<Integer>>foo(m);
        this.<Number, List<Number>>foo(m);
        this.<Number, List<Integer>>foo(m);
        return null;
    }
}

