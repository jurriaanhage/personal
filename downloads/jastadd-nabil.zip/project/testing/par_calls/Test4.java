import java.util.List;

class Test4{
    <T extends Number> void foo(List<? extends T> a){
        List<Integer> l = null;
        this.<Double>foo(l);
        List<String> l2 = null;
        this.<String>foo(l2);
    }
}
