import java.util.List;

class Test6{
    <T> void foo(List<? extends T> a){
        List<? super Number> l = null;
        this.<Number>foo(l);
        //this.<Object>foo(l);
    }
}
