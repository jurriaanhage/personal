class Test1{

    <T extends Number> T bar(T a){
        //this.<Double>bar(0d);
        //this.<String>bar("");
        this.<Integer>bar(0d);
        return null;
    }
}
