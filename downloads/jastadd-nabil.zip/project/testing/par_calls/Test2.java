import java.util.Map;

class Test2{

    <T extends Number> T foo(Map<T, ? extends T> a){
        Map<Integer, Number> m = null;
        this.<Integer>foo(m);
        this.<Number>foo(m);
        return null;
    }

    <T> void bar(Map<T, ? super T> a){
        Map<Object, String> m = null;
        this.<String>bar(m);
        this.<Object>bar(m);
    }
}

