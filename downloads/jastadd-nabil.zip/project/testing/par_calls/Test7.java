class Test7{
    <T extends Number> void foo(){
        this.<Integer>foo();
        this.<String>foo();
    }

    <T extends Number> void foo(Object o){
        this.<Integer>foo(1);
        this.<String>foo(null);
    }
}
