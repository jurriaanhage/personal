import java.util.List;

class Test1{
    <T extends Number> List<T> foo(T a){
        return null;
    }

    <S extends Integer> void bar(List<S> a){
        List<String> l = null;
        bar(foo(l));
    }
}
