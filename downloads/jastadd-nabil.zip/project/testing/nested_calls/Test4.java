import java.util.List;

class Test4{
    <T> List<T> newList(T t){ return null;}

    <S> void foo(List<S> b, List<S> a){
         List<Integer> li = null;
         foo(li, newList(1.0));
    }
}
