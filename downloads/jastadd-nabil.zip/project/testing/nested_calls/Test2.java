import java.util.List;

class Test2{
    <T extends Number> List<T> foo(T a){
        return null;
    }

    <S extends Integer> void bar(List<S> a){
        Double d = null;
        bar(foo(d));
    }
}

