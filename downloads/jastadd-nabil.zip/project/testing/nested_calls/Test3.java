import java.util.List;

class Test1{
    <T extends Number> List<T> foo(T a){
        return null;
    }

    <S extends Integer> List<S> bar(List<S> a){
        return null;
    }

    <R extends Integer> void baz(Object o, List<R> a){
        baz(0, bar(foo("1.5")));
        baz(0, bar(foo(1.5)));
    }
}
