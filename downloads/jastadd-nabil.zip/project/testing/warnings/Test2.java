import java.util.*;

class Test2{
    <T> void foo(List<? extends T> a, Map<T, T> b){
        List<String> l = null;
        Map<? extends String, ? super Double> m = null;
        foo(l, m);
    }

    <T> void bar(List<? super T> a, Map<T, T> b){
        List<String> l = null;
        Map<? extends Integer, ? super Integer> m = null;
        bar(l, m);
    }
}
