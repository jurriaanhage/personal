import java.util.*;

class Test1{
    <T> void foo(List<? extends T> a, Map<T, T> b){
        List<String> l = null;
        Map<Integer, Double> m = null;
        foo(l, m);
    }

    <T> void bar(List<? super T> a, Map<T, T> b){
        List<String> l = null;
        Map<Integer, Double> m = null;
        bar(l, m);
    }
}
