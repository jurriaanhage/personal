import java.util.List;

class Test4{
    <T extends Number> void foo(List<T> a){
        List<? super String> l = null;
        foo(l);
    }
}
