interface Map<K, V> {}

//interface IntMap<T> extends Map<T, String>{}
//interface IntMap<T> extends Map<T, Number>{}
interface IntMap<T> extends Map<T, Integer>{}

class Test8{
    // I think the compilers(javac, ecj) wrongfully reject the call in foo.
    // Eclipse acts real strange. For the type of T, it just copies whatever is was given in the
    // extends class of interface IntMap.
    <T> void foo(Map<? super T, ? super T> a){
        IntMap<? extends Integer> im = null;
        foo(im);
        /*
         * Let WeT = '? extends Integer'
         * Map<WeT, Integer> << Map<? super T, ? super T>
         * T <: Integer
         * T = Integer
         * Integer </: '? extends Integer'
         */
    }

    <T> void bar(Map<? super T, ? extends T> a){
        IntMap<? extends Integer> im = null;
        bar(im);
        /*
         * Map<? extends Integer, Integer> << Map<? super T, ? extends T>
         * Integer <: T
         * T = Integer
         * Integer </: '? extends Integer'
         */
    }
}
