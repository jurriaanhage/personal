import java.util.List;

class Test1{
    <T extends Number> void foo(List<T> a){
        List<? super Integer> l = null;
        foo(l);
        /*
         * Let WsT = ? super Integer
         * List<WsT> << List<T> ==> WsT = T
         * Bounds: T <: Number ==> WsT </: Number
         *
         * Let WeT = ? extends Integer
         * List<WeT> << List<T> ==> WeT = T
         * Bounds: T <: Number ==> WeT <: Number, becuase Integer <: Number
         *
         * changing List<? super Integer> to List<? extends Integer> solves the bound conflict 
         */

        List<? super Comparable<? extends Number>> lc = null;
        foo(lc);
        /*
         * Let WsT = ? super Comparable<? extends Number>
         * List<WsT> << List<T> ==> T = WsT
         * Bounds: T <: Number ==> WsT </: Number
         *
         * Let WeT = ? extends Comparable<? extends Number>
         * List<WeT> << List<T> ==> WeT = T
         * Bounds: T <: Number ==> WeT </: T, becuase Comparable<? extends Number> </: Number
         *
         * changing List<? super ...> to List<? extends ...> solves nothing.
         */
    }
    
}
