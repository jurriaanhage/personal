import java.util.Map;

class Test5{
    //TODO find out why this program is accepted, while it must be rejected.
    <T> void foo(Map<? extends T, T> a){
        Map<Number, ? super Integer> m = null;
        foo(m);
    }
}
