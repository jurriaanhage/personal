import java.util.List;

class Test6{
    <T extends Num> void foo(List<T> a, List<? super T> b){
        List<? super SInt> ls = null;
        //List<? extends SInt> ls = null;
        List<Int> li = null;
        foo(ls, li);
        /*
         * Let WsT = ? super SInt
         * List<WsT> << List<T> and List<Int> << List<? super T>
         * T = WsT and T </: Int, because WsT could be Num
         * =====================================================
         * Let WeT = ? extends SInt
         * List<WeT> << List<T> and List<Int> << List<? super T>
         * T = WeT and T <: Int, because WeT can at most be SInt which is a subtype of Int
         */
    }
    <T extends Num> void bar(List<T> a, List<? extends T> b){
        List<? super SInt> ls = null;
        //List<? extends SInt> ls = null;
        List<Int> li = null;
        bar(ls, li);
        /*
         * Let WsT = ? super SInt
         * List<WsT> << List<T> and List<Int> << List<? extends T>
         * T = WsT and Int </: T, because WsT could be SInt
         * =====================================================
         * Let WeT = ? extends SInt
         * List<WeT> << List<T> and List<Int> << List<? extends T>
         * T = WeT and Int </: T, because WeT can at most be SInt 
         */
    }
}

class Num{}
class Int extends Num{}
class SInt extends Int{}
