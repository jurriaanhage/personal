import java.util.Map;
import java.util.List;

class Test2{
    <T> void foo(Map<? super T, T> a){
        Map<? extends Integer, Number> m = null;
        foo(m);
    }

    <T extends Number> void bar(Map<? extends T, ? extends T> a){
        Map<? super Object, ? extends Integer> m = null;
        bar(m);
    }
}
