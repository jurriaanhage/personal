import java.util.*;

interface IntMap<T> extends Map<T, Integer>{}

class Test9{

    <T> void foo(Map<? extends T, ? extends T> a){
        IntMap<? super Integer> im = null;
        foo(im);
        /*
         * Let WsT = '? super Integer'
         * Map<WsT, Integer> << Map<? extends T, ? extends T>
         * WsT <: T AND Integer <: T
         * T = lub(WsT, Integer) = Integer
         */
    }

    <T> void bar(Map<? extends T, ? super T> a){
        IntMap<? super Integer> im = null;
        bar(im);
        /*
         * Let WsT = '? super Integer'
         * Map<WsT, Integer> << Map<? extends T, ? super T>
         * WsT <: T AND T <: Integer
         * T = WsT T <: Integer
         * WsT </: Integer
         * =====================================
         * Replace 'super' with 'extends':
         * Let WeT = '? extends Integer'
         * Map<WeT, Integer> << Map<? extends T, ? super T>
         * WeT <: T AND T <: Integer
         * T = WeT AND T <: Integer
         * WeT <: Integer
         */
    }
}

