import java.util.Map;

class Test7{
    <T extends Number, S extends T> void foo(Map<T,S> a ){
        Map<? super Integer, Number> m = null;
        foo(m);
        /*
         * Let WsT = '? super Integer'
         * Map<WsT, Number> << Map<T, S>
         * T = WsT and S = Number
         * bounds: 
         * T <: Number ==> WsT </: Number, because WsT could Object
         * S <: T      ==> Number </: WsT, because WsT could be Integer 
         * =====================================================
         * Let WeT = '? extends Integer'
         * Map<WeT, Number> << Map<T, S>
         * T = WeT and S = Number
         * bounds: 
         * T <: Number ==> WeT <: Number
         * S <: T      ==> Number </: WeT, because WeT is at most Integer 
         */
    }
}

