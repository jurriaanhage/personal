import java.util.List;

class Test3{
    <T extends Number> List<T> foo(List<T> a){
        List<? super Integer> l = null;
        List<Number> ret = foo(l);
        return null;
    }
}
