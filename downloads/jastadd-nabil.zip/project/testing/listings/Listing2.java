import java.util.*;

class Listing2{
    static <T> void bar(Map<T, ? extends T> a){
        Map<Integer, Number> m2 = null;
        bar(m2);
    }
}
