import java.util.*;

class Listing3{
    <T extends Number> void baz(List<T> a){
        List<Comparable<Integer>> x = null;
        baz(x);
    }
}
