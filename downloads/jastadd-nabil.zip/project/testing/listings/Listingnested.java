import java.util.*;

class Listingnested{
    <T> Map<Number,Integer> foo(Map<T,T> a){
        Map<Number,String> m1 = null;
        foo(foo(m1));
    }
}

