import java.util.*;

class JavacError3{
    <T extends Number> List<T> bar(Map<? super T, ? super T> a){        
        Map<List<String>, List<String>> m1 = null;
        Map<Double, Number> m2 = null;
        List<Integer> l = bar(m1);
        List<Integer> s = bar(m2);
        s = bar(m1);
        return null;
    }
}

