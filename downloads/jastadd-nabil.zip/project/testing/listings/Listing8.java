import java.util.*; 

class Listing8{
   <T> void foo(Map<? super T, T> a) {
      Map<Integer, Number> m = null;
      foo(m);
   }
}

