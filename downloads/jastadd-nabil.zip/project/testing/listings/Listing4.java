import java.util.*;

class Listing4{
    <T> void bar(Map<T, T> a){
        Map<? extends Number, ? extends Number> m = null;
        bar(m);
    }
}
