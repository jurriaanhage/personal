import java.util.*;

class Listing1{
    <T> void foo(Map<T,T> a){
        Map<Number, Integer> m1 = null;
        foo(m1);
    }
}
