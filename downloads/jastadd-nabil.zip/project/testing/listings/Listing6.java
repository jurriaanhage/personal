import java.util.*;

class Listing6{
    <T extends Number> void foo(Map<? super T, ? super T> a){        
        Map<Number, String> m = null;
        foo(m);
    }
}

