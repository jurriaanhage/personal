import java.util.*;

class Listingindep{
    <T,S> void foo(Map<T,T> a, Map<S,S> b){
        Map<Number,String> m1 = null;
        Map<Integer,String> m2 = null;
        foo(m1,m2);
    }
}

