import java.util.*;

class MapOps {
    MapOps(){
    }
    
    static <T,S> void copy(HashMap<T,S> from, HashMap<T,S> to) {
      for (T key : from.keySet()) {
         to.put(key, from.get(key));
      }
    }
    
    static <T,S> HashMap<T,S> project(HashMap<T,S> cmap, ArrayList<? extends S> dom) {
        HashMap<T,S> retmap = new HashMap<T,S>();
        copy(cmap,retmap);         
        Set<T> keyset = retmap.keySet();
        keyset.retainAll(dom);
        return retmap;
    }
    
    static <T,S> void printRange(HashMap<T,S> cmap) {
        System.out.println(cmap.values().toString());
    }
    
    static <T> HashMap<T,T> selfcompose(HashMap<T,T> map) {
        HashMap<T,T> twm = new HashMap<T,T>();
        Set<T> domain = map.keySet();
         
        for (T key : domain) {
          T img = map.get(key);
          if (domain.contains(img)) {
            twm.put(key, map.get(img));
          }
        }
        return twm;
    }
}

class Main {
    public static void main(String[] parameters)
    {
       HashMap<Number, String> hm1 = new HashMap<Number,String>();
       hm1.put(10,"ten");
       hm1.put(20,"twenty");
       hm1.put(21.5,"twenty-one-and-a-half");
       ArrayList<Integer> l1 = new ArrayList<Integer>();
       l1.add(20);
       l1.add(30);
       hm1 = MapOps.project(hm1,l1);
       MapOps.printRange(hm1);      
    }
  
}

