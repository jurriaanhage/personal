import java.util.*;

class JavacError2 {
  <T extends Number> void foo(List<? super T> a){
    List<String> x = null;
    foo(x);
  }
}