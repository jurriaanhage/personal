import java.util.Map;

class Listing51{
    <T extends Number> void foo(Map<? super T, ? super T> a){
        Map<String, Number> m = null;
        foo(m);
    }
}
