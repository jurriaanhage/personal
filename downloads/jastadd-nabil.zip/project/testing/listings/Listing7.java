class BarUtil{
   static <T extends Number>void bar(T a, T b){}
   static <T extends Integer>void bar(T a, T b){}
   void dummy() {
     BarUtil.bar('0', 3.14);
   }
}

