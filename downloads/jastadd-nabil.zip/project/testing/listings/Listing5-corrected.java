import java.util.Map;

class Listing52{
    /*
     * Strange behaviour from ejc.
     */
    <T extends Number> void foo(Map<? super T, ? super T> a){
        Map<Number, Number> m = null;
        foo(m);
    }
}
