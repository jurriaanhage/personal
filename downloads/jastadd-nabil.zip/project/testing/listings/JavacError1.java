class JavacError1 {
  <T extends Number> void foo(T a, T b){
    foo(1, false); 
  } 
}

