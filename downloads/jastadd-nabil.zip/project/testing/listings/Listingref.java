import java.util.*;

class Listingref{
    <T> void foo(Map<T,Map<T,T>> a){
        Map<Number, Map<Integer,String>> m1 = null;
        foo(m1);
    }
}

