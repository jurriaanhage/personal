import java.util.Map;

class Listing52{
    <T extends Number> void foo(Map<? super T, ? super T> a){
        Map<Number, String> m = null;
        foo(m);
    }
}
