import java.util.*;

class Test4{
    <T> void foo(List<T> a, Map<? extends String, ? extends T> b){
        List<? super Object> l = null;
        //List<Object> l = null;
        Map<? super Integer, ? super Object> m = null;
        //Map<? super Integer, ? extends Object> m = null;
        foo(l, m);
    }
}
