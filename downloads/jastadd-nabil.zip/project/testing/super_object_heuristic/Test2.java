import java.util.*;

class Test2{
    <T> void foo(Map<? extends T, T> a){
        Map<? super Object, ? super Object> m = null;
        foo(m);
    }
}
