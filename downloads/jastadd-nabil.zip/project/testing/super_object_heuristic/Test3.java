import java.util.*;
class Test3{
    /*
     * The error in this case is not really caused by the value/type of T, but
     * by the second bound Number. So even if the user does what the compiler
     * suggests he/she will still be faced with a bound error.
     */
    <T, S extends List<? extends T> & Number > void foo(Map<T, T> a, S b){
        Map<? super Object, ? super Object> m = null;
        //Map<Object, Object> m = null;
        List<String> l = null;
        foo(m, l);        
    }
}
