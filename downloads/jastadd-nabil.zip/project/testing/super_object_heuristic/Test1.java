import java.util.*;

class Test1{
    <T> void foo(Map<T, T> a){
        Map<? super Object,? super Object> m = null;
        foo(m);
    }
}
