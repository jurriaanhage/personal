import java.util.*;

class Test5{
    <T extends String> void foo(Map<T, T> a){
        Map<? super Object, ? super Object> m = null;
        foo(m);
    }
}
