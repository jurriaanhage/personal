import java.util.*;

class Test1{
    /*
     * should print a hint for T, because String will solve the type error.
     */
    <T> void foo(Map<T, T> a){
        Map<? extends String, ? extends String> m = null;
        foo(m);
    }
}
