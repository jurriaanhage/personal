import java.util.*;

class Test3{
    /*
     * Due to some bug in JastAdd this exmple is considered to be a valid call.
     */
    <T> void foo(Map<? extends T, T> a){
        Map<? extends String, ? extends String> m1 = null;
        Map<? extends String, String> m2 = null;
        foo(m1); //Error
        //foo(m2); //OK
    }
}
