import java.util.*;

class Test2{
    /*
     * No hint should be printed for this because String is not a subtype of T's
     * bound Number.
     */
    <T extends Number> void foo(Map<T, T> a){
        Map<? extends String, ? extends String> m = null;
        foo(m);
    }
}

