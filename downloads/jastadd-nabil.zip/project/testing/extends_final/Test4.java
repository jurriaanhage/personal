import java.util.*;

class Test4{
    /*
     * No hint should be printed for this.
     */
    <T extends Number> void foo(Map<? extends T, T> a){
        Map<? extends String, ? extends String> m1 = null;
        foo(m1); //Error
    }
}

