import java.util.List;

class Test1{
    <T extends Number> void foo(T a){
        String v = "";
        foo(2 + v);
    }
    
    <T> void foo(List<T> a, T b){
        List<String> v = null;
        foo(v, 2);
    }
}
