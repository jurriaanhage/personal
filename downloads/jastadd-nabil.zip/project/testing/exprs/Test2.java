class Test2{
    <T extends Byte> void foo(T a){
        byte b = 0;
        // Type of ?: is Integer, because 5000 cannot fit in a byte.
        foo(2 > 1 ? b : 5000);
    }
}

