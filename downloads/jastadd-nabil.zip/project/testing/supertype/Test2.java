import java.util.*;

class Test2{
    static Map<Number, Integer> ff = null;

    <T> void foo(Map<? extends T, ? extends T> a, Map<? super T, ? super T> b){
        HashMap<Number, Integer> m = null;
        Map<Number, Integer> n = null;
        foo(m,Test2.ff);
        /*
         * Map<Number, Integer> << Map<? extends T, ? extends T> 
         * and Map<Number, Integer> << Map<? super T, ? super T>
         * Number <: T and Integer <: T and T <: Number and T <: Integer
         * T = lub(Number, Integer) = Number and T <: Number and T <: Integer
         * T = Number and Number <: Number and Number <: Integer
         * ==>
         * Number in <: constraints is the source of error
         */
    }
}
