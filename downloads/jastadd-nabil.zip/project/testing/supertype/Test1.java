import java.util.*;

class Test1{
    <T> void foo(Map<? extends T, T> a){
        Map<Number, Integer> m = null;
        foo(m);
        /*
         * Map<Number, Integer> << Map<? extends T, T>
         * Number <: T and Integer = T
         * Number </: Integer and Integer = T
         */
    }
}
