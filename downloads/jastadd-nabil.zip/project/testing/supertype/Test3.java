import java.util.Map;

class test3{
    <T> void foo(Map<? extends T, ? extends T> a)
    {
        Map<Integer, String> m = null;
        foo(m);
    }
}
