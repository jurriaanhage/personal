import java.util.*;

public class Test10 {


    public <T, S , R extends Map<T, S>> Map<T, S> foo(T a, S b, R c) {
        String t = null;
        Map<Integer, Double> m = null;
        Map<Integer, Double> ret =  foo(t, t, m);   // print no fix
        return null;
    }
    
    public void testFoo() {
        String t = null;
        String r = null;
        Map<Integer, Double> m = null;
        Map<Integer, Double> ret =  foo(t, r, m);  // print a fix
    }

    public <T, S , R extends Map<T, S>> Map<T, S> bar(Map<T, T> a, Map<S, S> b, R c) {
        Map<String, String> t = null;
        Map<Integer, Double> m = null;
        Map<Integer, Double> ret = bar(t, t, m);
        return null;
    }

    public void testBar() {
        Map<String, String> t = null;
        Map<String, String> t1 = null;
        Map<Integer, Double> m = null;
        Map<Integer, Double> ret = bar(t, t1, m);
    }
}