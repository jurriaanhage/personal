import java.util.*;

class Test3{
    <T, S extends Map<Integer, T>> List<T> foo(Map<T, ? super T> a, S b){
        Map<Number, Integer> mt = null;
        Map<Integer, Integer> ms = null;
        List<Integer> ret = foo(mt, ms);
        return null;
        /*
         * Map<Number, Integer> << Map<T, ? super T> and Map<Integer, Integer> << S
         * Number = T  and T <: Integer and Map<Integer, Integer> = S
         * Number = T  and Number <: Integer and Map<Integer, Integer> = S
         * cxt =>
         * List<T> <: List<Integer> ==> T = Integer
         * subs: T <: Integer ==> Integer <: Integer
         * bounds: S <: Map<Integer, T> ==> Map<Integer, Integer> <: Map<Integer, Integer> 
         */

    }
    <T, S extends Map<Int, T>> List<T> bar(Map<T, ? super T> a, S b){
        Map<Num, Int> mt = null;
        Map<Int, Int> ms = null;
        List<SInt> ret = bar(mt, ms);
        return null;
        /*
         * Map<Num, Int> << Map<T, ? super T> and Map<Int, Int> << S
         * Num = T  and T <: Int and Map<Int, Int> = S
         * Num = T  and Num <: Int and Map<Int, Int> = S
         * cxt =>
         * List<T> <: List<SInt> ==> T = SInt
         * subs: T <: Int ==> SInt <: Int
         * bounds: S <: Map<Int, T> ==> Map<Int, Int> </: Map<Int, SInt> 
         */
    }
}
class Num{}
class Int extends Num{}
class SInt extends Int{}
