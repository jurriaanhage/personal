import java.util.*;

class Test8{
    <T extends Number, S> List<T> foo(Map<T, S> a, List<? extends S> b){
        Map<String, String> m = null;
        List<? super Number> l = null;
        List<Integer> i = foo(m, l);
        return null;
    }

    <T extends Number> List<T> bar(Map<T, T> a, List<? extends T> b){
        Map<Boolean, String> m = null;
        List<? super Number> l = null;
        List<Integer> i = bar(m, l);
        return null; 
    }
}
