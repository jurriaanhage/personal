import java.util.*;

class Test5{
    <T> Set<T> foo(Tri<? super T, ? extends T, ? extends T> a){
        Tri<Integer,Integer, Number> t = null;
        Set<Integer> ret = foo(t);
        return null;
        /*
         * Tri<Integer, Integer, Number> << Tri<? super T, ? extends T, ? extends T>
         * T <: Integer  and  Integer <: T and  Number <: T
         * T <: Integer  and  T = lub(Integer, Number) = Number
         * Number </: Integer  and  T = Number
         *
         * cxt ==> Set<T> <: Set<Integer> ==> T = Integer
         * Integer <: Integer  and  Integer <: Integer and  Integer <: Integer
         *
         */
    }
}

class Tri<R, S, T>{}
