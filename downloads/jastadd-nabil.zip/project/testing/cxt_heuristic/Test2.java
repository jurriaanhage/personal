
import java.util.*;

class Test2{
    <T> List<T> foo(Map<T, ? extends T> a){
        Map<Integer, Number> m = null;
        List<Number> ret = foo(m);
        return null;
        /*
         * Map<Integer, Number> << Map<T, ? extends T> 
         * Integer = T and Number <: T 
         * Integer = T and Number </: Integer 
         * ==> Number is a solution
         */
    }
    void bar(){
        Map<Integer, Number> m = null;
        List<Integer> ret = foo(m);
        /*
         * Map<Integer, Number> << Map<T, ? extends T> 
         * Integer = T and Number <: T 
         * Integer = T and Number </: Integer 
         * ==> Integer is not a solution
         */
    }
}
