import java.util.*;

public class Test11 {


    public <T extends Number, S  extends Integer> Map<T, S> foo(T a, S b) {
        String t = null;
        Map<Double, Integer> ret =  foo(t, t);   // print no fix
        return null;
    }

    public void test() {
        String t = null;
        String r = null;
        Map<Double, Integer> ret =  foo(t, r);  // print a fix
    }
}