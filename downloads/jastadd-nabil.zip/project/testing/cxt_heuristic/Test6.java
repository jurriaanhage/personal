import java.util.*;

class Test6{
    <T> Set<T> foo(Quad<? super T, ? extends T, ? extends T, ? extends T> a){
        Quad<Integer, Integer, Number, String> q = null;
        Set<Integer> r = foo(q);
        return null;
        /*
         * Quad<Integer, Integer, Number, String> << Quad<? super T, ? extends T, ? extends T, ? extends T> 
         * T <: Integer and Integer <: T and Number <: T and String <: T
         * T <: Integer and T = lub(Integer, Number, String)
         * T <: Integer and T = Object
         * Ob <: Integer and T = Object 
         * 
         * cxt => Set<T> <: Set<Integer> ==> T = Integer
         * ==> change Number and String with Integer.
         */
    }
}

class Quad<T1, T2, T3, T4>{}
