import java.util.*;

class Test7{
    <T extends Number, S extends Number> List<T> foo(Map<T, S> a){
        Map<String, String> m = null;
        List<Integer> i = foo(m);
        return null;
    }
}
