import java.util.*;

class Test4{
    <T, S extends T> Map<S, T> foo(Map<S, T> a, Map<? super S, ? extends T> b){
        Map<Number, Integer> m1 = null;
        Map<Integer,Number> m2 = null;
        Map<Double, Object> ret = foo(m1, m2);
        return null;
        /*
         * Map<Number, Integer> << Map<S, T> and Map<Integer,Number> << Map<? super S, ? extends T>
         * Number = S and Integer = T and S <: Integer and Number <: T
         * Number = S and Integer = T and Number </: Integer and Number </: Integer
         * bounds ==> S <: T ==> Number </: Integer
         *
         * cxt ==> 
         * Map<Double, Object> << Map<S, T> and Map<Integer,Number> << Map<? super S, ? extends T>
         * Double = S and Object = T and S <: Integer and Number <: T
         * Double = S and Object = T and Double </: Integer and Number <: Object
         * bounds ==> S <: T ==> Double <: Object
         * 
         * Do not show a suggestion, because types from context will not fix all the errors.
         */
    }
}
