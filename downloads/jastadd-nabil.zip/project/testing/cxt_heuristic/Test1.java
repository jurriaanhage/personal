import java.util.*;

class Test1{
    <T> List<T> foo(Map<T, ? super T> a){
        Map<Number, Integer> m = null;
        List<Integer> ret = foo(m);
        return null;
        /*
         * Map<Number, Integer> << Map<T, ? super T> 
         * Number = T and T <: Integer  
         * Number = T and Number </: Integer  
         * ==> Integer is a solution
         */
    }
    void bar(){
        Map<Number, Integer> m = null;
        List<Double> ret = foo(m);
        /*
         * Map<Number, Integer> << Map<T, ? super T>
         * Number = T and T <: Integer
         * Number = T and Number </: Integer  
         * ==> Double is not a solution
         */
    }
}
