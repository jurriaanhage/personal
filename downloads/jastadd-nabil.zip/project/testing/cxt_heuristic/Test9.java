import java.util.*;

class Test9{
    <T, S extends Map<Number, T>> List<T> baz(T a, S b){
        Number n = null; 
        Map<Number, Integer> ms = null;     
        List<Integer> ret = baz(n, ms);
        return null;
    }

    <T,R, S extends Map<R, T>> Map<T, R> baz(T a, R c, S b){
        Number t = null; 
        Number r = null; 
        Map<Double, Integer> ms = null;     
        Map<Integer, Double> ret = baz(t, r, ms);
        return null;
    }
}
