import java.util.List;

class Test5_3{
    // se ss
    <T> void foo7(List<? super List<? extends T>> a){
        List<? super List<? super Integer>> l = null;
        foo7(l);
        /*
         * Error
         *
         * List<? super List<? super Integer>>  << List<? super List<? extends Object>>
         * List<? extends Object> </: List<? super Integer>
         */
         // List<? super List<? super Integer>> <: List<? super List<? extends Object>> true
         //   2
    }

    // se es
    <T> void foo8(List<? super List<? extends T>> a){
        List<? extends List<? super Integer>> l = null;
        foo8(l);
        /*
         * Error
         *
         * Let WeT = ? extends List<? super Integer>
         * List<WeT> << List<? super List<? extends Object>>
         * List<? extends Object> </: WeT, because WeT could be List<? super Integer>
         */
    }
    // se se
    <T> void foo9(List<? super List<? extends T>> a){
        List<? super List<? extends Integer>> l = null;
        foo9(l);
        /*
         * OK
         *
         * List<? super List<? extends Integer>> << List<? super List<? extends T>>
         * List<? extends T> << List<? extends Integer>
         * T <: Integer ==> T = Integer
         */
    }
}
