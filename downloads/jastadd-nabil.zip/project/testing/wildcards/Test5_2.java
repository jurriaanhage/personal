import java.util.List;

class Test5_2{
    // es ss
    <T> void foo4(List<? extends List<? super T>> a){
        List<? super List<? super Integer>> l = null;
        foo4(l);
        /*
         * Error
         *
         * Let WsT = ? super List<? super Integer>
         * List<WsT> << List<? extends List<? super Object>>
         * WsT </: List<? super Object>, because WsT could be Collection<? super Integer>
         * =====================================================
         * List<? extends List<? super Integer>> << List<? extends List<? super T>>
         * List<? super Integer> << List<? super T>
         * T <: Integer ==> T = Integer
         */
    }

    // es es
    <T> void foo5(List<? extends List<? super T>> a){
        List<? extends List<? super Integer>> l = null;
        foo5(l);
        /*
         * Ok
         *
         * List<? extends List<? super Integer>> << List<? extends List<? super T>>
         * List<? super Integer> << List<? super T>
         * T <: Integer ==> T = Integer
         */
    }

    // es se
    <T> void foo6(List<? extends List<? super T>> a){
        List<? super List<? extends Integer>> l = null;
        foo6(l);
        /*
         * Error
         *
         * Let WsT = ? super List<? extends Integer>
         * List<WsT> << List<? extends List<? super Object>>
         * WsT </: List<? super Object>, because WsT could be List<? extends Integer>
         * =====================================================
         * List<? extends List<? super Integer>> << List<? extends List<? super T>>
         * List<? super Integer> << List<? super T>
         * T <: Integer => T = Integer
         *
         */
    }
}
