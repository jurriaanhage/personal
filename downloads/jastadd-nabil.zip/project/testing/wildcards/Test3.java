import java.util.Map;

class Test3{
    <T> void foo(Map<? extends T, T> a){
        Map<? super Number, Integer> m = null;
        foo(m);
        /*
         * Let WsT = ? super Number
         *
         * Map<WsT, Integer> << Map<? extends T, T>
         * WsT <: T and T = Integer
         * WsT </: Integer and T = Integer
         * Exp: WsT could be Number or Object.
         */
        Map<? super Integer, Number> m2 = null;
        foo(m2);
        /*
         * Let WsT = ? super Integer
         *
         * Map<? super Integer, Number> << Map<? extends T, T>
         * WsT <: T and T = Number
         * WsT </: T and T = Number
         * Exp: WsT could be Comparable<Integer> or Object    
         */
    }
}
