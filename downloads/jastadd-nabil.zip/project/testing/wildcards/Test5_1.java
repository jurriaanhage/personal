import java.util.List;

class Test5_1{
    // ee ss
    <T> void foo1(List<? extends List<? extends T>> a){
        List<? super List<? super Integer>> l = null;
        foo1(l);
        /*
         * Error
         *
         * Let WsT = ? super List<? super Integer>
         * List<WsT> << List<? extends List<? extends T>>
         * WsT </< List<? extends T>, because WsT could be Collection<?>
         */
    }

    // ee es
    <T> void foo2(List<? extends List<? extends T>> a){
        List<? extends List<? super Integer>> l = null;
        foo2(l);    
        /*
         * OK
         * List<? extends List<? super Integer>> << List<? extends List<? extends Object>>
         * List<? super Integer> << List<? extends Object>
         * Let WsT = ? super Integer
         * List<WsT> << List<? extends Object>
         * Wst <: Object
         */
    }

    // ee se
    <T> void foo3(List<? extends List<? extends T>> a){
        List<? super List<? extends Integer>> l = null;
        foo3(l);
        /*
         * Error
         *
         * Let WsT = ? super List<? extends Integer>
         * List<WsT> << List<? extends List<? extends Object>>
         * WsT </: List<? extends Object>, because WsT could be Collection<? extends Number>
         */
    }
}
