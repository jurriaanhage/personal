import java.util.*;

class Test6{
    // es ss
    <T> void foo(List<? extends List<? super T>> a, T b){
        ArrayList<? super List<? extends Integer>> l = null;
        Number n = null;
        foo(l, n);
        /*
         * Error
         *
         * Let WsT = ? super List<? super Integer>
         * List<WsT> << List<? extends List<? super Number>>
         * WsT </: List<? super Number>, because WsT could be Collection<? super Integer>
         * ====================================================================
         * ArrayList<? extends List<? super Integer>> <: List<? extends List<? super T>>
         * List<? extends Integer> <: List<? super T>
         * T <: '? extends Integer'  && Number <: T ==> No solution
         * 
         */
        //foo(l, 1);
    }

    <T> void bar(Map<? extends T, ? super T> a, T b){
        HashMap<? super Integer, ? extends Number> m = null;
        Number n = null;
        bar(m, n);
    }
}
