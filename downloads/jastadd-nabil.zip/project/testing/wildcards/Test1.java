import java.util.*;

class Test1{
    <T> void foo(Map<T, T> a){
        Map<? extends String, ? extends String> m = null;
        foo(m);
    }
}
