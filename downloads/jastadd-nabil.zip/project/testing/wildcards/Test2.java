import java.util.Map;

class Test2{
    <T> void foo(Map<T, T> a){
        Map<? extends Number, ? super Integer> m = null;
        foo(m);
    }
}
