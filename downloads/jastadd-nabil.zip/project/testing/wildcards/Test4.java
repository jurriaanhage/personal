import java.util.Map;
import java.util.List;

class Test4{
    <T> void bar(Map<? super List<T>, T> a){
        Map<? extends List<Integer>, Integer> m = null;
        bar(m);
        /*
         * Let WeT = ? extends List<Integer>
         *
         * Map<WeT, Integer> << Map<? super List<T>, T>
         * List<T> <: WeT  and Integer = T 
         * List<Integer> </: WeT  and Integer = T 
         * Exp: WeT could be ArrayList<Integer>
         */
    }
}
