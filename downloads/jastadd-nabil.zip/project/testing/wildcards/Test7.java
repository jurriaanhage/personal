import java.util.List;

class Test7{
    <T> void foo(List<? super List<? extends T>> a, T b){
        List<? super List<? super Number>> l =null;
        foo(l,1); 
        /*
         * List<? super List<? extends Number>> <: List<? super List<? extends T>>
         * List<? extends T> <: List<? extends Number>
         * T <: Number && T :> Integer ==> OK
         */
    }
}
