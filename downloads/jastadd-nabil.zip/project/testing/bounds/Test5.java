import java.util.*;

class Test5{
    <T,S extends Map<List<T>, S>> void foo(T a, List<S> b){
        List<Number> ln = null;
        foo(1,ln);
        /*
         * List<Number> << List<S> and Integer << T
         * Number = S and Integer = T
         * ==>
         * S <: Map<List<T>, S> ==> Number </: Map<List<Integer>, Number>
         */
        List<Map<List<Integer>, Object>> mlo = null;
        foo(1,mlo);
        /*
         * List<Map<List<Integer>, Object>> << List<S> and Integer << T
         * Map<List<Integer>, Object> = S and Integer = T
         * ==>
         * S <: Map<List<T>, S> ==> 
         *  Map<List<Integer>, Object> </: Map<List<Integer>, Map<List<Integer>, Object>>
         */
    }
}
