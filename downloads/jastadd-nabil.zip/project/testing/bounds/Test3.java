import java.util.*;

class Test3{
    <T,S extends List<T> > void foo(T a, S b){
        List<Number> ln = null;
        foo(new Integer(0),ln);
        /*
         * List<Number> << S and Integer << T
         * List<Number> <: S and Integer <: T
         * List<Number> = S and Integer = T
         * ==>
         * S <: List<T> ==> List<Number> </: List<Integer>
         */
    }
}
