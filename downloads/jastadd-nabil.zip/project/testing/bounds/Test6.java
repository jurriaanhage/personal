import java.util.*;


class Test6{
    <S extends Comparable<S>, T extends Comparable<S>> void foo(Map<T,S> a){
        Map<Double, Integer> m = null;
        foo(m);
        /*
         * Map<Double, Integer> << Map<T, S>
         * Double = T and Integer = S
         * ==>
         * S <: Comparable<S> ==> Integer <: Comparable<Integer>
         * T <: Comparable<S> ==> Double </: Comparable<Integer>
         */
    }
}
