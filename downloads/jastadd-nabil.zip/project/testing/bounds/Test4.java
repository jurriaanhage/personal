import java.util.*;

class Test4{
    <T,S extends Map<List<T>, S>> void foo(T a, S b){
        foo(1,new Object());
        /*
         * Integer << T and Object << S
         * Integer = T and Object = S
         * ==>
         * S <: Map<List<T>, S> ==> Object </: Map<List<Integer>, Object>
         */
        Map<ArrayList<Integer>, Object> m = null;
        foo(1,m);
        /*
         * Integer << T and Map<ArrayList<Integer>, Object> << S
         * Integer = T and Map<ArrayList<Integer>, Object> = S
         * ==>
         * S <: Map<List<T>, S> ==> Map<ArrayList<Integer>, Object> </: Map<List<Integer>, Map<ArrayList<Integer>, Object>>
         */
    }
}
