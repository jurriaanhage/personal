import java.util.*;

class Test2{
    <T,S, R extends Map<T,R>> void foo(R a, Map<T,S> b){
        Map<Integer, Number> mr = null;
        foo(mr,mr);
        /*
         * Map<Integer, Number> << Map<T, S>
         * Integer = T and Number = S
         * Map<Integer, Number> << R
         * Map<Integer, Number> = R
         * Map<Integer, Number> </: Map<Integer, Map<Integer,Number>>
         */
    }
}
