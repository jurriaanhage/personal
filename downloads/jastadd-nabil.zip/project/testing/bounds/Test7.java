import java.util.*;
import java.io.*;

class Test7{
    <T extends List<T> & Serializable & Number> void foo(T a){
       foo(new ArrayList<Integer>());
    }
}