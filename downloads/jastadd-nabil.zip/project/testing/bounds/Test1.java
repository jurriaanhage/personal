class Class1
{
    <T extends Number> void foo(T a){
        foo(new Object());
        /*
         * Error: Objetc is not subtype of Number
         */
    }
}
