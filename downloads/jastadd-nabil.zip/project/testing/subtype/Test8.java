import java.util.Map;

class Test8{
    /*
     * javac, ignore the the constraints that T <: Number. But it does verify that glb exists.
     */
    <T extends Number> void foo(Map<? super T, ? super T> a){
        Map<Object, String> m = null;
        //Map<String, Number> m = null;
        foo(m);
    }
}
