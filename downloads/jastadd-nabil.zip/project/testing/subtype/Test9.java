import java.util.Map;

interface I{}
interface J{}

class IJoin implements I,J{}

class Test9{
      // javac: NOT OK
      // ecj  : OK
      <T> int foo(Map<? super T, ? super T> a, T b){
          Map<I, J> m = null;
          foo(m, new IJoin());
          return 0;
      }
      // javac: NOT OK
      // ecj  : NOT OK
      <T> int bar(Map<? super T, ? super T> a){
          Map<I, J> m = null;
          bar(m);
          return 0;
      }

}
