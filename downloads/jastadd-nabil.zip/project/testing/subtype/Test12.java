import java.util.*;

class Test12{
    <T, S extends T> List<T> foo(Map<? super T, ? super T> a, S b){
        Map<? super Number, ? super String> m = m;
        List<Integer> r = foo(m, "");

        Map<? super Number, ? super Integer> mn = m;
        r = foo(mn, "");

        return null ;
    }
}