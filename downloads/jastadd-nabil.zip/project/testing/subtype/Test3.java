import java.util.*;

class Test3{
    <T> T foo(Map<? super T, ? super T> a){
        Map<Integer, String> m = null;
        foo(m);
        return null;
        /*
         * Map<Integer, String> and Map<? super T, ? super T>
         * T <: Integer and T <: String
         * ==> add cxt
         * T <: Object and T <: Integer and T <: String
         * T = glb(Object, Integer, String) = BOTTOM
         */
    }
}

