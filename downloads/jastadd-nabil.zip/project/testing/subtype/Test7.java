import java.util.*;

class Test7{
    /*
     * javac, ignore the the constraints that T <: Number.
     */
    <T extends Number> void foo(List<? super T> a){
        List<String> l = null;
        foo(l);
    }
}
