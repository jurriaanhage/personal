import java.util.*;

class Test6{
    <T extends Number> void foo(Map<? super T, ? super T> a){        
        Map<Number, String> m = null;
        //Map<Number, Object> m = null;
        foo(m);
        /*
         * Map<Integer, String> << Map<? super T, ? super T>
         * T <: Integer and T <: String
         * T = glb(Integer, String) = BOTTOM
         *
         * blame String
         */
        /*
         * Check if a type in not in the same inheritance tree as the bound, then it's probably the
         * source of he error.
         */
    }
}

