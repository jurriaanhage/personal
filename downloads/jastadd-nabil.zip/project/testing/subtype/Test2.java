import java.util.*;

class Test2{
    <T> void foo(Map<? super T, ? super T> a){
        Map<Integer, String> m = null;
        foo(m);
        /*
         * Map<Integer, String> << Map<? super T, ? super T> 
         * T <: Integer and T <: String
         * T =glb(Integer, String) = BOTTOM
         * ==>
         * There is no type that is a subtype of Integer and String
         */
    }
}
