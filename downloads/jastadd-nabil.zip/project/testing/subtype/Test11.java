import java.util.*;

class Test11{
    <T extends Number> void foo(Map<? super T, ? super T> a, List<? super T> b){
        Map<? super String, ? super Error> m =null;
        List<? super Object> l = null;
        foo(m, l);
    }
}