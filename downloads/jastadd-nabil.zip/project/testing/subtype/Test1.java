import java.util.*;

class Test1{
    <T> void foo(Map<? super T, T> a){
        Map<Integer, Number> m = null;
        foo(m);
        /*
         * Map<Integer, Number> << Map<? super T, T>
         * T <: Integer and Number = T
         * Number <: Integer Number = T
         */
    }
}
