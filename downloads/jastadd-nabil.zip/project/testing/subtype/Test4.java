import java.util.*;

class Test4{
    <T> List<T> foo(Map<? super T, ? super T> a){
        Map<Integer, String> m = null;
        List<Number> ret = foo(m);
        return null;
        /*
         * Map<Integer, String> << Map<? super T, ? super T>
         * T <: Integer and T <: String
         * ==> add cxt
         * T = Number and T <: Integer and T <: String
         * T = Number and Number </: Integer and Integer </: String
         */
    }
}


