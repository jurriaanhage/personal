import java.util.Map;

class Tri<T, R, S> {}

class Test6{

    <T> void foo(Map<? super T, ? super T> a){
        Map<II, JJ> m = null;
        foo(m); // OK
    }

    <T extends NN> void foon(Map<? super T, ? super T> a){
        Map<II, JJ> m = null;
        foon(m); // OK
    }

    <T> void bar(Tri<? super T, ? super T, ? super T> a){
        Tri<JJ, II, NN> m =null;
        bar(m); // OK
    }
}

class NN{}
interface II{}
interface JJ{}
