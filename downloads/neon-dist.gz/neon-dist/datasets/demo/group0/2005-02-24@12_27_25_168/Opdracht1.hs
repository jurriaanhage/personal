module Opdracht1 where
import List

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]

type Table = [[String]]

--                       
--                                     
bepaalLangsteWoord :: [String] -> Int
bepaalLangsteWoord xs = maximum (map length xs)

--                                                                                                                    
breedteKolom               :: Table -> [Int]
breedteKolom tabel         = map bepaalLangsteWoord (transpose tabel)

--                 
schrijfRegel               :: [Int] -> [String] -> String
schrijfRegel _ []          = "   "
schrijfRegel ns (x:xs)     = " " ++ x ++ replicate (head ns - length x) ' ' ++ schrijfRegel (tail ns) xs

--                     
schrijfRegels   :: Table -> String
schrijfRegels tabel       = concatMap (schrijfRegel (breedteKolom tabel )) tabel

--                      
scheidingsRegel :: [Int] -> String
scheidingsRegel (x:xs)     = " " ++ replicate (x) '-' ++ scheidingsRegel xs
scheidingsRegel []         = "   "

--               
writeTable :: Table -> String
writeTable tabel = str ++ schrijfRegel (breedteKolom tabel) (head tabel) ++ str ++ schrijfRegels (tail tabel)++ str
                where  str = scheidingsRegel(breedteKolom tabel)

--                                    
--                    


--                       
project :: [String] -> Table -> Table
project x tabel  = transpose (controleTotaal x tabel)

controleTotaal :: [String] -> Table -> Table
controleTotaal [] _           = []
controleTotaal (x:xs) tabel   | not (null p)                           = p: controleTotaal xs tabel
                              | otherwise                              = controleTotaal xs tabel
                       where p = (controlePerWoord x (transpose tabel ))

controlePerWoord :: String -> Table -> [String]
controlePerWoord _ []                       = []
controlePerWoord x (y:ys)                   | eqString x (head y) = y
                                            | otherwise           = controlePerWoord x ys


--                                               "    " "    "  "    "                         
--                                                                                                 "    " "    "  "    "               

--                             "    " "    "  "    "              
--               


--                      
--                 -          -        -        -       
select veld conditie tabel = filter conditie  (tail(controlePerWoord veld  (transpose tabel )))

selecteerRijen [] tabel                                                 = []
selecteerRijen lijst tabel | elemBy eqString head(lijst) (head(tail(tabel))) = (head(tail(tabel))) ++  selecteerRijen (tail(lijst)) tabel
                           | otherwise                                  = [] ++ selecteerRijen (tail(lijst)) tabel













       
       

       
       
       
       
       
       
       
       
       

















































