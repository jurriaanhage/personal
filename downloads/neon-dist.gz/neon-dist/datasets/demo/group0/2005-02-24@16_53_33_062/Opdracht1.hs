module Opdracht1 where
import List

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]

soort :: Table
soort =
  [ ["                    ", "     "]
  , ["                    ", "            "]
  , ["                  ", "            "]
  , ["                  ", "       "]
  , ["                  ", "       "]
  , ["                         ", "            "]
  , ["                                 ", "            "]
  ]

query :: Table
query =
    project ["        "]
      (select "     " (eqString "            ")
        (join compilers (join locaties soort)))

type Table = [[String]]

--                       
--                                     
bepaalLangsteWoord :: [String] -> Int
bepaalLangsteWoord xs = maximum (map length xs)

--                                                                                                                    
breedteKolom               :: Table -> [Int]
breedteKolom tabel         = map bepaalLangsteWoord (transpose tabel)

--                 
schrijfRegel               :: [Int] -> [String] -> String
schrijfRegel _ []          = "   "
schrijfRegel ns (x:xs)     = " " ++ x ++ replicate (head ns - length x) ' ' ++ schrijfRegel (tail ns) xs

--                     
schrijfRegels   :: [Int]->Table -> String
schrijfRegels widths tabel       = concatMap (schrijfRegel widths) tabel

--                      
scheidingsRegel :: [Int] -> String
scheidingsRegel (x:xs)     = " " ++ replicate (x) '-' ++ scheidingsRegel xs
scheidingsRegel []         = "   "

--               
writeTable :: Table -> String
writeTable tabel = str ++ schrijfRegel widths (head tabel) ++ str ++ schrijfRegels widths (tail tabel)++ str
                where  str = scheidingsRegel(breedteKolom tabel)
                       widths = breedteKolom tabel

--                                    
--                    


--                       
project :: [String] -> Table -> Table
project x tabel  = transpose (controleTotaal x tabel)

controleTotaal :: [String] -> Table -> Table
controleTotaal [] _           = []
controleTotaal (x:xs) tabel   | not (null p)                           = p: controleTotaal xs tabel
                              | otherwise                              = controleTotaal xs tabel
                       where p = (controlePerWoord x (transpose tabel ))

controlePerWoord :: String -> Table -> [String]
controlePerWoord _ []                       = []
controlePerWoord x (y:ys)                   | eqString x (head y) = y
                                            | otherwise           = controlePerWoord x ys


--                                               "    " "    "  "    "                         
--                                                                                                 "    " "    "  "    "               

--                             "    " "    "  "    "              
--               


--                      
select :: String -> (String -> Bool) -> Table -> Table
select veld conditie tabel = head tabel:selecteerRijen (filter conditie (drop 1 k)) tabel
       where k = controlePerWoord veld  (transpose tabel )

selecteerRijen :: [String] -> Table -> Table
selecteerRijen []           _                                             = []
selecteerRijen _            []                                            = []
selecteerRijen lijst@(y:ys) tabel@(x:xs) | elemBy eqString y x            = x :  selecteerRijen ys xs
                                         | otherwise                       = selecteerRijen lijst xs
--                                                                            


--                       
--                   
join :: Table -> Table -> Table
join (_ : _) [] = [[]]
join [] _ = [[]]
join x  t = transpose ( (transpose (delKolom (vindGem (head x) (head t)) (geefKortste x t))) ++ (transpose (check x t)) )
--                                    --                
--                                 

--                                                                    
geefLangste :: Table -> Table -> Table
geefLangste tabel1 tabel2   | length(head(transpose(tabel1)))>=(length(head(transpose(tabel2)))) = tabel1
                            | otherwise                                                          = tabel2
geefKortste :: Table -> Table -> Table
geefKortste tabel1 tabel2   | length(head(transpose(tabel1)))>=(length(head(transpose(tabel2)))) = tabel2
                            | otherwise                                                          = tabel1

--                                                                 
vindGem :: [String] -> [String] -> String
vindGem [] _          = []
vindGem (x:xs) l      | elemBy eqString x l = x
                      | otherwise    = vindGem xs l

--                                                                                                            
check :: Table -> Table -> Table
check tabel1 tabel2 =  selecteerRijen (controlePerWoord (vindGem (head tabel1)(head tabel2)) (transpose (geefLangste tabel1 tabel2))) (geefKortste tabel1 tabel2)

--                                             
delKolom :: String->Table->Table
delKolom str t = transpose (delKolom2 str (transpose t))

--                                                                                               
delKolom2 :: String->Table->Table
delKolom2 _ [] = []
delKolom2 x (y:ys) | not (eqString x (head y)) = y:delKolom2 x ys
                   | otherwise                 = delKolom2 x ys

--          












       
       
       
       
       
       
       

















































