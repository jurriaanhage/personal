module Opdracht1 where
import List

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]

soort :: Table
soort =
  [ ["                    ", "     "]
  , ["                    ", "            "]
  , ["                  ", "            "]
  , ["                  ", "       "]
  , ["                  ", "       "]
  , ["                         ", "            "]
  , ["                                 ", "            "]
  ]

query :: Table
query =
    project ["        "]
      (select "     " (eqString "            ")
        (join compilers (join locaties soort)))

type Table = [[String]]

--                       
--                                     
bepaalLangsteWoord :: [String] -> Int
bepaalLangsteWoord xs = maximum (map length xs)

--                                                                                                                    
breedteKolom               :: Table -> [Int]
breedteKolom tabel         = map bepaalLangsteWoord (transpose tabel)

--                 
schrijfRegel               :: [Int] -> [String] -> String
schrijfRegel _ []          = "   "
schrijfRegel ns (x:xs)     = " " ++ x ++ replicate (head ns - length x) ' ' ++ schrijfRegel (tail ns) xs

--                     
schrijfRegels   :: [Int]->Table -> String
schrijfRegels widths tabel       = concatMap (schrijfRegel widths) tabel

--                      
scheidingsRegel :: [Int] -> String
scheidingsRegel (x:xs)     = " " ++ replicate (x) '-' ++ scheidingsRegel xs
scheidingsRegel []         = "   "

--               
writeTable :: Table -> String
writeTable tabel = str ++ schrijfRegel widths (head tabel) ++ str ++ schrijfRegels widths (tail tabel)++ str
                where  str = scheidingsRegel(breedteKolom tabel)
                       widths = breedteKolom tabel

--                                    
--                    


--                       
project :: [String] -> Table -> Table
project x tabel  = transpose (controleTotaal x tabel)

controleTotaal :: [String] -> Table -> Table
controleTotaal [] _           = []
controleTotaal (x:xs) tabel   | not (null p)                           = p: controleTotaal xs tabel
                              | otherwise                              = controleTotaal xs tabel
                       where p = (controlePerWoord x (transpose tabel ))

controlePerWoord :: String -> Table -> [String]
controlePerWoord _ []                       = []
controlePerWoord x (y:ys)                   | eqString x (head y) = y
                                            | otherwise           = controlePerWoord x ys


--                                               "    " "    "  "    "                         
--                                                                                                 "    " "    "  "    "               

--                             "    " "    "  "    "              
--               


--                      
select :: String -> (String -> Bool) -> Table -> Table
select veld conditie tabel = head tabel:selecteerRijen (filter conditie (drop 1 k)) tabel
       where k = controlePerWoord veld  (transpose tabel )

selecteerRijen :: [String] -> Table -> Table
selecteerRijen []           _                                             = []
selecteerRijen _            []                                            = []
selecteerRijen lijst@(y:ys) tabel@(x:xs) | elemBy eqString y x            = x :  selecteerRijen ys xs
                                         | otherwise                       = selecteerRijen lijst xs
--                                                                            


--                       
{--                   
              -        -       
                      
                
                                                                                                                         
--                                    --                
--                                               
-}
join :: Table -> Table -> Table
join table1 table2 = transpose [ x ++ y | x <- (transpose table1), y <- (transpose table2)]


{-
--                                                                    
                     -        -       
                                                                                                         
                                                                                                         
                     -        -       
                                                                                                         
                                                                                                         

--                                                                 
                    -           -        
                          
                                               
                                                   

--                                                                                                            
               -        -       
                                                                                                                                                                
--

--                                             
                  -      -      
                                                        

--                                                                                               
                   -      -      
                   
                                                                 
                                                               

--          
   -}











       
       
       
       
       
       
       

















































