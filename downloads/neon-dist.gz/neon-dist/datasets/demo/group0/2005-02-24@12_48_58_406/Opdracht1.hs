module Opdracht1 where
import List

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]

type Table = [[String]]

--                       
--                                     
bepaalLangsteWoord :: [String] -> Int
bepaalLangsteWoord xs = maximum (map length xs)

--                                                                                                                    
breedteKolom               :: Table -> [Int]
breedteKolom tabel         = map bepaalLangsteWoord (transpose tabel)

--                 
schrijfRegel               :: [Int] -> [String] -> String
schrijfRegel _ []          = "   "
schrijfRegel ns (x:xs)     = " " ++ x ++ replicate (head ns - length x) ' ' ++ schrijfRegel (tail ns) xs

--                     
schrijfRegels   :: Table -> String
schrijfRegels tabel       = concatMap (schrijfRegel (breedteKolom tabel )) tabel

--                      
scheidingsRegel :: [Int] -> String
scheidingsRegel (x:xs)     = " " ++ replicate (x) '-' ++ scheidingsRegel xs
scheidingsRegel []         = "   "

--               
writeTable :: Table -> String
writeTable tabel = str ++ schrijfRegel (breedteKolom tabel) (head tabel) ++ str ++ schrijfRegels (tail tabel)++ str
                where  str = scheidingsRegel(breedteKolom tabel)

--                                    
--                    


--                       
project :: [String] -> Table -> Table
project x tabel  = transpose (controleTotaal x tabel)

controleTotaal :: [String] -> Table -> Table
controleTotaal [] _           = []
controleTotaal (x:xs) tabel   | not (null p)                           = p: controleTotaal xs tabel
                              | otherwise                              = controleTotaal xs tabel
                       where p = (controlePerWoord x (transpose tabel ))

controlePerWoord :: String -> Table -> [String]
controlePerWoord _ []                       = []
controlePerWoord x (y:ys)                   | eqString x (head y) = y
                                            | otherwise           = controlePerWoord x ys


--                                               "    " "    "  "    "                         
--                                                                                                 "    " "    "  "    "               

--                             "    " "    "  "    "              
--               


--                      
select :: String -> (String -> Bool) -> Table -> Table
select veld conditie tabel = selecteerRijen (filter conditie  (drop 1(controlePerWoord veld  (transpose tabel )))) tabel

selecteerRijen []           _                                             = []
selecteerRijen _            []                                            = []
selecteerRijen lijst@(y:ys) tabel@(x:xs) | elemBy eqString y x            = head xs :  selecteerRijen ys tabel
                                         | otherwise                      = selecteerRijen lijst xs













       
       

       
       
       
       
       
       
       
       
       

















































