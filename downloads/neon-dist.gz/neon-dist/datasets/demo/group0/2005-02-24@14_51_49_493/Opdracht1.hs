module Opdracht1 where
import List

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]

type Table = [[String]]

--                       
--                                     
bepaalLangsteWoord :: [String] -> Int
bepaalLangsteWoord xs = maximum (map length xs)

--                                                                                                                    
breedteKolom               :: Table -> [Int]
breedteKolom tabel         = map bepaalLangsteWoord (transpose tabel)

--                 
schrijfRegel               :: [Int] -> [String] -> String
schrijfRegel _ []          = "   "
schrijfRegel ns (x:xs)     = " " ++ x ++ replicate (head ns - length x) ' ' ++ schrijfRegel (tail ns) xs

--                     
schrijfRegels   :: [Int]->Table -> String
schrijfRegels widths tabel       = concatMap (schrijfRegel widths) tabel

--                      
scheidingsRegel :: [Int] -> String
scheidingsRegel (x:xs)     = " " ++ replicate (x) '-' ++ scheidingsRegel xs
scheidingsRegel []         = "   "

--               
writeTable :: Table -> String
writeTable tabel = str ++ schrijfRegel widths (head tabel) ++ str ++ schrijfRegels widths (tail tabel)++ str
                where  str = scheidingsRegel(breedteKolom tabel)
                       widths = breedteKolom tabel

--                                    
--                    


--                       
project :: [String] -> Table -> Table
project x tabel  = transpose (controleTotaal x tabel)

controleTotaal :: [String] -> Table -> Table
controleTotaal [] _           = []
controleTotaal (x:xs) tabel   | not (null p)                           = p: controleTotaal xs tabel
                              | otherwise                              = controleTotaal xs tabel
                       where p = (controlePerWoord x (transpose tabel ))

controlePerWoord :: String -> Table -> [String]
controlePerWoord _ []                       = []
controlePerWoord x (y:ys)                   | eqString x (head y) = y
                                            | otherwise           = controlePerWoord x ys


--                                               "    " "    "  "    "                         
--                                                                                                 "    " "    "  "    "               

--                             "    " "    "  "    "              
--               


--                      
select :: String -> (String -> Bool) -> Table -> Table
select veld conditie tabel = head tabel:selecteerRijen (filter conditie (drop 1 k)) tabel
       where k = controlePerWoord veld  (transpose tabel )

selecteerRijen :: [String] -> Table -> Table
selecteerRijen []           _                                             = []
selecteerRijen _            []                                            = []
selecteerRijen lijst@(y:ys) tabel@(x:xs) | elemBy eqString y x            = x :  selecteerRijen ys tabel
                                         | otherwise                      = selecteerRijen lijst xs
--                                                                            

--                       

--                   
--              -        -       
--                      
--                
--                  

zoekUit:: Table -> Table -> [String] -> Table
zoekUit tabel1 tabel2 gemeen = (max tabel1 tabel2)

--                                                                            
--                                             
--                  -      -      
--                                            

--                   -      -      
--                   
--                                                                 
--                                                               




--                                
vindGem :: [String] -> [String] -> String
vindGem [] _          = []
vindGem (x:xs) l      | elemBy eqString x l = x
                      | otherwise    = vindGem xs l










       
       
       
       
       
       
       

















































