module Graph where

    countryLookUp :: String -> Graph -> Maybe Int
    countryLookUp country graph = indexOf country graph  where

    indexOf :: String -> Graph -> Maybe Int	
    indexOf _ Empty = Nothing
    indexOf country (Graph intmap) = indexOf' country $ IntMap.assocs intmap
        where indexOf' country [] = Nothing
              indexOf' country (x:xs) = if isCountry country x
                                        then Just (fst x)
                                        else indexOf' country xs
                where isCountry country (_, Node string _) = country == string
    


