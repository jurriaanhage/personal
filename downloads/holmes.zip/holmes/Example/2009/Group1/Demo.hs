module Demo where

import List

data Table = Table TableName FieldNames Records
type TableName = String
type FieldNames = [String]
type Records = [[ String]]
{-
top10 :: Table
top10 = Table "Top10"
         ["Nr" , "Artist" , "Title"]
         [ [ "1" , "Mark Ronson ft . Amy Winehouse" , "Valerie"]
         , [ "2" , "Alain Clark " , "Father and Friend " ]
         , [ "3" , "Leona Lewis " , "Bleeding Love" ]
         , [ "4" , "Kane" , "Catwalk Criminal " ]
         , [ "5" , "Colbie Caillat " , "Bubbly" ]
         , [ "6" , "Anouk" , " I Don't Wanna Hurt" ]
         , [ "7" , "Timbaland ft One Republic " , "Apologize " ]
         , [ "8" , "Lenny Kravitz " , " I'll Be Waiting " ]
         , [ "9" , "DJ Jean" , "The Lauch Relaunched" ]
         , [ "10" , "Rihanna" , "Don't Stop the Music" ]
         ]
-}
printTable :: Table -> IO()
printTable = putStrLn . writeTable

writeTable :: Table -> [Char]
writeTable (Table nm fn recs) = writeName ++ writeRecord fn ++ writeLine ++ concatMap writeRecord recs
        where
             maxwidth = columnWidth (fn:recs)
             writeName = nm ++ ": \n"
             writeRecord rec = "|" ++ fit maxwidth rec ++ "\n"
             writeLine = (replicate (foldr (+) 4 maxwidth) '-') ++ "\n"

fit :: [Int] -> FieldNames -> String
fit []     _      = ""
fit (x:xs) []     = (replicate x ' ') ++ "|"
fit (x:xs) (y:ys) = y ++ spaces ++ "|" ++ fit xs ys
        where
             spaces = replicate (x - (length y)) ' '

columnWidth :: Records -> [Int]
columnWidth recs = map maximum $ transpose [map length rec | rec <- recs]