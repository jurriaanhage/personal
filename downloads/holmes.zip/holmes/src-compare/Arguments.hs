module Arguments where

import System.Console.GetOpt (OptDescr(Option), ArgDescr(NoArg, ReqArg), getOpt, ArgOrder (Permute), usageInfo)
import Utils.HUtils(split)
import Control.Monad (when)

import Data.List (genericIndex)

data Flag = Help
          | NoFingerPrinting
          | NoCallgraph
          | NoTokens
--          | CSV           
--          | Threshold Int Int Int 
          | FileOnly 
          | SubOnly 
          | Single String String
   deriving (Show, Eq)

options :: [OptDescr Flag]
options = [ Option "h" ["help"]           (NoArg Help)                         "display this help message"
          , Option "f" ["fingerprinting"] (NoArg NoFingerPrinting)               "DON'T compare fingerprints"
          , Option "c" ["callgraph"]      (NoArg NoCallgraph)                    "DON'T compare callgraph"
          , Option "t" ["tokens"]         (NoArg NoTokens)                       "DON'T compare tokens"
--          , Option ['c'] ["csv"]   		    (NoArg CSV)                          "output csv file"
--          , Option ['t'] ["threshold"]	    (ReqArg tresh "t1,t2,t3" )           "threshold submission level for STRUCTURAL, LITERAL & SEMANTIC heuristics"
          , Option "F" ["fileonly"]   	(NoArg FileOnly)                     "only file comparisson"
          , Option "S" ["subonly"]   	    (NoArg SubOnly)                      "only submission comparison"
          , Option ""  ["single"]         (ReqArg paths "pathname1,pathname2") "do a single comparison" ]

-- Helper function for the single flag          
paths :: String -> Flag          
paths input = output
    where output | (length lst /= 2) = error "\n\nERROR: need to give two paths\n"
                 | otherwise = Single (head lst) (genericIndex lst 1)
          lst = (split input ',')
{-
tresh :: String -> Flag
tresh input = Threshold (t 0) (t 1) (t 2)
    where t i = if length lst /= 3 
                then error "\n\nERROR: need 3 arguments for Threshold e.g -t 30,40,50\n"
                else genericIndex lst i
          lst = [read x :: Int | x  <- (split input ',')]	
-}

userInfo = usageInfo header options 
  where header = "Usage: holmes-compare [options] dir"
  
-- The handling of the arguments
processArguments :: [String] -> IO ([Flag], [String])
processArguments argv =
   case getOpt Permute options argv of      
      (o,n,[]  ) -> do
        when ((Help `elem` o) || (null n)) (putStrLn userInfo)
        return (checkArguments o,n)       
      (_,_,errs) -> ioError (userError (concat errs ++ userInfo))

-- Check if both the f and s flag are not activated at the same time    
checkArguments :: [Flag] -> [Flag]
checkArguments options | (FileOnly `elem` options) && (SubOnly `elem` options) = error "\n\nERROR: at most one argument -f or -s is allowed"
                       | otherwise = options
