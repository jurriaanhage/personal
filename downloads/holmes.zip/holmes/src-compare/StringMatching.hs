module StringMatching where

type Table = [(Int,Int,Int)]

-- Calculate the levenshteinDistance for a list of items
levenshteinDistance :: (Eq t) => [t] -> [t] -> Int
levenshteinDistance str1 str2 = checkTable (length str1) (length str2) table
	where table = calc str1 str2 1 1 []

-- Helper function for the levenshtein distance function    
checkTable :: Int ->  Int -> Table -> Int
checkTable 0 j _     = j
checkTable i 0 _     = i
checkTable i j table = head [t | (x,y,t) <- table, x == i, y == j]

-- Actual calculations for the levenshtein distance
calc :: (Eq t) => [t] -> [t] -> Int -> Int -> Table -> Table
calc str1 str2 i j tab | i > (length str1) = calc str1 str2 1 (j+1) tab
                       | j > (length str2) = tab
                       | otherwise = calc str1 str2 (i+1) j ((i,j,newValue):tab)
    where newValue = if item1 == item2 then (checkTable (i-1) (j-1) tab) else smallest + 1
          min3 x y z = min (min x y) z
          smallest = min3 (checkTable (i-1) j tab) (checkTable i (j-1) tab) (checkTable (i-1) (j-1) tab)
          item1 = (take 1 $ drop (i-1) str1)
          item2 =	(take 1 $ drop (j-1) str2)