module Utils.HUtils where

split :: String -> Char -> [String]
split []     sep = [""]
split (x:xs) sep | x == sep  = [] : rest
                 | otherwise = (x : head rest) : tail rest
   where rest = split xs sep

fst3 (x,_,_) = x
snd3 (_,x,_) = x

fst5 (x,_,_,_,_) = x
snd5 (_,x,_,_,_) = x