module HandleResult where

import Compare (Report(Report), FileResult(FileRes), GraphResult, SubmissionResult(SubRes), FingerprintResult)
import Arguments (Flag(NoFingerPrinting, NoTokens, NoCallgraph))

import System.FilePath (splitDirectories)

import Data.Maybe (fromJust)

-- File prints
csvFileHeader :: [Flag] -> String
csvFileHeader options = 
    (whenS (NoFingerPrinting `notElem` options) "fingerprints; ") ++
    (whenS (NoTokens `notElem` options) "tokens; sorted tokens; ") ++ "file VS file;\n"
    
csvFiles :: [Flag] -> Report -> String
csvFiles options (Report p1 p2 _ fileRes) =
    let (prog1:inc1:_) = reverse $ splitDirectories p1
        (prog2:inc2:_) = reverse $ splitDirectories p2
    in  concatMap (csvFileResult options (inc1,prog1) (inc2, prog2)) fileRes

csvFileResult :: [Flag] -> (String, String) -> (String, String) -> FileResult -> String
csvFileResult options (inc1,prog1) (inc2,prog2) fileRes =
    let (FileRes f1 f2 mToks {-str comm-} fp) = fileRes
        (tok,tks) = fromJust mToks
        (_,_,tValue, tLenght1, tLength2) = tok
        (_,_,tsValue, tsLenght1, tsLength2) = tks
        {-(_,_,sValue, sLenght1, sLength2) = str
        (_,_,cValue, cLenght1, cLength2) = comm-}
        (_,_,fValue) = getFPvalue fp
    in  if (NoTokens `elem` options && NoFingerPrinting `elem` options)
        then ""
        else (whenS (NoFingerPrinting `notElem` options) ((showRound fValue) ++ "; ")) ++
             (whenS (NoTokens `notElem` options) ((showRound tValue) ++ "; " ++ (showRound tsValue) ++ "; "))
             {-(showRound sValue) ++ ";" ++-}
             {-(showRound cValue) ++ ";" ++-}
             ++ inc1 ++ "/" ++ prog1 ++ "/" ++ f1 ++ " VS " ++ inc2 ++ "/" ++ prog2 ++ "/" ++ f2 ++ ";\n"
             
-- Submission prints
csvSubHeader :: [Flag] -> String     
csvSubHeader options = (whenS (NoFingerPrinting `notElem` options) "fingerprints; ") ++
                       (whenS (NoTokens `notElem` options) "(sorted) tokens; ") ++ 
                       (whenS (NoCallgraph `notElem` options) "indegree1; indegree2; indegree3; ") ++
                       "sub VS sub;\n";
                       -- ;outdegree1;outdegree2;outdegree3;totaldegree1;totaldegree2;totaldegree3;idMinDiff;idMaxDiff;idAvgDiff;odMinDiff;odMaxDiff;odAvgDiff;tdMinDiff;tdMaxDiff;tdAvgDiff;diameterDiff;parameter1;parameter2;parameterAvg") {-;Strings;Comments"-} ++
                     
                       
csvSubmissions :: [Flag] -> Report -> String
csvSubmissions options (Report p1 p2 subRes _) = 
    let (prog1:inc1:_) = reverse $ splitDirectories p1
        (prog2:inc2:_) = reverse $ splitDirectories p2
        (SubRes mGrRes mTok {-str comm-} fp) = subRes
        gr = fromJust mGrRes
        tok = fromJust mTok
        (_,_,tValue, tLenght1, tLength2) = tok
        --(_,_,sValue, sLenght1, sLength2) = str
        --(_,_,cValue, cLenght1, cLength2) = comm
        (_,_,fValue) = getFPvalue fp
    in  (whenS (NoFingerPrinting `notElem` options) $ (showRound fValue) ++ "; ")
        ++ (whenS (NoTokens `notElem` options) $ (showRound tValue) ++ "; ")
        ++ (whenS (NoCallgraph `notElem` options) $ 
            (showGraph "indegree1" gr ++ "; " 
            ++ showGraph "indegree2" gr ++ "; " 
            ++ showGraph "indegree3" gr ++ "; "))
            ++ inc1 ++ "/" ++ prog1 ++ " VS " ++ inc2 ++ "/" ++ prog2 ++ ";\n"
            {- ++ showGraph "outdegree1" gr ++ ";" 
            ++ showGraph "outdegree2" gr ++ ";" 
            ++ showGraph "outdegree3" gr ++ ";" 
            ++ showGraph "totaldegree1" gr ++ ";" 
            ++ showGraph "totaldegree2" gr ++ ";" 
            ++ showGraph "totaldegree3" gr ++ ";" 
            ++ showGraph "idMin" gr ++ ";" 
            ++ showGraph "idMax" gr ++ ";" 
            ++ showGraph "idAvg" gr ++ ";"
            ++ showGraph "odMin" gr ++ ";" 
            ++ showGraph "odMax" gr ++ ";" 
            ++ showGraph "odAvg" gr ++ ";" 
            ++ showGraph "tdMin" gr ++ ";" 
            ++ showGraph "tdMax" gr ++ ";" 
            ++ showGraph "tdAvg" gr ++ ";"
            ++ showGraph "diameter" gr ++ ";" 
            ++ showGraph "parameters1" par ++ ";" 
            ++ showGraph "parameters2" par ++ ";" 
            ++ showGraph "parametersAvg" par ++ ";"
            )
            (showRound sValue) ++ ";" ++
            (showRound cValue) ++ ";" ++
            -}
                    
-- Helper function for showing of a graphresult                    
showGraph :: String -> GraphResult -> String
showGraph name gr = showRound $ fromJust $ lookup name gr

fillout :: String -> String
fillout s = (take (filloutLength - length s) (repeat '0')) ++ s
  where filloutLength = 3

-- Rounding a double, and then convert that to a string
showRound :: Double -> String
showRound num = fillout (if (show num) == "NaN" then (show 0) else show $ round num)

-- Get a fingerprintresult a maybe fingerprintresult. Returns a defaultvalue when it is Nothing
getFPvalue :: Maybe FingerprintResult -> FingerprintResult
getFPvalue fp | fp == Nothing = ("","",0)
              | otherwise = fromJust fp

-- Like a monadic when, but for strings. When it is false, it is an empty string              
whenS :: Bool -> String -> String
whenS b s | b         = s
          | otherwise = ""