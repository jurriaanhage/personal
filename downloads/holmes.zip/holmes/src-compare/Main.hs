module Main where

import System.Directory   (setCurrentDirectory, getCurrentDirectory, doesDirectoryExist, getDirectoryContents)
import System.FilePath    (splitDirectories)
import Control.Monad      (liftM, when, filterM)
import Data.List          ((\\), sort)
import System.Environment (getArgs)

import Compare      (compareCurrent, comparePrevious, Report)
import HandleResult (csvSubHeader, csvSubmissions, csvFileHeader, csvFiles)
import Arguments    (processArguments, Flag(SubOnly, FileOnly, Single))
import ReadData     (getData)
   
runtest :: IO()
runtest = ghci ["../test/FQL/incarnation1/","-f", "-T"]

-- Main function
main :: IO() 
main = do args <- getArgs
          ghci args

-- Function for testing in ghci          
ghci :: [String] -> IO()
ghci args = do          
      (options,dir) <- processArguments args 
      startDir <- getCurrentDirectory
      let progDir = addSlash $ head dir
      case (singleCompare options) of
        True -> do 
            let progs = getSinglePaths options
            progData <- mapM (getData options) progs
            let totalResult = compareCurrent progData options              
            outputResult progDir totalResult options
        False -> do 
            --get programs from current incarnation
            mainProgs <- getPrograms progDir
            mainData <- mapM (getData options) mainProgs --data from programs in current incarnation
            let mainResult = compareCurrent mainData options                   
            --print (head mainResult)
            allIncarnations <- getPrograms (progDir ++ "../")         
            let prevIncarnations = (allIncarnations \\ [progDir ++ "../" ++ last (splitDirectories (addSlash startDir ++ progDir))])                        
            prevIncProgs <- (liftM concat) $ mapM (getPrograms.addSlash) prevIncarnations
            prevIncData <- mapM (getData options) (sort prevIncProgs)
            let prevResult = comparePrevious mainData prevIncData options
                totalResult = mainResult ++ prevResult
            cur <- getCurrentDirectory
            setCurrentDirectory startDir
            outputResult progDir totalResult options

-- The outputting of the result            
outputResult :: String -> [Report] -> [Flag] -> IO()
outputResult dir totalResult options = do           
    when (FileOnly `notElem` options) $
      writeFile (dir ++ "submissionoutput.csv") ((csvSubHeader options) ++ (concatMap (csvSubmissions options) (totalResult)))
    when (SubOnly `notElem` options) $
      writeFile (dir ++ "fileoutput.csv") ((csvFileHeader options) ++ (concatMap (csvFiles options) (totalResult)))

-- Searches for all the possible programs in a folder      
getPrograms :: String -> IO [FilePath]
getPrograms basedir = do
			baseExist <- doesDirectoryExist basedir
			case baseExist of
				False -> error "directory doesnt exist!"
				True ->	do
					contents <- getDirectoryContents basedir
					let fContents = filter (\x -> (head x) /= '.') contents
					subdirs <- filterM doesDirectoryExist (map (basedir ++) fContents)
					return subdirs

-- Adds a slash in the end of the filepath when it isn't there yet                    
addSlash :: FilePath -> FilePath
addSlash dir = if last dir /= '/' then dir ++ "/" else dir

-- Checks if Single is an element of a list of flags
singleCompare :: [Flag] -> Bool
singleCompare []                  = False
singleCompare ((Single p1 p2):xs) = True
singleCompare (x:xs)              = singleCompare xs

-- Get the paths from a single flag
getSinglePaths :: [Flag] -> [String]
getSinglePaths ((Single p1 p2):xs) = [p1,p2]
getSinglePaths (x:xs)              = getSinglePaths xs

{-
-- Two functions for thresholds. Maybe it can be used when it is necessary to use it.
getThresholds :: [Flag] -> (Int, Int, Int)
getThresholds []                        = (50,50,50)
getThresholds ((Threshold i1 i2 i3):xs) = (i1,i2,i3)
getThresholds (x:xs)                    = getThresholds xs 
	 

aboveThreshold (struc,lit,sem) (Report _ _ (SubmissionGrade tr gr pr sr cr fpr) _) = strucVal || litVal || semVal
	where
		getTokVal (TokenResult _ _ gr _ _) = gr
		getGraphVal (idDiff,idDiff2,idDiff3,odDiff,odDiff2,odDiff3,tdDiff,tdDiff2,tdDiff3,idMinDiff, idMaxDiff, idAvgDiff,odMinDiff, odMaxDiff, odAvgDiff, tdMinDiff, tdMaxDiff, tdAvgDiff, diameterDiff)
			= maximum [idDiff3, odDiff3, tdDiff3]
		getParVal (val1, val2, avg) = val2
		strucVal = (fromIntegral struc) <= (max (getTokVal tr) (getParVal pr))
		litVal = (fromIntegral lit) <= (max (getTokVal sr) (getTokVal cr))
		semVal = (fromIntegral sem) <= (getGraphVal gr)
-}