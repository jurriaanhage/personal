module ReadData where

import System.FilePath  (takeExtension, takeDirectory, takeFileName)
import System.IO.Unsafe (unsafeInterleaveIO)
import System.Directory (getDirectoryContents, doesDirectoryExist)

import Control.Monad (when)
import Data.Maybe    (fromJust)
import Data.List     (sort, findIndex)

import Arguments (Flag(NoTokens, NoCallgraph, NoFingerPrinting))

type TokenList       = [String] 
type TokenData       = [(FilePath, TokenList)]
--type StringData      = TokenData
--type CommentData     = TokenData
type FingerPrintData = [(FilePath, [(Int,Int)])]
type MetaListData    = [(String,[Int])]
type MetaValueData   = [(String,Double)]
data ProgData        = ProgData FilePath (Maybe (TokenData,TokenData)) {-StringData CommentData-} (Maybe FingerPrintData) (Maybe (MetaListData,MetaValueData))  deriving Show

-- Getting the data from the files
getData :: [Flag] -> FilePath -> IO ProgData
getData options prog = do
    tokens <- getTokens prog ".tok"
    sortTokens <- getTokens prog ".tks"
    --strings <- getStringComments prog ".str"
    --comments <- getStringComments prog ".comm"
    fingerprints <- getFingerprints prog
    (list, value) <- getMetadata prog
    let tok = if (NoTokens `notElem` options)         then Just (tokens,sortTokens) else Nothing
        fp  = if (NoFingerPrinting `notElem` options) then Just fingerprints        else Nothing
        md  = if (NoCallgraph `notElem` options)      then Just (list,value)        else Nothing
    return (ProgData prog tok {-strings comments-}fp md)

-- MetaData
getMetadata :: FilePath -> IO (MetaListData,MetaValueData)
getMetadata dir = do
    let filename = dir ++ "/holmesdata/metadata.hol"
    metastring <- unsafeInterleaveIO $ readFile filename
    let metawords = [seperateMD word | word <- (words metastring)]
        lists = [(name, read value :: [Int])| (name,value) <- metawords, elem name ["indegree","outdegree","totaldegree","parameters"]]
        values = [(name, read value :: Double)| (name,value) <- metawords, notElem name ["indegree","outdegree","totaldegree","parameters"]]
    return (lists,values)
        
seperateMD :: String -> (String,String)
seperateMD str = (name, (drop 1 value))
    where (name, value) = splitAt index str 
          index = fromJust $ findIndex (==':') str
		

-- Fingerprints
getFingerprints :: FilePath -> IO FingerPrintData
getFingerprints prog = do
    let fpDir = prog ++ "/fingerprints/"
    fpFiles_ <- getDirectoryContents fpDir
    fps <- sequence [readFingerprints(fpDir ++ fpfile) |fpfile <- fpFiles_, takeExtension fpfile == ".fpr"]
    return fps

readFingerprints :: FilePath -> IO (FilePath,[(Int,Int)])
readFingerprints file = do
    exist <- doesDirectoryExist (takeDirectory file) 
    when (not exist) $ error ("HOLMES ERROR: no fingerprints found at " ++ (takeDirectory file))
    content <- unsafeInterleaveIO $ readFile file
    return (takeFileName file,(read content :: [(Int,Int)]))

{-    
-- String / Comments
getStringComments :: FilePath -> String -> IO [(FilePath, TokenList)]
getStringComments prog extension = do
    let scDir = prog ++ "/StringComments/"
    scFiles_ <- getDirectoryContents scDir
    tokens <- sequence [readTokens (scDir ++ scfile) |scfile <- scFiles_, takeExtension scfile == extension]
    return (sort tokens)
-}
-- Tokens
getTokens :: FilePath -> String -> IO TokenData
getTokens prog extension = do
    let tokenDir = prog ++ "/tokens/"
    tokenFiles_ <- getDirectoryContents tokenDir
    tokens <- sequence [readTokens (tokenDir ++ tokenfile) |tokenfile <- tokenFiles_, takeExtension tokenfile == extension]
    return (tokens)
	
readTokens :: FilePath -> IO (FilePath,[String])
readTokens file = do
    content <- unsafeInterleaveIO $ readFile file
    let content_ = words content
    return (takeFileName file, content_)