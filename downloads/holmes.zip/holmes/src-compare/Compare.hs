module Compare where

import ReadData (ProgData(ProgData), FingerPrintData, TokenData, TokenList, MetaListData, MetaValueData)
import Arguments (Flag(NoFingerPrinting, NoTokens, NoCallgraph))
import StringMatching (levenshteinDistance)

import System.FilePath (dropExtension)
import Data.Algorithm.Diff (getDiff, DI(F,S,B))

import Data.Maybe (fromJust)
import Data.List (nub, (\\), isInfixOf, sortBy)

import Utils.HUtils (fst3, snd3, fst5, snd5)

data Report = Report Program Program SubmissionResult [FileResult] deriving Show
data SubmissionResult = SubRes (Maybe GraphResult) (Maybe TokenResult) {-StringResult CommentResult-} (Maybe FingerprintResult) deriving Show --FingerprintResult
data FileResult = FileRes Program Program (Maybe (TokenResult,TokenResult)) {-StringResult CommentResult-} (Maybe FingerprintResult) deriving Show
type Program = String -- submissionname

type GraphResult = [(String,Double)]
--type ParaResult = [(String,Double)]
type TokenResult = (String, String, Double, Int, Int)
{-type StringResult = TokenResult
type CommentResult = TokenResult-}
type FingerprintResult = (String, String, Double)

-- Compare all programs from the first parameter with eachother
compareCurrent :: [ProgData] -> [Flag] -> [Report]
compareCurrent [] _ = [] 
compareCurrent (fst:rest) options = [compare_ fst r options | r <- rest] ++ (compareCurrent rest options)

-- Compare all the programs from the first parameter with the programs from the second parameter
comparePrevious :: [ProgData] -> [ProgData] -> [Flag] -> [Report]
comparePrevious current previous options = [compare_ cur prev options | cur <- current, prev <- previous]

-- The actual comparing function
compare_ :: ProgData -> ProgData -> [Flag] -> Report
compare_ (ProgData file1 mtoks1 {-str1 com1-} mfp1 mmd1) 
         (ProgData file2 mtoks2 {-str2 com2-} mfp2 mmd2) options
	= Report file1 file2 subRes fileRes
		where
            (tok1,tks1) = fromJust mtoks1
            (tok2,tks2) = fromJust mtoks2
            fp1 = fromJust mfp1
            fp2 = fromJust mfp2
            (ml1,mv1) = fromJust mmd1
            (ml2,mv2) = fromJust mmd2
            subRes = SubRes graphRes tokSubResult {-stringSubResult commentSubResult-} fpSubResult
            graphRes = if (NoCallgraph `notElem` options)
                       then let graphResult = compareGraph (ml1,mv1) (ml2,mv2)
                                -- paraResult = compareParameter (fromJust $ lookup "parameters" ml1) (fromJust $ lookup "parameters" ml2)
                            in  Just graphResult
                       else Nothing            
            tokSubResult = if (NoTokens `notElem` options)
                           then Just $ compareTokenSubmission tks1 tks2
                           else Nothing
            --stringSubResult = compareSCSubmission "all.str" str1 str2
            --commentSubResult = compareSCSubmission "all.comm" com1 com2
            fpSubResult = if (NoFingerPrinting `notElem` options)
                          then Just (compareFPSubmission fp1 fp2)
                          else Nothing
            fileRes = if (NoTokens `notElem` options && NoFingerPrinting `notElem` options) 
                      then [ FileRes (dropExtension $ fst5 at) (dropExtension $ snd5 at) (Just (at,ast)) {-as ac-} (Just af)
                           | ast <- allFileSortTokens, at <- allFileTokens, af <- allFileFPs ,
                             getNames at == getNames ast, getFPNames af == getNames at   ] -- do original list comprehension
                      else if (NoTokens `notElem` options)
                           then [FileRes (dropExtension $ fst5 at) (dropExtension $ snd5 at) (Just (at,ast)) {-as ac-} Nothing 
                                | ast <- allFileSortTokens, at <- allFileTokens, getNames at == getNames ast] -- only tokens
                           else if   NoTokens `elem` options && NoFingerPrinting `elem` options
                                then [FileRes "" "" Nothing {-as ac-} Nothing | af <- allFileFPs]
                                else [FileRes (dropExtension $ fst3 af) (dropExtension $ snd3 af) Nothing {-as ac-} (Just af) | af <- allFileFPs]                                               
            allFileTokens = [compareTokens name1 name2 tkl1 tkl2 |(name1,tkl1) <- tok1, (name2,tkl2) <- tok2, notElem name1 ["all.tok"]]
            allFileSortTokens = [compareTokens name1 name2 tkl1 tkl2 |(name1,tkl1) <- tks1, (name2,tkl2) <- tks2, notElem name1 ["all.tks"]]
            --allFileStrings = [compareStringComments name1 name2 s1 s2 |(name1, s1) <- str1, (name2, s2) <- str2]
            --allFileComments = [compareStringComments name1 name2 c1 c2 |(name1, c1) <- com1, (name2, c2) <- com2]
            allFileFPs = [compareFingerPrints name1 name2 f1 f2 | (name1, f1) <- fp1, (name2, f2) <- fp2]
            getNames (name1, name2, _, _, _) = (dropExtension name1, dropExtension name2)
            getFPNames (name1, name2, _) = (dropExtension name1, dropExtension name2)

-- Compare Fingerprints
compareFPSubmission :: FingerPrintData -> FingerPrintData -> FingerprintResult
compareFPSubmission fpd1 fpd2 = compareFingerPrints "all.fpr" "all.fpr" (fpSub fpd1) (fpSub fpd2)
    where fpSub a = fromJust $ lookup "all.fpr" a

compareFingerPrints :: String -> String -> [(Int,Int)] -> [(Int,Int)] -> FingerprintResult
compareFingerPrints name1 name2 fp1 fp2 = (name1, name2, (100 ::Double) / (fromIntegral most) * (fromIntegral noh))
    where noh = length $ nub [(h1,i1) | (h1,i1) <- fp1, (h2,i2) <- (fp2), h1 == h2]
          most = max (length fp1) (length fp2)

{-
-- Compare Strings / Comments
compareSCSubmission :: String -> TokenData -> TokenData -> TokenResult
compareSCSubmission name data1 data2 = compareStringComments name name (scSub data1) (scSub data2)
              where 
                    scSub data_ = concat [value| (_,value)<- data_]

compareStringComments :: String -> String -> TokenList -> TokenList -> TokenResult                    
compareStringComments = compareTokens 
-}

-- Compare Tokens
compareTokenSubmission :: TokenData -> TokenData -> TokenResult
compareTokenSubmission tok1 tok2 = (compareTokens "all.tks" "all.tks" (toksub tok1) (toksub tok2))
    where toksub a = fromJust $ lookup "all.tks" a

compareTokens :: String -> String -> TokenList -> TokenList -> TokenResult
compareTokens name1 name2 tokenlist1 tokenlist2 = (name1, name2, score, length1, length2)
    where diff = getDiff tokenlist1 tokenlist2
          tokenDiff = length [(a,b)|(a,b) <- diff, a /= B]
          length1 = length tokenlist1
          length2 = length tokenlist2
          totallength = length1 + length2
          score = (fromIntegral $ 100 * (totallength - tokenDiff)) / (fromIntegral totallength)

{--
-- Compare parameters
compareParameter :: [Int] -> [Int] -> ParaResult
compareParameter par1 par2 = [((name ++ "1"),compareDegree1 par1 par2), ((name ++ "2"),compareDegree3 par1 par2), ((name ++ "Avg"),compareSingle (avg par1) (avg par2))]
    where avg lst = (fromIntegral $ foldr (+) 0 lst) / (fromIntegral $ length lst)  
          name = "parameters"
--}

-- Compare callgraph data
compareGraph :: (MetaListData,MetaValueData) -> (MetaListData,MetaValueData) -> GraphResult
compareGraph (list1, values1) (list2, values2) = listResults ++ valueResults
    where listResults = concat [compareDegrees name1 intList1 intList2 | (name1, intList1) <- list1, (name2, intList2) <- list2, elem name1 ["indegree","outdegree", "totaldegree"], name1 == name2]
          compareDegrees name l1 l2 = [((name ++ "1"),compareDegree1 l1 l2),((name ++ "2"),compareDegree2 l1 l2),((name ++ "3"),compareDegree3 l1 l2)]
          valueResults = [(name1, compareSingle v1 v2) | (name1,v1) <- values1, (name2,v2) <- values2, name1 == name2]

-- Helper functions for the comparison of a degreelist          
compareDegree1 :: [Int] -> [Int] -> Double
compareDegree1 dg1 dg2 = (fromIntegral $ 100 * (maxlength - (levenshteinDistance dg1 dg2)))/ (fromIntegral $ maxlength )
    where maxlength = max (length dg1) (length dg2)

compareDegree2 :: [Int] -> [Int] -> Double
compareDegree2 dg1 dg2 = compareDegree1 (transformDegree dg1) (transformDegree dg2)
    where transformDegree degree = concat [repeteDegree index amount | (index, amount) <- zip [1..] degree]            
          repeteDegree toPrint amount | amount <= 1 = [toPrint]
                                      | otherwise = [toPrint] ++ repeteDegree toPrint (amount-1)

compareDegree3 :: [Int] -> [Int] -> Double
compareDegree3 first second = (same + compareDiff largest difF difS) * 100
    where diff = getDiff first second
          largest = max (length first) (length second)
          same = (fromIntegral $ length [i | (b, i) <- diff, b == B]) / (fromIntegral $ largest)
          difF = [i | (b, i) <- diff, b == F]
          difS = [i | (b, i) <- diff, b == S]
          compareDiff :: Int -> [Int] -> [Int] -> Double
          compareDiff base f s = foldr (+) 0 diffPart
            where diffPart = map (* (1/ (fromIntegral base))) cpd'		
                  cpd' = if (length f) > (length s) then cpd s f else cpd f s		
                  cpd lst [] = []			
                  cpd [] lst = []		
                  cpd (x:xs) lst = [(fromIntegral $ min x closest)/(fromIntegral $ max x closest)] ++ cpd xs (lst \\ [closest]) 
                    where closest = getClosest x lst

getClosest :: Int -> [Int] -> Int
getClosest base list = head newList
    where newList = sortBy (closeTo base)	list
          closeTo b x y = compare (abs $ b-x) (abs $ b-y)

compareSingle :: Double -> Double -> Double
compareSingle a b = 100 * ((biggest - (abs (a-b))) / biggest)
    where biggest = max a b