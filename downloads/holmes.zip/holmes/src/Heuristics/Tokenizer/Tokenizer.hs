module Heuristics.Tokenizer.Tokenizer where

import Language.Haskell.Exts hiding (Token)

import Utils.HUtils (ModulePackage(MPackage), Program, TokenPackage(TPackage), getModule)
import Utils.Utils(fth4)

import Data.List (intersperse, sort, reverse)
import Data.Char (toLower)

type Tokens = [Token]
type Token = String

-- List of identifiers which should come in the tokenstream when encountered
specialIDs :: [String]
specialIDs = ["Int","String","Bool","Char","Double","Float","FilePath","Complex" ,"IO", "Maybe", "Just", "Nothing", "Either", "Left", "Right","Read" ,"Show", "Eq", "Ord"]

-- Tokenizes a complete module (unsorted)
tokenizeModule :: ModulePackage -> TokenPackage
tokenizeModule (MPackage fn mname mod tem) = (TPackage fn $ tokenize mod)

-- Tokenizes a complete module (sorted)
sortedTokenizeModule :: ModulePackage -> TokenPackage
sortedTokenizeModule (MPackage fn mname mod tem) = (TPackage fn $ sortedTokenize mod)

-- Tokenizes a complete program (unsorted)
tokenizeAll :: Program -> TokenPackage
tokenizeAll mps = (TPackage "all" $ concatMap (tokenize .getModule) mps)

-- Tokenizes a complete program (sorted)
sortedTokenizeAll :: Program -> TokenPackage
sortedTokenizeAll mps = let props = reverse $ sort $ concatMap getProperties $ map getModule mps
                        in (TPackage "all" $ concatMap fth4 props)

-- Creates 4-tuples for the three sorting conditions. Then does a sort and reverse to get it in the right order.
-- Then the tokens are selected from these tuples.
sortedTokenize :: Module -> Tokens
sortedTokenize m = let props = reverse $ sort $ getProperties m
                   in  concatMap fth4 props

-- Gets the necessary information for the sorting                   
getProperties :: Module -> [(Int, Int, String, Tokens)]
getProperties (Module _ _ _ _ _ _ decls) = concatMap getFuncProperties decls

getFuncProperties :: Decl -> [(Int, Int, String, Tokens)]
getFuncProperties f@(FunBind matches) = let tokens = tokenize f
                                        in [(getParams $ head matches, length tokens, map toLower $ concat tokens, tokens)]
getFuncProperties p@(PatBind {})      = let tokens = tokenize p
                                        in [(0, length tokens, map toLower $ concat tokens, tokens)]
getFuncProperties _                   = []  

-- Get the number of parameters for a match
getParams :: Match -> Int
getParams (Match _ _ ps _ _ _) = length ps

-- Type class for the actual tokenizing. It is implemented for almost the complete
-- parse tree of haskell-src-exts.
class Tokenize a where
  tokenize :: a -> Tokens
  
instance Tokenize a => Tokenize [a] where
  tokenize = concatMap tokenize

instance Tokenize a => Tokenize (Maybe a) where  
  tokenize Nothing  = []
  tokenize (Just x) = tokenize x
  
instance Tokenize Module where
  tokenize (Module _ _ _ _ _ _ decls) = tokenize decls  
  
instance Tokenize Decl where
  tokenize (FunBind matches)           = tokenize matches
  tokenize (PatBind _ pat _ rhs binds) = tokenize pat ++ 
                                         tokenize rhs ++
                                         if isEmptyBinding binds then [] else ["where"] ++ tokenize binds
  tokenize _                           = [] 

-- Checks if the binding is empty or an implicit parameter binding
isEmptyBinding :: Binds -> Bool
isEmptyBinding (BDecls  []) = True
isEmptyBinding (IPBinds _ ) = True
isEmptyBinding _            = False

-- Concatenates two tokenstreams, but merges the last token of the first stream with the first token of the second stream
specialConcat :: Tokens -> Tokens -> Tokens
specialConcat []     []     = []
specialConcat x      []     = x
specialConcat []     y      = y
specialConcat (x:[]) (y:ys) = (x ++ y) : ys
specialConcat (x:xs) ys     = x : specialConcat xs ys

-- Append a string to the front of the first token in the stream 
appendFirst :: String -> Tokens -> Tokens
appendFirst s []     = [s]
appendFirst s (x:xs) = (s ++ x) : xs

-- Append a string to the back of the last token in the stream
appendLast :: String -> Tokens -> Tokens
appendLast s []     = [s]
appendLast s (x:[]) = [x ++ s]
appendLast s (x:xs) = x : (appendLast s xs)
  
instance Tokenize Match where
  tokenize (Match _ name patterns mtyp rhs binds) = tokenize name ++
                                                    tokenize patterns ++
                                                    tokenize rhs ++ 
                                                    if isEmptyBinding binds then [] else ["where"] ++ tokenize binds
  
instance Tokenize Pat where 
  tokenize (PVar x)             = tokenize x
  tokenize (PLit l)             = tokenize l
  tokenize (PNeg p)             = appendFirst "-" $ tokenize p 
  tokenize (PNPlusK name _)     = tokenize name ++ ["0","I"] 
  tokenize (PInfixApp p1 qn p2) = tokenize p1 ++ tokenize qn ++ tokenize p2 
  tokenize (PApp qn pats)       = tokenize qn ++ tokenize pats
  tokenize (PTuple pats)        = "(" : tokenize pats ++ [")"] 
  tokenize (PList pats)         = if pats == [] then ["[]"] else ["["] ++ tokenize pats ++ ["]"]
  tokenize (PParen pats)        = "(" : tokenize pats ++ [")"]
  tokenize (PRec qn pfds)       = tokenize qn ++ ["{"] ++ tokenize pfds ++ ["}"] 
  tokenize (PAsPat name pat)    = specialConcat (appendLast "@" $ tokenize name) (tokenize pat)
  tokenize  PWildCard           = ["_"]
  tokenize (PIrrPat pat)        = appendFirst "~" $ tokenize pat
  tokenize (PatTypeSig _ pat _) = tokenize pat
  tokenize (PViewPat exp pat)   = tokenize exp ++ ["->"] ++ tokenize pat 
  tokenize _                    = []

instance Tokenize PatField where
  tokenize (PFieldPat qn pat) = tokenize qn ++ ["="] ++ tokenize pat
  tokenize (PFieldPun name  ) = tokenize name
  tokenize  PFieldWildcard    = [".."]
  
instance Tokenize Name where
  tokenize (Ident x)  = if elem x specialIDs then [x] else ["X"]
  tokenize (Symbol x) = ["(","O",")"] 
  
instance Tokenize QName where
  tokenize (Qual m name) = tokenize name
  tokenize (UnQual name) = tokenize name
  tokenize (Special spc) = tokenize spc
  
instance Tokenize SpecialCon where
  tokenize UnitCon          = ["()"]
  tokenize ListCon          = ["[]"]
  tokenize FunCon           = ["->"]
  tokenize (TupleCon _ i)   = ["(" ++ replicate (i-1) ',' ++")"]
  tokenize Cons             = ["O"]
  tokenize UnboxedSingleCon = []

instance Tokenize Rhs where
  tokenize (UnGuardedRhs  exp) = "=" : tokenize exp
  tokenize (GuardedRhss grhss) = tokenize grhss
  
instance Tokenize GuardedRhs where
  tokenize (GuardedRhs _ stmts exp) = "|": tokenize stmts ++ ["="] ++ tokenize exp
  
instance Tokenize Exp where 
  tokenize (Var qn)                  = tokenize qn
  tokenize (IPVar _)                 = [] 
  tokenize (Con qn)                  = tokenize qn
  tokenize (Lit l)                   = tokenize l
  tokenize (InfixApp e1 qop e2)      = tokenize e1 ++ tokenize qop ++ tokenize e2
  tokenize (App e1 e2)               = tokenize e1 ++ tokenize e2
  tokenize (NegApp e)                = appendFirst "-" $ tokenize e
  tokenize (Lambda _ pats e)         = "\\" : tokenize pats ++ ["->"] ++ tokenize e
  tokenize (Let binds e)             = "let" : tokenize binds ++ ["in"] ++ tokenize e
  tokenize (If e1 e2 e3)             = "if" : tokenize e1 ++ ["then"] ++ tokenize e2 ++ ["else"] ++ tokenize e3
  tokenize (Case e alts)             = "case" : tokenize e ++ ["of"] ++ tokenize alts
  tokenize (Do stmts)                = "do" : tokenize stmts
  tokenize (MDo stmts)               = "mdo" : tokenize stmts
  tokenize (Tuple exps)              = "(" : tokenize exps ++ [")"] 
  tokenize (TupleSection mexps)      = "(" : tokenize mexps ++ [")"]
  tokenize (List exps)               = if exps == [] then ["[]"] else "[" : tokenize exps ++ ["]"] 
  tokenize (Paren exp)               = "(" : tokenize exp ++ [")"]
  tokenize (LeftSection e qop)       = "(" : tokenize e ++ tokenize qop ++ [")"]
  tokenize (RightSection qop e)      = "(" : tokenize qop ++ tokenize e ++ [")"]
  tokenize (RecConstr qn fldupds)    = tokenize qn ++ ["{"] ++ tokenize fldupds ++ ["}"]
  tokenize (RecUpdate e fldupds)     = tokenize e ++ ["{"] ++ tokenize fldupds ++ ["}"]
  tokenize (EnumFrom e)              = appendFirst "[" $ tokenize e ++ ["..","]"]
  tokenize (EnumFromTo e1 e2)        = appendFirst "[" $ tokenize e1 ++ [".."] ++ (appendLast "]" $tokenize e2)
  tokenize (EnumFromThen e1 e2)      = appendFirst "[" $ tokenize e1 ++ tokenize e2 ++ ["..","]"]
  tokenize (EnumFromThenTo e1 e2 e3) = appendFirst "[" $ tokenize e1 ++ tokenize e2 ++ [".."] ++ (appendLast "]" $ tokenize e3)
  tokenize (ListComp e qualstmts)    = "[" : tokenize e ++ ["|"] ++ tokenize qualstmts ++ ["]"]
  tokenize (ParComp e qualstmtss)    = "[" : tokenize e ++ ["|"] ++ (concat $ intersperse ["|"] $ map (concatMap tokenize) qualstmtss) ++ ["]"]
  tokenize (ExpTypeSig _ exp _)      = tokenize exp
  tokenize _                         = []
  
instance Tokenize QualStmt where
  tokenize (QualStmt stmt)      = tokenize stmt
  tokenize (ThenTrans exp)      = tokenize exp
  tokenize (ThenBy e1 e2)       = tokenize e1 ++ tokenize e2 
  tokenize (GroupBy exp)        = tokenize exp
  tokenize (GroupUsing exp)     = tokenize exp
  tokenize (GroupByUsing e1 e2) = tokenize e1 ++ tokenize e2 
  
instance Tokenize FieldUpdate where
  tokenize (FieldUpdate qn e) = tokenize qn ++ ["="] ++ tokenize e
  tokenize (FieldPun name)    = tokenize name
  tokenize (FieldWildcard)    = [".."]
  
instance Tokenize Stmt where
  tokenize (Generator _ pat exp) = tokenize pat ++ ["<-"] ++ tokenize exp
  tokenize (Qualifier exp)       = tokenize exp
  tokenize (LetStmt binds)       = "let" : tokenize binds
  tokenize (RecStmt stmts)       = tokenize stmts

instance Tokenize Alt where
  tokenize (Alt _ pat guardedalts binds) = tokenize pat ++ tokenize guardedalts ++ if isEmptyBinding binds then [] else "where" : tokenize binds
  
instance Tokenize GuardedAlts where
  tokenize (UnGuardedAlt exp) = "->" : tokenize exp
  tokenize (GuardedAlts alts) = tokenize alts

instance Tokenize GuardedAlt where  
  tokenize (GuardedAlt _ stmts exp) = "|" : tokenize stmts ++ ["->"] ++ tokenize exp
  
instance Tokenize QOp where
  tokenize (QVarOp qn) = ["O"]
  tokenize (QConOp qn) = tokenize qn

instance Tokenize Binds where
  tokenize (BDecls decls)    = tokenize decls
  tokenize (IPBinds ipbinds) = []
  
instance Tokenize Literal where
  tokenize (Char       _) = ["C"]
  tokenize (String     _) = ["S"]
  tokenize (Int        _) = ["I"]
  tokenize (Frac       _) = ["F"]
  tokenize (PrimInt    _) = ["I"]
  tokenize (PrimWord   _) = ["I"]	
  tokenize (PrimFloat  _) = ["F"]
  tokenize (PrimDouble _) = ["F"]
  tokenize (PrimChar   _) = ["C"]
  tokenize (PrimString _) = ["S"]  