module Heuristics.HeuristicsCollector where

import Language.Haskell.Exts (prettyPrint)
import System.FilePath (takeFileName)
import System.Directory (doesDirectoryExist, createDirectory)

import Heuristics.Tokenizer.Tokenizer (sortedTokenizeModule, tokenizeModule, tokenizeAll, sortedTokenizeAll)
import Heuristics.Fingerprinting.Moss (fingerPrinting)
import Heuristics.Parametercollector.ParamColl (getParameters)
import Utils.HUtils (Program, writeFileDir, TokenPackage(TPackage), ModulePackage(MPackage))
import qualified Main.HolmesArgs as F (Flag(DeChain, Callgraph, Png, FingerPrinting, Tokens)) 
import Callgraph.CallgraphTypes (CallGraph)              
import Callgraph.GraphAnalysis (deChain, getDegrees, degreeListInfo, sndElm, allShortestPaths, createDot)
import Globals

import Data.List (sortBy)
import Control.Monad(when)
import System.Process (waitForProcess, runInteractiveCommand)
import System.Exit (ExitCode (ExitSuccess, ExitFailure))
import System.IO(hGetContents)

-- Collect all the information for the heuristics and print it to the files
collect :: FilePath -> Program -> CallGraph -> [F.Flag] -> IO()
collect root prog cg flags = do    
    -- Preparation
    let location = root ++ "/" ++ holmesDataDir ++ "/"
        fileName = "metadata.hol"
        callgraph = if elem F.DeChain flags then deChain cg else cg
        metaFileName = location ++ fileName            
    -- Step 1: information on callgraph
    when (notElem F.Callgraph flags) (do 
             writeFileDir location fileName ""  
             let (totaldegree, indegree, outdegree) = getDegrees cg
                 (tdMin, tdMax, tdAvg) = degreeListInfo totaldegree
                 (idMin, idMax, idAvg) = degreeListInfo indegree
                 (odMin, odMax, odAvg) = degreeListInfo outdegree
                 diameter = let res = sortBy sndElm $ allShortestPaths cg
                            in if res == [] then 0 else snd $ last $ res
                 writeString = "totaldegree:" ++ show (map snd totaldegree) ++ "\n" ++
                               "indegree:" ++ show (map snd indegree) ++ "\n" ++
                               "outdegree:" ++ show (map snd outdegree) ++ "\n" ++
                               "tdMin:" ++ show tdMin ++ "\n" ++
                               "tdMax:" ++ show tdMax ++ "\n" ++
                               "tdAvg:" ++ show tdAvg ++ "\n" ++
                               "idMin:" ++ show idMin ++ "\n" ++
                               "idMax:" ++ show idMax ++ "\n" ++
                               "idAvg:" ++ show idAvg ++ "\n" ++
                               "odMin:" ++ show odMin ++ "\n" ++
                               "odMax:" ++ show odMax ++ "\n" ++
                               "odAvg:" ++ show odAvg ++ "\n" ++
                               "diameter:" ++ show diameter ++ "\n"
             appendFile (location ++ fileName) writeString
             let parameters = [para |(MPackage _ _ mod _) <- prog, para <- getParameters mod ]
             appendFile metaFileName ("parameters:" ++ show (map snd parameters) ++ "\n")          
             let dotstring = createDot cg
                 dotFileName = location ++ "callgraph.dot"
                 pngFileName = location ++ "callgraph.png"            
             writeFile dotFileName dotstring
             when (elem F.Png flags) (do                 
                (hin,hout,herr,res) <- runInteractiveCommand ("dot -Tpng " ++ dotFileName ++ " -o " ++ pngFileName)
                exitcode <- waitForProcess res 
                case exitcode of
                  ExitSuccess   -> putStrLn "Creation callgraph PNG File SUCCESFULL..."
                  ExitFailure n -> do err <- hGetContents herr
                                      putStrLn $ "Warning: creating callgraph PNG file with dot FAILED !!!!\n" ++ err ) )                
    -- Step 2: tokenize and save tokens    
    when (notElem F.Tokens flags) (do
        let tokenLocation = root ++ "/" ++ tokensDir ++ "/"
        exist <- doesDirectoryExist tokenLocation
        case exist of
          False -> do putStrLn "Generating token files in tokens directory..."
                      createDirectory tokenLocation
                      writeTokens tokenLocation (map tokenizeModule prog)       ".tok"
                      writeTokens tokenLocation (map sortedTokenizeModule prog) ".tks"
                      writeTokens tokenLocation [tokenizeAll prog]              ".tok"
                      writeTokens tokenLocation [sortedTokenizeAll prog]        ".tks"
          True  -> putStrLn "Token files not generated; directory already exists")
    
    -- Step 3: fingerprint stripped document
    when (notElem F.FingerPrinting flags) (do 
        let prints = [(mn, prettyPrint mod)| MPackage fn mn mod _ <- prog]
            fpLocation = root ++ "/" ++ fingerprintsDir ++ "/"
        exist <- doesDirectoryExist fpLocation
        case exist of
          False -> do putStrLn "Generating fingerprint files in fingerprints directory..."
                      createDirectory fpLocation      
                      writeFingerPrintFiles fpLocation prints
                      writeFingerPrintFiles fpLocation [("all", concatMap snd prints)] 
          True  -> putStrLn "Fingerprint files not generated; directory already exists")
        
-- Write fingerprints to given filepath    
writeFingerPrintFiles :: FilePath -> [(String,String)] -> IO()
writeFingerPrintFiles _ [] = return ()
writeFingerPrintFiles location ((mname, string):xs) = do
    writeFile (location ++ (mname) ++ ".fpr") (show $ fingerPrinting 25 5 string)
    writeFingerPrintFiles location xs    
    
-- Write tokens to given filepath with given extension
writeTokens :: FilePath -> [TokenPackage] -> String -> IO()
writeTokens _ [] _ = return ()
writeTokens location ((TPackage fn toks):xs) extension = do 
    writeFile (location ++ (takeFileName fn) ++ extension) (concatMap (\x -> x ++ "\n") toks)
    writeTokens location xs extension   