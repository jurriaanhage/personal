module Heuristics.Parametercollector.ParamColl where

import Language.Haskell.Exts

import Utils.ParserUtils (getDecls)
import Callgraph.CallgraphTypes (Named(nameOf))

type Parameter = (String, Int)
type Parameters = [Parameter]

-- For a module, collects the number of parameters for each function
getParameters :: Module -> Parameters
getParameters mod = (getParams . getDecls) mod

-- For a list of declarations, collects the number of parameters for each function
getParams :: [Decl] -> Parameters
getParams []        = []
getParams (d:decls) = if isFunBind d then (getName d, getP d) : getParams decls else getParams decls

-- Get the name of a function binding
getName :: Decl -> String
getName (FunBind ((Match _ name _ _ _ _) : ms)) = nameOf name
getName _                                       = error "Should not be reachable"

-- Get the number of patterns(which is the number of parameters) for a function binding
getP :: Decl -> Int
getP (FunBind ((Match _ _ pats _ _ _):ms)) = length pats
getP _                                     = error "Should not be reachable."

-- Check if a declaration is a function binding
isFunBind :: Decl -> Bool
isFunBind FunBind{} = True
isFunBind _         = False