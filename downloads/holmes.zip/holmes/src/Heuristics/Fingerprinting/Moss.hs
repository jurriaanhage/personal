module Heuristics.Fingerprinting.Moss where

import Data.Char (isSpace, ord)
import Data.List (nub)

--makes k-grams of a string e.g 5 grams of "foobar" = "fooba", "oobar"
kgrams :: Int -> String -> [String]
kgrams k string = makeKgrams k [char | char <- string, not (isSpace char)]

makeKgrams :: Int -> [t] -> [[t]]
makeKgrams k item
      | k > length item = []
      | otherwise = [take k item] ++ makeKgrams k (drop 1 item)

--returns the list with the indexnumbers in a tuble e.g [x,y] = [(0,x),(1,y)]
giveIndex :: [a] -> [(a,Int)]
giveIndex list = zip list [0..]

-- depending on the window size it will choose a fingerprint out of a window
chooseFingerprint w hashes = nub [foldl1 minX win | win <- windows]
     where
          iHashes = giveIndex hashes
          windows = makeKgrams w iHashes
          minX (a1,b1) (a2,b2)
               | a1 < a2 = (a1,b1)
               | (a1 == a2) && b1 > b2 = (a1,b1)
               | otherwise = (a2,b2)

-- a simpel rolling hash
rollingHash :: Int -> [String] -> [Int] 
rollingHash _ [] = []
rollingHash base (x:kgrams) = getHashes [(initialHash x)] [x] kgrams
    where
         getHashes hashes _ [] = reverse hashes
         getHashes hashes done todo = getHashes (new:hashes) (current:done) (drop 1 todo)
                   where
                        current = head todo
                        minus = (ord $ head $ head done) * base ^ ((length x) - 1)
                        plus = ord $ last current
                        new = ((head hashes) - minus) * base + plus
         initialHash :: String -> Int
         initialHash x = foldr1 (+) [ascii * base ^ s |(ascii,s) <- (zip (map ord x) (reverse size))]
                     where
                          size = let s = (length x) - 1 in [0 .. s]

--given de size of k and the size w it will returns a set of fingerprints.                           
fingerPrinting :: Int -> Int -> String -> [(Int,Int)]
fingerPrinting k w text = chooseFingerprint w (rollingHash 101 (kgrams k text))