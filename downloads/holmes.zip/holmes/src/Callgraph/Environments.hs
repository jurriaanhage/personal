module Callgraph.Environments where

import Callgraph.CallgraphTypes (Environment, QEntity, Entity(Ent), nameOf, qName)
import Utils.ParserUtils (getFunctions, getModName, getExports, getImports, getVarExportName, lookupModule, getImpSpecVars, getModuleExports)

import Language.Haskell.Exts (Module, ImportDecl(importModule, importQualified, importAs, importSpecs), ModuleName, QName)

import qualified Data.Map as M (empty, fromList, lookup, union, unions, toList, filterWithKey, filter, mapKeys)
import Data.Maybe (fromMaybe, fromJust)

-- Creates the complete function environment (local and imported)
mkCompleteEnv :: Module -> [Module] -> Environment
mkCompleteEnv myMod allMods = M.union (mkLocalEnv myMod) (mkImportedEnvs myMod allMods)

-- Creates a local environment. Only functions that are declared in the same module
-- are added to the environment (qualified and unqualified)
mkLocalEnv :: Module -> Environment
mkLocalEnv mod = let mname = nameOf $ getModName mod 
                 in  M.fromList $ concatMap (\x -> [((Nothing, x), (Ent mname x)), ((Just mname, x), (Ent mname x))]) (getFunctions mod)                 

-- Uses importname, qualified and as to create the imported environment 
mkImportedEnv :: Module -> [Module] -> ImportDecl -> Environment
mkImportedEnv myMod allMods importDecl = if lookupModule (importModule importDecl) allMods == Nothing 
                                         then M.empty
                                         else let importedMod = fromJust $ lookupModule (importModule importDecl) allMods
                                                  importedEnv = mkExportedEnv importedMod allMods
                                                  newImportedEnv = fixImportedEnv importedEnv importDecl
                                              in  newImportedEnv

-- Resolves the import declaration with the imported environment. Things that are handeld are:
-- import specifications, qualified and as(renaming of import).                                              
fixImportedEnv :: Environment -> ImportDecl -> Environment
fixImportedEnv env importDecl = let mname = nameOf $ importModule importDecl
                                    mImportSpecs = importSpecs importDecl 
                                    specEnv = if mImportSpecs == Nothing
                                              then env
                                              else let (isHiding, impSpecs) = fromJust mImportSpecs
                                                       impSpecVars = getImpSpecVars impSpecs
                                                    in  if isHiding 
                                                        then removeFuncs impSpecVars env
                                                        else filterFuncs impSpecVars env
                                    qualEnv = if importQualified importDecl then M.filterWithKey (\x _ -> isQualified x) specEnv 
                                                                            else specEnv
                                    asName = importAs importDecl
                                    asEnv = if asName == Nothing 
                                            then qualEnv 
                                            else changeQual qualEnv (mname, nameOf $ fromJust asName)
                                in  asEnv

-- Changes all the qualifications in an environment which are the first item of the tuple into the second item of the tuple.
-- Qualification which are not equal are left untouched. Used for imports with as.                                 
changeQual :: Environment -> (String, String) -> Environment
changeQual env (from,to) = M.mapKeys (\(entqual,entname) -> (if entqual == Just from then Just to else entqual,entname)) env 

-- Used by importlist hiding specification
removeFuncs :: [String] -> Environment -> Environment
removeFuncs nms env = M.filter (\(Ent mod name) -> if name `elem` nms then False else True) env

-- Used by importlist specification
filterFuncs :: [String] -> Environment -> Environment
filterFuncs nms env = M.filter (\(Ent mod name) -> if name `elem` nms then True else False) env
                                
-- Creates the resulting imported environment                                  
mkImportedEnvs :: Module -> [Module] -> Environment
mkImportedEnvs myMod allMods = M.unions (map (mkImportedEnv myMod allMods) (getImports myMod))    

-- Creates the environment that is exported from a module (unqualified, so only function names)                                  
-- Is using exportlist, only variables
mkExportedEnv :: Module -> [Module] -> Environment
mkExportedEnv mod allMods = case getExports mod of 
                              Nothing      -> mkLocalEnv mod
                              Just exports -> let mname = nameOf $ getModName mod
                                                  compEnv = mkCompleteEnv mod allMods
                                                  qent x = fromJust $ qName x
                                                  funcExports = getVarExportName exports
                                                  funcExportEnv = calculateFuncExportEnv compEnv mname funcExports
                                                  modExports = getModuleExports exports
                                                  importedEnv = calculateImportedEnv mod allMods modExports
                                                  modExportEnv = fixExportedModules mname importedEnv
                                              in  M.union funcExportEnv modExportEnv

-- For a list of modulenames, calculates and unions their environments which are imported by the module (and handled with the correct import declarations)                                          
calculateImportedEnv :: Module -> [Module] -> [ModuleName] -> Environment
calculateImportedEnv mod allMods = M.unions . (map (\m -> M.unions $ map (mkImportedEnv (fromJust $ lookupModule m allMods) allMods) (getImportDecls mod m)))

-- Calculates the exported environment for the function exports                                              
calculateFuncExportEnv :: Environment -> String -> [QName] -> Environment
calculateFuncExportEnv compEnv mname = M.fromList . (concatMap (\x -> makeQualAndUnqual mname (qent x) (lookupEnv (qent x) compEnv)))
   where qent x = fromJust $ qName x

-- Removes qualifications other and adds qualified and unqualified version for this module.                                                  
fixExportedModules :: String -> Environment -> Environment
fixExportedModules mname env = M.fromList $ concatMap (\(qent,ent) -> makeQualAndUnqual mname qent ent) $ M.toList $ M.filterWithKey (\x _ -> not $ isQualified x) env                                                  
                                                  
-- Returns the import declarations in a module which correspond to the modulename
getImportDecls :: Module -> ModuleName -> [ImportDecl]
getImportDecls mod mname = filter (\d -> mname == importModule d) (getImports mod)
                                                  
-- Creates an list of tuples which can be converted into an environment
-- It adds only a qualified and unqualifed version of the QEntity where the input string is the qualification                                                  
makeQualAndUnqual :: String -> QEntity -> Entity -> [(QEntity, Entity)]
makeQualAndUnqual modname (_, name) ent =  [((Nothing, name),ent),((Just modname, name),ent)]

-- Do a lookup in an environment                                   
lookupEnv :: QEntity -> Environment -> Entity
lookupEnv qent env = fromMaybe (Ent "UnknownModule" (pp qent)) $ M.lookup qent env

-- Little pretty printing function for QEntities
pp :: QEntity -> String
pp (Nothing, x) = x
pp (Just x, y) = x ++ "." ++ y

-- Returns whethere a QEntity is qualified
isQualified :: QEntity -> Bool
isQualified (Just _,_) = True
isQualified _          = False  