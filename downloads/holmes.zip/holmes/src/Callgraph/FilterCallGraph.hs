module Callgraph.FilterCallGraph where

import Callgraph.CallgraphTypes (WorkList, FuncList, CallGraph, Entity(Ent, modu), QNamed(qName), QEntity)
import Utils.HUtils (EnvPackage(EPackage))
import Callgraph.Environments(lookupEnv)

import Data.List (nub, sort, intersperse)
import System.FilePath (takeExtension, takeBaseName)
import Utils.HUtils (split)
import Data.Maybe (fromJust, fromMaybe)

-- Filters the funclist according to the startingpoints and the environments
filterFuncList :: WorkList -> FuncList -> [EnvPackage] -> CallGraph
filterFuncList wl fl envs = let initwl = solveInitWL wl fl envs
                                usedEnts = checkFuncList initwl fl envs 
                            in  map (\x -> (x, getCallEnts envs fl x)) usedEnts

-- The actual filtering of the call graph
checkFuncList :: [Entity] -> FuncList -> [EnvPackage] -> [Entity]
checkFuncList el fl envs = if sort el == sort newEl then newEl else checkFuncList newEl fl envs 
               where 
                 newEl = nub $ [additions | funcEnt <- el, additions <- getCallEnts envs fl funcEnt] ++ el

-- Looking up the calls in the funclist and the corresponding entities in the environment  
getCallEnts :: [EnvPackage] -> FuncList -> Entity -> [Entity]
getCallEnts []                            _  _   = []
getCallEnts ((EPackage fn modn env):envs) fl ent | modn == modu ent = map (flip lookupEnv env) (getFuncCallsFromList ent fl)              
                                                 | otherwise        = getCallEnts envs fl ent

-- From a function list returns all the called functions from that entity                                                 
getFuncCallsFromList :: Entity -> FuncList -> [QEntity]
getFuncCallsFromList _    []              = []
getFuncCallsFromList ent1 ((ent2,qns):fs) | ent1 == ent2 = map (fromJust . qName) qns
                                          | otherwise    = getFuncCallsFromList ent1 fs                  
                 
-- Resolving the module.* startpoints (wildcards) and when the filename is different from the modulename      
solveInitWL :: WorkList -> FuncList -> [EnvPackage] -> [Entity]
solveInitWL wl fl envs = concat [if (takeExtension w == ".*") then solve w else [stringToEntity w envs]  | w <- wl]
               where
                    solve w = nub $ concat [if (takeBaseName w == modu x) then [x] else [] | (x,_) <- fl ]      

-- Converts a string into an entity                    
stringToEntity :: String -> [EnvPackage] -> Entity
stringToEntity s envs = let mod = toModule s
                            env = getEnvPackageByFile mod envs
                            newmod = fromMaybe mod $ differentModNameEnv env
                        in  Ent newmod (toFuncName s)                    

-- Helper function of stringToEntity
toModule :: String -> String
toModule s = concat $ intersperse "." $ init $ split s '.'

-- Helper function of stringToEntity
toFuncName :: String -> String
toFuncName s = last $ split s '.'

-- Gets the environment for a certain modulename
getEnvPackageByFile :: String -> [EnvPackage] -> EnvPackage
getEnvPackageByFile s []                         = error $ "Should not occur! In getEnvPackageByFile. For: " ++ s
getEnvPackageByFile s (e@(EPackage _ mn _):envs) | s == mn   = e
                                                 | otherwise = getEnvPackageByFile s envs

-- Checks if filename and modulename are the same, and when different returns the modulename
differentModNameEnv :: EnvPackage -> Maybe String
differentModNameEnv (EPackage fn mn _) | fn == mn  = Nothing
                                       | otherwise = Just mn