module Callgraph.GraphAnalysis where

import Data.List (nub, (\\), sortBy, elemIndices)
import Data.Maybe (fromJust)
import Callgraph.CallgraphTypes(Entity (Ent), CallGraph)

type Degree = (Entity, Int)
type DegreeList = [Degree]
type DegreeTriple = (DegreeList,DegreeList,DegreeList)

type Node = Entity
type Nodes = [Node]
type Edge = (Node,Node)
type Edges = [Edge]

data Visit = Yes | No deriving (Show, Eq)

-- Sorting a Degreelist by the Degree (so snd part of the tuple)
sortDegreeList :: DegreeList -> DegreeList
sortDegreeList = sortBy sndElm

sndElm :: (Ord b) => (a, b) -> (a, b) -> Ordering               
sndElm (a1,b1) (a2,b2) | b1 == b2 = EQ
                       | b1 > b2 = GT
                       | b1 < b2 = LT

-- getting the Degrees from a Graph in a triple (totaldegree, indegree, outdegree)
getDegrees :: CallGraph -> DegreeTriple
getDegrees graph = (totaldegree ,indegree, outdegree)
            where
                 totaldegree = sortDegreeList [(a, b + (fromJust $ lookup a indegree))| (a,b) <- outdegree ]
                 outdegree = sortDegreeList [(a, length b) | (a,b)<- graph ]
                 indegree =  sortDegreeList [(a, countElem a calls) | (a,b) <- graph]
                 calls = (concatMap snd graph)

countElem :: Eq a => a -> [a] -> Int
countElem a b = length $ elemIndices a b

-- computing the Minimum Maximum and Average Degree form a Degreelist
degreeListInfo :: DegreeList -> (Int,Int,Double)  --(min, max, avg)
degreeListInfo degreelist = (minDL , maxDL , avgDL)
               where
                    dl = [x | (_,x) <- degreelist]
                    minDL = if dl == [] then 0 else minimum dl
                    maxDL = if dl == [] then 0 else maximum dl
                    avgDL = (fromIntegral $ foldr (+) 0 dl) / (fromIntegral $ length dl)

-- giving a Callgraph returning the Nodes (aka Vertices)
getNodes :: CallGraph -> Nodes
getNodes grph = nub $ concat [[x] ++ ys  | (x, ys) <- grph ]

-- giving a Callgraph returning the Edges
getEdges :: CallGraph -> Edges
getEdges grph = [ (x,y) | (x,ys) <- grph, y <- ys]

-- create syntax for .dot file to create visual callgraph with dot (graphviz)
createDot :: CallGraph -> String
createDot grph = "digraph callgraph { \n" ++ concat (nodesdot ++ edgesdot) ++ "\n}"
	where
		nodes = getNodes grph
		edges = getEdges grph
		nodesdot = [ (addquotes $ showEntity node) ++ " [label=" ++ (addquotes $ showEntity node) ++ "]\n"| node <- nodes ]
		edgesdot = [(addquotes $ showEntity from) ++ "->" ++ (addquotes $ showEntity to) ++ "\n" | (from,to) <- edges]
		addquotes str = "\"" ++ str ++ "\""

--giving a Callgraph returning a list with the shortest paths between all Nodes (-1 stand for infinity, meaning no path possible)
allShortestPaths :: CallGraph -> [(Edge, Int)]
allShortestPaths clgrph = [((n,to),dist)| n <- nodes, (to, dist) <- (shortestPath clgrph n)]
             where
                   nodes = getNodes clgrph

--compute a the shortest paths from a given start node. (Dijksta algorithm)
shortestPath :: CallGraph -> Node -> DegreeList
shortestPath clgrph startNode = calcSP initDistanceList initVisitList edges worklist
             where
                  initDistanceList = (startNode, 0) : [(nds,-1) | nds <- (getNodes clgrph), nds /= startNode]
                  initVisitList = [(nds,No) | nds <- (getNodes clgrph)]
                  worklist = [startNode]
                  edges = getEdges clgrph
  
-- Actual calculating of the shortest path  
calcSP :: [(Entity,Int)] -> [(Entity,Visit)]->[(Entity,Entity)] -> [Entity] -> [(Entity, Int)]
calcSP distL visitL edges worklist = if worklist == [] then distL else calcSP newdistL newvisitL edges newWorkList
           where
                  current = head worklist
                  neighbours = [t |(f,t) <- edges, f==current, (fromJust $ lookup t visitL) == No]
                  newValue = (fromJust $ lookup current distL) + 1
                  newdistL = replace [(n,newValue)| (n,d) <- distL, nb <- neighbours, n == nb, d > newValue || d == -1] distL
                  newvisitL = replace [(current, Yes)] visitL
                  newWorkList = (drop 1 worklist) ++ map fst (sortDegreeList [(n,d)|(n,d) <- newdistL, nb <- neighbours, n == nb])

-- Replace function for the tuples
replace :: (Eq a) => [(a,b)] -> [(a,b)] -> [(a,b)]
replace []       orgList = orgList
replace (x:list) orgList = replace list (rplc x orgList)
                  
rplc :: (Eq a) => (a,b) -> [(a,b)] -> [(a,b)]
rplc (index, val) list = (index, val) : [(x,xval) | (x,xval) <- list, x /= index]
                  
-- Showing function for a degree list
showDegreeList :: DegreeList -> String
showDegreeList dgl = concat [showDegree i i | (_,i) <- dgl]

-- Showing function for a degree
showDegree :: Int -> Int -> String
showDegree toPrint amount 
           | amount <= 1 = show toPrint
           | otherwise = (show toPrint) ++ showDegree toPrint (amount-1) 
           
-- Dechaining a callgraph (removing nodes which have an in and out degree of 1)
deChain :: CallGraph -> CallGraph
deChain callgraph = replaceNodes [(x,y) | (x,y) <- callgraph , not $ elem x toBeRemoved ] toBeReplaced
        where
             (_ , inD, outD) = getDegrees callgraph
             toBeRemoved = [nodeI | (nodeI,iD) <- inD, (nodeO, oD) <- outD, nodeI == nodeO, iD == 1,  oD == 1]
             toBeReplaced = [(node, ([tbr], (fromJust $ lookup tbr callgraph))) | (node, trans) <- callgraph, tbr <- toBeRemoved, tbr `elem` trans]
             replaceNodes graph [] = graph
             replaceNodes graph (x:xs) = replaceNodes [if a == (fst x) then (a, (b ++ (snd $ snd x)) \\ (fst$snd x) ) else (a,b) | (a,b) <- graph] xs
             
showEntity :: Entity -> String
showEntity (Ent mod name) = mod ++ "." ++ name             