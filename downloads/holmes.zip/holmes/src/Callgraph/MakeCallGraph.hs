module Callgraph.MakeCallGraph where

import Language.Haskell.Exts(Module, QName)

import Callgraph.CollectFuncCalls (getFuncCalls)
import Callgraph.Environments     (mkCompleteEnv)
import Callgraph.CallgraphTypes   (WorkList, CallGraph, nameOf, Entity(Ent))
import Callgraph.FilterCallGraph  (filterFuncList)

import Utils.HUtils      (ModulePackage (MPackage), EnvPackage(EPackage), getModule, getFileName)
import Utils.ParserUtils (getDecls, getModName, isFunOrPat, getDeclName)  
   
-- Uses the environments that are constructed in Environments module and the starting points
-- that are calculated in the main module.
calcCallGraph :: [ModulePackage] -> WorkList -> [String] -> CallGraph
calcCallGraph mods startpoints exlist = let modules = map getModule mods
                                            envs = map (\x -> EPackage (getFileName x) (nameOf $ getModName $ getModule x) (mkCompleteEnv (getModule x) modules)) mods
                                            funcCalls = concatMap collectFuncCalls mods
                                            callgraph = filterFuncList startpoints funcCalls envs
                                        in  callgraph

-- Collects all the function calls from a certain module                                        
collectFuncCalls :: ModulePackage -> [(Entity,[QName])]
collectFuncCalls (MPackage _ _ mod _) = concatMap (\x -> map (\y -> (Ent (nameOf $ getModName mod) y, getFuncCalls [] x)) (getDeclName x)) (filter isFunOrPat (getDecls mod))