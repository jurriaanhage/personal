module Callgraph.CollectFuncCalls where

import Language.Haskell.Exts

import Data.List (partition, nub, (\\), reverse, delete)

import Utils.ParserUtils (isFunOrPat)
import Callgraph.CallgraphTypes(nameOf)

----------------------------------------------------------------------------
-- Collecting variables in patterns
----------------------------------------------------------------------------
getVars :: Pat -> [Name]
getVars (PVar name)          = [name]
getVars (PLit _)             = []
getVars (PNeg pat)           = getVars pat
getVars (PNPlusK name _)     = [name]
getVars (PInfixApp p1 _ p2)  = getVars p1 ++ getVars p2
getVars (PApp _ pats)        = concatMap getVars pats
getVars (PTuple pats)        = concatMap getVars pats
getVars (PList pats)         = concatMap getVars pats
getVars (PParen pat)         = getVars pat
getVars (PRec _ patfields)   = concatMap getVarsField patfields
getVars (PAsPat name pat)    = name : getVars pat
getVars (PIrrPat pat)        = getVars pat
getVars (PatTypeSig _ pat _) = getVars pat
getVars (PViewPat _ pat)     = getVars pat
getVars (PBangPat pat)       = getVars pat
getVars (PRPat _)            = []
getVars _                    = []

getVarsField :: PatField -> [Name]
getVarsField (PFieldPat _ pat) = getVars pat
getVarsField (PFieldPun name)  = [name]
getVarsField _                 = []

----------------------------------------------------------------------------
-- Functionality for resolving the local scope 
----------------------------------------------------------------------------
type Calls = [(QName, [QName])]

-- Get the qualified names from a declaration
getDeclQName :: Decl -> [QName]
getDeclQName (FunBind ((Match _ name _ _ _ _): xs)) = [UnQual name]
getDeclQName (PatBind _ pat _ _ _)                  = map UnQual (getVars pat)
getDeclQName x                                      = error $ show x

-- Collect the calls from a binding
funcCallsFromBinds :: LocalVars -> Binds -> Calls
funcCallsFromBinds vars binds = case binds of
                                  BDecls decls  -> concatMap (\x -> map (\y -> (y, getFuncCalls vars x)) (getDeclQName x)) (filter isFunOrPat decls)
                                  IPBinds _     -> []

-- For listcomprehension and parallel listcomprehension
funcCallsFromQualStmts :: LocalVars -> [QualStmt] -> Calls
funcCallsFromQualStmts vars qstmts = funcCallsFromStmts vars (qualStmtsToStmts qstmts) 

-- For do's and mdo's
funcCallsFromStmts :: LocalVars -> [Stmt] -> Calls
funcCallsFromStmts vars stmts = concatMap (funcCallsFromStmt vars) stmts 

-- Converting QualStmts to Stmts
qualStmtsToStmts :: [QualStmt] -> [Stmt]
qualStmtsToStmts []                   = []
qualStmtsToStmts ((QualStmt stmt):xs) = stmt : qualStmtsToStmts xs
qualStmtsToStmts (_:xs)               = qualStmtsToStmts xs

-- Collect the function calls from a stmt
funcCallsFromStmt :: LocalVars -> Stmt -> Calls
funcCallsFromStmt vars (Generator _ pat exp) = let funccalls = getFuncCalls vars exp 
                                               in map (\x -> ((UnQual x),funccalls)) (getVars pat)
funcCallsFromStmt vars (Qualifier exp)       = []
funcCallsFromStmt vars (LetStmt binds)       = funcCallsFromBinds vars binds
funcCallsFromStmt vars (RecStmt stmts)       = funcCallsFromStmts vars stmts

-- Splitting a list of QNames in two separate lists for the UnQual and Qual constructor
splitCalls :: [QName] -> ([QName], [QName])
splitCalls = partition isUnQual 

-- Helperfunction for splitCalls
isUnQual :: QName -> Bool
isUnQual UnQual{} = True
isUnQual _        = False

-- Solve the scoping for the do constructions
solveDoScope :: [String] -> [QName] -> Calls -> [QName]
solveDoScope vars []    _       = []
solveDoScope vars calls doCalls = let (unqual, qual) = splitCalls calls
                                  in  qual ++ filterVar vars (solveDoScope' unqual (nub $ reverse doCalls))

-- This has to be changed to get it to work correctly
-- go throught the reversed call list and add things when it is found
solveDoScope' :: [QName] -> Calls -> [QName]
solveDoScope' []    _              = []
solveDoScope' qns   []             = qns
solveDoScope' calls (dCall:dCalls) = if (fst dCall) `elem` calls then solveDoScope' (nub $ (delete (fst dCall) calls) ++ (snd dCall)) dCalls
                                                                 else solveDoScope' calls dCalls

-- Function for the actual solving of the scope
solveLocalScope :: [String] -> [QName] -> Calls -> [QName]
solveLocalScope vars []     _         = []
solveLocalScope vars calls localCalls = let (unqual, qual) = splitCalls calls
                                        in  qual ++ filterVar vars (solveLocalScope' [] unqual localCalls)
                                        
-- Filter out all variables from a list of qualified names
filterVar :: [String] -> [QName] -> [QName]
filterVar _    []                  = []
filterVar vars (un@(UnQual n):qns) = if nameOf n `elem` vars then filterVar vars qns else un : filterVar vars qns
filterVar vars (qual:qns)          = qual : filterVar vars qns                          

-- Helper function for the solving of the local scope
solveLocalScope' :: [QName] -> [QName] -> Calls -> [QName]
solveLocalScope' doneCalls []    _          = []
solveLocalScope' doneCalls calls localCalls = if newCalls == initCalls then initCalls else solveLocalScope' (nub $ doneCalls ++ initCalls) newCalls localCalls
	where
        initCalls = nub calls
        newCalls  = nub $ (initCalls \\ map fst localCalls) ++ concatMap (flip lookupCalls localCalls) (initCalls \\ doneCalls)

-- Lookup for a QName in a list of calls, to what functions he does a call.        
lookupCalls :: QName -> Calls -> [QName]
lookupCalls qname localcalls = concat [filter (/= qname) calls | (qnm, calls) <- localcalls, qnm == qname] 

----------------------------------------------------------------------------
-- Typeclass declaration and instances for the collection of functioncalls
----------------------------------------------------------------------------
type LocalVars = [String]

class FuncCalls a where
  getFuncCalls :: LocalVars -> a -> [QName]

instance FuncCalls a => FuncCalls [a] where
  getFuncCalls vars xs = concatMap (getFuncCalls vars) xs
  
instance FuncCalls a => FuncCalls (Maybe a) where  
  getFuncCalls vars (Just x) = getFuncCalls vars x
  getFuncCalls vars Nothing  = []
  
instance FuncCalls Binds where
  getFuncCalls vars (BDecls decls)    = getFuncCalls vars decls 
  getFuncCalls vars (IPBinds ipbinds) = getFuncCalls vars ipbinds
  
instance FuncCalls IPBind where
  getFuncCalls vars (IPBind _ _ exp) = getFuncCalls vars exp  
  
instance FuncCalls Decl where
  getFuncCalls vars (FunBind ms)                = getFuncCalls vars ms
  getFuncCalls vars (PatBind _ pat _ rhs binds) = let newvars = (map nameOf (getVars pat)) ++ vars
                                                      bindcalls = funcCallsFromBinds [] binds 
                                                  in  solveLocalScope newvars (getFuncCalls [] rhs) bindcalls
  getFuncCalls vars _                           = [] 
   
instance FuncCalls Match where
  getFuncCalls vars (Match _ name pats _ rhs binds) = let newvars = (map nameOf (concatMap getVars pats)) ++ vars
                                                          bindcalls = funcCallsFromBinds [] binds
                                                      in  solveLocalScope newvars (getFuncCalls [] rhs) bindcalls

instance FuncCalls Rhs where
  getFuncCalls vars (UnGuardedRhs exp)  = getFuncCalls vars exp
  getFuncCalls vars (GuardedRhss grhss) = getFuncCalls vars grhss  
  
instance FuncCalls Exp where
  getFuncCalls vars (Var qname)               = addQName vars qname 
  getFuncCalls vars (IPVar ipname)            = [] 
  getFuncCalls vars (Con qname)               = [] 
  getFuncCalls vars (Lit lit)                 = []
  getFuncCalls vars (InfixApp e1 qop e2)      = getFuncCalls vars e1 ++ getFuncCalls vars qop ++ getFuncCalls vars e2
  getFuncCalls vars (App e1 e2)               = getFuncCalls vars [e1,e2]
  getFuncCalls vars (NegApp exp)              = getFuncCalls vars exp
  getFuncCalls vars (Lambda _ pats exp)       = let newvars = (map nameOf (concatMap getVars pats)) ++ vars
                                                in  getFuncCalls newvars exp
  getFuncCalls vars (Let binds exp)           = let bindcalls = funcCallsFromBinds [] binds
                                                in solveLocalScope vars (getFuncCalls vars exp) bindcalls
  getFuncCalls vars (If e1 e2 e3)             = getFuncCalls vars [e1, e2, e3]
  getFuncCalls vars (Case e alts)             = getFuncCalls vars e ++ getFuncCalls vars alts
  getFuncCalls vars (Do stmts)                = let stmtcalls = funcCallsFromStmts vars (init stmts)
                                                in  solveDoScope vars (getFuncCalls vars stmts) stmtcalls
  getFuncCalls vars (MDo stmts)               = let stmtcalls = funcCallsFromStmts vars (init stmts)
                                                in  solveLocalScope vars (getFuncCalls vars stmts) stmtcalls
  getFuncCalls vars (Tuple exps)              = getFuncCalls vars exps
  getFuncCalls vars (TupleSection mexps)      = getFuncCalls vars mexps
  getFuncCalls vars (List exps)               = getFuncCalls vars exps
  getFuncCalls vars (Paren exp)               = getFuncCalls vars exp
  getFuncCalls vars (LeftSection exp qop)     = getFuncCalls vars exp ++ getFuncCalls vars qop
  getFuncCalls vars (RightSection qop exp)    = getFuncCalls vars qop ++ getFuncCalls vars exp 
  getFuncCalls vars (RecConstr _ fldupdates)  = getFuncCalls vars fldupdates
  getFuncCalls vars (RecUpdate _ fldupdates)  = getFuncCalls vars fldupdates
  getFuncCalls vars (EnumFrom exp)            = getFuncCalls vars exp
  getFuncCalls vars (EnumFromTo e1 e2)        = getFuncCalls vars [e1, e2]
  getFuncCalls vars (EnumFromThen e1 e2)      = getFuncCalls vars [e1, e2]
  getFuncCalls vars (EnumFromThenTo e1 e2 e3) = getFuncCalls vars [e1, e2, e3]
  getFuncCalls vars (ListComp exp qualstmts)  = let stmtcalls = funcCallsFromQualStmts [] qualstmts
                                                in  solveLocalScope vars (getFuncCalls vars exp ++ getFuncCalls vars qualstmts) stmtcalls
  getFuncCalls vars (ParComp exp qualstmtss)  = let stmtcalls = concatMap (funcCallsFromQualStmts []) qualstmtss
                                                in  solveLocalScope vars (getFuncCalls vars exp ++ getFuncCalls vars qualstmtss) stmtcalls
  getFuncCalls vars (ExpTypeSig _ exp _)      = getFuncCalls vars exp
  getFuncCalls vars (VarQuote qname)          = addQName vars qname
  getFuncCalls vars _                         = []

instance FuncCalls Alt where
  getFuncCalls vars (Alt _ pat guardedalts binds) = let newvars = map nameOf (getVars pat) ++ vars
                                                        bindcalls = funcCallsFromBinds [] binds
                                                    in  solveLocalScope vars (getFuncCalls newvars guardedalts) bindcalls
                                                        
instance FuncCalls GuardedAlts where
  getFuncCalls vars (UnGuardedAlt exp)        = getFuncCalls vars exp
  getFuncCalls vars (GuardedAlts guardedalts) = getFuncCalls vars guardedalts
  
instance FuncCalls GuardedAlt where
  getFuncCalls vars (GuardedAlt _ stmts exp) = let stmtcalls = funcCallsFromStmts [] stmts
                                               in  solveLocalScope vars (getFuncCalls vars stmts ++ getFuncCalls vars exp) stmtcalls
  
instance FuncCalls FieldUpdate where
  getFuncCalls vars (FieldUpdate _ exp) = getFuncCalls vars exp
  getFuncCalls vars (FieldPun _)        = []
  getFuncCalls vars (FieldWildcard)     = []

instance FuncCalls QualStmt where
  getFuncCalls vars (QualStmt stmt)      = getFuncCalls vars stmt
  getFuncCalls vars (ThenTrans exp)      = getFuncCalls vars exp
  getFuncCalls vars (ThenBy e1 e2)       = getFuncCalls vars [e1, e2]
  getFuncCalls vars (GroupBy exp)        = getFuncCalls vars exp
  getFuncCalls vars (GroupUsing exp)     = getFuncCalls vars exp
  getFuncCalls vars (GroupByUsing e1 e2) = getFuncCalls vars [e1, e2]
  
instance FuncCalls QOp where
  getFuncCalls vars (QVarOp qname) = addQName vars qname
  getFuncCalls _    (QConOp _)     = []
    
instance FuncCalls GuardedRhs where
  getFuncCalls vars (GuardedRhs _ stmts exp) = let stmtcalls = funcCallsFromStmts [] stmts 
                                               in  solveLocalScope vars (getFuncCalls vars stmts ++ getFuncCalls vars exp) stmtcalls

instance FuncCalls Stmt where
  getFuncCalls vars (Generator _ pat exp) = []
  getFuncCalls vars (Qualifier exp)       = getFuncCalls vars exp 
  getFuncCalls vars (LetStmt binds)       = []
  getFuncCalls vars (RecStmt stmts)       = getFuncCalls vars stmts  
  
----------------------------------------------------------------------------
-- Helperfunction for the type class instances
----------------------------------------------------------------------------  
addQName :: LocalVars -> QName -> [QName]
addQName vars u@(UnQual name) = if (nameOf name) `elem` vars then [] else [u]
addQName _    qname           = [qname]  