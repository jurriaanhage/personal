module Callgraph.CallgraphTypes where

import Language.Haskell.Exts

import Data.Map (Map)

type WorkList = [FuncName]
type FuncName = String

type FuncList = [Func]
type Func = (Entity,[QName])

-- Callgraph type
type CallGraph = [(From, [To])]
type From = Entity 
type To   = Entity

-- Entity is a full qualified name to the correct module
data Entity = Ent { modu :: ModName
                  , name :: EntityName
                  }
                  deriving (Eq, Ord)
                  
instance Show Entity where
  show (Ent mod name) = mod ++ "." ++ name
  
type ModName = String
type EntityName = String                  

-- QEntity is the representation of the QName (so how it is in the module)
-- This is used to also represent Names with Nothing as qualification. 
type QEntity = (EntQual, EntityName)
type EntQual = Maybe String

-- An environment is a mapping from a QEntity to the actual entities
type Environment = Map QEntity Entity

-- Typeclasses for the name's and qname's
class Named a where
  nameOf :: a -> String
  
instance Named ModuleName where
  nameOf (ModuleName mname) = mname

instance Named Name where
  nameOf (Ident i)  = i
  nameOf (Symbol s) = s  

class QNamed a where
  qName :: a -> Maybe QEntity
  
instance QNamed QName where
  qName (Qual mod name) = Just (Just $ nameOf mod, nameOf name)
  qName (UnQual name)   = Just (Nothing, nameOf name)
  qName (Special _)     = Nothing