module Main.HolmesArgs where

import System.Console.GetOpt (OptDescr(Option), ArgDescr(NoArg), getOpt, ArgOrder (Permute), usageInfo)
import Control.Monad (when)

data Flag = Help
          | DeChain 
          | Png
          | Callgraph 
          | FingerPrinting
          | Tokens 
          | Single
          | RemoveTemps
          | Clean
   deriving (Show, Eq)

options :: [OptDescr Flag]
options = [ Option ['h'] ["help"]            (NoArg Help)           "display options that may be passed"
          , Option ['d'] ["dechain"]         (NoArg DeChain)        "get rid of chains in callgraph (remove functions with indegree 1 and outdegree 1)"          
          , Option ['c'] ["callgraph"]       (NoArg Callgraph)      "DON'T create a callgraph with its characteristics" 
          , Option ['p'] ["png"]             (NoArg Png)            "create a png-file for the callgraph"
          , Option ['f'] ["fingerprinting"]  (NoArg FingerPrinting) "DON'T perform document fingerprinting with k=25 w=5"
          , Option ['t'] ["tokens"]          (NoArg Tokens)         "DON'T perform tokenizing (sorted and unsorted)" 
          , Option ['s'] ["single"]          (NoArg Single)         "if the directory name you pass indicates a single assignment"
          , Option ['r'] ["removetemplates"] (NoArg RemoveTemps)    "Remove templates from the callgraph"
          , Option []    ["clean"]           (NoArg Clean)          "Remove all Holmes generated material"]

userInfo = usageInfo header options 
  where header = "Usage: holmes-prepare [options] dir"
  
processHolmesArgs :: [String] -> IO ([Flag], [String])
processHolmesArgs argv =
   case getOpt Permute options argv of      
      (o,n,[]  ) -> do
        when ((Help `elem` o) || (null n)) (putStrLn userInfo)
        return (o,n)        
      (_,_,errs) -> ioError (userError (concat errs ++ userInfo))

