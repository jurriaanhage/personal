module Templatehandler.TemplateHandling where

import Templateparser.TemplateParser(SCPToken(HPrag))
import Utils.HUtils(TemplateFunctions, split)
import Utils.ParserUtils (findFunctionFromLine, getFunctionNames, checkName)

import Language.Haskell.Exts (Module)
import Data.List (union, isInfixOf, (\\), nub, delete)

-- Process the templates, to create a list of template functions
handleTemplates :: [SCPToken] -> Module -> TemplateFunctions
handleTemplates tokens mod = union lstTempFuncs slTempFuncs
    where
       templateLines = giveTemplateLines tokens
       slTempFuncs = checkLines templateLines mod
       lstFuncs = templateSets tokens
       lstTempFuncs = checkSet lstFuncs mod

-- Handling line templates       
giveTemplateLines :: [SCPToken] -> [Int]
giveTemplateLines []                 = []
giveTemplateLines ((HPrag kw ln):xs) = if "TEMPLATE " `isInfixOf` kw then ln : giveTemplateLines xs else giveTemplateLines xs
giveTemplateLines (x:xs)             = giveTemplateLines xs      

-- Find out which functions belong to which line templates
checkLines :: [Int] -> Module -> TemplateFunctions
checkLines lines mod = map (findFunctionFromLine mod) lines

-- Handling templates with sets of functions
templateSets :: [SCPToken] -> [String]
templateSets []                 = []
templateSets ((HPrag kw ln):xs) = if "TEMPLATESET" `isInfixOf` kw then (getFuncs functions) ++ (templateSets xs) else templateSets xs
	where
		functions = kw \\ "TEMPLATESET" --strip the TEMPLATESET keyword
templateSets (_:xs)             = templateSets xs

-- Get the functions from a templateset
getFuncs :: String -> [String]
getFuncs funcs = delete "" $ nub $ split purefuncs '#'
	where
		purefuncs =  [x | x<-funcs,  not $ elem x removeChars] --remove whitespaces
		removeChars = [' ','\t'] 

-- Check if there is a wildcard and lookup if the functions are present
checkSet :: [String] -> Module -> TemplateFunctions
checkSet funcs mod = let names = getFunctionNames mod
                     in  if elem "*" funcs then names 
                                           else [x | x <- names, y <- funcs, checkName y x]