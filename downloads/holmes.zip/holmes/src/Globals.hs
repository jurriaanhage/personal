module Globals where

holmesDataDir   = "holmesdata"
tokensDir       = "tokens"
fingerprintsDir = "fingerprints"
