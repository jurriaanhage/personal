module Removal.RemoveGarbage where

import Callgraph.CallgraphTypes (CallGraph, Entity(Ent, modu, name), nameOf)

import Utils.HUtils (ModulePackage (MPackage))
import Utils.ParserUtils (updateModule)

import Data.List ((\\))

-- Removing garbage from a modulepackage using a list of template functions which have to be removed
-- and the callgraph do determine the rest of the garbage
removeGarbage :: [ModulePackage] -> CallGraph -> [ModulePackage]
removeGarbage [] cg                                  =  []
removeGarbage ((MPackage fn mname mod temps):mps) cg = let funcsFromCg = getFuncsFromCallgraph mname cg
                                                           mp = (MPackage fn mname (updateModule temps funcsFromCg mod) temps)
                                                       in  (mp : removeGarbage mps cg)

-- Collect all the functions from a callgraph for a certain module
getFuncsFromCallgraph :: String -> CallGraph -> [String]
getFuncsFromCallgraph mname cg = map (name.fst) $ filter (\(from,_) -> modu from == mname) cg

-- Remove template functions from the callgraph
cleanCallgraph :: CallGraph -> [ModulePackage] -> CallGraph
cleanCallgraph cg mpkgs = [(from, (toList \\ temps)) |(from, toList)<- cg, not(elem from temps)]
               where
                    temps = concatMap getTemp mpkgs
                    getTemp (MPackage _ mn _ temp) = map (\x -> (Ent mn x)) (map nameOf temp)