module Parser.Parser where
 
import Templatehandler.TemplateHandling (handleTemplates) 
import Templateparser.TemplateParser (parseFromFile) 
import Utils.HUtils (ModulePackage(MPackage), moduleToFileName)
import Utils.ParserUtils (getImportNames, getModName)
import Callgraph.CallgraphTypes(Named(nameOf))

import System.FilePath (dropExtension)
import Language.Haskell.Exts (ParseResult(ParseFailed, ParseOk), parseFileWithMode, SrcLoc(SrcLoc))
import Language.Haskell.Exts.Parser (ParseMode (..), defaultParseMode)
import Language.Haskell.Exts.Extension (Extension (..), haskell2010, glasgowExts)

import Data.List (find)

holmesMode :: ParseMode
holmesMode = defaultParseMode { extensions = haskell2010 ++ glasgowExts, fixities = Nothing }

-- Parse a program
parseProgram :: FilePath -> [String] -> [String] -> IO (ParseResult [ModulePackage])
parseProgram basedir allmods mods = do 
  xs <- parseModules basedir allmods [] mods
  return $ sequence $ fst xs

-- Parses modules and possible imported modules. Uses a list with modules which are done, 
-- so you can avoid looping of imports and don't do double work.
-- Parameters:
-- Base directory
-- All modules that are available
-- The modules that are allready parsed (in modulenames)
-- The modules that need to be parsed
-- Return: Resulting modules, parsed modules in this call
parseModules :: FilePath -> [String] -> [String] -> [String] -> IO ([ParseResult ModulePackage], [String])
parseModules basedir allmods donemods []       = return ([], [])
parseModules basedir allmods donemods (m:mods) = do
  let filename = moduleToFileName m 
  res <- parseFileWithMode holmesMode (basedir ++ "/" ++ m)
  temps <- parseFromFile $ basedir ++ "/" ++ m
  (x1,x2) <- case res of 
                ParseOk a       -> do let imps = getImportNames a
                                          filteredimps = filter (\x -> x `notElem` donemods) imps 
                                          localimps = filter (\x -> x `elem` allmods) (map moduleToFileName filteredimps)
                                      -- parse the imported modules which are available
                                      (localmods,donemods') <- parseModules basedir allmods (m:donemods) localimps
                                      let diffname = find differentModNameParseResult localmods 
                                      case diffname of 
                                        Just a  -> return ([makeParseFailed a], [])
                                        Nothing -> case sequence localmods of
                                                     (ParseOk mo)      -> return (((ParseOk $ MPackage m (nameOf $ getModName a) a (handleTemplates temps a)) : localmods), m : donemods')
                                                     (ParseFailed b c) -> return ([ParseFailed b c], [])
                ParseFailed a b -> return $ ([ParseFailed a b], [])
  (y1,y2) <- parseModules basedir allmods x2 mods
  return $ (x1 ++ y1, x2 ++ y2)
  
-- Helperfunction to create a ParseResult with the ParseFailed constructor
makeParseFailed :: ParseResult ModulePackage -> ParseResult ModulePackage
makeParseFailed (ParseFailed b c)              = ParseFailed b c
makeParseFailed (ParseOk (MPackage fn mn _ _)) = ParseFailed (SrcLoc fn 1 7) ("Error: Filename does not match module name: \nSaw: `" ++ mn ++ "'\nExpected: `" ++ (dropExtension fn) ++ "'")

-- Check if the modulename inside the file and the filename are the same
differentModNameParseResult :: ParseResult ModulePackage -> Bool
differentModNameParseResult (ParseFailed b c)              = False
differentModNameParseResult (ParseOk (MPackage fn mn _ _)) | fn == (moduleToFileName mn) = False
                                                           | otherwise                   = True
                                                           