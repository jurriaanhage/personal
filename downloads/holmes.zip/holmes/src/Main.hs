{-# LANGUAGE DoAndIfThenElse #-}
module Main where

import Prelude hiding (catch)
import Control.Exception
import System.IO.Error hiding (catch)
import System.Environment (getArgs)
import System.Time(getClockTime)
import System.Directory(doesFileExist, doesDirectoryExist, getDirectoryContents, removeDirectoryRecursive)
import System.FilePath (dropFileName, takeExtension, takeBaseName, dropExtension, replaceBaseName, replaceExtension)
import Language.Haskell.Exts (ParseResult(ParseFailed, ParseOk), prettyPrint)
import Language.Haskell.Exts.SrcLoc (SrcLoc(..))
import Main.HolmesArgs (processHolmesArgs, Flag(RemoveTemps,Clean))
import Utils.HUtils (split, replace, getModule, getModuleName, getFileName, ModulePackage, moduleToFileName)
import Utils.ParserUtils (getFunctions, getMName)
import Parser.Parser(parseProgram)
import Heuristics.HeuristicsCollector (collect)
import Removal.RemoveGarbage (removeGarbage, cleanCallgraph)
import Callgraph.MakeCallGraph (calcCallGraph)

import Control.Monad (filterM, sequence_, when, unless)
import Data.List (sort, nub, (\\), intersperse, partition)

import Globals

main :: IO ()
main = do
    args <- getArgs
    ghci args
    
runloop :: IO()
runloop = ghci ["../Loop/2009/","-P"]    
    
runtest :: IO()
runtest = ghci ["../Example/2009/","-P"]    
                   
runAll :: IO()
runAll = do ghci ["../test/FQL/incarnation1/"]
            ghci ["../test/FQL/incarnation2/"]
            ghci ["../test/FQL/incarnation3/"]
            ghci ["../test/FQL/incarnation4/"]
            ghci ["../test/FQL/incarnation5/"]
            ghci ["../test/FQL/incarnation6/"]
            ghci ["../test/FQL/merges/"]
                    
-- For running it in the interpreter  
ghci :: [String] -> IO()
ghci ss = do
    (options, dirs) <- processHolmesArgs ss
    let numberOfNames = length dirs
        dir = checkDirs dirs
    existDir <- doesDirectoryExist dir
    if (Clean `elem` options) then 
      cleanAll dir 
    else do
      (programs, config) <- getPrograms dir
      processPrograms programs config options
      return ()

-- Process a list of programs    
processPrograms :: [FilePath] -> [String] -> [Flag] -> IO()
processPrograms [] _ _ = return ()
processPrograms (p:prgs) cfg options = do
         done <- alreadyDone p -- Don't do it, if all generated directories are there
         if done then
           putStrLn ("Skipping " ++ p)
         else do 
           putStrLn ("Working on " ++ p ++ "....")
           processProgram p cfg options
         processPrograms prgs cfg options

-- Process a single program         
processProgram :: FilePath -> [String] -> [Flag] -> IO()	
processProgram basedir incStartPoints options = do 
  locStartPoints <- checkStartPoints basedir
  let startPoints = if (locStartPoints == []) then incStartPoints else locStartPoints
  if startPoints == []
   then error "Error: holmes-conf does not provide starting points"
   else do
     allModules <- getAllModules basedir "/"
     putStrLn (unlines (map (flip replaceExtension ".*" . replace '/' '.') allModules))
     let starStartPoints = filter (\x -> dropExtension x == "*") startPoints
         nonStarStartPoints = startPoints \\ starStartPoints
         newStartPoints = if (elem "*.*" starStartPoints) then map (flip replaceExtension ".*" . replace '/' '.') allModules
                                                          else nub ((replaceModules allModules starStartPoints) ++
                                                                    (filter (\x -> takeBaseName x /= "*") startPoints))              
     let (validStartpoints,unvalidStartpoints) = partition validateStartingpoint newStartPoints      
     when (unvalidStartpoints /= []) (sequence_ $ map (\x -> putStrLn $ "Warning: start point \"" ++ x ++ "\" is skipped since it is not correct.") unvalidStartpoints)         
     (existSPs,notexistSPs) <- liftedPartition (doesFileExist . ((++) (basedir ++ "/")). startpointToFilename) validStartpoints
     let parseFiles = nub $ map startpointToFilename validStartpoints
     if existSPs == [] 
       then putStrLn "Warning: no starting points, so submission is skipped"
         else do 
          when (notexistSPs /= []) (sequence_ $ map (\x -> putStrLn $ "Warning: start point \"" ++ x ++"\" is given, but the corresponding file does not exist!") notexistSPs)
          res <- parseProgram basedir allModules parseFiles
          case res of
            ParseFailed srcloc err -> putStrLn $ "Error: parsing " ++ srcFilename srcloc ++ " (" ++ prettyPrint srcloc ++ "): " ++ err
            ParseOk asts           -> do
               -- Check if the start points are present in the modules
               let asts' = nub asts
                   (goodSPs, badSPs) = findStartPoints existSPs asts'
               when (badSPs /= []) (sequence_ $ map (\x -> putStrLn $ "Warning: start point \"" ++ x ++"\" is given, but not present in the corresponding file!") badSPs)
               if goodSPs == []
                 then putStrLn "Warning: no valid starting points, so submission is skipped"
                   else do -- create callgraph and remove garbage from modules using callgraphs and templates
                           let callgraph = calcCallGraph asts' goodSPs undefined
                               newasts = removeGarbage asts' callgraph
                               -- give new ast and callgraph to the collect function
                               newcallgraph = if RemoveTemps `elem` options 
                                                 then cleanCallgraph callgraph asts'
                                                 else callgraph  
                           collect basedir newasts newcallgraph options

-- Add a slash at the end when it is not present                             
addSlash :: FilePath -> FilePath		
addSlash dir = if last dir /= '/' then dir ++ "/" else dir               
               
-- Check if the starting point is an actual function or not. First list is for the found startpoints, 
-- the second list contains startpoint which are not found
findStartPoints :: [String] -> [ModulePackage] -> ([String],[String])
findStartPoints sps mps = let mods = map getModule mps
                              newsps = map (convertModName mps) sps
                              funcs = concatMap (\x-> map (\y -> getMName x ++ "." ++ y) (getFunctions x)) mods  
                          in  partition (\x -> x `elem` funcs || takeExtension x == ".*") newsps

-- Change the module name for a starting point when filename and modulename don't match                          
convertModName :: [ModulePackage] -> String -> String
convertModName []       sp = sp   
convertModName (mp:mps) sp = if getFileName mp == (moduleToFileName $ dropExtension sp)
                             then if (moduleToFileName $ getModuleName mp) /= getFileName mp 
                                  then getModuleName mp ++ takeExtension sp 
                                  else sp
                             else convertModName mps sp
                                       
--get submission and incarnation startpoint
getPrograms :: FilePath -> IO ([FilePath], [String])
getPrograms basedir = do
			baseExist <- doesDirectoryExist basedir
			case baseExist of
				False -> error "Error: directory does not exist!"
				True ->	do
					contents <- getDirectoryContents basedir
					let fContents = filter (\x -> (head x) /= '.') contents					
					subdirs <- filterM doesDirectoryExist (map (basedir ++) fContents)
					startPoints <- checkStartPoints basedir
					return ((sort subdirs), startPoints)

--check if directory contains config file and return the content
checkStartPoints :: String -> IO [String]
checkStartPoints basedir = do
           configExist <- doesFileExist (basedir ++ "holmes-conf")
           if configExist
              then do 
                  config <- readFile (basedir ++ "holmes-conf")
                  let startPoints = words config
                  return startPoints
              else return []

-- check if it's a list with one element and adds a slash when needed              
checkDirs :: [String] -> String
checkDirs dirs
          | length dirs == 1 = addSlash $ head dirs
          | otherwise = error "Error: provide one, and only one, directory name"

-- New version to work with haskell files in subdirectories
getAllModules :: FilePath -> String -> IO [FilePath]               
getAllModules basedir subdirs = do
              content <- getDirectoryContents (basedir ++ subdirs)
              let fContent = filter (\x -> (head x) /= '.') content
                  modules = filter (\x -> takeExtension x == ".hs") content
              newsubdirs <- filterM doesDirectoryExist (map ((basedir ++ subdirs) ++) fContent)
              let newsubdirs' = map (\x -> x \\ (basedir ++ subdirs)) newsubdirs
              submodules <- mapM (getAllModules basedir) (map (\x -> subdirs ++ x ++ "/") newsubdirs')
              return $ (map tail (map (subdirs ++) modules)) ++ (concat submodules)            

-- Replace the star in a startpoint with all the modules, so multiple startpoints are created for the star.              
replaceModules :: [FilePath] -> [String] -> [String]
replaceModules allModules starStartpoints = [replace '/' '.' $ replaceBaseName star (dropExtension mod) | mod <- allModules , star <- starStartpoints]         

-- Partially lift partition into monad for doesFileExist                           
liftedPartition :: Monad m => (a -> m Bool) -> [a] -> m ([a],[a])
liftedPartition f []     = return ([],[])
liftedPartition f (x:xs) = do (tr,fa) <- liftedPartition f xs
                              bool <- f x
                              if bool
                                then return (x : tr, fa)
                                else return (tr, x:fa)

-- Validate a startingpoints. It should contain at least one dot.
validateStartingpoint :: String -> Bool
validateStartingpoint s = let parts = split s '.' 
                          in if length parts < 2 then False 
                                                 else True

-- Length of splitted string must be greater than 1 (validated by previous function)
startpointToFilename :: String -> String
startpointToFilename s = let parts = split s '.'
                             fp = init parts
                         in  (concat $ intersperse "/" fp) ++ ".hs"

--get submission and incarnation startpoint
getSubmissions :: FilePath -> IO [FilePath]
getSubmissions basedir = 
  do
    baseExist <- doesDirectoryExist basedir
    case baseExist of
      False -> error "Error: directory does not exist!"
      True -> do
		contents <- getDirectoryContents basedir
		let fContents = filter (\x -> (head x) /= '.') contents					
		subdirs <- filterM doesDirectoryExist (map (basedir ++) fContents)
		return subdirs
      
-- Clean all subdirectories of Holmes generated subdirectories
cleanAll :: String -> IO ()
cleanAll dir = 
  do 
    putStrLn ("Cleaning assignments in `" ++ dir ++ "' ...")
    programs <- getSubmissions dir
    mapM cleanAssignment programs
    return ()

-- Stolen from the web: delete first and recover if failed.
cleanIfExists :: FilePath -> IO ()
cleanIfExists fileName = removeDirectoryRecursive fileName `catch` handleExists
  where handleExists e
          | isDoesNotExistError e = return ()
          | otherwise = throwIO e
          
cleanAssignment :: FilePath -> IO ()
cleanAssignment fp = 
  do
    cleanIfExists (fp ++ "/" ++ tokensDir)
    cleanIfExists (fp ++ "/" ++ holmesDataDir)    
    cleanIfExists (fp ++ "/" ++ fingerprintsDir)
    return ()


-- We take the presence of all three created dirs to signal that this submission has been handled 		
alreadyDone = allThreeExist

allThreeExist :: FilePath -> IO Bool
allThreeExist fp = 
  do
    tok <- doesDirectoryExist (fp ++ "/" ++ tokensDir)
    hd  <- doesDirectoryExist (fp ++ "/" ++ holmesDataDir)
    fp  <- doesDirectoryExist (fp ++ "/" ++ fingerprintsDir)
    return (tok && hd && fp) 
