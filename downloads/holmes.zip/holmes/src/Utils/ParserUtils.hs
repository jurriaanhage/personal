module Utils.ParserUtils where

import Language.Haskell.Exts

import Callgraph.CallgraphTypes (Named(nameOf))

-- Returns the modules in an export specification
getModuleExports :: [ExportSpec] -> [ModuleName]
getModuleExports []                           = []
getModuleExports ((EModuleContents mod):exps) = mod : getModuleExports exps
getModuleExports (_:exps)                     = getModuleExports exps

-- Return the variables in the import specification
getImpSpecVars :: [ImportSpec] -> [String]
getImpSpecVars []              = []
getImpSpecVars ((IVar n):imps) = nameOf n : getImpSpecVars imps
getImpSpecVars (_:imps)        = getImpSpecVars imps

-- Lookup a module in a list of modules with the modulename
lookupModule :: ModuleName -> [Module] -> Maybe Module
lookupModule _       []       = Nothing
lookupModule modname (m:mods) | getModName m == modname = Just m
                              | otherwise               = lookupModule modname mods 
                             
-- Helperfunction to get the modulename from a module
getModName :: Module -> ModuleName
getModName (Module _ mname _ _ _ _ _) = mname

getMName :: Module -> String
getMName (Module _ (ModuleName s) _ _ _ _ _) = s

-- Helperfunction to get the declarations from a module 
getDecls :: Module -> [Decl]
getDecls (Module _ _ _ _ _ _ decls) = decls

-- Helperfunction to get the imports from a module
getImports :: Module -> [ImportDecl]
getImports (Module _ _ _ _ _ imports _) = imports

-- Helperfunction to get the exports from a module
getExports :: Module -> Maybe [ExportSpec]
getExports (Module _ _ _ _ exports _ _) = exports 

-- Helperfunction to get the names of the imports from a module
getImportNames :: Module -> [String]
getImportNames (Module _ _ _ _ _ imports _) = map getImportName imports

-- Helperfunction to get the name of import from an import declaration
getImportName :: ImportDecl -> String
getImportName x = case importModule x of
                    ModuleName y -> y

-- Returns all the names of the variables from an export specification                    
getVarExportName :: [ExportSpec] -> [QName]
getVarExportName []             = []
getVarExportName ((EVar qn):es) = qn : getVarExportName es
getVarExportName (_:es)         = getVarExportName es

-- Updates a module so it removes the list of names and removes what is not in the list of strings.
updateModule :: [Name] -> [String] -> Module -> Module
updateModule remove keep (Module a b c d e f decls) = Module a b c d e f $ updateDecls remove keep decls

-- Updates a list of declaration just like updateModule                               
updateDecls :: [Name] -> [String] -> [Decl] -> [Decl]
updateDecls remove keep decls = filter (updateDeclFilter remove keep) decls    
                                
-- The filtering function which is used in updateDecls
updateDeclFilter :: [Name] -> [String] -> Decl -> Bool
updateDeclFilter remove keep decl = if not $ isFunOrPat decl 
                              then True
                              else let funNames = getDeclName decl
                                   in if remove /= [] && (and $ map (\x -> x `elem` funNames) (map nameOf remove))
                                      then False
                                      else if or $ map (\x -> x `elem` funNames) keep
                                           then True
                                           else False

-- A simple function which determines if a declaration is function or patternbinding
isFunOrPat :: Decl -> Bool
isFunOrPat FunBind{} = True
isFunOrPat PatBind{} = True
isFunOrPat _         = False

-- Returns the name of a function or patternbinding and an empty string otherwise
getDeclName :: Decl -> [String]
getDeclName (FunBind ((Match _ name _ _ _ _):xs)) = [nameOf name]
getDeclName (PatBind _ pat _ _ _)                 = map nameOf $ getNames pat
getDeclName _                                     = []

-- Return all names from a pattern
getNames :: Pat -> [Name]
getNames (PVar name)          = [name]
getNames (PLit _)             = []
getNames (PNeg pat)           = getNames pat
getNames (PNPlusK name _)     = [name]
getNames (PInfixApp p1 _ p2)  = getNames p1 ++ getNames p2
getNames (PApp _ pats)        = concatMap getNames pats
getNames (PTuple pats)        = concatMap getNames pats
getNames (PList pats)         = concatMap getNames pats
getNames (PParen pat)         = getNames pat
getNames (PRec _ patfields)   = concatMap getNamesField patfields
getNames (PAsPat name pat)    = name : getNames pat
getNames (PIrrPat pat)        = getNames pat
getNames (PatTypeSig _ pat _) = getNames pat
getNames (PViewPat _ pat)     = getNames pat
getNames (PBangPat pat)       = getNames pat
getNames (PRPat _)            = []
getNames _                    = []

-- Return all names from a patternfield
getNamesField :: PatField -> [Name]
getNamesField (PFieldPat _ pat) = getNames pat
getNamesField (PFieldPun name)  = [name]
getNamesField _                 = []

-- Equality for strings against names
checkName :: String -> Name -> Bool
checkName func (Ident s)  = func == s
checkName func (Symbol s) = func == s 

-- Finding functions from a line number in a module
findFunctionFromLine :: Module -> Int -> Name
findFunctionFromLine (Module _ _ _ _ _ _ decls) n = findFunc n decls

-- Finding functions from a line number in a list of declarations
findFunc :: Int -> [Decl] -> Name
findFunc n []                                               = error "Function could not be found"
findFunc n ((FunBind ((Match srcloc name _ _ _ _):_)) : xs) | n + 1 == srcLine srcloc = name
                                                            | otherwise               = findFunc n xs 
findFunc n ((PatBind srcloc (PVar name) _ _ _): xs)         | n + 1 == srcLine srcloc = name
                                                            | otherwise               = findFunc n xs
findFunc n (_:xs)                                           = findFunc n xs

-- Collection function from a module in strings
getFunctions :: Module -> [String]
getFunctions mod = map prettyPrint $ getFunctionNames mod

-- Collecting all the function names from a module
getFunctionNames :: Module -> [Name]
getFunctionNames (Module _ _ _ _ _ _ decls) = getFuncs decls

-- Collecting all te function names from a list of delcarations
getFuncs :: [Decl] -> [Name]
getFuncs []                                          = []
getFuncs ((FunBind ((Match _ name _ _ _ _):_)) : xs) = name : getFuncs xs
getFuncs ((PatBind _ pat _ _ _) : xs)                = getNames pat ++ getFuncs xs
getFuncs (_:xs)                                      = getFuncs xs