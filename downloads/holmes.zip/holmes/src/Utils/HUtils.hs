module Utils.HUtils where

import System.Directory(doesFileExist, doesDirectoryExist, createDirectory)
import Language.Haskell.Exts(Module, Name)

import Callgraph.CallgraphTypes (Environment)

data ModulePackage = MPackage FileName ModuleName Module TemplateFunctions deriving (Eq,Show)
data TokenPackage = TPackage FileName Tokens deriving Show
data EnvPackage = EPackage FileName ModuleName Environment deriving Show

type ModuleName = String
type FileName = String
type TemplateFunctions = [Name]
type Program = [ModulePackage]
type Tokens = [String]


moduleToFileName :: String -> String
moduleToFileName s = (replace '.' '/' s) ++ ".hs"

replace :: Eq a => a -> a -> [a] -> [a]
replace x y = map (\z -> if z == x then y else z)

getFileName :: ModulePackage -> String
getFileName (MPackage fn _ _ _) = fn

getModuleName :: ModulePackage -> String
getModuleName (MPackage _ mn _ _) = mn

getModule :: ModulePackage -> Module
getModule (MPackage _ _ mod _) = mod

split :: String -> Char -> [String]
split []     sep = [""]
split (x:xs) sep | x == sep  = [] : rest
                 | otherwise = (x : head rest) : tail rest
   where
       rest = split xs sep

       
--writeLog :: FilePath -> String -> IO()
--writeLog basedir content = return ()
{- 
writeLog basedir content = do  
    let logFile = basedir ++ "/holmes.log"
    fileExist <- doesFileExist logFile
    case (fileExist) of
      True  -> appendFile logFile (content ++ "\n")
      False -> writeFile (basedir ++ "/holmes.log") (content ++ "\n")
-}

writeFileDir :: FilePath -> String -> String -> IO()
writeFileDir location filename content = do
             
             locationExist <- doesDirectoryExist location
             let fileName = location ++ filename
	   
	     case locationExist of
                  False -> do
				createDirectory location
				writeFile (fileName) content
		  True -> do
				writeFile (fileName) content