module Templateparser.TemplateParser where

import Utils.Utils (fst3, snd3, thd3)

data SCPToken = LitString String | Comment String | HPrag Keyword Linenum deriving Show
type Keyword = String
type Linenum = Int

-- Calling the lexer on the file
parseFromFile :: FilePath -> IO [SCPToken]
parseFromFile fp = do string <- readFile fp
                      return $ lexer string 1 

-- The actual lexer for the templates, comments and literal strings                     
lexer :: String -> Int -> [SCPToken]
lexer [] _ = []
lexer ('-':'-':slcs) linenum = Comment (fst3 slcomment) : lexer (snd3 slcomment) (thd3 slcomment)
      where
           slcomment = singleLineComment slcs "" linenum
lexer ('{':'-':'H':' ':hps) linenum = HPrag(fst3 hpragma) linenum : lexer (snd3 hpragma) (thd3 hpragma)
      where
           hpragma = hpragsP hps "" linenum
lexer ('{':'-':mlcs) linenum = Comment (fst3 mlcomment) : lexer (snd3 mlcomment) (thd3 mlcomment)
      where
           mlcomment = multiLineComment mlcs "" 0 linenum
lexer ('"':strs) linenum = LitString (fst3 string) : lexer (snd3 string) (thd3 string)
      where
           string = litString strs "" linenum
lexer ('\n':xs) linenum = lexer xs (linenum +1)
lexer (x:xs) linenum = lexer xs linenum

hpragsP :: String -> String -> Int-> (String,String,Int)
hpragsP ('H':'-':'}':xs) hprags linenum = (hprags,xs,linenum)
hpragsP ('\n':xs)        hprags linenum = hpragsP xs hprags (linenum +1)
hpragsP (x:xs)           hprags linenum = hpragsP xs (hprags ++ [x]) linenum
hpragsP []               hprags linenum = (hprags, [], linenum)

singleLineComment :: String -> String -> Int -> (String, String, Int)
singleLineComment [] coms linenum = (coms, [], linenum)
singleLineComment ('\n':xs) coms linenum = (coms, xs, (linenum + 1))
singleLineComment (x:xs) coms linenum = singleLineComment xs (coms ++ [x]) linenum

multiLineComment :: String -> String -> Int -> Int-> (String, String, Int)
multiLineComment ('-':'}': xs) coms level linenum
                           | level == 0 = (coms, xs, linenum)
                           | otherwise = multiLineComment xs  (coms ++ "-}") (level - 1) linenum
multiLineComment ('{':'-': xs) coms level linenum = multiLineComment xs  (coms ++ "{-") (level + 1) linenum
multiLineComment ('\n':xs) coms level linenum = multiLineComment xs coms level (linenum + 1)
multiLineComment (x:xs) coms level linenum = multiLineComment xs (coms ++ [x]) level linenum
multiLineComment [] coms level linenum = (coms, [], linenum)

litString :: String -> String -> Int -> (String,String,Int)
litString ('"': xs) coms linenum = (coms, xs,linenum)
litString ('\n':xs) coms linenum = litString xs (coms ++ ['\n']) (linenum + 1) 
litString (x:xs) coms linenum = litString xs (coms ++ [x]) linenum
litString [] coms linenum = (coms, [],linenum)