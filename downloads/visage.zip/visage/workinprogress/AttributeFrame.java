package visage.visual;

import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;

import visage.bridge.*;
import visage.util.*;

/**
 * A Frame containing a checkbox display for selecting
 * the attribute that are supposed to be on and off.
 */
public class AttributeFrame extends JFrame {
  
  private GraphicView graphicView;
  private Container contentPane;
  
  /**
   *  Creates a new AttributeFrame.
   *
   *  In I expect a structure mapping attributes to booleans.
   *  A modified version of the Attr..Toggler.
   *
   */
  public AttributeFrame(  ) {
    this.contentPane = this.getContentPane();
    contentPane.setLayout( new GridLayout() );
    itemControl = new SelectedItemController(this,
		                    prodBridge.getAttrRelInfo( prodRuleId ) );
 //   createCodePanel( );
    createGraphicPane( attrToggler );
 //		itemControl.setCodePanel ( codeDetailPanel );
		itemControl.setGraphicView ( graphicView);
    this.setVisible( true );
  }

  /**
   *  Creates a GraphicView in a JScrollPane in the center of the frame.
   *
   *  @param  attrToggler The AttrOnOffToggler to be passed to the GraphicView.
   */
  private void createGraphicPane( AttrOnOffToggler attrToggler ) {
    graphicPane = new JScrollPane();
    graphicPane.setPreferredSize( this.getSize() );
    graphicView = new GraphicView( prodRuleId, prodBridge, itemControl, attrToggler, graphicPane );
    graphicPane.add( graphicView );
    graphicPane.setViewportView( graphicView );
    contentPane.add( graphicPane, BorderLayout.CENTER );
  }
  
  /**
   *  Creates a JPanel at the south of the frame which holds the code detail area and the attribute relation view.
   */
/*  private void createCodePanel() {
    this.codeDetailPanel = 
		   new CodePanel(itemControl,
			  (int) this.getSize().getWidth(), CODEDETAIL_HEIGHT);
    contentPane.add( codeDetailPanel, BorderLayout.SOUTH );
  }
	*/
}
