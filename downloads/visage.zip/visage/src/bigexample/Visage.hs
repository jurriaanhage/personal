
-- UUAGC 0.9.5 (Visage.ag)


import UU.Scanner.Position(Pos(..))
import CommonTypes
import ATermAbstractSyntax
import Expression
import VisagePatterns
import VisageSyntax


import CommonTypes
import UU.Pretty
import AbstractSyntax
import VisagePatterns
import Expression


import UU.Scanner.Position(Pos)
import CommonTypes


import UU.Scanner.Position(Pos)

convert :: String -> String
convert [] = []
convert (c:ct) | c == '\n' = '\\' : 'n' : convert ct
               | otherwise = c : convert ct
 
sQ :: String -> String
sQ []     = []
sQ (x:xs) = if (x=='"') then rest else x:rest
    where
      rest = if not (null xs) && last xs == '"' then init xs else xs

showAGPos :: Pos -> String
showAGPos (Pos l c f) | l == (-1) = ""
                      | otherwise = let file = if null f then "" else f -- No show of f
                                        lc = "(line " ++ show l ++ ", column " ++ show c ++")"
                                    in file ++ lc


-- Expression --------------------------------------------------
-- VisageAlternative -------------------------------------------
-- VisageAlternatives ------------------------------------------
-- VisageChild -------------------------------------------------
-- VisageChildren ----------------------------------------------
-- VisageGrammar -----------------------------------------------
-- VisagePattern -----------------------------------------------
-- VisagePatterns ----------------------------------------------
-- VisageProduction --------------------------------------------
-- VisageProductions -------------------------------------------
-- VisageRule --------------------------------------------------
-- VisageRules -------------------------------------------------