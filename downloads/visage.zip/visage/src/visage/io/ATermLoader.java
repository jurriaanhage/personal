package visage.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *  Class for loading ATerms.
 */
public class ATermLoader {
	private File file;
  
	/**
	 *  Creates an ATermLoader which loads from the specified location.
	 *
	 * @param  file  The file to load from.
	 */
	public ATermLoader(String file) {
		this.file = new File(file);
	}


	/**
	 *  Creates an ATermLoader which loads from the specified location.
	 *
	 * @param  file  The file to load from.
	 */
	public ATermLoader(File file) {
		this.file = file;
	}


	/**
	 *  Loads and returns a string representation of the full ATerm.
	 *
	 * @return                            A string containing the
	 *      information from the file.
	 * @exception  FileNotFoundException  Description of the Exception
	 * @exception  IOException            Description of the Exception
	 */
	public String load() throws FileNotFoundException, IOException {
		String         str   = "";
		String         line;
		BufferedReader input;

		input = new BufferedReader(new FileReader(file));
		line = input.readLine();

		while (line != null) {
			str += "\n"+line;
      line = input.readLine();
		}

    input.close();
    return str;
	}
}
