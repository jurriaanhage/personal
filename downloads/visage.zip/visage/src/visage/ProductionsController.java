package visage;

import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JInternalFrame;
import visage.model.*;
import visage.bridge.*;
import visage.visual.*;
import visage.parser.*;
import visage.util.*;

/**
 *  Class that causes a loaded file to be parsed, sets the ProductionsView and controls which frames with
 *  graphics for production-rules are currently opened.
 */
public class ProductionsController {

  private Production[] prods;
  private ProductionsBridge prodbridge;
  private ProductionLabel[] prodlabels;
  private ProductionsView prodview;
  private JDesktopPane graphicpane;
  private GraphicViewFrame[] graphicframes;
  private AttrOnOffToggler attrToggler;
  private JLabel statusLabel;
  
  /**
   *  Creates a new ProductionsController.
   *
   *  @param  prodview    The ProductionsView of the main frame.
   *  @param  graphicpane The JDesktopPane of the main frame.
   *  @param  statusLabel The statusLabel of the main frame.
   */
  public ProductionsController( ProductionsView prodview, JDesktopPane graphicpane, JLabel statusLabel ) {
    this.prodview = prodview;
    this.graphicpane = graphicpane;
    this.statusLabel = statusLabel;
  }
  
  /**
   *  Initializes this ProductionsController. Tries to parse the given aterm and set the 
   *  ProductionsView by creating labels for all production-rules.
   *
   *  @param      aterm           The loaded aterm.
   *  @exception  ParseException  Sets statuslabel text.
   */
  public void initController( String aterm ) {
    try {
      UUAGATermParser parser = new UUAGATermParser( aterm );
      parser.parse();
      prods = parser.getProductions();
      prodbridge = new ProductionsBridge( prods );      
      prodlabels = createProdLabels();
      graphicframes = new GraphicViewFrame[prodlabels.length];
      attrToggler = new AttrOnOffToggler();
      closeAllFrames();
      prodview.setView( prodlabels, "Select a production:" );
    }
    catch( ParseException pe ) {
      Debug.output( "ParseException: " + pe, Debug.PARSER );
      statusLabel.setText( "Error: file is invalid or empty" );
    }
  }
  
  /**
   *  Method to create all ProductionLabels for the given Production array. 
   *  So it extracts the production rules from the Productions and creates labels for them.
   *
   *  @return        Array containing all created ProductionLabels.
   */
  private ProductionLabel[] createProdLabels() {
    String nt;
    String[] childTypes;
    ProductionLabel[] prodlabels = new ProductionLabel[prodbridge.getNumProdRules()];;
    
    for( int i=0; i<prodbridge.getNumProdRules(); i++ ) {
      nt = prodbridge.getNt( i );
      childTypes = prodbridge.getChildTypes( i );
      prodlabels[i] = new ProductionLabel( i, prodbridge.getCon( i ), nt, childTypes, this );
    }
    
    return prodlabels;
  }
  
  /**
   *  This method shows the details of a production rule in GraphicViewFrames on the JDesktopPane. 
   *  If there's no GraphicView(Frame) for this rule yet it creates one. If there already is a 
   *  frame for this rule, it just sets the pane to show this frame. 
   *
   *  @param      prodRuleId              The id of the production-rule we want to show.
   *  @param      prodRuleText            A String representing the production rule.
   *  @exception  PropertyVetoException   Does nothing.
   */
  public void showDetails( int prodRuleId, String prodRuleText ) {
    if( graphicframes[prodRuleId]==null ) {
      graphicframes[prodRuleId] = new GraphicViewFrame( prodRuleId, prodRuleText, prodbridge, attrToggler );
      graphicframes[prodRuleId].setSize( graphicpane.getSize() );
      graphicpane.add( graphicframes[prodRuleId] );
    }
    try {
        if( graphicframes[prodRuleId].isClosed() ) { graphicpane.add( graphicframes[prodRuleId] ); }
        graphicframes[prodRuleId].setSelected( true );
        graphicframes[prodRuleId].setMaximum( true );
        graphicframes[prodRuleId].setVisible( true );
    } catch ( java.beans.PropertyVetoException e ) {}
    graphicframes[prodRuleId].validate();
  }
  
  /**
   *  Method that closes all frames in the graphicpane.
   */
  public void closeAllFrames() {
    JInternalFrame[] frames = (JInternalFrame[]) graphicpane.getAllFrames();
    for( int i=0; i<frames.length; i++ ) {
        frames[i].dispose();
    }
    graphicpane.validate();
  }
}
