package visage.bridge;

import java.util.Vector;
import java.util.Enumeration;

import visage.model.*;
import visage.Debug;

/**
 *  Class which extracts all info we're interested in from a given piece of code.
 *  So it searches for all the attributes that are contained in the code.
 */
public class CodeExtractor {
  
  private String code;
  private String[] attrNames, childNames;
  
  /**
   *  Creates a new CodeExtractor.
   *
   *  @param  code  The code we'll extract the attribute-info from.
   */
  public CodeExtractor( String code ) {
    this.code = code;
  }
  
  /**
   *  Starts extracting the info.
   *
   *  @param  children      The children belonging to the production-rule this code also belongs to.
   *  @param  locAttrNames  The names of the local attribues belonging to the same production-rule this code belongs to.
   */
  public void extract( Child[] children, Enumeration locAttrNames ) {
    Debug.output( "in extract of CodeExtractor", Debug.CODE_EXTRACTOR );
    extractAttrRelInfo( extractStartsWithAt(), children, locAttrNames );
  }
  
  /**
   *  Method extracting all the substrings that start with the @-sign and which end with one of the chars given in the splitChars array.
   *
   *  @return     A Vector containing all the found substrings.
   */
  private Vector extractStartsWithAt() {
    int beginPos = 0;
    Vector startsWithAt = new Vector();
    char[] splitChars = {' ', ',', ')', ']', '=', '!', '+', '*', '/', '-', '!', '>', '<', '\n', '\r', '\t'}; //these chars are the ones that let us know that the part of a string behind an @-sign ends (examples: (@lhs.pos,@lhs.name) or @int==1 ... )
    
    for( int i=0; i<code.length(); i++ ) {
      if( code.charAt( i ) == '@' ) { beginPos = i; }
      else {
        for( int j=0; j<splitChars.length; j++ ) {
          if( code.charAt( i ) == splitChars[j] && code.charAt( beginPos ) == '@' ) {
            Debug.output( "startswithat: " + code.substring( beginPos, i ), Debug.CODE_EXTRACTOR );
            if( !contains( startsWithAt.elements(), code.substring( beginPos, i ) ) ) {  
              startsWithAt.add( code.substring( beginPos, i ) );
            }
            beginPos = i;  
          }
        }
      } 
    }
    
    if( code.charAt( beginPos ) == '@' ) { //last piece of code is something that starts with the @-sign, so we're interested
      Debug.output( "startswithat: " + code.substring( beginPos, code.length() ), Debug.CODE_EXTRACTOR );
      if( !contains( startsWithAt.elements(), code.substring( beginPos, code.length() ) ) ) {  
        startsWithAt.add( code.substring( beginPos, code.length() ) );
      }
    }
    return startsWithAt;
  }
  
  /**
   *  Method which checks if a given String exists in the given Enumeration of Strings.
   *
   *  @param  e           An Enumeration of Strings.
   *  @param  newString   The String we're looking for.
   *  @return             A boolean value which indicates wether the String was found.
   */
  private boolean contains( Enumeration e, String newString ) {
    while( e.hasMoreElements() ) {
      if( newString.equals( (String) e.nextElement() ) ) { return true; }
    }
    return false;
  }
  
  /**
   *  Method which fills two arrays: the attrNames- and childNames arrays. 
   *  In the attrNames array are stored all the attributes found in the code.
   *  In the childNames array are stored all the childNames to which the corresponding (same index) attribute belongs.
   *  If the attribute belongs to a non-terminal the childName is "lhs".
   *  If the attribute is a local one the childName is "loc".
   *  If the value of a child itself was meant, then the attrName is "".
   *
   *  @param  startsWithAt  All the substrings that start with the @-sign (determined by extractStartsWithAt()).
   *  @param  children      The children belonging to the production-rule this code also belongs to.
   *  @param  locAttrNames  The names of the local attribues belonging to the same production-rule this code belongs to.  
   */
  private void extractAttrRelInfo( Vector startsWithAt, Child[] children, Enumeration locAttrNames ) {
    String temp;
    Vector childTemp = new Vector(); //these Vectors are necessary because we don't know yet if all of the Strings that starts with an @ are really things we need here
    Vector attrTemp = new Vector();
    boolean found;
    
    for( int i=0; i<startsWithAt.size(); i++ ) {
      found = false;
      temp = (String) startsWithAt.elementAt( i );
      for( int j=1; j<temp.length(); j++ ) {
        if( temp.charAt( j ) == '.' ) { //is of the form @child.name
          childTemp.add( temp.substring( 1, j ) );
          attrTemp.add( temp.substring( j+1, temp.length() ) );
          found = true;
          break;
        }
      }
      if( !found ) { //check if there's a child with that name, otherwise it might be a local attribute name
        String name = temp.substring( 1, temp.length() );
        for( int l=0; l<children.length; l++ ) {
          if( name.equals( children[l].getName() ) ) {
            childTemp.add( name );
            attrTemp.add( "" );
            found = true;
          }
        }
        if( !found ) { //there was no child with that name, it might be a local attribute otherwise it wasn't something we're interested in
          String[] locNames;
          
          while( locAttrNames.hasMoreElements() ) {
            locNames = (String[]) locAttrNames.nextElement();
            for( int l=0; l<locNames.length; l++ ) {
              if( name.equals( locNames[l] ) ) {
                attrTemp.add( name );
                childTemp.add( "loc" );
                found = true;
                break;
              }
            }
            if( found ) { break; }
          }
        }
      }
    }
    attrNames = new String[attrTemp.size()];
    childNames = new String[childTemp.size()];
    
    for( int m=0; m<attrTemp.size(); m++ ) {
      attrNames[m] = (String) attrTemp.elementAt( m );
      childNames[m] = (String) childTemp.elementAt( m );
    }
  }
  
  /**
   *  @return   A String array storing all the attributes found in the code.
   */
  public String[] getChildNames() {
    return childNames;
  }
  
  /**
   *  @return   A String array storing all the childNames to which the corresponding (same index) attribute belongs.
   */
  public String[] getAttrNames() {
    return attrNames;
  }
  
  /**
   *  @param  children  The children belonging to the production-rule this code also belongs to.
   *  @return           An array storing integer values for the childNames (-2 if the attribute is a local one, -1 if it's a non-terminal, an integer value between 0 and i for the corresponding children).
   */
  public int[] getChildNamesIntVal( Child[] children ) {
    int[] childNamesIntVal = new int[childNames.length];
    
    for( int i=0; i<childNames.length; i++ ) {
      if( childNames[i].equals( "lhs" ) )       { childNamesIntVal[i] = -1; } 
      else if( childNames[i].equals( "loc" ) )  { childNamesIntVal[i] = -2; } //denotes that attribute is a local one
      else {
        for( int j=0; j<children.length; j++ ) {
          if( childNames[i].equals( children[j].getName() ) ) { childNamesIntVal[i] = j; }
        }
      }
    }
    return childNamesIntVal;
  }
}
