package visage.bridge;

import java.util.Vector;

import visage.model.*;
import visage.Debug;

/**
 *  Class which forms a bridge between the model and the graphical representation.
 */
public class ProductionsBridge {
  
  private Production[] prods; //index is a production id
  private ProductionRuleInfo[] prodRuleInfo; //index is a production rule id
  
  /**
   *  Creates a new ProductionsBridge for a given model.
   *
   *  @param  prods   The collection of Productions which is the model.
   */
  public ProductionsBridge( Production[] prods ) {
    this.prods = prods;
    this.prodRuleInfo = createProdRuleInfo( prods );
  }
  
  /**
   *  Method used by the bridge to create a collection of production rule info objects
   *  for a given model. These objects are necessary to know which Production and which
   *  of its Alternatives to use for a given prodRuleId.
   *
   *  @param  prods   The collection of Productions which is the model.
   *  @return         A collection of ProductionRuleInfo objects.
   */
  private ProductionRuleInfo[] createProdRuleInfo( Production[] prods ) {
    ProductionRuleInfo[] prodRuleInfo;
    Alternative[] alts;
    Vector temp = new Vector();
    
    for( int i=0; i<prods.length; i++ ) {
      alts = prods[i].getAlts();
      for( int j=0; j<alts.length; j++ ) {
        temp.add( new ProductionRuleInfo( i, j ) );
      }
    }
    prodRuleInfo = new ProductionRuleInfo[temp.size()];
    for( int k=0; k<temp.size(); k++ ) {
      prodRuleInfo[k] = (ProductionRuleInfo) temp.elementAt( k );
      Debug.output( "added to ruleinfo: prodid: " + prodRuleInfo[k].getProdId() + " altid: " + prodRuleInfo[k].getAltId(), Debug.BRIDGE );
    }
    return prodRuleInfo;
  }
  
  /**
   *  @return   The number of production rules in the model.
   */
  public int getNumProdRules() {
    return prodRuleInfo.length;
  }
  
  /**
   *  @param    prodRuleId  The id of the production-rule we want info from.
   *  @return               The non-terminal name of a Production.
   */
  public String getNt( int prodRuleId ) {
    return prods[prodRuleInfo[prodRuleId].getProdId()].getNt();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               The name of the alternative of this production-rule.
   **/
  public String getCon( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    return alts[prodRuleInfo[prodRuleId].getAltId()].getCon();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               The collection of LocRules of this production-rule.
   **/
  public LocRule[] getLocRules( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    return alts[prodRuleInfo[prodRuleId].getAltId()].getLocrules();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               An array with all the composite names of the local attributes.
   **/
  public String[] getCompositeLocAttrNames( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    LocRule[] locrules = alts[prodRuleInfo[prodRuleId].getAltId()].getLocrules();
    String[] locAttrNames = new String[locrules.length];
    for( int i=0; i<locAttrNames.length; i++ ) {
      locAttrNames[i] = getCompositePatternName( locrules[i].getPattern() );
    }
    return locAttrNames;
  }
  
  /**
   *  Method used to recursively create composite names of a local attribute.
   *
   *  @param    pat   The Patteren we want the composite name of.
   *  @return         The composite name of a Pattern.      
   **/
  public String getCompositePatternName( Pattern pat ) {
    String name = "";
    if( pat instanceof PatternConstr ) {
      PatternConstr patConstr = (PatternConstr) pat;
      name += patConstr.getName();
      Pattern[] pats = patConstr.getPats();
      for( int i=0; i<pats.length; i++ ) {
        name += " " + getCompositePatternName( pats[i] );
      }
    }
    else if( pat instanceof PatternProduct ) {
      PatternProduct patProduct = (PatternProduct) pat;
      name += "(";
      Pattern[] pats = patProduct.getPats();
      for( int i=0; i<pats.length-1; i++ ) {
        name += getCompositePatternName( pats[i] ) + ",";
      }
      name += getCompositePatternName( pats[pats.length-1] ) + ")";
    }
    else if( pat instanceof PatternVar ) {
      PatternVar patVar = (PatternVar) pat;
      name += patVar.getName();
    }
    else if( pat instanceof PatternAlias ) {
      PatternAlias patAlias = (PatternAlias) pat;
      name += patAlias.getName() + "@" + getCompositePatternName( patAlias.getPat() );
    }
    else {
      name += "_";
    }
    return name;
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               A Vector of String[] with all the names of a local 
   *                        attribute, including the composite name. On String[] for each local attribute.
   **/
  public Vector getAllLocAttrNames( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    LocRule[] locrules = alts[prodRuleInfo[prodRuleId].getAltId()].getLocrules();
    String[] allNames;
    Vector allLocAttrNames = new Vector();
    Vector temp;
    
    for( int i=0; i<locrules.length; i++ ) {
      temp = getAllPatternNames( locrules[i].getPattern() );
      allNames = new String[temp.size()+1];
      for( int j=0; j<temp.size(); j++ ) {
        allNames[j] = (String) temp.elementAt( j );
      }
      allNames[allNames.length-1] = getCompositePatternName( locrules[i].getPattern() );
      allLocAttrNames.add( allNames );
    }
    return allLocAttrNames;
  }
  
  /**
   *  Method used to recursively get all names a Pattern name exists of.
   *
   *  @param    pat   The Pattern we want all the names of.
   *  @return         A Vector with all the found names.      
   **/
  public Vector getAllPatternNames( Pattern pat ) {
    Vector names = new Vector();
    
    if( pat instanceof PatternConstr ) {
      PatternConstr patConstr = (PatternConstr) pat;
      names.add( patConstr.getName() );
      Pattern[] pats = patConstr.getPats();
      for( int i=0; i<pats.length; i++ ) {
        names.addAll( getAllPatternNames( pats[i] ) );
      }
    }
    else if( pat instanceof PatternProduct ) {
      PatternProduct patProduct = (PatternProduct) pat;
      Pattern[] pats = patProduct.getPats();
      for( int i=0; i<pats.length; i++ ) {
        names.addAll( getAllPatternNames( pats[i] ) );
      }
    }
    else if( pat instanceof PatternVar ) {
      PatternVar patVar = (PatternVar) pat;
      names.add( patVar.getName() );
    }
    else if( pat instanceof PatternAlias ) {
      PatternAlias patAlias = (PatternAlias) pat;
      names.add( patAlias.getName() );
      names.addAll( getAllPatternNames( patAlias.getPat() ) );
    }
    return names;
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               String[] with all the types of the children of the production-rule.
   **/
  public String[] getChildTypes( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    Debug.output( "prodruleid: " + prodRuleId + "prodid: " + prodRuleInfo[prodRuleId].getProdId() + "altid: " + prodRuleInfo[prodRuleId].getAltId(), Debug.BRIDGE );
    Child[] children = alts[prodRuleInfo[prodRuleId].getAltId()].getChildren();
    String[] childTypes = new String[children.length];
    for( int i=0; i<children.length; i++ ) {
      childTypes[i] = children[i].getTp();
    }
    return childTypes;
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               The name of the alternative of this production-rule.
   **/
  public String getAltName( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    return alts[prodRuleInfo[prodRuleId].getAltId()].getCon();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               Array of all inherited attributes of the non-terminal of a production-rule.
   **/
  public Attr[] getNtInhAttr( int prodRuleId ) {
    return prods[prodRuleInfo[prodRuleId].getProdId()].getInh();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               Array of all synthesized attributes of the non-terminal of a production-rule.
   **/
  public Attr[] getNtSynAttr( int prodRuleId ) {
    return prods[prodRuleInfo[prodRuleId].getProdId()].getSyn();
  }
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               The number of children of a production-rule.
   **/
  public int getNumChildren( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    return alts[prodRuleInfo[prodRuleId].getAltId()].getChildren().length;
  }
  
  
  /*public Child[] getChildren( int prodRuleId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    return alts[prodRuleInfo[prodRuleId].getAltId()].getChildren();
  }*/
  
  /**
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @param    childId     The id of a Child of a production-rule.
   *  @return               The Child found with the given id's.
   **/
  public Child getChild( int prodRuleId, int childId ) {
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    Child[] children = alts[prodRuleInfo[prodRuleId].getAltId()].getChildren();
    return children[childId];
  }
  
  /**
   *  Method that creates all the AttrRelInfo objects for a given production-rule.
   *
   *  @param    prodRuleId  The id of the production rule we want info from.
   *  @return               Array of AttrRelInfo objects.
   **/
  public AttrRelInfo[] getAttrRelInfo( int prodRuleId ) {
    Debug.output( "in getAttrRelInfo!", Debug.BRIDGE );
    AttrRelInfo[] info;
    Vector temp = new Vector();
    Alternative[] alts = prods[prodRuleInfo[prodRuleId].getProdId()].getAlts();
    Child[] children = alts[prodRuleInfo[prodRuleId].getAltId()].getChildren();
    for( int i=0; i<children.length; i++ ) {
      Rule[] rules = children[i].getRules();
      for( int j=0; j<rules.length; j++ ) {
        Expression expr = rules[j].getRhs();
        String fullpat = getCompositePatternName( rules[j].getFullPattern() );
        Debug.output( "expr: " + expr, Debug.BRIDGE );
        CodeExtractor ce = new CodeExtractor( expr.getText() );
        ce.extract( children, getAllLocAttrNames( prodRuleId ).elements() );
        String[] fromAttrNames = ce.getAttrNames();
        String[] fromChildNames = ce.getChildNames();
        int[] fromChildNamesIntVal = ce.getChildNamesIntVal( children );
        if (fromAttrNames.length > 0) 
          for( int l=0; l<fromAttrNames.length; l++ ) {
            temp.add( new AttrRelInfo( rules[j].getAttr(), fromAttrNames[l], children[i].getName(), fromChildNames[l], i, fromChildNamesIntVal[l], fullpat, expr.getText(), expr.getPos() ) );
            Debug.output( temp.elementAt( temp.size()-1 ).toString(), Debug.BRIDGE );
          }
        else
          temp.add( new AttrRelInfo( rules[j].getAttr(), null, children[i].getName(), null, i, -3, fullpat, expr.getText(), expr.getPos() ) );
      }
    }
    
    //de rules van alternative
    Rule[] rules = alts[prodRuleInfo[prodRuleId].getAltId()].getRules();
    for( int j=0; j<rules.length; j++ ) {
      Expression expr = rules[j].getRhs();
      String fullpat = getCompositePatternName( rules[j].getFullPattern() );
      CodeExtractor ce = new CodeExtractor( expr.getText() );
      ce.extract( children, getAllLocAttrNames( prodRuleId ).elements() );
      String[] fromAttrNames = ce.getAttrNames();
      String[] fromChildNames = ce.getChildNames();
      int[] fromChildNamesIntVal = ce.getChildNamesIntVal( children );
      if (fromAttrNames.length > 0) 
        for( int l=0; l<fromAttrNames.length; l++ ) {
          temp.add( new AttrRelInfo( rules[j].getAttr(), fromAttrNames[l], "lhs", fromChildNames[l], -1, fromChildNamesIntVal[l], fullpat, expr.getText(), expr.getPos() ) );
        }      
      else
        temp.add( new AttrRelInfo( rules[j].getAttr(), null, "loc", null, -1, -3, fullpat, expr.getText(), expr.getPos() ) );
    }
    
    //de locrules
    LocRule[] locrules = alts[prodRuleInfo[prodRuleId].getAltId()].getLocrules();
    for( int j=0; j<locrules.length; j++ ) {
      Expression expr = locrules[j].getRhs();
      String fullpat = getCompositePatternName( locrules[j].getFullPattern() );
      CodeExtractor ce = new CodeExtractor( expr.getText() );
      ce.extract( children, getAllLocAttrNames( prodRuleId ).elements() );
      String[] fromAttrNames = ce.getAttrNames();
      String[] fromChildNames = ce.getChildNames();
      int[] fromChildNamesIntVal = ce.getChildNamesIntVal( children );
      String[] toAttrNames = getCompositeLocAttrNames( prodRuleId ); //get toAttrNames from Patterns of locrules
      if (fromAttrNames.length > 0) 
        for( int l=0; l<fromAttrNames.length; l++ ) {
          temp.add( new AttrRelInfo( toAttrNames[j], fromAttrNames[l], "loc", fromChildNames[l], -2, fromChildNamesIntVal[l], fullpat, expr.getText(), expr.getPos() ) );
        }
      else
        temp.add( new AttrRelInfo( toAttrNames[j], null, "loc", null, -2, -3, fullpat, expr.getText(), expr.getPos() ) );
    }
    
    info = new AttrRelInfo[temp.size()];
    for( int k=0; k<info.length; k++ ) {
      info[k] = (AttrRelInfo) temp.elementAt( k );
    }
    return info;
  }
    
}
