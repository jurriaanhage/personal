package visage.bridge;

/**
 *  Class which holds information about a certain relation between two attributes.
 *  Nowadays, it can also hold the case that their is no from attribute.
 */
public class AttrRelInfo {
  
  private String fromAttrName, toAttrName, toChildName, fromChildName, fullpat, code, position;
  private int fromChildNameIntVal, toChildNameIntVal; //used to determine to which production type the attributes belong (-1 for the non-terminal and 0...* for the children (same as their array index))
  
  /**
   *  Creates a new AttrRelInfo object.
   *
   *  @param  toAttrName            The name of the attribute which has to be assigned a value.
   *  @param  fromAttrName          The name of the attribute which is used to determine a value for the to-attribute.
   *  @param  toChildName           The name of the non-terminal or child the to-attribute belongs to.
   *  @param  fromChildName         The name of the non-terminal or child the from-attribute belongs to.
   *  @param  toChildNameIntVal     An integer value for the toChildName (-2 if the attribute is a local one, -1 if it's a non-terminal, an integer value between 0 and i for the corresponding children).
   *  @param  fromChildNameIntVal   An integer value for the fromChildName (-2 if the attribute is a local one, -1 if it's a non-terminal, an integer value between 0 and i for the corresponding children)
   *  @param  fullpat               Textual presentation of the full pattern.
   *  @param  code                  The code in which this relation can be found (the to-attribute can be found there).
   *  @param  position              The position of where this code can be found.
   */
  public AttrRelInfo( String toAttrName, String fromAttrName, String toChildName, String fromChildName, int toChildNameIntVal, int fromChildNameIntVal, String fullpat, String code, String position ) {
    this.toAttrName = toAttrName;
    this.fromAttrName = fromAttrName;
    this.toChildName = toChildName;
    this.fromChildName = fromChildName;
    this.toChildNameIntVal = toChildNameIntVal;
    this.fromChildNameIntVal = fromChildNameIntVal;
    this.fullpat = fullpat;
    this.code = code;
    this.position = position;
  }
  
  /**
   *  @return   The name of the attribute which has be assigned a value.
   */
  public String getToAttrName() {
    return toAttrName;
  }
  
  /**
   *  @return   The name of the attribute which is used to determine a value for the to-attribute.
   */
  public String getFromAttrName() {
    return fromAttrName;
  }
  
  /**
   *  @return   The name of the non-terminal or child the to-attribute belongs to.
   */
  public String getToChildName() {
    return toChildName;
  }
  
  /**
   *  @return   The name of the non-terminal or child the from-attribute belongs to.
   */
  public String getFromChildName() {
    return fromChildName;
  }
  
  /**
   *  @return   An integer value for the toChildName (-2 if the attribute is a local one, -1 if it's a non-terminal, an integer value between 0 and i for the corresponding children).
   */
  public int getToChildNameIntVal() {
    return toChildNameIntVal;
  }
  
  /**
   *  @return   An integer value for the fromChildName (-2 if the attribute is a local one, -1 if it's a non-terminal, an integer value between 0 and i for the corresponding children)
   */
  public int getFromChildNameIntVal() {
    return fromChildNameIntVal;
  }

  /**
   *  @return    The full pattern going with the code.
   */
  public String getFullPat() {
    return fullpat;
  }
  
  /**
   *  @return    The code in which this relation can be found (the to-attribute can be found there).
   */
  public String getCode() {
    return code;
  }
  
  /**
   *  @return   The position of where this code can be found.
   */
  public String getPosition() {
    return position;
  }
  
  /**
   *  Method which creates a description of the relation it represents)
   *  TODO: child + attr is not always descriptive enough (number the children?).
   *  @param  toAttr      The name of the attribute which has be assigned a value.
   *  @param  toChild     The name of the non-terminal or child the to-attribute belongs to.
   *  @param  fromAttr    The name of the attribute which is used to determine a value for the to-attribute.
   *  @param  fromChild   The name of the non-terminal or child the from-attribute belongs to.
   *  @return             A String which holds the created description. 
   */
    public static String createDepDescr( String toAttr, String toChild, String fromAttr, String fromChild ) {
        String result = toChild+ "."+toAttr+" depends on ";
        if (fromAttr.equals(""))
            result += "the value of "+fromChild; 
        else
            result += fromChild+"."+fromAttr;
        return result;
    }
  
   public String getText () {
     return createDepDescr (toAttrName, toChildName, fromAttrName, fromChildName);
   }
   
  /**
   * @return	True if the relation comes from a copy rule.
   */
  public boolean isCopyRule () {
    return getPosition().equals( "" );
  }
      
  /**
   *  @return   String describing all info with respect to this AttrRelInfo object.
   */
  public String toString() {
    return "AttrRelInfo - toAttrName: \n" + this.toAttrName 
                        + "\n fromAttrName: " + this.fromAttrName 
                        + "\n toChildName: " + this.toChildName
                        + "\n fromChildName: " + this.fromChildName
                        + "\n toChildNameIntVal: " + this.toChildNameIntVal 
                        + "\n fromChildNameIntVal: " + this.fromChildNameIntVal 
                        + "\n fullpat: " + this.fullpat
                        + "\n code: " + this.code 
                        + "\n position: " + this.position + "\n";
  }
}
