package visage.bridge;

/**
 *  An object which contains the info to determine where to get the info for a given production rule.
 *  Used by the prodbridge to see where to get it's info.
 *  Simply, every combination of a non-terminal with one of it's Alternatives is a production rule.
 */
public class ProductionRuleInfo {
  
  private int prodId, altId;
  
  /**
   *  Creates a new ProductionRuleInfo object.
   *
   *  @param  prodId  The Id of the Production (non-terminal).
   *  @param  altId   The Id of one of this Productions Alternatives.
   */
  public ProductionRuleInfo( int prodId, int altId ) {
    this.prodId = prodId;
    this.altId = altId;
  }
  
  /**
   *  @return   The Id of the Production (non-terminal).
   */
  public int getProdId() {
    return prodId;
  }
  
  /**
   *  @return   The Id of one of this Productions Alternatives.
   */
  public int getAltId() {
    return altId;
  }
}
