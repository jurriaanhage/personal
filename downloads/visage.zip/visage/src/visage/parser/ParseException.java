package visage.parser;

import java.lang.Exception;

/**
 *  Class for representing exceptions occured during the parsing proces.
 */
public class ParseException extends Exception {
	/**
	 *  Creates a ParseException.
	 *
	 * @param  msg  The message of this exception.
	 */
	public ParseException(String msg) {
		super(msg);
	}
}
