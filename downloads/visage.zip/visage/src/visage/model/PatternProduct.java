package visage.model;

/**
 *  Represents a Product Pattern as defined in the UUAG syntax.
 */
public class PatternProduct extends Pattern {
  
  private Pattern[] pats;
  
  /**
   *  Creates a new Product Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   *  @param  pats  An array containing the Patterns this Pattern is a product of.
   */
  public PatternProduct( String pos, Pattern[] pats ) {
    super( pos );
    this.pats = pats;
  }
  
  /**
   *  @return   An array containing the Patterns this Pattern is a product of.
   */
  public Pattern[] getPats() {
    return pats;
  }
  
  /**
   *  @return   String describing all info with respect to this Product Pattern.
   */
  public String toString() {
    String desc = "Pattern - Product - Position: " + super.getPos() + "\n";
    desc += "Patterns: \n";
    for( int i=0; i<pats.length; i++ ) { desc += pats[i].toString(); }
    return desc;
  }
}
