package visage.model;

/**
 *  Represents a Pattern as defined in the UUAG syntax.
 *  There are 5 different kinds of Patterns.
 */
public abstract class Pattern extends ModelItem {
  
  private String pos;
  
  /**
   *  Creates a new Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   */
  public Pattern( String pos ) {
    super();
    this.pos = pos;
  }
  
  /**
   *  @return   The position where this Pattern can be found.
   */
  public String getPos() {
    return pos;
  }
  
  /**
   *  @return   String describing all info with respect to this Pattern.
   */
  public abstract String toString();
}
