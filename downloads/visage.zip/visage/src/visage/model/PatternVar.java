package visage.model;

/**
 *  Represents a Var Pattern as defined in the UUAG syntax.
 */
public class PatternVar extends Pattern {
  
  private String name;
  
  /**
   *  Creates a new Var Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   *  @param  name  The name of this variable.
   */
  public PatternVar( String pos, String name ) {
    super( pos );
    this.name = name;
  }
  
  /**
   *  @return   The name of this variable.
   */
  public String getName() {
    return name;
  }
  
  /**
   *  @return   String describing all info with respect to this Var Pattern.
   */
  public String toString() {
    String desc = "Pattern - Var - Position: " + super.getPos() + " Name: " + name + "\n";
    return desc;
  }
}
