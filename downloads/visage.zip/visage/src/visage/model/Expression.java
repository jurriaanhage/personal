package visage.model;

public class Expression extends ModelItem {
  
  private String pos, text;
  
  public Expression( String pos, String text ) {
    super();
    this.pos = pos;
    this.text = text;
  }
  
  
  public String getPos() {
    return pos;
  }
  
  
  public String getText() {
    return text;
  }
  
  
  public String toString() {
    String desc = "";
    desc += "Expression - Position: " + pos + " Text: " + text + "\n";
    return desc;
  }
}
