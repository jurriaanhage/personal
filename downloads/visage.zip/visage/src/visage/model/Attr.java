package visage.model;

/**
 *  Represents an Attribute as defined in the UUAG syntax.
 */
public class Attr extends ModelItem {
  
  private String name, type;
  
  /**
   *  Creates a new Attribute representation.
   *
   *  @param  name  The name of this Attribute.
   *  @param  type  The type of this Attribute.
   */
  public Attr( String name, String type ) {
    super();
    this.name = name;
    this.type = type;
  }
  
  /**
   *  @return   The name of this Attribute.
   */
  public String getName() {
    return name;
  }
  
  /**
   *  @return   The type of this Attribute.
   */
  public String getType() {
    return type;
  }
  
  /**
   *  @return   String describing all info with respect to this Attribute.
   */
  public String toString() {
      return "Attribute - Name: " + name + " Type: " + type + "\n";
  }
}
