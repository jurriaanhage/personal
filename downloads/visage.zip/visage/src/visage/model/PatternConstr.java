package visage.model;

/**
 *  Represents a Constr Pattern as defined in the UUAG syntax.
 */
public class PatternConstr extends Pattern {
  
  private String name;
  private Pattern[] pats;
  
  /**
   *  Creates a new Constr Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   *  @param  name  The constructor name.
   *  @param  pats  An array containing all the Patterns belonging to this Constructor.
   */
  public PatternConstr( String pos, String name, Pattern[] pats ) {
    super( pos );
    this.name = name;
    this.pats = pats;
  }
  
  /**
   *  @return   The constructor name.
   */
  public String getName() {
    return name;
  }
  
  /**
   *  @return   An array containing all the Patterns belonging to this Constructor.
   */
  public Pattern[] getPats() {
    return pats;
  }
  
  /**
   *  @return   String describing all info with respect to this Constr Pattern.
   */
  public String toString() {
    String desc = "Pattern - Constr - Position: " + super.getPos() + " Name: " + name + "\n";
    desc += "Patterns: \n";
    for( int i=0; i<pats.length; i++ ) { desc += pats[i].toString(); }
    return desc;
  }
}
