package visage.model;

/**
 *  Represents an Alternative as defined in the UUAG syntax.
 */
public class Alternative extends ModelItem {
  
  private String con;
  private Child[] children;
  private Rule[] rules;
  private LocRule[] locrules;
  
  /**
   *  Creates a new Alternative representation.
   *
   *  @param  con       The name of this Alternative.
   *  @param  children  Child array containing the Children of this Alternative.
   *  @param  rules     Rule array containing the Rules belonging to this Alternative.
   *  @param  locrules  LocRule array containing the LocRules belonging to this Alternative.
   */
  public Alternative( String con, Child[] children, Rule[] rules, LocRule[] locrules ) {
    super();
    this.con = con;
    this.children = children;
    this.rules = rules;
    this.locrules = locrules;
  }
  
  /**
   *  @return   The name of this Alternative.
   */
  public String getCon() {
    return con;
  }
  
  /**
   *  @return   Child array containing the Children of this Alternative.
   */
  public Child[] getChildren() {
    return children;
  }
  
  /**
   *  @return   Rule array containing the Rules belonging to this Alternative.
   */
  public Rule[] getRules() {
    return rules;
  }
  
  /**
   *  @return   LocRule array containing the LocRules belonging to this Alternative.
   */
  public LocRule[] getLocrules() {
    return locrules;
  }  
  
  /**
   *  @return   String describing all info with respect to this Alternative.
   */
  public String toString() {
    String desc = "";
    desc += "Alternative: " + con + "\n";
    desc += "Children: \n";
    for( int i=0; i<children.length; i++ ) { desc += children[i].toString(); }
    desc += "Rules: \n";
    for( int i=0; i<rules.length; i++ ) { desc += rules[i].toString(); }
    desc += "LocRules: \n";
    for( int i=0; i<locrules.length; i++ ) { desc += locrules[i].toString(); }
    return desc;
  }
}
