package visage.model;

/**
 *  Abstract ModelItem used as a super class for all the DATA defined in the UUAG syntax.
 */
public abstract class ModelItem {

  public ModelItem() {
  }
}
