package visage.model;

/**
 *  Represents an Underscore Pattern as defined in the UUAG syntax.
 */
public class PatternUnderscore extends Pattern {
  
  /**
   *  Creates a new Underscore Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   */
  public PatternUnderscore( String pos ) {
    super( pos );
  }
  
  /**
   *  @return   String describing all info with respect to this Underscore Pattern.
   */
  public String toString() {
    String desc = "Pattern - Underscore - Position: " + super.getPos() + "\n";
    return desc;
  }
}
