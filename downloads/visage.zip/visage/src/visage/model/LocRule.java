package visage.model;

/**
 *  Represents a LocRule as defined in the UUAG syntax.
 */
public class LocRule extends ModelItem {
  
  private Pattern pat;
  private Pattern fullpat;
  private Expression rhs;
  private boolean owrt;
  
  /**
   *  Creates a new LocRule representation.
   *
   *  @param  pat   The Pattern belonging to this LocRule.
   *  @param  rhs   The righthand-side of this LocRule.
   *  @param  owrt  Boolean indicating owrt.
   */
  public LocRule( String attr, Pattern fullpat, Expression rhs, boolean owrt ) {
    super();
    this.pat = new PatternVar( fullpat.getPos(), attr); // Mimick that we have a pattern, will always be a Var pattern
    this.fullpat = fullpat;
    this.rhs = rhs;
    this.owrt = owrt;
  }

  /**
   *  @return   The Pattern belonging to this LocRule.
   */
  public Pattern getPattern() {
    return pat;
  }
  
  /**
   *  @return   The Pattern belonging to this LocRule.
   */
  public Pattern getFullPattern() {
    return fullpat;
  }

  /**
   *  @return   The righthand-side of this LocRule.
   */
  public Expression getRhs() {
    return rhs;
  }
  
  /**
   *  @return   Boolean indicating owrt.
   */
  public boolean getOwrt() {
    return owrt;
  }

  /**
   *  @return   String describing all info with respect to this LocRule.
   */
  public String toString() {
    String desc = "";
    desc += "LocRule: \n";
    desc += pat.toString() + "\n";
    desc += fullpat.toString() + "\n";    
    desc += rhs.toString() + "\n";
    desc += "Owrt: " + owrt + "\n";
    return desc;
  }
}
