package visage.model;

/**
 *  Represents an Alias Pattern as defined in the UUAG syntax.
 */
public class PatternAlias extends Pattern {
  
  private String name;
  private Pattern pat;
  
  /**
   *  Creates a new Alias Pattern representation.
   *
   *  @param  pos   The position where this Pattern can be found.
   *  @param  name  The alias name.
   *  @param  pat   The Pattern which this is an alias of.
   */
  public PatternAlias( String pos, String name, Pattern pat ) {
    super( pos );
    this.name = name;
    this.pat = pat;
  }
  
  /**
   *  @return   The alias name.
   */
  public String getName() {
    return name;
  }
  
  /**
   *  @return   The Pattern which this is an alias of.
   */
  public Pattern getPat() {
    return pat;
  }
  
  /**
   *  @return   String describing all info with respect to this Alias Pattern.
   */
  public String toString() {
    String desc = "Pattern - Alias - Position: " + super.getPos() + " Name: " + name + "\n";
    desc += pat.toString();
    return desc;
  }
}
