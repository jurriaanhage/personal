package visage.model;

/**
 *  Represents a Child as defined in the UUAG syntax.
 */
public class Child extends ModelItem {
  
  private String name, tp;
  private Attr[] inh, syn;
  private Rule[] rules;
  
  /**
   *  Creates a new Child representation.
   *
   *  @param  name    The name of this Child.
   *  @param  tp      The type of this Child.
   *  @param  inh     The inherited Attributes of this Child.
   *  @param  syn     The synthesized Attributes of this Child.
   *  @param  rules   The Rules belonging to this Child.
   */
  public Child( String name, String tp, Attr[] inh, Attr[] syn, Rule[] rules ) {
    super();
    this.name = name;
    this.tp = tp;
    this.inh = inh;
    this.syn = syn;
    this.rules = rules;
  }
  
  /**
   *  @return   The name of this Child.
   */
  public String getName() {
    return name;
  }
  
  /**
   *  @return   The type of this Child.
   */
  public String getTp() {
    return tp;
  }
  
  /**
   *  @return   The inherited Attributes of this Child.
   */
  public Attr[] getInh() {
    return inh;
  }
  
  /**
   *  @return   The synthesized Attributes of this Child.
   */
  public Attr[] getSyn() {
    return syn;
  }
  
  /**
   *  @return   The Rules belonging to this Child.
   */
  public Rule[] getRules() {
    return rules;
  }
  
  /**
   *  @return   String describing all info with respect to this Child.
   */
  public String toString() {
    String desc = "";
    desc += "Child - Name: " + name + " Type: " + tp + "\n";
    desc += "Inherited attributes: \n";
    for( int i=0; i<inh.length; i++ ) { desc += inh[i].toString(); }
    desc += "Synthesised attributes: \n";
    for( int i=0; i<syn.length; i++ ) { desc += syn[i].toString(); }
    desc += "Rules: \n";
    for( int i=0; i<rules.length; i++ ) { desc += rules[i].toString(); }
    return desc;
  }
}
