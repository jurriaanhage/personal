package visage.model;

/**
 *  Represents a Rule as defined in the UUAG syntax.
 */
public class Rule extends ModelItem {
  
  private Pattern fullpat;
  private Expression rhs;
  private String attr;
  
  /**
   *  Creates a new Rule representation. The first Pat should
   *  always be a variable and will be converted to a string by
   *  an explicit cast. TODO.
   */
  public Rule( String attr, Pattern fullpat, Expression rhs ) {
    super();
    this.fullpat = fullpat;
    this.rhs     = rhs;
    this.attr    = attr;
  }
    
  /**
   *  @return The attribute defined by this rule.
   */
  public String getAttr() {
    return attr;
  }


  /**
   *  @return   The full Pattern of which this rule was part.
   */
  public Pattern getFullPattern() {
    return fullpat;
  }
    
  /**
   *  @return 
   */
  public Expression getRhs() {
    return rhs;
  }
  
  /**
   *  @return   String describing all info with respect to this Rule.
   */
  public String toString() {
    String desc = "";
    desc += "Rule: " + getAttr() + "\n";
    desc += fullpat.toString() + "\n";
    desc += rhs.toString() + "\n";
    return desc;
  }
}
