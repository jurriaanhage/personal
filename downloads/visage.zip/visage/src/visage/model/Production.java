package visage.model;

/**
 *  Represents a Production as defined in the UUAG syntax.
 */
public class Production extends ModelItem {
  
  private String nt;
  private Attr[] inh, syn;
  private Alternative[] alts;
  
  /**
   *  Creates a new Production representation.
   *
   *  @param  nt    The non-terminal name.
   *  @param  inh   The inherited Attributes belonging to this Production.
   *  @param  syn   The synthesized Attributes belonging to this Production.
   *  @param  alts  The Alternatives belonging to this Production.
   */
  public Production( String nt, Attr[] inh, Attr[] syn, Alternative[] alts ) {
    super();
    this.nt = nt;
    this.inh = inh;
    this.syn = syn;
    this.alts = alts;
  }

  /**
   *  @return   The non-terminal name.
   */
  public String getNt() {
    return nt;
  }
  
  /**
   *  @return   The inherited Attributes belonging to this Production.
   */
  public Attr[] getInh() {
    return inh;
  }
  
  /**
   *  @return   The synthesized Attributes belonging to this Production.
   */
  public Attr[] getSyn() {
    return syn;
  }
  
  /**
   *  @return   The Alternatives belonging to this Production.
   */
  public Alternative[] getAlts() {
    return alts;
  }
    
  /**
   *  @return   String describing all info with respect to this Production.
   */
  public String toString() {
    String desc = "";
    desc += "Nonterminal: " + nt + "\n";
    desc += "Inherited attributes: \n";
    for( int i=0; i<inh.length; i++ ) { desc += inh[i].toString(); }
    desc += "Synthesised attributes: \n";
    for( int i=0; i<syn.length; i++ ) { desc += syn[i].toString(); }
    desc += "Alternatives: \n";
    for( int i=0; i<alts.length; i++ ) { desc += alts[i].toString(); }
    return desc;
  }
}
