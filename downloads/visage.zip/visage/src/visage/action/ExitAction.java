package visage.action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/**
 *  Class for representing the actions to be taken when the user has
 *  chosen to exit.
 */
public class ExitAction extends AbstractAction {
	/**
	 *  Creates an ExitAction.
	 *
	 * @param  name  The name of this action.
	 */
	public ExitAction(String name) {
		super(name);
	}


	/**
	 *  Method which is invoked whenever this action is triggered.
	 *
	 * @param  e  The generated ActionEvent.
	 */
	public void actionPerformed(ActionEvent e) {
		System.exit(0);
	}
}
