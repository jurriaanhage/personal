package visage.action;

import javax.swing.AbstractAction;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import java.awt.event.ActionEvent;

/**
 *  Action which closes all currently opened InternalFrames.
 */
public class CloseAllAction extends AbstractAction {
  
  private JDesktopPane graphicPane;
  
  /**
   *  Creates a new CloseAllAction.
   *
   *  @param  description   A description of this action.
   *  @param  graphicPane   The JDesktopPane which contains the InternalFrames
   */
  public CloseAllAction( String description, JDesktopPane graphicPane ) {
    super( description );
    this.graphicPane = graphicPane;
  }
  
  /**
   *  Gets all frames and closes them.
   */
  public void actionPerformed( ActionEvent ae ) {
    JInternalFrame[] frames = (JInternalFrame[]) graphicPane.getAllFrames();
    for( int i=0; i<frames.length; i++ ) {
        frames[i].dispose();
    }
    graphicPane.validate(); 
  }
}
