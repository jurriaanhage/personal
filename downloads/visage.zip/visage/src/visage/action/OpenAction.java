package visage.action;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.filechooser.FileFilter;
import java.awt.event.ActionEvent;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;

import visage.visual.*;
import visage.Visage;
import visage.ProductionsController;
import visage.io.ATermLoader;
import visage.Debug;
import visage.Globals;

/**
 *  Action that opens a file and causes it to be displayed.
 */
public class OpenAction extends AbstractAction {
  private JFileChooser chooser;
  private ProductionsView prodView;
  private JDesktopPane graphicPane;
  private Visage root;
//  private ProductionsController control;
  private JLabel statusLabel;
  private static File previousFile = null;
  
  /**
   *  Creates a new OpenAction.
   *
   *  @param  description   Description of this action.
   *  @param  prodView      The ProductionView which lists all the productions.
   *  @param  graphicPane   The JDesktopPane which can hold all the GraphicViewFrames.
   *  @param  statusLabel   The statusLabel at the bottom of the screen.
   *  @param  root          The root class of the program.
   */
  public OpenAction( String description, ProductionsView prodView, JDesktopPane graphicPane, JLabel statusLabel, Visage root ) {
    super( description );
    this.prodView = prodView;
    this.graphicPane = graphicPane;
    this.statusLabel = statusLabel;
    this.root = root;
    createChooser();
  }
  
  /**
   *  Gets the filename from the JChooser and tries to load it and display it.
   *
   *  @exception  FileNotFoundException  Sets statuslabel text.
   *  @exception  IOException           Sets statuslabel text.
   */
  public void actionPerformed( ActionEvent e ) {
    if( chooser.showOpenDialog( root ) == JFileChooser.APPROVE_OPTION ) {
      loadIt(chooser.getSelectedFile(),prodView,graphicPane,statusLabel,root);
    }
  }

  /**
   * Reload the previously loaded file.
   * 
   */
  public File getPreviousFile ( ) {
    return previousFile;
  }
   
  /**
   * Load the File.
   */
  public static void loadIt(File f,  ProductionsView prodView, JDesktopPane graphicPane, JLabel statusLabel, Visage root) { 
      statusLabel.setText( "Loading file: " + f );
      ATermLoader loader = new ATermLoader( f);
      ProductionsController control = new ProductionsController( prodView, graphicPane, statusLabel  );
      try {
        control.initController( loader.load() );
        root.setTitle( "Visage v1.0 - " + f );
        statusLabel.setText( "Ready" );
        previousFile = f;
      }
      catch( FileNotFoundException fnfe ) {
        Debug.output( "FileNotFoundException: " + fnfe, Debug.LOAD );
        statusLabel.setText( "Error: file doesn't exist" );
      }
      catch( IOException ioe ) {
        Debug.output( "IOException: " + ioe, Debug.LOAD );
        statusLabel.setText( "Error: unable to read file" );
      }
  }
  
  /**
   *  Creates a JFileChooser and displays it.
   */
  private void createChooser() {
    chooser = new JFileChooser(System.getProperty("user.dir"));
    chooser.setDialogType( JFileChooser.OPEN_DIALOG );
    chooser.setDialogTitle( "Open file..." );
    chooser.addChoosableFileFilter( new ATermFilter() );
  }
  
  /**
   *  Class for filtering the ATerms.
   */
  class ATermFilter extends FileFilter {
    /**
     *  Method for determining whether a file is an aterm file or not.
     *
     * @param  f  The file to be investigated.
     * @return    Description of the Return Value
     */
    public boolean accept(File f) {
      if (f.isDirectory()) {
        return true;
      }

      String extension = null;
      String s         = f.getName();
      int    i         = s.lastIndexOf('.');

      if (i > 0 && i < s.length() - 1) {
        extension = s.substring(i + 1).toLowerCase();
      }

      if (extension != null) {
        if (extension.equals(Globals.STANDARDEXTENSION)) {
          return true;
        } else {
          return false;
        }
      }
      return false;
    }


    /**
     *  Returns a string description of this filter.
     *
     * @return    The description value
     */
    public String getDescription() {
      return "ATerms";
    }
  }
}
