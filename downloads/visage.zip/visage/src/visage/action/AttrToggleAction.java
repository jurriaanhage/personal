package visage.action;

import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;

import visage.util.*;
import visage.visual.GraphicView;

/**
 *  Action used to toggle off a given attribute in the views.
 */
public class AttrToggleAction extends AbstractAction {
  
  private AttrOnOffToggler attrToggler;
  private String attrName, prodType;
  private GraphicView graphicView;
  
  /**
   *  Creates a new AttrToggleAction.
   *
   *  @param  description   A description of this action.
   *  @param  attrToggler   The AttrOnOffToggler which keeps track of which are toggled off.
   *  @param  attrName      The name of the attribute to be toggled on/off.
   *  @param  prodType      The name of the non-terminal or child this attribute belongs to.
   *  @param  graphicView   The GraphicView where the attribute this toggle action belongs to is displayed.
   */
  public AttrToggleAction( String description, AttrOnOffToggler attrToggler, String attrName, String prodType, GraphicView graphicView ) {
    super( description );
    this.attrToggler = attrToggler;
    this.attrName = attrName;
    this.prodType = prodType;
    this.graphicView = graphicView;
  }

  public void toggle( ) {
    if( attrToggler.isOff( attrName, prodType ) ) {
      attrToggler.toggleOn( attrName, prodType );
    }
    else {
      attrToggler.toggleOff( attrName, prodType );
    }
    graphicView.repaint();
  }
  
  /**
   *  Toggles an attribute off it was currently on or the opposite.
   */
  public void actionPerformed( ActionEvent ae ) {
    toggle();
  }
}
