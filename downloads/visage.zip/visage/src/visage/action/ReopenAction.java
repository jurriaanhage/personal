package visage.action;

import javax.swing.AbstractAction;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import java.awt.event.ActionEvent;
import visage.visual.*;
import visage.Visage;

/**
 *  Action that reopens a file and causes it to be displayed.
 */
public class ReopenAction extends AbstractAction {
  private OpenAction openaction;
  private ProductionsView prodView;
  private JDesktopPane graphicPane;
  private Visage root;
  private JLabel statusLabel;

  /**
   *  Creates a new OpenAction.
   *
   *  @param  description   Description of this action.
   *  @param  prodView      The ProductionView which lists all the productions.
   *  @param  graphicPane   The JDesktopPane which can hold all the GraphicViewFrames.
   *  @param  statusLabel   The statusLabel at the bottom of the screen.
   *  @param  root          The root class of the program.
   */
  public ReopenAction( String description, OpenAction openaction, ProductionsView prodView, JDesktopPane graphicPane, JLabel statusLabel, Visage root ) {
    super( description );
    this.prodView = prodView;
    this.graphicPane = graphicPane;
    this.statusLabel = statusLabel;
    this.root = root;
    this.openaction = openaction;
  }
  
  /**
   *  Gets the filename from the OpenAction and tries to load it and display it.
   *
   */
  public void actionPerformed( ActionEvent e ) {
    if (openaction.getPreviousFile() != null)
      openaction.loadIt(openaction.getPreviousFile(),prodView,graphicPane,statusLabel,root);
    else
      System.out.println("Program error, no previously loaded file");
  }
}
