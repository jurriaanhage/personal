package visage.visual;

import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RectangularShape;
import java.awt.Color;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;

import visage.util.*;
import visage.action.AttrToggleAction;

/**
 *  Visual representation of an attribute.
 */
public class VisualAttribute extends RectangularVisualItem {
  
  private Ellipse2D.Double textEllipse;
  private AttrOnOffToggler attrToggler;
  private JPopupMenu menu;
  private AttrToggleAction toggleAction;
  private String prodType;
  
  /**
   *  Constructs a new VisualAttribute.
   *
   *  @param  name          The name of the attribute.
   *  @param  type          The type of the attribute.
   *  @param  prodType      The type of the attributes non-terminal.
   *  @param  color         The fill color for the ellipse.
   *  @param  selColor      The fill color for the ellipse when selected.
   *  @param  textColor     The color of the text in the ellipse.
   *  @param  itemControl   The SelectedItemController that controls this VisualAttribute.
   *  @param  attrToggler   The AttrOnOffToggler that knows if this attribute is currently toggled on/off.
   *  @param  graphicView   The GraphicView this VisualAttribute has to be drawn in.
   *  @param  g2d           The Graphics2D object we're painting with.
   */
  public VisualAttribute( String name, String type, String prodType, Color color, Color selColor, Color textColor, SelectedItemController itemControl, AttrOnOffToggler attrToggler, GraphicView graphicView, Graphics2D g2d ) {
    super( name, type, name, color, selColor, textColor, itemControl, g2d );
    this.attrToggler = attrToggler;
    this.prodType = prodType;
    createPopupMenu( graphicView );
  }
  
  /**
   *  Creates a new JPopupMenu with a AttrToggleAction.
   *
   *  @param  graphicView   The GraphicView this VisualAttribute has to be drawn in.
   */
  public void createPopupMenu( GraphicView graphicView ) {
    this.menu = new JPopupMenu( "Attribute" );
    toggleAction = new AttrToggleAction( "Toggle on/off", attrToggler, name, prodType, graphicView );
    menu.add( toggleAction );
  }
  
  /**
   *  @return   The RectangularShape of the ellipse.
   */
  public RectangularShape getRect() {
    return textEllipse;
  }
  
  /**
   *  If the left mousebutton is clicked it tells the SelecteditemController to select this item.
   *  Double clicks toggle the attribute, Meta+mouse shows a menu.
   *
   *  @param  me  MouseEvent
   */
  public void mouseClicked( MouseEvent me ) {
    if( me.isMetaDown() ) { 
        menu.show( this, me.getX(), me.getY() ); 
    }
    else
        if( me.getButton() == 1 ) { 
            itemControl.setSelectedItem( this ); 
            if (me.getClickCount() > 1) {
                toggleAction.toggle();
            }
        }    
  }
  
  /**
   *  Creates a new ellipse and paints it. Checks if the attribute is toggled on or off.
   *  If on it paints the ellipse with text in it, else a small black ellipse.
   *  Also sets the preferred size and bounds of this VisualAttribute.
   *
   *  @param  x     x-coordinate of the left uppercorner of the RectangularShape of this ellipse.
   *  @param  y     y-coordinate of the left uppercorner of the RectangularShape of this ellipse.
   *  @param  g2d   The Graphics2D object we're painting with.
   */
  public void paintItem( double x, double y, Graphics2D g2d ) {
    textEllipse = new Ellipse2D.Double();
    if( attrToggler.isOff( name, prodType ) ) {
      super.setToggledOn( false );
      textEllipse.setFrame( x, y, 10, super.calculateHeight() );
      g2d.setColor( Color.BLACK );
      g2d.fill( textEllipse );
      this.setPreferredSize( new java.awt.Dimension( 10, (int) super.calculateHeight() ) );
    }
    else {
      super.setToggledOn( true );
      textEllipse.setFrame( x, y, super.calculateWidth(), super.calculateHeight() );
      if( selected )  { g2d.setColor( selColor ); } 
      else            { g2d.setColor( color ); }
      g2d.fill( textEllipse );
      g2d.setColor( textColor );
      g2d.drawString( name, (float) x+insets.left, (float) (y+(stringHeight/2)+insets.top+fm.getDescent()) );
      this.setPreferredSize( new java.awt.Dimension( (int) super.calculateWidth(), (int) super.calculateHeight() ) );
    }
    this.setBounds( (int) x, (int) y, (int) this.getPreferredSize().getWidth(), (int) this.getPreferredSize().getHeight() );
    this.validate();
  }
}
