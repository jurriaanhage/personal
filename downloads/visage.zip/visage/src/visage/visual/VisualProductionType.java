package visage.visual;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.event.MouseEvent;

/**
 *  Class to graphically represent a non-terminal.
 */
public class VisualProductionType extends RectangularVisualItem {
  
  private Rectangle2D.Double rect;
  private VisualAttribute[] inhVisual, synVisual;
  
  /**
   *  Constructs a new VisualProductionType.
   *
   *  @param  name          The name of the attribute.
   *  @param  type          The type of the attribute.
   *  @param  color         The fill color for the ellipse.
   *  @param  selColor      The fill color for the ellipse when selected.
   *  @param  textColor     The color of the text in the ellipse.
   *  @param  itemControl   The SelectedItemController that controls this VisualAttribute.
   *  @param  inhVisual     This non-terminal's visual representations of it's inherited attributes.
   *  @param  synVisual     This non-terminal's visual representations of it's synthesized attributes.
   *  @param  g2d           The Graphics2D object we're painting with.
   */
  public VisualProductionType( String name, String type, Color color, Color selColor, Color textColor, SelectedItemController itemControl, VisualAttribute[] inhVisual, VisualAttribute[] synVisual, Graphics2D g2d ) {
    super( name, type, name, color, selColor, textColor, itemControl, g2d );
    this.inhVisual = inhVisual;
    this.synVisual = synVisual;
  }
  
  /**
   *  @return   Array of this non-terminal's visual representations of it's inherited attributes.
   */
  public VisualAttribute[] getInhVisualAttributes() {
    return inhVisual;
  }
  
  /**
   *  @return   Array of this non-terminal's visual representations of it's synthesized attributes.
   */
  public VisualAttribute[] getSynVisualAttributes() {
    return synVisual;
  }
  
  /**
   *  @return   The RectangularShape of the rectangle.
   */
  public RectangularShape getRect() {
    return rect;
  }
  
  /**
   *  If the left mousebutton is clicked it tells the SelecteditemController to select this item.
   *  Else it leaves the interpretation up to the rightMouseClicked method.
   *
   *  @param  me  MouseEvent
   */
  public void mouseClicked( MouseEvent me ) {
    if( me.getButton() == 1)  {
        itemControl.setSelectedItem( this ); 
    }
  }

  /**
   *  Creates a new rectangle and paints it with the given text. 
   *  Also sets the preferred size and bounds of this VisualProductionType.
   *
   *  @param  x     x-coordinate of the left uppercorner of the RectangularShape of this ellipse.
   *  @param  y     y-coordinate of the left uppercorner of the RectangularShape of this ellipse.
   *  @param  g2d   The Graphics2D object we're painting with.
   */
  public void paintItem( double x, double y, Graphics2D g2d ) {
    rect = new Rectangle2D.Double();
    rect.setRect( x, y, stringWidth+insets.left+insets.right, stringHeight+insets.top+insets.bottom );
    if( selected )  { g2d.setColor( selColor ); } 
    else            { g2d.setColor( color ); }
    g2d.fill( rect );
    g2d.setColor( textColor );
    g2d.drawString( text, (float) x+insets.left, (float) (y+(stringHeight/2)+insets.top+fm.getDescent()) );
    this.setBounds( (int) x, (int) y, (int) this.getPreferredSize().getWidth(), (int) this.getPreferredSize().getHeight() );
    this.validate();
  }
}
