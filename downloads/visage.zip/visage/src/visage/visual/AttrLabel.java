package visage.visual;

import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.FontMetrics;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

/**
 *  A label describing a given relation between two attributes.
 *  Clicking on this label will trigger the SelectedItemController.
 */
public class AttrLabel extends JLabel implements MouseListener {
  
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private SelectedItemController controller;
  private int attrRelId;
  
  /**
   *  Creates a new AttrLabel.
   *
	 *  @param	attrName	  Describes the 
   *  @param  attrRelId   Id of this relation (the i-th relation of an attribute)
   *  @param  controller  The SelectedItemController.
   */
  public AttrLabel( String attrName, int attrRelId, 
										SelectedItemController controller ) {
    super();
    this.setText( attrName );
    this.attrRelId = attrRelId;
    this.controller = controller;
    this.setOpaque( true );
    this.setBackground( java.awt.Color.WHITE );
    FontMetrics fm = this.getFontMetrics( this.getFont() );
    this.setMinimumSize( new java.awt.Dimension( fm.stringWidth( this.getText() ), fm.getHeight() ) );
    this.setToolTipText( this.getText() );
    this.addMouseListener( this );
		this.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
  }

  /**
   *  When clicked on this label the SelectedItemController is triggered
   */
  public void mouseClicked( MouseEvent me ) {
    controller.setSelectedAttrRel( attrRelId );
  }
  
  
  public void mousePressed( MouseEvent me ) {
  }
  
  
  public void mouseReleased( MouseEvent me ) {
  }
  
  
  public void mouseEntered( MouseEvent me ) {
  }
  
  
  public void mouseExited( MouseEvent me ) {
  }
}
