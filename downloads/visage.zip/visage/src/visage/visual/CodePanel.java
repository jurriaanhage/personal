//
//  CodePanel.java
//  
//
//  Created by Jurriaan Hage on Tue Aug 19 2003.
//  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
//

package visage.visual;

import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.BorderFactory;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Font;
import visage.Globals;

public class CodePanel extends JPanel {

    private JTextArea codeArea;
    private JScrollPane codePane;
    private JLabel headerLabel;
    private PositionLabel positionLabel;
    private FontMetrics fm;
		
    private final String CODEINDENT = "   ";
    private final static int CODEDETAIL_HEIGHT = 150;
    private final static int CODEDETAIL_WIDTH = 500;

    public CodePanel (String defname, String position,
											AttrLabel[] deps, String fullpatdescr, String code) {
				super(new BorderLayout()); // Room for two labels and a textarea.
				this.setBorder (	BorderFactory.createEmptyBorder(4,4,4,4) );	
				fm = this.getFontMetrics( this.getFont() );
				JPanel temp = new JPanel(new BorderLayout());        
				
				if (defname == null)
					constructHeaderLabel ("No additional information");
				else
					constructHeaderLabel ("Selected attribute: "+defname);
			  temp.add( headerLabel, BorderLayout.WEST );

				if (position != null) {
				  constructPositionLabel (position);
          temp.add( positionLabel, BorderLayout.EAST );
				}
				this.add (temp, BorderLayout.NORTH);

				
				if ((deps != null) && (deps.length > 0)) {
  				JPanel depsbar = new JPanel(new FlowLayout(FlowLayout.LEFT));  
				  depsbar.add( new JLabel(defname +" is used by:"));
  				for (int i=0; i < deps.length; i++) {
  				  depsbar.add( deps[i] );
  				}
					this.add( depsbar, BorderLayout.CENTER );
				}
				
				if (code != null) {
          constructCodePane(fullpatdescr, code);				
          this.add( codePane, BorderLayout.SOUTH );
		  		setToOrigin();
				}	
//        validate();
    }
    
    /* Can this be done at all? TODO */     
    public void setToOrigin () {
        JScrollBar bar = codePane.getHorizontalScrollBar();
        bar.setValue( bar.getMinimum() );
        validate();
    }

    public void constructHeaderLabel (String header) {
        headerLabel = new JLabel(header);
        headerLabel.setBackground( java.awt.Color.WHITE );
        headerLabel.setOpaque( true );
    }

    public void constructPositionLabel (String positiondescription) {
        positionLabel = new PositionLabel( fm.stringWidth(positiondescription)+4, fm.getHeight() + 4 );
        positionLabel.setSpecial("Location:",positiondescription);
    }
    
    public void constructCodePane (String defname, String code) {
        codeArea = new JTextArea( defname+" =\n"+indent(code) );
        codeArea.setEditable( false );
        codeArea.setLineWrap( false ); 
        codeArea.setFont( new Font( "monospaced", Font.BOLD,
				                  Globals.getGlobals().getFontSize() ) );
        codePane = new JScrollPane();
        codePane.add( codeArea );
        codePane.setPreferredSize( new Dimension( CODEDETAIL_WIDTH, 
				   StrictMath.min(CODEDETAIL_HEIGHT, fm.getHeight() * (countLines(code)+2) ) ) );
        codePane.setViewportView( codeArea );
    }

		private int countLines ( String text ) {
		  /* Count how many \n we have */
			return text.split("\n").length;
		}
		    
		private String indent( String code ) {
        return CODEINDENT+code.replaceAll("\n","\n"+CODEINDENT);
    }   
}
