package visage.visual;

import java.awt.Graphics2D;
import java.awt.geom.RectangularShape;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.Color;
import java.util.Vector;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

/**
 *  Abstract class to create VisualItems that are based on a RectangularShape (rectangles or ellipses).
 */
public abstract class RectangularVisualItem extends VisualItem implements MouseListener {
  
  protected String name, type, text, code, position;
  protected Color textColor;
  protected double stringWidth, stringHeight;
  protected Insets insets;
  protected FontMetrics fm;
  private Vector toRels, fromRels;
  protected SelectedItemController itemControl;
  private boolean toggledOn;
  
  /**
   *  Creates a new RectangularVisualItem.
   *
   *  @param  name          The name of the item this is a visual representation of.
   *  @param  type          The type of the item this is a visual representation of.
   *  @param  text          The text to be displayed in this representation.
   *  @param  color         The fill color.
   *  @param  selColor      The fill color when selected.
   *  @param  textColor     The text color.
   *  @param  itemControl   The SelectedItemController that keeps track of which item is selected.
   *  @param  g2d           The Graphics2D object we're painting with.
   */
  public RectangularVisualItem( String name, String type, String text, Color color, Color selColor, Color textColor, SelectedItemController itemControl, Graphics2D g2d ) {
    super( color, selColor );
    this.name = name;
    this.type = type;
    this.text = text; //text of the label, sometimes is name and sometimes type
//    this.code = code;
//    this.position = position;
    this.textColor = textColor;
    this.itemControl = itemControl;
    toRels = new Vector();
		fromRels = new Vector();
    calculateBounds( text, g2d );
    this.toggledOn = true;
    this.setPreferredSize( new java.awt.Dimension( (int) calculateWidth(), (int) calculateHeight() ) );
    this.setToolTipText( name + " : " + type );
    this.addMouseListener( this );
  }
  
  /**
   *  Calculates the width and height of the String that has to be displayed in the item.
   *  Also sets the insets of this item.
   *
   *  @param  text  The text to be displayed in this representation.
   *  @param  g2d   The Graphics2D object we're painting with.
   */
  private void calculateBounds( String text, Graphics2D g2d ) {
    fm = g2d.getFontMetrics();
    this.stringWidth = fm.stringWidth( text );
    this.stringHeight = fm.getHeight();
    this.insets = new Insets( 4, 10, 4, 10 );
  }
  
  /**
   *  @return   The width this item has to have.
   */
  public double calculateWidth() {
    return insets.left + stringWidth + insets.right;
  }
  
  /**
   *  @return   The height this item has to have.
   */
  public double calculateHeight() {
    return insets.top + stringHeight + insets.bottom;
  }
  
  /**
   *  @return   The name of the item this is a visual representation of.
   */
  public String getName() {
    return name;
  }

  /**
   *  @return   The name of the item this is a visual representation of.
   */
  public String getCode() {
    return code;
  }
  /**
   *  @return   The name of the item this is a visual representation of.
   */
  public String getPosition() {
    return position;
  }
  
  /**
   *  @return   The type of the item this is a visual representation of.
   */
  public String getType() {
    return type;
  }
  
  /**
   *  @return   Boolean value indicating whether this item is currently toggled on.
   */
  public boolean toggledOn() {
    return toggledOn;
  }
  
  /**
   *  Toggles this item on/off.
   *
   *  @param   toggledOn  Boolean value to decide whether the item has to be toggled off or on.
   */
  public void setToggledOn( boolean toggledOn ) {
    this.toggledOn = toggledOn;
  }
  
  /**
   *  Used when a new VisualAttrRel is created where this item is involved with,
   *  so this item knows which attribute relations it is part of.
	 *  At this point we also need to know the 'direction'
   *
   *  @param  attrRel The visual attribute relation.
   */
  public void addToVisualAttrRel( VisualAttrRel attrRel ) {
	  this.toRels.add( attrRel );
  }

  public void addFromVisualAttrRel( VisualAttrRel attrRel ) {
	  this.fromRels.add( attrRel );
  }
  
	
  /**
   *  @return   An array containing all the visual attribute relation objects which 
   *            represent a relation this item is part of.
   */
  public VisualAttrRel[] getVisualToAttrRels() {
    VisualAttrRel[] temp = new VisualAttrRel[toRels.size()];
		toRels.copyInto( temp );
    return temp;
  }

  public VisualAttrRel[] getVisualFromAttrRels() {
    VisualAttrRel[] temp = new VisualAttrRel[fromRels.size()];
		fromRels.copyInto( temp );
    return temp;
  }
  
  /**
   *  Abstract method where subclasses can define how to paint this item.
   *
   *  @param  x     The x-coordinate of the left uppercorner of the item.
   *  @param  y     The y-coordinate of the left uppercorner of the item.
   *  @param  g2d   The Graphics2D object we're painting with.
   */
  public abstract void paintItem( double x, double y, Graphics2D g2d );
  
  /**
   *  Abstract method where subclasses can return the RectangularShape of their main shape.
   *
   *  @return   The RectangularShape of this item's main shape.
   */
  public abstract RectangularShape getRect();
  
  /**
   *  Abstract class where subclasses can define what to do when somebody clicked
   *  this item with the right mousebutton.
   *
   *  @param  me  MouseEvent
   */
  public void mouseClicked( MouseEvent me ) {
  }
    
  public void mousePressed( MouseEvent me ) {
  }
  
  
  public void mouseReleased( MouseEvent me ) {
  }
  
  
  public void mouseEntered( MouseEvent me ) {
  }
  
  
  public void mouseExited( MouseEvent me ) {
  }
}
