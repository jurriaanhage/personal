package visage.visual;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import java.awt.Container;
import java.awt.BorderLayout;
import visage.bridge.*;
import visage.util.*;

/**
 *  A Frame containing three views (graphic view, attribute relation view and code detail view).
 *  Used to be able to display all info of a production rule.
 */
public class GraphicViewFrame extends JInternalFrame {
  
  private GraphicView graphicView;
  private Container contentPane;
  private int prodRuleId; 
  private ProductionsBridge prodBridge;
  private JScrollPane graphicPane, attrRelPane;
  private SelectedItemController itemControl;
  private final static int CODEDETAIL_HEIGHT = 200;
  private final static int CODEDETAIL_WIDTH = 500;
  
  /**
   *  Creates a new GraphicViewFrame.
   *
   *  @param  prodRuleId    The Id of the production rule we want to display.
   *  @param  title         The title of this frame.
   *  @param  prodBridge    The ProductionsBridge where we get all the info from to display the right information about the given production rule.
   *  @param  attrToggler   The AttrOnOffToggler which keeps track off all the attributes that are currently toggled off for the whole loaded file.
   */
  public GraphicViewFrame( int prodRuleId, String title, ProductionsBridge prodBridge, AttrOnOffToggler attrToggler ) {
    super( title, true, true, true, true );
    this.prodRuleId = prodRuleId;
    this.prodBridge = prodBridge;
    this.contentPane = this.getContentPane();
    contentPane.setLayout( new BorderLayout() );
    itemControl = new SelectedItemController(this,
		                    prodBridge.getAttrRelInfo( prodRuleId ) );
    createGraphicPane( attrToggler );
		itemControl.setGraphicView ( graphicView);
    this.setVisible( true );
  }

  /**
   *  Creates a GraphicView in a JScrollPane in the center of the frame.
   *
   *  @param  attrToggler The AttrOnOffToggler to be passed to the GraphicView.
   */
  private void createGraphicPane( AttrOnOffToggler attrToggler ) {
    graphicPane = new JScrollPane();
    graphicPane.setPreferredSize( this.getSize() );
    graphicView = new GraphicView( prodRuleId, prodBridge, itemControl, attrToggler, graphicPane );
    graphicPane.add( graphicView );
    graphicPane.setViewportView( graphicView );
    contentPane.add( graphicPane, BorderLayout.CENTER );
  }
  
}
