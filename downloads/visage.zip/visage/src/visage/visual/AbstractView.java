package visage.visual;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Insets;
import java.awt.Color;

/**
 *  Abstract class which can be used to create views containing a header and a series of JLabels
 *  which will be listed.
 */
public abstract class AbstractView extends JPanel {
  
  private JLabel header;
  private Insets insets;
  private final int gap = 3;
  
  /**
   *  Creates a new AbstractView.
   */
  public AbstractView() {
    super();
    this.setOpaque( true );
    this.setLayout( null );
    this.insets = new Insets( 10, 10, 10 ,10 );
  }
  
  /**
   *  Empties the view and replaces the headertext with a new one.
   *
   *  @param  text  The new headertext to be set.
   */
  private void setHeader( String text ) {
    this.removeAll();
    header = new JLabel();
    header.setOpaque( true );
    header.setBackground( Color.BLACK );
    header.setForeground( Color.WHITE );
    header.setHorizontalAlignment( JLabel.CENTER );
    header.setText( text );
    this.add( header );
    java.awt.FontMetrics fm = header.getFontMetrics( header.getFont() );
    header.setPreferredSize( new java.awt.Dimension( fm.stringWidth( header.getText() )+20, fm.getHeight()+5 ) );
    header.setBounds( 0, insets.top, (int) header.getPreferredSize().getWidth(), (int) header.getPreferredSize().getHeight() );
  }
  
  /**
   *  Empties the view, replaces the headertext with a new one and makes a new list of JLabels.
   *
   *  @param  labels      An array containing the JLabels to be listed.
   *  @param  headerText  The new headertext to be set.
   */
  public void setView( JLabel[] labels, String headerText ) {
    this.removeAll();
    this.setBackground( java.awt.Color.WHITE );
    if( !headerText.equals( "" ) ) { setHeader( headerText ); }
    
    int y, longestWidth;
    
    if( header!=null ) { 
      y = insets.top+header.getHeight()+gap; 
      longestWidth = header.getWidth();
    }
    else { 
      y = insets.top;
      longestWidth = 0; 
    }
    for( int i=0; i<labels.length; i++ ) {
      this.add( labels[i] );
      labels[i].setBounds( insets.left, y, (int) labels[i].getPreferredSize().getWidth(), (int) labels[i].getPreferredSize().getHeight() );
      if( labels[i].getWidth() > longestWidth ) { longestWidth = labels[i].getWidth(); }
      y += labels[i].getHeight() + gap;
    }
    this.setPreferredSize( new java.awt.Dimension( longestWidth+insets.left+insets.right, y+insets.bottom ) );
    this.validate();
    this.repaint();
    if( this.getTopLevelAncestor()!=null ) {
		   this.getTopLevelAncestor().validate(); 
		}
  }
}
