package visage.visual;

import java.awt.Color;
import java.awt.Graphics2D;

import visage.util.*;

/**
 *  Class to represent a local attribute.
 */
public class VisualLocAttribute extends VisualAttribute {
  
  private String[] allNames;
  
  /**
   *  Creates a new VisualLocAttribute.
   *
   *  @param  compositeName   The composite name of the local attribute.
   *  @param  type            The type of the local attribute.
   *  @param  prodType        The type of the local attributes non-terminal.
   *  @param  allNames        A string array with all names the composite name exists of and the composite name itself.
   *  @param  color           The fill color for the ellipse.
   *  @param  selColor        The fill color for the ellipse when selected.
   *  @param  textColor       The color of the text in the ellipse.
   *  @param  itemControl     The SelectedItemController that controls this VisualLocAttribute.
   *  @param  attrToggler     The AttrOnOffToggler that knows if this local attribute is currently toggled on/off.
   *  @param  graphicView     The GraphicView this VisualLocAttribute has to be drawn in.
   *  @param  g2d             The Graphics2D object we're painting with. 
   */
  public VisualLocAttribute( String compositeName, String type, String prodType, String[] allNames, Color color, Color selColor, Color textColor, SelectedItemController itemControl, AttrOnOffToggler attrToggler, GraphicView graphicView, Graphics2D g2d  ) {
    super( compositeName, type, prodType, color, selColor, textColor, itemControl, attrToggler, graphicView, g2d );
    this.allNames = allNames;
  }
  
  /**
   *  @return   A string array with all names the composite name of the local attribute exists of and the composite name itself.
   */
  public String[] getAllNames() {
    return allNames;
  }
}
