package visage.visual;

import java.awt.BorderLayout;
import visage.bridge.*;

/**
 *  Class that controls what to do when an item is selected or when an attribute relation is selected.
 */
public class SelectedItemController {

  private RectangularVisualItem selItem;
/*  private AttrRelView attrRelView;*/
  private AttrRelInfo[] relInfo;

  private CodePanel codePanel;
  private GraphicView view;
	private GraphicViewFrame viewframe;
	
    
  /**
   *  Creates a new SelectedItemController.
   *
   *  @param  attrRelView     The attribute relations view in the GraphicViewFrame.
   *  @param  codepanel       The panel which contains the code and some labels
   *  @param  relInfo         Array of all attribute relation info objects for this production rule.
   */
  public SelectedItemController( GraphicViewFrame viewframe, AttrRelInfo[] relInfo ) {
/*    this.attrRelView = attrRelView;*/
    this.viewframe = viewframe;
    this.relInfo = relInfo;
		this.codePanel = null;
  }
  
  /**
   *  Sets the GraphicView this SelectedItemController has to control.
   *
   *  @param  view  The GraphicView to control.
   */
  public void setGraphicView( GraphicView view ) {
    this.view = view;
  }

  /**
   *  Sets a rectangularVisualItem selected and shows it's attribute relations in
   *  the attribute relation view (by calling method setAttrRelView).
   *
   *  @param  selItem   The RectangularVisualItem to select.
   */
  public void setSelectedItem( RectangularVisualItem selItem ) {
    if( selItem.toggledOn() ) {
      if( this.selItem!=null ) { this.selItem.setSelected( false ); }
      //if( this.selAttrRel!=null ) { this.selAttrRel.setSelected( false ); }
      this.selItem = selItem;
      selItem.setSelected( true );
      setAttrRelView( selItem );
    }
    else {
    }		
    view.repaint();
  }
  
  private String buildName (String child, String attr) {
    if (child.equals(""))
      return attr;
    else
      if (attr.equals(""))
        return child;
      else
        return (child + "." + attr);
  }
  
  /**
   *  Method that sets the attribute relation view for a given RectangularVisualItem.
   *
   **  @param  selItem   The RectangularVisualItem to set the attribute relation view for.
   */
  public void setAttrRelView( RectangularVisualItem selItem ) {
	  String position, fullpatdescr, code, header, defname;
    VisualAttrRel[] toSels = selItem.getVisualToAttrRels();
		VisualAttrRel[] fromSels = selItem.getVisualFromAttrRels();
    AttrLabel[] labels = new AttrLabel[fromSels.length];
    AttrRelInfo info;
    String name = "";
    int j;
        		
    for( j=0; j < fromSels.length; j++ ) {
      info = fromSels[j].getAttrRelInfo();
      labels[j] = new AttrLabel( info.getToChildName() + "." +  info.getToAttrName(), j, this );
    }

    if (toSels.length > 0) {
  		info = toSels[0].getAttrRelInfo();
  		name = buildName( info.getToChildName(), info.getToAttrName());
          
      if( info.isCopyRule() ) {
        position = "";
      } 
      else {
        position = info.getPosition();
      }
      code = info.getCode();
      fullpatdescr = info.getFullPat();
		}
		else {
			code = null;
      fullpatdescr = null;
			position = null;
      name = null;
		  if (fromSels.length > 0) {
			  AttrRelInfo info2 = fromSels[0].getAttrRelInfo();
  			name = buildName( info2.getFromChildName(), info2.getFromAttrName());
			}
		}		
		if (codePanel != null) {
		  viewframe.getContentPane().remove(codePanel);
		}
		codePanel = new CodePanel(name, position, labels, fullpatdescr, code );
	  viewframe.getContentPane().add(codePanel, BorderLayout.SOUTH);
		viewframe.validate();
		viewframe.repaint();
  }
  
  /**
   *  Sets an attribute relation in the attribute relation view selected and shows it's details
   *  in the code detail area (by calling method setCodeDetailArea).
   *
   *  @param  attrRelId   The id of the attribute relation.
   */
  public void setSelectedAttrRel( int attrRelId ) {
		System.out.println("TODO");
/*    if( this.selAttrRel!=null ) { this.selAttrRel.setSelected( false ); }
    this.selAttrRel = attrRelsToSel[attrRelId];
    selAttrRel.setSelected( true );
//    setCodeDetailArea( selAttrRel );
    view.bringAttrRelToFront( attrRelsToSel[attrRelId] );
    view.repaint();*/
  }  
}
