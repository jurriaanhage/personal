package visage.visual;

/**
 *  View containing textual representations of a set of production-rules.
 */
public class ProductionsView extends AbstractView {
  
  /**
   *  Creates a new ProductionsView.
   */
  public ProductionsView() {
    super();
  }

  /**
   *  Sets the view to display the given labels and header.
   *
   *  @param  prodlabels  An array containing ProductionLabels.
   *  @param  headerText  The text to be set as the header of this view.
   */
  public void setView( ProductionLabel[] prodlabels, String headerText ) {
    super.setView( prodlabels, headerText );
  }
}
