package visage.visual;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.BasicStroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.QuadCurve2D;
import java.awt.geom.RectangularShape;
import visage.bridge.AttrRelInfo;

/**
 *  Visual representation of relation between two RectangularVisualItems.
 */
public class VisualAttrRel extends VisualItem {
  
  private AttrRelInfo info;
  private GeneralPath arrow;
  private RectangularVisualItem toItem, fromItem;
  private final double LOOPFACTOR = 2.0;
  private final double CURVEFACTOR = 1.5;
  private final int ARROWTHICKNESS = 5;
  private final int ARROWLENGTH = 10;
  private final int EXTRA = 2* ARROWTHICKNESS;
    
  private static Stroke dashedStroke = 
	  new BasicStroke(
          1, 
          BasicStroke.CAP_BUTT,
          BasicStroke.JOIN_BEVEL,
          0,
          new float[] {9}, 
          0
        );;
	
  /**
   *  Creates a new VisualAttrRel.
   *
   *  @param  toItem    The RectangularVisualItem which represents the attribute that depends on the value of the fromItem.
   *  @param  fromItem  The RectangularVisualItem that's the item which value is of importance for the value of the toItem.
   *  @param  info      AttrRelInfo object which conatins all the info about this relation.
   *  @param  color     The color of this visual item.
   *  @param  selColor  The color when selected.
   */
  public VisualAttrRel( RectangularVisualItem toItem, RectangularVisualItem fromItem, AttrRelInfo info, Color color, Color selColor ) {
    super( color, selColor );
    this.info = info;
    this.toItem = toItem;
    this.fromItem = fromItem;
    toItem.addToVisualAttrRel( this );
    if (!dummyItem()) fromItem.addFromVisualAttrRel( this );
  }
  
  public boolean dummyItem( ) {
    return (fromItem == null);
  }
  
  /**
   *  @return   Returns true if both the to- and fromItem are currently toggled on (in that case this relation has to be toggled on too).
   */
  public boolean toggledOn() {
    if (dummyItem()) 
      return toItem.toggledOn();
    else  
      return toItem.toggledOn() && fromItem.toggledOn();
  }
  
  /**
   *  Paints this item. (First decides whether to paint a lineair or a curved line.)
   *
   *  @param  heightDif   The heightDifference between the bottom of the non-terminal- and the top of the childrenitems.
   *  @param  g2d         The Graphics2D object we're painting with.
   */
  public void paintItem( double heightDif, Graphics2D g2d ) {
    if( !dummyItem() && toggledOn() ) {
		  Stroke oldStroke = null;
      RectangularShape toShape = toItem.getRect();
      RectangularShape fromShape = fromItem.getRect();
      
			if (info.isCopyRule()) {
			  oldStroke = g2d.getStroke();			
   		  g2d.setStroke(dashedStroke);						    
			}
      if (toItem == fromItem) // Handle loops.
        paintLoopItem ( info.getToChildNameIntVal() <= -1, LOOPFACTOR*toShape.getHeight(), toShape.getMinX(), toShape.getCenterY(), toShape.getMaxX(), toShape.getCenterY(), g2d);
      else if( info.getToChildNameIntVal() <= -1 && info.getFromChildNameIntVal() >= 0 ) { // From lhs/loc to one of the children
        paintItem( toShape.getCenterX(), toShape.getMaxY(), fromShape.getCenterX(), fromShape.getMinY(), g2d );
      }
      else if( info.getToChildNameIntVal() >= 0 && info.getFromChildNameIntVal() <= -1 ) { // From one of the children to lhs/loc.
        paintItem( toShape.getCenterX(), toShape.getMinY(), fromShape.getCenterX(), fromShape.getMaxY(), g2d );
      }
      else if( info.getToChildNameIntVal() >= 0 && info.getFromChildNameIntVal() >= 0 ) { // Between children
        paintItem( info.getToChildNameIntVal() >=0 , heightDif, toShape.getCenterX(), toShape.getMinY(), fromShape.getCenterX(), fromShape.getMinY(), g2d ); 
      }
      else if( info.getToChildNameIntVal() <= -1 && info.getFromChildNameIntVal() <= -1 ) { // Between any combination of loc/lhs attributes
        paintItem( info.getToChildNameIntVal() >= 0, heightDif, toShape.getCenterX(), toShape.getMaxY(), fromShape.getCenterX(), fromShape.getMaxY(), g2d );
      }
			if (info.isCopyRule()) {
  			g2d.setStroke(oldStroke);
			}	
      this.validate();      
    }    
  }
  
  /**
   *  Calculates the center x-coordinate between two RectangularVisualItems.
   *
   *  @param  toShape     The shape of the toItem.
   *  @param  fromShape   The shape of the fromItem.
   */
  private double calculateMiddleX( RectangularShape toShape, RectangularShape fromShape ) {
    double toX = toShape.getCenterX();
    double fromX = fromShape.getCenterX();
    
    if( toX > fromX ) { return fromX + (toX - fromX)/2; }
    else { return toX + (fromX - toX)/2; }
  }
  
  /**
   *  Paints a linear attribute relation.
   *
   *  @param  tox     x-coordinate of where the line has to start.
   *  @param  toy     y-coordinate of where the line has to start.
   *  @param  fromx   x-coordinate of where the line has to end.
   *  @param  fromy   y-coordinate of where the line has to end.
   *  @param  g2d     The Graphics2D onject we're painting with.
   */
  private void paintItem( double tox, double toy, double fromx, double fromy, Graphics2D g2d ) {
    Line2D.Double line = new Line2D.Double( fromx, fromy, tox, toy );
    
    if( selected )  { g2d.setColor( selColor ); } 
    else            { g2d.setColor( color ); }
    g2d.draw( line );
    
    double arrowHeadX, arrowHeadY;
    if( tox<fromx ) { arrowHeadX = tox+(fromx-tox)/4; }
    else            { arrowHeadX = tox-(tox-fromx)/4; }
    if( toy<fromy ) { arrowHeadY = toy+(fromy-toy)/4; }
    else            { arrowHeadY = toy-(toy-fromy)/4; }
    paintArrow( arrowHeadX, arrowHeadY, fromx, fromy, g2d );
  }

  /**
   *  Paints a curved attribute relation.
   *
   *  @param  bool    curve up or down?
   *  @param  heightDif maximum curve displacement
   *  @param  tox     x-coordinate of where the line has to start.
   *  @param  toy     y-coordinate of where the line has to start.
   *  @param  xcontr  x-coordinate of the control point of the curved line.
   *  @param  ycontr  y-coordinate of the control point of the curved line.
   *  @param  fromx   x-coordinate of where the line has to end.
   *  @param  fromy   y-coordinate of where the line has to end.
   *  @param  g2d     The Graphics2D object we're painting with.
   */
  private void paintItem( boolean up, double heightDif, double tox, double toy, double fromx, double fromy, Graphics2D g2d ) {
    double displacement = Math.min(heightDif, CURVEFACTOR*Math.abs(tox - fromx));
    if (tox - fromx < 0) displacement += EXTRA;
    else displacement -= EXTRA;
     
    double xcontr = (tox + fromx)/2;
    double ycontr;
    if (up) ycontr = toy - displacement;
    else ycontr = toy + displacement;
    QuadCurve2D.Double curve = new QuadCurve2D.Double( tox, toy, xcontr, ycontr, fromx, fromy );
    
    if( selected )  { g2d.setColor( selColor ); } 
    else            { g2d.setColor( color ); }
    g2d.draw( curve );
    
    double middleMaxYItems;
    if( toy<fromy ) { middleMaxYItems = toy+(fromy-toy)/2; }
    else            { middleMaxYItems = fromy+(toy-fromy)/2; }
    double arrowHeadY;
    if( toy<ycontr )  { arrowHeadY = middleMaxYItems+(curve.getFlatness()/2); }
    else              { arrowHeadY = middleMaxYItems-(curve.getFlatness()/2); }
    
    if( tox<fromx ) { paintArrow( xcontr-5, arrowHeadY, xcontr+100, arrowHeadY, g2d ); }
    else            { paintArrow( xcontr+5, arrowHeadY, xcontr-100, arrowHeadY, g2d ); }
  }
  
  /**
   *  Paints a curved attribute relation.
   *
   *  @param  uploop  true if the loop goes up
   *  @param  displacement difference in Y with the up/low end of the loop
   *  @param  tox     x-coordinate of where the line has to start.
   *  @param  toy     y-coordinate of where the line has to start.
   *  @param  fromx   x-coordinate of where the line has to end.
   *  @param  fromy   y-coordinate of where the line has to end.
   *  @param  g2d     The Graphics2D object we're painting with.
   */
  private void paintLoopItem( boolean uploop, double displacement, double tox, double toy, double fromx, double fromy, Graphics2D g2d ) {
    double xcontr = (fromx + tox) / 2, ycontr;
    if (uploop) ycontr = toy - displacement;
    else ycontr = toy + displacement;
    
    QuadCurve2D.Double curve = new QuadCurve2D.Double( tox, toy, xcontr, ycontr, fromx, fromy );
    
    if( selected )  { g2d.setColor( selColor ); } 
    else            { g2d.setColor( color ); }
    g2d.draw( curve );

    double middleMaxYItems;
    if( toy<fromy ) { middleMaxYItems = toy+(fromy-toy)/2; }
    else            { middleMaxYItems = fromy+(toy-fromy)/2; }
    double arrowHeadY;
    if( toy<ycontr )  { arrowHeadY = middleMaxYItems+(curve.getFlatness()/2); }
    else              { arrowHeadY = middleMaxYItems-(curve.getFlatness()/2); }
    
    if( tox<fromx ) { paintArrow( xcontr-5, arrowHeadY, xcontr+100, arrowHeadY, g2d ); }
    else            { paintArrow( xcontr+5, arrowHeadY, xcontr-100, arrowHeadY, g2d ); }
  }

  /**
   *  Paints the arrow of this relation.
   *
   *  @param  xhead   x-coordinate of the head of the arrow.
   *  @param  yhead   y-coordinate of the head of the arrow.
   *  @param  xdir    x-coordinate of the direction of the arrow.
   *  @param  ydir    y-coordinate of the direction of the arrow.
   *  @param  g2d     The Graphics2D onject we're painting with.
   */
  private void paintArrow( double xhead, double yhead, double xdir, double ydir, Graphics2D g2d ) {
    double arrowEndY;
    
    if( yhead<ydir ) {
      arrowEndY = yhead+ARROWLENGTH;
    }
    else {
      arrowEndY = yhead-ARROWLENGTH;
    }
    
    arrow = new GeneralPath();
    arrow.moveTo( (float) xhead, (float) yhead );
    arrow.lineTo( (float) xhead+ARROWTHICKNESS, (float) arrowEndY );
    arrow.lineTo( (float) xhead-ARROWTHICKNESS, (float) arrowEndY );
    arrow.closePath();
    
    g2d.rotate( -Math.atan( (xhead-xdir) / (yhead-ydir) ), xhead, yhead );
    if( selected )  { g2d.setColor( selColor ); } 
    else            { g2d.setColor( color ); }
    g2d.fill( arrow );
    g2d.rotate( Math.atan( (xhead-xdir) / (yhead-ydir) ), xhead, yhead );    
  }
  
  /**
   *  @return   The AttrRelInfo object of this relation.
   */
  public AttrRelInfo getAttrRelInfo() {
    return info;
  }
}
