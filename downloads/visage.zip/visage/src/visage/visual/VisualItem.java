package visage.visual;

import java.awt.Color;
import javax.swing.JComponent;

/**
 *  Abstract class for all VisualItems that can be painted in the GraphicView.
 */
public abstract class VisualItem extends JComponent {
  
  protected Color color, selColor;
  protected boolean selected;
  
  /**
   *  Constructs a new VisualItem and sets it deselected.
   *
   *  @param  color     The color of this VisualItem.
   *  @param  selColor  The color of this VisualItem when selected.
   */
  public VisualItem( Color color, Color selColor ) {
    super();   
    this.color = color;
    this.selColor = selColor;
    this.selected = false;
  }
  
  /**
   *  Method to set this VisualItem selected or not.
   *
   *  @param  selected   Boolean value indicating whether we want to select or deselect this item.
   */
  public void setSelected( boolean selected ) {
    this.selected = selected;
  }
}
