package visage.visual;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Font;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

import visage.ProductionsController;

/**
 *  A label representing a production rule.
 */
public class ProductionLabel extends JLabel implements MouseListener {
  
  private int prodRuleId; //id of a combination of a nt and one of it's alternatives <- production rule
  private ProductionsController controller;
  
  /**
   *  Creates a new ProductionLabel
   *
   *  @param  prodRuleId  Id of a combination of a nt and one of it's alternatives <- production rule.
   *  @param  nt          The name of the non-terminal.
   *  @param  childTypes  String[] containing all the types of the children.
   *  @param  controller  The ProductionsController controlling which production rules are displayed.
   */
  public ProductionLabel( int prodRuleId, String con, String nt, String[] childTypes, ProductionsController controller ) {
    super();
    this.prodRuleId = prodRuleId;
    this.controller = controller;
    this.setOpaque( true );
    this.setFont( new Font( "Sans Serif", Font.BOLD, 13 ) );
    this.setText( createText( con, nt, childTypes ) );
    this.setBackground( Color.WHITE );
    FontMetrics fm = this.getFontMetrics( this.getFont() );
    int width = (int) fm.stringWidth( this.getText() );
    int height = (int) fm.getHeight();
    this.setPreferredSize( new java.awt.Dimension ( width, height ) );
    this.setToolTipText( this.getText() );
    this.addMouseListener( this );
  }
  
  /**
   *  Creates the text for this label representing the production rule.
   *
   *  @param  nt          The name of the non-terminal.
   *  @param  childTypes  String[] containing all the types of the children.
   *  @return             The text for this label.
   */
  private String createText( String con, String nt, String[] childTypes ) {
    String text = con + " : " + nt + " -> ";
    for( int i=0; i<childTypes.length; i++ ) {
      text += childTypes[i] + " ";
    }
    return text; 
  }
  
  /**
   *  When this label is clicked it's corresponding GraphicViewFrame will be opened by the PorductionsController.
   */
  public void mouseClicked( MouseEvent me ) {
    controller.showDetails( prodRuleId, this.getText() );
  }
  
  
  public void mousePressed( MouseEvent me ) {
  }
  
  
  public void mouseReleased( MouseEvent me ) {
  }
  
  
  public void mouseEntered( MouseEvent me ) {
  }
  
  
  public void mouseExited( MouseEvent me ) {
  }
}
