package visage.visual;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.util.Vector;
import visage.bridge.*;
import visage.model.*;
import visage.util.*;
import visage.Debug;

/**
 *  A view which holds the whole graphical representation of a production rule.
 */
public class GraphicView extends JPanel {
  
  private int prodRuleId;
  private ProductionsBridge prodBridge;
  private Container contentPane;
  private VisualProductionType visualNt;
  private VisualProductionType[] visualChildren;
  private VisualAttrRel[] visualAttrRels;
  private VisualLocAttribute[] visualLocAttributes;
  private boolean initNotDone;
  private SelectedItemController itemControl;
  private AttrOnOffToggler attrToggler;
  private JScrollPane graphicPane;
  private static final Color PRODTYPE_COLOR = Color.BLUE;
  private static final Color PRODTYPE_COLOR_SEL = Color.BLUE.darker();
  private static final Color PRODTYPE_TEXTCOLOR = Color.WHITE;
  private static final Color ATTR_DEF_COLOR = Color.RED;
  private static final Color ATTR_DEF_COLOR_SEL = Color.RED.darker();
  private static final Color ATTR_USE_COLOR = Color.GRAY;
  private static final Color ATTR_USE_COLOR_SEL = Color.DARK_GRAY;
  private static final Color ATTR_TEXTCOLOR = Color.WHITE;
  private static final Color ATTRREL_COLOR = Color.BLACK;
  private static final Color ATTRREL_COLOR_SEL = Color.WHITE;
  
  private static final Color LOCATTR_COLOR = new Color( 240, 230, 30 );
  private static final Color LOCATTR_COLOR_SEL = LOCATTR_COLOR.darker();
  private static final Color LOCATTR_TEXTCOLOR = Color.BLACK;
  private static final double GAP_BETWEEN_ATTRS = 10;
  private static final double GAP_BETWEEN_CHILDREN = 70;
  private static final double HEIGHTDIF_BETWEEN_INH_SYN = 10;
  private static final double HEIGHTDIF_BETWEEN_NT_LOCATTRS = 20; //relative to the VisualProductionType
  private static final double STANDARD_HEIGHTDIF_BETWEEN_NT_CHILDREN = 200;
  private static final double HEIGHTDIF_BETWEEN_NT_CHILDREN_INCR_UNIT = 10;
  
  /**
   *  Constructs a new GraphicView.
   *
   *  @param  prodRuleId  The Id of the production rule we want to display (used by the ProductionsBridge to get the right info)
   *  @param  prodBridge  The ProductionsBridge where we get all the info from to display the right information about the given production rule.
   *  @param  itemControl The SelectedItemController which keeps track of which items are selected and where to display which information.
   *  @param  attrToggler The AttrOnOffToggler which keeps track off all the attributes that are currently toggled off for the whole loaded file.
   */
  public GraphicView( int prodRuleId, ProductionsBridge prodBridge, SelectedItemController itemControl, AttrOnOffToggler attrToggler, JScrollPane graphicPane ) {
    super();
    this.prodRuleId = prodRuleId;
    this.prodBridge = prodBridge;
    this.initNotDone = true;
    this.itemControl = itemControl;
    this.attrToggler = attrToggler;
    this.graphicPane = graphicPane;
    itemControl.setGraphicView( this );
    this.setOpaque( true );
    this.setBackground( Color.LIGHT_GRAY );
    this.setLayout( null );
    this.setVisible( true );
  }
  
  private void debug ( String s ) {
    Debug.output( s, Debug.GRAPHIC_VIEW);
  }
  
  /**
   *  Creates all the VisualItems used to graphically represent the production rule, except for the VisualAttrRels.
   *
   *  @param g2d  The Graphics2D object from paintComponent().
   */
  private void createVisualItems( Graphics2D g2d ) {
    createNtVisualItems( g2d );
    createChildrenVisualItems( g2d );
    createLocAttrVisualItems( g2d );
  }
  
  /**
   *  Creates a VisualProductionType representing the non-terminal and it's VisualAttributes.
   *  The VisualProductionType is stored in the visualNt variable, and it's attributes 
   *  are stored in the VisualProductionType itself.
   *  Method uses the ProductionsBridge to get it's info.
   *
   *  @param g2d  The Graphics2D object from paintComponent().
   */
  private void createNtVisualItems( Graphics2D g2d ) {
    Attr[] attrs;
    VisualAttribute[] inh, syn;
    
    attrs = prodBridge.getNtInhAttr( prodRuleId );
    inh = new VisualAttribute[attrs.length];
    for( int i=0; i<attrs.length; i++ ) {
      inh[i] = new VisualAttribute( attrs[i].getName(), attrs[i].getType(), prodBridge.getNt( prodRuleId ), ATTR_USE_COLOR, ATTR_USE_COLOR_SEL, ATTR_TEXTCOLOR, itemControl, attrToggler, this, g2d );
      this.add( inh[i] );
    }
    
    attrs = prodBridge.getNtSynAttr( prodRuleId );
    syn = new VisualAttribute[attrs.length];
    for( int i=0; i<attrs.length; i++ ) {
      syn[i] = new VisualAttribute( attrs[i].getName(), attrs[i].getType(), prodBridge.getNt( prodRuleId ), ATTR_DEF_COLOR, ATTR_DEF_COLOR_SEL, ATTR_TEXTCOLOR, itemControl, attrToggler, this, g2d );
      this.add( syn[i] );
    }
    
    visualNt = new VisualProductionType( "lhs" /*prodBridge.getCon( prodRuleId )*/, prodBridge.getNt( prodRuleId ), PRODTYPE_COLOR, PRODTYPE_COLOR_SEL, PRODTYPE_TEXTCOLOR, itemControl, inh, syn, g2d );
    this.add( visualNt );
  }
  
  /**
   *  Creates the VisualProductionTypes to represent the Children and their VisualAttributes.
   *  The VisualProductionTypes are stored in the visualChildren array, and their attributes 
   *  are stored in the VisualProductionTypes itself.
   *  Method uses the ProductionsBridge to get it's info.
   *
   *  @param g2d  The Graphics2D object from paintComponent().
   */
  private void createChildrenVisualItems( Graphics2D g2d ) {
    Attr[] attrs;
    Child child;
    VisualAttribute[] inh, syn;
    
    visualChildren = new VisualProductionType[prodBridge.getNumChildren( prodRuleId )];
    for( int j=0; j<prodBridge.getNumChildren( prodRuleId ); j++ ) {
      child = prodBridge.getChild( prodRuleId, j );
      attrs = child.getInh();
      inh = new VisualAttribute[attrs.length];
      for( int i=0; i<attrs.length; i++ ) {
        inh[i] = new VisualAttribute( attrs[i].getName(), attrs[i].getType(), child.getTp(), ATTR_DEF_COLOR, ATTR_DEF_COLOR_SEL, ATTR_TEXTCOLOR, itemControl, attrToggler, this, g2d );
        this.add( inh[i] );
      }
    
      attrs = child.getSyn();
      syn = new VisualAttribute[attrs.length];
      for( int i=0; i<attrs.length; i++ ) {
        syn[i] = new VisualAttribute( attrs[i].getName(), attrs[i].getType(), child.getTp(), ATTR_USE_COLOR, ATTR_USE_COLOR_SEL, ATTR_TEXTCOLOR, itemControl, attrToggler, this, g2d );
        this.add( syn[i] );
      }
      
      visualChildren[j] = new VisualProductionType( child.getName(), child.getTp(), PRODTYPE_COLOR, PRODTYPE_COLOR_SEL, PRODTYPE_TEXTCOLOR, itemControl, inh, syn, g2d );
      this.add( visualChildren[j] );
    }
  }
  
  /**
   *  Creates all the VisualLocAttributes and stores them in the visualLocAttributes array.
   *  Method uses the ProductionsBridge to get it's info.
   *
   *  @param g2d  The Graphics2D object from paintComponent().
   */
  private void createLocAttrVisualItems( Graphics2D g2d ) {
    String[] locAttrNames = prodBridge.getCompositeLocAttrNames( prodRuleId );
    Vector allLocAttrNames = prodBridge.getAllLocAttrNames( prodRuleId );
    visualLocAttributes = new VisualLocAttribute[locAttrNames.length];
    
    for( int i=0; i<locAttrNames.length; i++ ) {
      String[] allNames = (String[]) allLocAttrNames.elementAt( i );
      visualLocAttributes[i] = new VisualLocAttribute( locAttrNames[i], "Pattern", prodBridge.getNt( prodRuleId ), allNames, LOCATTR_COLOR, LOCATTR_COLOR_SEL, LOCATTR_TEXTCOLOR, itemControl, attrToggler, this, g2d );
      this.add( visualLocAttributes[i] );
    }
  }
  
  /**
   *  Calculates the center x-coordinate of the VisualProductionType representing the non-terminal.
   *  Used to determine the right coordinates for the VisualItems
   */
  private double calculateMiddleXNt() {
    double result = 0;
    VisualAttribute[] inhAttrNt = visualNt.getInhVisualAttributes();
    
    for( int i=0; i<inhAttrNt.length; i++ ) {
      result += inhAttrNt[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
    }
    result += visualNt.getPreferredSize().getWidth()/2;
    
    return result;
  }
  
  /**
   *  Calculates the x-coordinate that lies in the center between the first- and the last VisualProductionType representing the Children.
   *  Used to determine the right coordinates for the VisualItems
   */
  private double calculateMiddleXChildren() {
    double result = 0;
    double resBetweenProdTypes = 0;
    double temp;
    VisualAttribute[] vas;
        
    for( int i=0; i<visualChildren.length; i++ ) {
      //inherited attrs
      vas = visualChildren[i].getInhVisualAttributes();
      for( int j=0; j<vas.length; j++ ) {
        temp = vas[j].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
        result += temp;
        if( i>0 ) { resBetweenProdTypes += temp; }
      }
      //child
      temp = visualChildren[i].getPreferredSize().getWidth();
      result += temp;
      resBetweenProdTypes += temp;
      if( i==visualChildren.length-1 ) {
        break;
      }
      //synthesized attrs
      vas = visualChildren[i].getSynVisualAttributes();
      for( int j=0; j<vas.length; j++ ) {
        temp = vas[j].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS; //last gap actually has to be subtracted but we lacked to count one gap for the child so it's ok
        result += temp;
        resBetweenProdTypes += temp;
      }
      result += GAP_BETWEEN_CHILDREN;
      resBetweenProdTypes += GAP_BETWEEN_CHILDREN;
    }
    
    return result - (resBetweenProdTypes/2);
  }
  
  /**
   *  Creates all the VisualAttrRels belonging to the production rule we're representing.
   *  Method uses the ProductionsBridge to get it's info.
   *
   *  @param g2d  The Graphics2D object from paintComponent().
   */
  private void createVisualAttrRels( Graphics2D g2d ) {
    AttrRelInfo[] info = prodBridge.getAttrRelInfo( prodRuleId );
    AttrRelInfo tempInfo;
    RectangularVisualItem toItem, fromItem;
    visualAttrRels = new VisualAttrRel[info.length];
    String attrName;
    int childIntVal;
    
    for( int i=0; i<info.length; i++ ) {    
        tempInfo = info[i];
        attrName = tempInfo.getToAttrName();        
        childIntVal = tempInfo.getToChildNameIntVal();

        if( childIntVal == -2 )       { toItem = searchLocAttr( visualLocAttributes, attrName ); }
        else if( childIntVal == -1 )  { toItem = searchAttr( visualNt.getSynVisualAttributes(), attrName ); }
        else                          { toItem = searchAttr( visualChildren[childIntVal].getInhVisualAttributes(), attrName ); }
    
        debug( "intval: " + tempInfo.getToChildNameIntVal() + " toattrname: " + tempInfo.getToAttrName() + " tochildname: " + tempInfo.getToChildName() + " item: " + toItem + "\nPOSITION: " + tempInfo.getPosition() );

        if (tempInfo.getFromAttrName() == null) {
          debug("No from for "+attrName);
          visualAttrRels[i] = new VisualAttrRel( toItem, null, tempInfo, ATTRREL_COLOR, ATTRREL_COLOR_SEL);     
          continue; // Not really an attrRel.
        }
        else {
          attrName = tempInfo.getFromAttrName();
          childIntVal = tempInfo.getFromChildNameIntVal();
          if( childIntVal == -2 )       { fromItem = searchLocAttr( visualLocAttributes, attrName ); }
          else if( childIntVal == -1 )  { fromItem = searchAttr( visualNt.getInhVisualAttributes(), attrName ); }
          else {
            if( attrName.equals( "" ) ) { fromItem = visualChildren[childIntVal]; }
            else                        { fromItem = searchAttr( visualChildren[childIntVal].getSynVisualAttributes(), attrName ); }
          }
          debug( "intval: " + tempInfo.getFromChildNameIntVal() + " fromattrname: " + tempInfo.getFromAttrName() + " fromchildname: " + tempInfo.getFromChildName() + " item: " + fromItem + "\nPOSITION: " + tempInfo.getPosition() );
 
          visualAttrRels[i] = new VisualAttrRel( toItem, fromItem, tempInfo, ATTRREL_COLOR, ATTRREL_COLOR_SEL);
        }          
      }
  }
  
  /**
   *  Method used searches for a VisualAttribute with the given name.
   *
   *  @param  attrs            An array of VisualAttributes in which we want to search.
   *  @param  attrName         The name of the attribute.
   *  @return                  The found corresponding VisualAttribute.
   */
  private VisualAttribute searchAttr( VisualAttribute[] attrs, String attrName ) {
    for( int i=0; i<attrs.length; i++ ) {
      if( attrName.equals( attrs[i].getName() ) ) { return attrs[i]; }
    }
    return null; //didn't find such an item -> too bad :-S
  }
  
  /**
   *  Method used searches for a VisualLocAttribute with the given name.
   *
   *  @param  attrs            An array of VisualLocAttributes in which we want to search.
   *  @param  attrName         The name of the local attribute.
   *  @return                  The found corresponding VisualLocAttribute.
   */
  private VisualAttribute searchLocAttr( VisualLocAttribute[] attrs, String attrName ) {
    for( int i=0; i<attrs.length; i++ ) {
      String[] attrNames = attrs[i].getAllNames();
      for( int j=0; j<attrNames.length; j++ ) {
        if( attrName.equals( attrNames[j] ) ) { return attrs[i]; }
      }
    }
    return null; //didn't find such an item -> too bad :-S
  }
  
  
  /**
   *  @return  The height difference between the non-terminal visual items and the children visual items.
   */
  private double calculateHeightDif() {
    RectangularVisualItem rvi;
    VisualAttribute[] vattrs = visualNt.getSynVisualAttributes();
    
    if( vattrs.length>0 ) { rvi = vattrs[vattrs.length-1]; }
    else                  { rvi = visualNt; }
    return calculateYPosChildren( rvi.getRect().getMinY() ) - rvi.getRect().getMaxY();
  }
  
  /**
   *  Sets a given VisualAttrRel to be the last element in the visualAttrRels array, so it'll be at the front of the graphical representation.
   *
   *  @param  var The VisualAttrRel to be displayed at the front of the representation.
   */
  public void bringAttrRelToFront( VisualAttrRel var ) {
    for( int i=0; i<visualAttrRels.length; i++ ) {
      if( visualAttrRels[i] == var ) {
        visualAttrRels[i] = visualAttrRels[visualAttrRels.length-1];
        visualAttrRels[visualAttrRels.length-1] = var;
        break;
      }
    }
  }
  
  /**
   *  Paints all the VisualProductionTypes, VisualAttributes and VisualLocAttributes at their right locations.
   *
   *  @param g2d  The Graphics2D object to paint stuff.
   */
  private void paintItems( Graphics2D g2d ) {
    //calculate begin coordinates//
    double startXNt, startXChildren;
    double middleXNt = calculateMiddleXNt();
    double middleXChildren = calculateMiddleXChildren();
    double middleXViewport = graphicPane.getViewportBorderBounds().getWidth()/2;
    if( middleXNt < middleXViewport && middleXChildren < middleXViewport ) {
      startXNt        = middleXViewport - middleXNt;
      startXChildren  = middleXViewport - middleXChildren;
    }
    else if( middleXNt < middleXChildren ) {
      startXNt        = middleXChildren - middleXNt;
      startXChildren  = 30;
    }
    else {
      startXNt        = 30;
      startXChildren  = middleXNt - middleXChildren;
    }
    
    //ntVisualItems and locAttrVisualItems//
    double x = startXNt;
    double y = 30;
    paintNtAndLocAttrs( x, y, g2d );
    
    //childrenVisualItems//
    x = startXChildren;
    y = calculateYPosChildren( y );
    paintChildren( x, y, g2d );
  }
  
  /**
   *  Paints the non-terminal with it's VisualAttributes and the local attributes, 
   *  starting at given x- and y-coordinate.
   *
   *  @param  x         The x-coordinate of where we start drawing (left uppercorner)
   *  @param  y         The y-coordinate of where we start drawing (left uppercorner)
   *  @param  g2d       The Graphics2D object to paint stuff.
   */
  private void paintNtAndLocAttrs( double x, double y, Graphics2D g2d ) {
    VisualAttribute[] inh, syn;
    
    inh = visualNt.getInhVisualAttributes();
    for( int i=0; i<inh.length; i++ ) {
      inh[i].paintItem( x, y, g2d );
      x += inh[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
    }
    
    y += HEIGHTDIF_BETWEEN_INH_SYN;
    visualNt.paintItem( x, y, g2d );
    x += visualNt.getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
    
    syn = visualNt.getSynVisualAttributes();
    for( int i=0; i<syn.length; i++ ) {
      syn[i].paintItem( x, y, g2d );
      x += syn[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
    }
    
    y -= HEIGHTDIF_BETWEEN_NT_LOCATTRS;
    for( int i=0; i<visualLocAttributes.length; i++ ) {
      visualLocAttributes[i].paintItem( x, y, g2d );
      x += visualLocAttributes[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
    }
  }
  
  /**
   *  Paints the children with their VisualAttributes, starting at given x- and y-coordinate.
   *
   *  @param  x         The x-coordinate of where we start drawing (left uppercorner)
   *  @param  y         The y-coordinate of where we start drawing (left uppercorner)
   *  @param  g2d       The Graphics2D object to paint stuff.
   */
  private void paintChildren( double x, double y, Graphics2D g2d ) {
    VisualAttribute[] inh, syn;
    
    for( int j=0; j<visualChildren.length; j++ ) {
      inh = visualChildren[j].getInhVisualAttributes();
      for( int i=0; i<inh.length; i++ ) {
        inh[i].paintItem( x, y, g2d );
        x += inh[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
      }
    
      visualChildren[j].paintItem( x, y, g2d );
      x += visualChildren[j].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
      y += HEIGHTDIF_BETWEEN_INH_SYN;
    
      syn = visualChildren[j].getSynVisualAttributes();
      for( int i=0; i<syn.length; i++ ) {
        syn[i].paintItem( x, y, g2d );
        x += syn[i].getPreferredSize().getWidth() + GAP_BETWEEN_ATTRS;
      }
      x += GAP_BETWEEN_CHILDREN - GAP_BETWEEN_ATTRS;
      y -= HEIGHTDIF_BETWEEN_INH_SYN;
    }
  }
  
  /**
   * Method calculates at which y-position the children should be drawn.
   * It uses the y-postion of the non-terminal, a given standard height difference between the 
   * non-terminal and the children. It also adds an extra given height for every relation that exists between attributes (and are toggled on).
   * The thought behind this last thing is that every relation makes the drawing more complex, so it needs extra space
   * to remain a bit readable.
   *
   * @param   yNt The y-position of the non-terminal (left upper-corner...).
   * @return      The y-position of the children (left upper-corner...).
   */
  
  private double calculateYPosChildren( double yNt ) {
    int numOfAttrRelsOn = 0;
    
    if( visualAttrRels!=null ) {    
      for( int i=0; i<visualAttrRels.length; i++ ) {
        if( (visualAttrRels[i] != null) && (visualAttrRels[i].toggledOn()) ) { numOfAttrRelsOn++; }
        else 
           debug( "VisualAttrRels["+i+"] not likely to be non-null" );
      }
    }
    
    return yNt + STANDARD_HEIGHTDIF_BETWEEN_NT_CHILDREN + numOfAttrRelsOn*HEIGHTDIF_BETWEEN_NT_CHILDREN_INCR_UNIT; 
  }
  
  /**
   *  Paints all the VisualAttrRels.
   *
   *  @param  g2d       The Graphics2D object to paint stuff.
   */
  private void paintAttrRels( Graphics2D g2d ) {
    for( int i=0; i<visualAttrRels.length; i++ ) 
      if (visualAttrRels[i] != null) {
        visualAttrRels[i].paintItem( calculateHeightDif(), g2d );
      }
  }
  
  /**
   *  @return   The size of this graphical representation.
   */
  public Dimension calculateSize() {
    VisualAttribute[] vattrs;
    RectangularVisualItem ntrvi, childrvi;
    double width, height;
    
    if( visualLocAttributes.length>0 ) {
      ntrvi = visualLocAttributes[visualLocAttributes.length-1];
    }
    else {
      vattrs = visualNt.getSynVisualAttributes();
      if( vattrs.length>0 ) { ntrvi = vattrs[vattrs.length-1]; }
      else                  { ntrvi = visualNt; }
    }
    
    if( visualChildren.length>0 ) {
      vattrs = visualChildren[visualChildren.length-1].getSynVisualAttributes();
      if( vattrs.length>0 ) { childrvi = vattrs[vattrs.length-1]; }
      else                  { childrvi = visualChildren[visualChildren.length-1]; } 
      width = Math.max( ntrvi.getRect().getMaxX(), childrvi.getRect().getMaxX() ) + 30;
      height = childrvi.getRect().getMaxY() + 30;
    }
    else {
      width = ntrvi.getRect().getMaxX() + 30;
      height = visualNt.getRect().getMaxY() + 30;
    }

    Dimension d = new Dimension();
    d.setSize( width, height );
    return d;
  }
  
  /**
   *  Method that sets the horizontal scrollbar of the pane this view is in, 
   *  so that the non-terminal is horizontally centered.
   */
  private void centerNonTerminal() {
    if( graphicPane.getHorizontalScrollBar()!=null ) {
      double centerXNt      = visualNt.getRect().getCenterX();
      double viewWidth      = this.getSize().getWidth();
      double viewportWidth  = graphicPane.getViewportBorderBounds().getWidth();
      int horScrollBarMax   = graphicPane.getHorizontalScrollBar().getMaximum();
      graphicPane.getHorizontalScrollBar().setValue( (int) ( ( ( centerXNt - ( viewportWidth / 2 ) ) / viewWidth  ) * horScrollBarMax ) );
    }
  }
  
  
  /**
   *  The paintComponent method where we get the Graphics2D object and paint all the items with it.
   *  If it's the first time this method is invoked it'll create all the items first.
   *  Method recalculates it's size at every repaint (in case attributes are toggled off/on).
   */
  public void paintComponent( Graphics g ) {
    Graphics2D g2d = (Graphics2D) g;
    super.paintComponent( g2d );
    if( initNotDone ) { 
      createVisualItems( g2d );
      paintItems( g2d ); //necessary because the x and y values must be set in order to create the VisualAttrRels
      createVisualAttrRels( g2d );
      paintAttrRels( g2d );
      this.setPreferredSize( calculateSize() );
      this.setBounds( 0, 0, (int) this.getPreferredSize().getWidth(), (int) this.getPreferredSize().getHeight() );
      this.validate();
      this.getTopLevelAncestor().validate();
      centerNonTerminal();
      this.initNotDone = false;
    }
    else {
      paintItems( g2d );
      paintAttrRels( g2d );
      this.setPreferredSize( calculateSize() );
      this.validate();
    }
  }
  
  
  /*public void repaint() {
    super.repaint();
  }*/
}
