package visage;

/**
 * Contains a static method which outputs a text to standard out when it's
 * level is set to true.
 */
 
public class Debug {

	public static final boolean PARSER = false;
  public static final boolean LOAD = false;
  public static final boolean CODE_EXTRACTOR = false;
  public static final boolean BRIDGE = false;
  public static final boolean GRAPHIC_VIEW = false;
  public static final boolean VISUAL_ATTRREL = false;
  public static final boolean STARTUP = false;
 
  /**
   *  Writes a debug line to system out.
   *
   *  @param  message   The debug message.
   *  @param  level     The level this debug message belongs to.
   */
	public static void output( String message, boolean level ) {
		if( level ) {
			System.out.println( message );
		}
	}
}
