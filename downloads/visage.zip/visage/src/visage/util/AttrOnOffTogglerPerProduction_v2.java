package visage.util;

import java.util.Vector;
import java.util.Enumeration;

/**
 *  Class which takes hold of all the Attributes that are toggled off for the currently loaded file.
 *  It uses the name of the attribute together with the name of the non-terminal or child to which it belongs as a key.
 */
public class AttrOnOffTogglerPerProduction_v2 {
  
  private Vector attrOff;
  
  /**
   *  Creates a new AttrOnOffToggler with all the attributes toggled on.
   */
  public AttrOnOffTogglerPerProduction_v2(  ) {
    attrOff = new Vector();
  }
  
  /**
   *  Toggles the attribute with the given key off.
   *
   *  @param  attrName  The name of the attribute, used as the 1st part of the key.
   *  @param  prodName  The type of the non-terminal or child the attribute belongs to, used as the 2nd part of the key.
   */
  public void toggleOff( String attrName, String prodType ) {
    String temp;
    boolean found = false;
    
    Enumeration e = attrOff.elements();
    while( e.hasMoreElements() ) {
      temp = (String) e.nextElement();
      if( temp.equals( attrName+prodType ) ) {
        found = true;
        break;
      }
    }
    if( !found ) { attrOff.add( attrName+prodType ); }
  }
  
  /**
   *  Toggles the attribute with the given key on.
   *
   *  @param  attrName  The name of the attribute, used as the 1st part of the key.
   *  @param  prodName  The type of the non-terminal or child the attribute belongs to, used as the 2nd part of the key.
   */
  public void toggleOn( String attrName, String prodType ) {
    String temp;
    
    Enumeration e = attrOff.elements();
    while( e.hasMoreElements() ) {
      temp = (String) e.nextElement();
      if( temp.equals( attrName+prodType ) ) {
        attrOff.removeElement( temp );
        break;
      }
    }
  }
  
  /**
   *  @param  attrName  The name of the attribute, used as the 1st part of the key.
   *  @param  prodName  The name of the non-terminal or child the attribute belongs to, used as the 2nd part of the key.
   *  @return           A boolean value indicating if the attribute meant with the given key is currently toggled off.
   */
  public boolean isOff( String attrName, String prodName ) {
    String temp;
    
    Enumeration e = attrOff.elements();
    while( e.hasMoreElements() ) {
      temp = (String) e.nextElement();
      if( temp.equals( attrName+prodName ) ) {
        return true;
      }
    }
    return false;
  }
}
