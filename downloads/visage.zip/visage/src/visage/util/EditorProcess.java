package visage.util;

import java.io.*;
import visage.Globals;

 /**
  * Class for handling access to editor.
  */
  
public class EditorProcess
{
    public EditorProcess () {
    }
    
    public static void callEditor(String filename, String row, String column) // throws IOException
    {
        File file = new File(filename);
        if (file == null)
            System.out.println("file is null");
        if (!file.exists() || !file.isFile()) {
            System.out.println("invalid file: "+filename);
            return;
        }    
       /* if (row < 0)
             throw new IllegalArgumentException("row < 0");
        if (column < 0)
            throw new IllegalArgumentException("column > 0");

        */
        String commandline = createCommandline(Globals.getGlobals().getEditorCommandlineTemplate(), filename, row, column);
        if (commandline.trim().equals(""))
            System.out.println("empty commandline");
        try {
           Runtime.getRuntime().exec(commandline, null, new File(Globals.getGlobals().getBasePath()) );
        }
        catch (IOException e) {
           System.out.println("Error while calling editor: "+e.toString());
        }
    }


    /**
     * Replaces in template;
     *
     *   %f  -> filename
     *   %r  -> row
     *   %c  -> column
     *   %%  -> %
     */

    public static String createCommandline(String template, String filename, String row, String column)
    {
        StringBuffer output = new StringBuffer();

        for(int i=0; i < template.length(); i++)
        {
            if (template.charAt(i) == '%' && i <= template.length())
            {
                i++;
                switch(template.charAt(i))
                {
                    case '%':
                        output.append('%');
                        break;

                    case 'f':
                     //   output.append("\"");
                        output.append(filename);
                     //   output.append("\"");
                        break;

                    case 'r':
                        output.append(row);
                        break;

                    case 'c':
                        output.append(column);
                        break;

                    default:
                        output.append('%');
                        output.append(template.charAt(i));
                        break;
                }
            }
            else
            {
                output.append(template.charAt(i));
            }
        }

        return output.toString();
    }
}
