package visage;


import java.io.*;
import java.util.*;


/**
 * A class containing many settable global values. The ones that govern the visualization can be found in 
 * classes in the visual directory, mainly GraphicViewFrame.
 * Some editor values are:
 *   ConText: "\"C:\\apps\\ConTEXT\\ConTEXT.exe\" %f /g%c:%r";
 *   Nedit  : "/sw/bin/nedit -line %r %f"
 *   emacs  : "xterm -e /usr/bin/emacs +%r:%c %f"
 *   TextEdit: "open -e %f"
 */

public class Globals
{
    private static Globals currentGlobals = null;

    private static String  editorCommandlineTemplate;
    private static int     fontSize;
    private static boolean allAttributesOn;
    private static String  basePath;
    private static int     tabSize;
		    
    public static final String  EDITORKEY = "editorCommandlineTemplate";
    public static final String  FONTSIZEKEY = "fontSize";
    public static final String  ATTRKEY = "allAttributesOn";
    public static final String  BASEPATHKEY = "basePath";
    public static final String  TABSIZEKEY = "tabSize";
    public static final String  DEFAULT_EDITOR_COMMANDLINE_TEMPLATE  =  "/sw/bin/nedit -line %r %f";
    public static final int     DEFAULT_FONTSIZE                     = 14;
    public static final boolean DEFAULT_ALLATTRIBUTESON		    = false;
    public static final String  DEFAULT_BASEPATH = "./";
    public static final int     DEFAULT_TAB = 4;
    public static final String  CONFIG_FILENAME = "visage.conf";
    public static final String  STANDARDEXTENSION = "visage";
    
    public static synchronized Globals getGlobals() {
        if (currentGlobals == null) {
            setGlobals(new Globals());
/*						try {
            	loadSettings();
						}
						catch (IOException ie) {
						   System.out.println("Error "+ie.toString());
						}*/
				}		
        return currentGlobals;
    }


    public static synchronized void setGlobals(Globals context) {
        currentGlobals = context;
    }


    public Globals() {
        setEditorCommandlineTemplate(DEFAULT_EDITOR_COMMANDLINE_TEMPLATE);
        setFontSize(DEFAULT_FONTSIZE);
        setAllAttributesOn(DEFAULT_ALLATTRIBUTESON);
        setBasePath(DEFAULT_BASEPATH);
        setTabSize(DEFAULT_TAB);
    }


    public void saveSettings() throws IOException
    {
        String userHomeDirectory = System.getProperty("user.home");
        File configFile = new File(userHomeDirectory, CONFIG_FILENAME);

        Properties props = new Properties();
        props.setProperty(EDITORKEY,   getEditorCommandlineTemplate());
        props.setProperty(FONTSIZEKEY, Integer.toString(getFontSize()));
        props.setProperty(ATTRKEY,		 Boolean.toString(getAllAttributesOn()));
        props.setProperty(BASEPATHKEY, basePath);
        props.setProperty(TABSIZEKEY,  Integer.toString(tabSize));
        
        FileOutputStream outputStream = new FileOutputStream(configFile);
        props.store(outputStream, "Visage");
        outputStream.flush();
        outputStream.close();
    }


    public void loadSettings() throws IOException
    {
        String userHomeDirectory = ".";
        // System.getProperty("user.home");
        File configFile = new File(userHomeDirectory, CONFIG_FILENAME);

        if (!configFile.exists())
            return;

        Properties props = new Properties();
        InputStream inputStream = new FileInputStream(configFile);
        props.load(inputStream);
        inputStream.close();
        
        Debug.output("Settings have been loaded"+props,Debug.STARTUP);
        
        if (props.containsKey(EDITORKEY))
            setEditorCommandlineTemplate(props.getProperty(EDITORKEY));
        try {
            if (props.containsKey(TABSIZEKEY))
                setFontSize(Integer.parseInt(props.getProperty(TABSIZEKEY)));
        
            if (props.containsKey(FONTSIZEKEY))
                setFontSize(Integer.parseInt(props.getProperty(FONTSIZEKEY)));
        } catch (NumberFormatException e) {}
        if (props.containsKey(ATTRKEY) && ((new Boolean(props.getProperty(ATTRKEY))).booleanValue()) ) // set if true, otherwise leave default.
            setAllAttributesOn(true);
        if (props.containsKey(BASEPATHKEY))
            setBasePath(props.getProperty(BASEPATHKEY));
    }

    public String getEditorCommandlineTemplate()
    {
        return editorCommandlineTemplate;
    }


    public void setEditorCommandlineTemplate(String commandline)
    {
        if (commandline == null)
            throw new IllegalArgumentException("commandline is null");

        editorCommandlineTemplate = commandline;
    }

    public boolean getAllAttributesOn () {
        return allAttributesOn;
    }
    
    public void setAllAttributesOn (boolean allon) {
        allAttributesOn = allon;
    }
    
    public String getBasePath () {
        return basePath;
    }
    
    public void setBasePath (String basepath) {
        basePath = basepath;
    }

    public int getTabSize () {
        return tabSize;
    }

    public void setTabSize (int tabsize) {
        tabSize = tabsize;
    }
        
    public int getFontSize()
    {
        return fontSize;
    }

    public void setFontSize(int newSize)
	  {
		  if (newSize > 40) newSize = 40;
		  if (newSize < 10) newSize = 10;
		  fontSize = newSize;
	  }

    /*****************************
    /* Replaces all \n \\ and so on by their ASCII codes
    /* \t is replaced by a constant amount, tabsize, of spaces.
    /* Currently supported, \t, \n and \\.
     */
   	public String unescape (String s) {
      StringBuffer output = new StringBuffer();
      final char escape = '\\';
      
      for (int i=0; i < s.length(); i++) {
        if (s.charAt(i) == escape && i <= s.length()) {
          i++;
          switch (s.charAt(i)) {
            case '\\': output.append("\\");
                      break;
            case 't': for (int c=0; c < getTabSize(); c++) output.append(" ");
                     break;
            case '"': output.append("\"");
                      break;         
            case 'n': 
            case 'r': output.append("\n");
                      break;
            default: System.out.println("Unknown escape code encountered in "+s);
          }
        }
        else
          output.append(s.charAt(i));  
      }
      return output.toString();
    }
    
}
