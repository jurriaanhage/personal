package visage;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JDesktopPane;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;

import visage.visual.*;
import visage.action.*;

/**
 *  The root of the program. Builds up the main frame.
 */
public class Visage extends JFrame {
  private JPanel prodPanel, detailPanel, status;
  private JButton prodHeader;
  private JScrollPane prodPane;
  private JDesktopPane graphicPane;
  private JLabel statusLabel;
  private ProductionsView prodView;
  private Container contentPane;
  private final static int PRODVIEW_WIDTH = 200;
  private final static int PRODHEADER_HEIGHT = 25;
  private final static int STATUS_HEIGHT = 25;
  
  /**
   *  Creates a new Visage.
   */
  public Visage() {
    super();
  }
  
  /**
   *  Initializes the program, builds the interface.
   */
  public void initVisage (String startupfile) {
    this.setSize( 1024, 768 );
    this.setTitle( "Visage v1.0" );
    this.addWindowListener( new AppCloser() );
    this.contentPane = this.getContentPane();
    contentPane.setLayout( new BorderLayout() );
    createProdPanel();
    createDetailPanel();
    createStatus();
    createMenu();
    this.setVisible( true );
    if (startupfile != null) {
      OpenAction.loadIt(new File(startupfile),prodView,graphicPane,statusLabel,this);
    }  
  }
  
/*
  public EditorProcess getEditorProcess () {
    return this.editorprocess;
  }
*/
  
  /**
   *  Creates a JPanel with a button on top and a ProductionsView beneath.
   */
  private void createProdPanel() {
    this.prodPanel =  new JPanel( new BorderLayout() );
    prodPanel.setOpaque( true );
    createProdViewHeader();
    createProdView();
    contentPane.add( prodPanel, BorderLayout.WEST );
    prodPanel.setPreferredSize( new Dimension( PRODVIEW_WIDTH, (int) this.getSize().getHeight()-STATUS_HEIGHT ) );
  }
  
  /**
   *  Creates a JPanel (which currently only contains a JDesktopPane for the GraphicViewFrames).
   */
  private void createDetailPanel() {
    this.detailPanel = new JPanel( new BorderLayout() );
    detailPanel.setOpaque( true );
    createGraphicView();
    contentPane.add( detailPanel, BorderLayout.CENTER );
    detailPanel.setPreferredSize( new Dimension( (int) this.getSize().getWidth()-PRODVIEW_WIDTH, (int) this.getSize().getHeight()-STATUS_HEIGHT ) );
  }
  
  /**
   *  Creates the status bar.
   */
  private void createStatus() {
    status = new JPanel( new BorderLayout() );
    statusLabel = new JLabel();
    statusLabel.setText( "Ready" );
    status.add( statusLabel, BorderLayout.WEST );
    contentPane.add( status, BorderLayout.SOUTH );
    status.setPreferredSize( new Dimension( (int) this.getSize().getWidth(), STATUS_HEIGHT ) );
  }
  
  /**
   *  Creates the menubar with the menus.
   */
  private void createMenu() {
    JMenuBar menu = new JMenuBar();
    JMenu filemenu = new JMenu( "File" );
    filemenu.setMnemonic( 'f' );
    OpenAction openaction = new OpenAction( "Open...", prodView, graphicPane, statusLabel, this );
    
    JMenuItem item = new JMenuItem( openaction );
    item.setMnemonic( 'o' );
    //item.setAccelerator( KeyStroke.getKeyStroke( 'o', 2 ) );
    filemenu.add( item );
    
    item = new JMenuItem( new ReopenAction( "Reopen...", openaction, prodView, graphicPane, statusLabel, this ) );
    item.setMnemonic( 'o' );
    //item.setAccelerator( KeyStroke.getKeyStroke( 'o', 2 ) );
    filemenu.add( item );
    
    item = new JMenuItem( new CloseAllAction( "Close all windows", graphicPane ) );
    item.setMnemonic( 'a' );
    //item.setAccelerator( KeyStroke.getKeyStroke( 'a', 2 ) );
    filemenu.add( item );

    item = new JMenuItem( new ExitAction( "Quit") );
    item.setMnemonic( 'q' );
    //item.setAccelerator( KeyStroke.getKeyStroke( 'o', 2 ) );
    filemenu.add( item );
    
    menu.add( filemenu );
    this.setJMenuBar( menu );
  }
  
  /**
   *  Creates a button as header above the ProductionsView.
   */
  private void createProdViewHeader() {
    prodHeader = new JButton( "Production rules overview" );
    prodHeader.setMargin( new java.awt.Insets( 0, 0, 0, 0 ) );
    prodPanel.add( prodHeader, BorderLayout.NORTH );
    prodHeader.setPreferredSize( new Dimension( PRODVIEW_WIDTH, PRODHEADER_HEIGHT ) );
  }
  
  /**
   *  Creates the ProductionsView.
   */
  private void createProdView() {
    prodPane = new JScrollPane();
    prodView = new ProductionsView();
    prodPane.add( prodView );
    prodPanel.add( prodPane, BorderLayout.CENTER );
    prodPane.setPreferredSize( new Dimension( PRODVIEW_WIDTH, (int) prodPanel.getSize().getHeight()-PRODHEADER_HEIGHT ) );
    prodPane.setViewportView( prodView );
    prodView.setView( new JLabel[0], "No file loaded yet." );
  }
  
  /**
   *  Creates a JDesktopPane for the GraphicViewFrames.
   */
  private void createGraphicView() {
    graphicPane = new JDesktopPane();
    graphicPane.setOpaque( true );
    detailPanel.add( graphicPane, BorderLayout.CENTER );
    graphicPane.setPreferredSize( new Dimension( (int) this.getSize().getWidth()-PRODVIEW_WIDTH, (int) this.getSize().getHeight()-STATUS_HEIGHT ) );
  }
  
  /**
   *  Starts the program...
   */
  public static void main( String[] args ) {
	  try { Globals.getGlobals().loadSettings(); }
    catch(IOException exception) {
		  System.out.println(exception.toString());
		}
    
    Visage vag = new Visage();
    if (args.length > 0) 
      vag.initVisage(args[0]);
    else
      vag.initVisage(null);  
  }
  
  /**
   *  Class that closes the program.
   */
  private static class AppCloser extends WindowAdapter
  { public void windowClosing( WindowEvent e )
    { System.exit(0);
    }
  }
}
