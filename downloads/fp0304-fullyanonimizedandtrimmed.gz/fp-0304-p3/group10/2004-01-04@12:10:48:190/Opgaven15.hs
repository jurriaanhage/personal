a :: Int
a = 2

b :: Int
b = 2
c :: Int
c = 2


aantal0pl :: Int -> Int
aantal0pl x = a*x*x + b*x + c
