voegIn :: Int -> [Int] -> [Int]


voegIn  a b | (head b)>a =  a:b
            | otherwise  = (head b):(voegIn (a (tail b)))
