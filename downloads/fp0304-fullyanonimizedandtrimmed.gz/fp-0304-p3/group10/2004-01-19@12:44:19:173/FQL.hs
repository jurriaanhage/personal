module FQL (module List, module FQL) where

import List


type Table = [[String]]

compilers :: Table
compilers =
  [ ["Compiler", "Universiteit/bedrijf"]
  , ["Helium", "Universiteit van Utrecht"]
  , ["NHC", "University of York"]
  , ["GHC", "Microsoft Research"]
  , ["Hugs", "Galois Connections"]
  , ["Hugs.NET", "Galois Connections"]
  , ["O'Haskell", "Oregon Graduate Institute"]
  , ["O'Haskell", "Chalmers University of Technology"]
  , ["HBC", "Chalmers University of Technology"]
  ]

locaties :: Table
locaties =
    [ ["Universiteit/bedrijf", "Land", "Stad"]
  , ["Universiteit van Utrecht", "Nederland", "Utrecht"]
  , ["University of York", "Engeland", "York"]
  , ["Microsoft Research", "Engeland", "Cambridge"]
  , ["Galois Connections", "Verenigde Staten", "Beaverton"]
  , ["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
  , ["Chalmers University of Technology", "Zweden", "Goteborg"]
  ]



listLength :: [String] -> [Int]
listLength lijst = map length lijst

maxColumnWidth :: [String] -> Int
maxColumnWidth column = foldr (max) 0 (listLength column)

maxColumnWidths :: [[String]] -> [Int]
maxColumnWidths lijst  | null lijst = []
                       | otherwise = maxColumnWidth (head lijst) : maxColumnWidths (tail lijst)

newLine :: [Int] -> String
newLine lijst | null lijst = "+\n"
              | otherwise = "+" ++ concat (replicate (head lijst)  "-") ++ newLine (tail lijst)

newEntry :: [String] -> [Int] -> String
newEntry lijst1 lijst2 | null lijst1 = "|\n"
                       | otherwise = "|" ++ (head lijst1) ++ concat(replicate ((head lijst2) - (length (head lijst1))) " ") ++ newEntry (tail lijst1) (tail lijst2)

writeFieldDefs :: Table -> [Int] -> String
writeFieldDefs table table1 = newLine table1  ++ newEntry (head table) table1 ++ newLine table1

writeRows :: Table -> [Int] -> String
writeRows table table1 | null table = newLine table1
                       | otherwise  = newEntry (head table) table1 ++ writeRows (tail table) table1

writeTable :: Table -> String
writeTable table = writeFieldDefs table a ++ writeRows (tail table) a
   where a = maxColumnWidths (transpose table)

findEntry :: String -> Table -> [String]
findEntry columnName table | null table = []
                           | eqString columnName (head (head table)) = head table
                           | otherwise = findEntry columnName (tail table)

findEntries :: [String] -> Table -> Table
findEntries lijst table | null lijst  = []
                        | otherwise = findEntry (head lijst) (transpose table) : findEntries (tail lijst) (table)

project :: [String] -> Table -> Table
project lijst table = transpose (findEntries lijst table)













test :: String -> (String -> Bool) -> [String]
test entry functie | functie entry = [entry]
                   | otherwise = []

test1 :: [String] -> (String -> Bool) -> [String]
test1 column f | null column = []
               | otherwise = test (head column) f ++ test1 (tail column) f

test2 :: String -> [String] -> (String -> Bool) -> [String]
test2 columnname getrtable functie | null getrtable = []
                                   | eqString (head getrtable) columnname = test1 (tail getrtable) functie
                                   | otherwise = []

test3 :: String -> Table -> (String -> Bool) -> [String]
test3 columnname table functie | null table = []
                               | otherwise = test2 columnname (head (transpose table)) functie ++ test3 columnname (tail (transpose table)) functie
