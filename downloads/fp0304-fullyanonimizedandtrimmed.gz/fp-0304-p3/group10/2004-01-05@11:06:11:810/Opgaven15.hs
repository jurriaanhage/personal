totEerste :: [Int] -> [Int]
totEerste Lijst | head Lijst == 0 = 0
                | otherwise = head Lijst + totEerste (tail Lijst)

naEerste :: [Int] -> [Int]
naEerste Lijst | head Lijst == 0 = 0
               | otherwise = head Lijst + naEerste (tail Lijst)

zonder :: [Int] -> [Int]
zonder Lijst | Lijst == [] = []
             | head Lijst == 0 = zonder (tail Lijst)
             | otherwise = head Lijst + zonder (tail Lijst)

vanafLaatste :: [Int] -> [Int]
vanafLaatste Lijst | Lijst == [] = []
                   | last Lijst == 0 = vanafLaatste (init Lijst)
                   | otherwise = last Lijst + vanafLaatste (init Lijst)
