lijst :: [Int]
lijst = [1, 3, 5, 0, 2, 6, 0, 9, 8, 7, 0, 6, 5, 4]

totEerste :: [Int] -> [Int]
totEerste lijst | head lijst == 0 = 0
                | otherwise = head lijst + totEerste (tail lijst)

naEerste :: [Int] -> [Int]
naEerste lijst | head lijst == 0 = 0
               | otherwise = head lijst + naEerste (tail lijst)

zonder :: [Int] -> [Int]
zonder lijst | lijst == [] = []
             | head lijst == 0 = zonder (tail lijst)
             | otherwise = head lijst + zonder (tail lijst)

vanafLaatste :: [Int] -> [Int]
vanafLaatste lijst | lijst == [] = []
                   | last lijst == 0 = vanafLaatste (init lijst)
                   | otherwise = last lijst + vanafLaatste (init lijst)
