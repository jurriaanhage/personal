data Prop
  = En [Prop]
  | Of [Prop]
  | Niet Prop
  | Prop :-> Prop
  | Var String
  | Bool Bool

type
   Bedeling = [String]

evalueer :: Prop -> Bedeling -> Bool
evalueer (Bool b) _               =  b
evalueer (Var v) bedeling         = elemBy eqString v bedeling
evalueer (Niet p) bedeling        = not (evalueer p bedeling)
evalueer (En p) bedeling          = and [evalueer p1 bedeling | p1 <- p]
evalueer (Of p) bedeling          = or [evalueer p1 bedeling | p1 <- p]
evalueer (p1 :-> p2) bedeling     = or [(evalueer (Niet p1) bedeling), (evalueer p2 bedeling)]

vervulbaar :: Prop -> [Bedeling]
vervulbaar (Bool b)   = []
vervulbaar (Var v)    = [v]
vervulbaar (Niet p)   = vervulbaar not(p)
