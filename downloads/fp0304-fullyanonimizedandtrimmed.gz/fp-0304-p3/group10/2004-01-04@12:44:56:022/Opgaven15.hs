voegIn :: Int -> [Int] -> [Int]


voegIn  a b | head b > a = a ++ b
            | otherwise  = voegIn (a (tail b))
