a :: [[Int]]
a = [[1,2,3],[],[4,5]]






slaPlat b | b == null = []
              | otherwise = head b ++ slaPlat (tail b)
