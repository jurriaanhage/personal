module FQL (module List, module FQL) where

import List


type Table = [[String]]

compilers :: Table
compilers =
  [ ["O'Haskell", "Oregon Graduate Institute"],
    ["Compiler", "Universiteit/bedrijf"]
  , ["O'Haskell", "Chalmers University of Technology"]
  , ["Helium", "Universiteit van Utrecht"]
  , ["NHC", "University of York"]
  , ["GHC", "Microsoft Research"]
  , ["Hugs", "Galois Connections"]
  , ["Hugs.NET", "Galois Connections"]

  , ["HBC", "Chalmers University of Technology"]
  ]

locaties :: Table
locaties =
  [ ["Universiteit/bedrijf", "Land", "Stad"]
  , ["Universiteit van Utrecht", "Nederland", "Utrecht"]
  , ["University of York", "Engeland", "York"]
  , ["Microsoft Research", "Engeland", "Cambridge"]
  , ["Galois Connections", "Verenigde Staten", "Beaverton"]
  , ["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
  , ["Chalmers University of Technology", "Zweden", "Goteborg"]
  ]

listLength :: [String] -> [Int]
listLength lijst = map length lijst

maxColumnWidth :: [String] -> Int
maxColumnWidth column = foldr (max) 0 (listLength column)

maxColumnWidths :: [[String]] -> [Int]
maxColumnWidths lijst  | null lijst = []
                       | otherwise = maxColumnWidth (head lijst) : maxColumnWidths (tail lijst)

newLine :: [Int] -> String
newLine lijst | null lijst = "+\n"
              | otherwise = "+" ++ concat (replicate (head lijst)  "-") ++ newLine (tail lijst)

newEntry :: [String] -> [Int] -> String
newEntry lijst1 lijst2 | null lijst1 = "|\n"
                       | otherwise = "|" ++ (head lijst1) ++ concat(replicate ((head lijst2) - (length (head lijst1))) " ") ++ newEntry (tail lijst1) (tail lijst2)

writeFieldDefs :: Table -> Table -> String
writeFieldDefs table table1 | null table = ""
                      | otherwise  = newLine table1  ++
                                     newEntry (head table) table1 ++
                                     newLine table1

writeRows :: Table -> Table -> String
writeRows table table1 | null table = newLine table1
                 | otherwise  = newEntry (head table) table1 ++
                                writeRows (tail table) table1

writeTable :: Table -> String
writeTable table = writeFieldDefs table a ++ writeRows (tail table) a
   where a   = maxColumnWidths $ transpose table
