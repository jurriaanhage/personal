data Prop
  = En [Prop]
  | Of [Prop]
  | Niet Prop
  | Prop :-> Prop
  | Var String
  | Bool Bool

type
   Bedeling = [String]

evalueer :: Prop -> Bedeling -> Bool

evalueer (Bool b) bedeling        =  b
evalueer (Var v) bedeling         = elemBy eqString v bedeling
evalueer (Niet p) bedeling        = not (evalueer p bedeling)
evalueer (En [p]) bedeling        = [True && x | x <- [p]]
                                          where x = evalueer x bedeling
