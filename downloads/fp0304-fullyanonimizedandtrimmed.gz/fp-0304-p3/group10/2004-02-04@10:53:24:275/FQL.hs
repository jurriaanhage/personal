module FQL (module List, module FQL) where

import List

type
   Table = [[String]]

compilers :: Table
compilers = [["Compiler", "Universiteit/bedrijf"]
   ,["Helium", "Universiteit van Utrecht"]
   ,["NHC", "University of York"]
   ,["GHC", "Microsoft Research"]
   ,["Hugs", "Galois Connections"]
   ,["Hugs.NET", "Galois Connections"]
   ,["O'Haskell", "Oregon Graduate Institute"]
   ,["O'Haskell", "Chalmers University of Technology"]
   ,["HBC", "Chalmers University of Technology"]]

locaties :: Table
locaties = [["Universiteit/bedrijf", "Land", "Stad"]
   ,["Universiteit van Utrecht", "Nederland", "Utrecht"]
   ,["University of York", "Engeland", "York"]
   ,["Microsoft Research", "Engeland", "Cambridge"]
   ,["Galois Connections", "Verenigde Staten", "Beaverton"]
   ,["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
   ,["Chalmers University of Technology", "Zweden", "Goteborg"]]


soort :: Table
soort = [["Universiteit/bedrijf", "Soort"]
   ,["Universiteit van Utrecht", "Universiteit"]
   ,["University of York", "Universiteit"]
   ,["Microsoft Research", "Bedrijf"]
   ,["Galois Connections", "Bedrijf"]
   ,["Oregon Graduate Institute", "Universiteit"]
   ,["Chalmers University of Technology", "Universiteit"]]


query :: Table
query = project ["Compiler"]
   (select "Soort" (eqString "Universiteit")
   (join compilers (join locaties soort)))




maxKolombreedte :: [String] -> Int
maxKolombreedte k = foldr (max) 0 (map length k)




maxKolombreedtes :: Table -> [Int]
maxKolombreedtes t | null t = []
                   | otherwise = maxKolombreedte (head t) : maxKolombreedtes (tail t)




scheiding :: [Int] -> String
scheiding kbs | null kbs = "+\n"
              | otherwise = "+" ++ concat (replicate (head kbs) "-") ++ scheiding (tail kbs)




scheidingVelden :: [String] -> [Int] -> String
scheidingVelden vn kbs | null vn = "|\n"
                       | otherwise = "|" ++ (head vn) ++ concat(replicate ((head kbs)-(length (head vn))) " ") ++ scheidingVelden (tail vn) (tail kbs)






kolommen :: Table -> [Int] -> String
kolommen t kbs = scheiding kbs ++ scheidingVelden (head t) kbs ++ scheiding kbs









gegevens :: Table -> [Int] -> String
gegevens t kbs | null t = scheiding kbs
               | otherwise = scheidingVelden (head t) kbs ++ gegevens (tail t) kbs

writeTable :: Table -> String
writeTable t = kolommen t kbs ++ gegevens (tail t) kbs
   where kbs = maxKolombreedtes (transpose t)




s2 :: String -> Table -> [String]
s2 c t | null t = []
       | eqString c (head(head t)) = tail (head t)
       | otherwise = s2 c (tail t)





s4 :: [String] -> Table -> Table
s4 cs t | null cs  = []
        | otherwise = s2 (head cs) (transpose t) : s4 (tail cs) t

project :: [String] -> Table -> Table
project cs t = transpose (s4 cs t)




s1 :: String -> (String -> Bool) -> Table -> [String]
s1 c f t = [x | x <- s2 c (transpose t), f x]






s3 :: String -> Table -> Table
s3 c t = [x | x <- t, f x]
   where f y = elemBy eqString c y

select :: String -> (String -> Bool) -> Table -> Table
select c f t = head t : concatMap g (s1 c f t)
   where g x = s3 x t






cmpfns :: String -> [String] -> String
cmpfns fn fns | null fns = []
              | eqString fn (head fns) = head fns
              | otherwise = cmpfns fn (tail fns)




cmpfds :: [String] -> [String] -> String
cmpfds fd1 fd2 | null fd1 = []
               | eqString (head fd1) (cmpfns (head fd1) fd2) = (head fd1)
               | otherwise = cmpfds (tail fd1) fd2




pos :: [String] -> String -> Int
pos cs c | null cs = 0
         | eqString (head cs) c = 0
         | otherwise = 1 + pos (tail cs) c














jntt :: Table -> Table -> Table
jntt lt rt =  [l++r | l <- lt, r <- rt, eqString (l !! i1) (r !! i2)]
   where cm = cmpfds (head lt) (head rt)
         i1 = pos (head lt) cm
         i2 = pos (head rt) cm












rmv :: Table -> String -> Table
rmv t f | null t = []
        | eqString (head (head t)) f = tail t
        | otherwise = (head t) : rmv (tail t) f

join :: Table -> Table -> Table
join lt rt = transpose (rmv (transpose(jntt lt rt)) f)
        where f =  cmpfds (head lt) (head rt)
