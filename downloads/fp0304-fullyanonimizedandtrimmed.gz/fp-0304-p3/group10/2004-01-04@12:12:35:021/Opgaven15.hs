a :: Int
a = 1

b :: Int
b = 1
c :: Int
c = 1


aantal0pl :: Int -> Int
aantal0pl x = a*x*x + b*x + c
