a :: [[Int]]
a = [[1,2,3],[],[4,5]]
b :: [[Int]]








slaPlat2 :: [[Int]] -> [Int]

slaPlat2 a = concat  a
