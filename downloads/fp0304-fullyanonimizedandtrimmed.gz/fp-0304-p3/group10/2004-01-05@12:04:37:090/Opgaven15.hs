rij :: [Int]
rij = []

totEerste :: [Int] -> [Int]
totEerste lijst | null lijst = []
                | head lijst == 0 = totEerste ([])
                | otherwise = head lijst : totEerste (tail lijst)

naEerste :: [Int] -> [Int]
naEerste lijst | null lijst = []
               | head lijst == 0 = (tail lijst)
               | otherwise = naEerste (tail lijst)


zonder :: [Int] -> [Int]
zonder lijst | null lijst = []
             | head lijst == 0 = zonder (tail lijst)
             | otherwise = head lijst : zonder (tail lijst)

vanafLaatste :: [Int] -> [Int]
vanafLaatste lijst | null lijst = []
                   | last lijst == 0 = vanafLaatste ([])
                   | otherwise =  vanafLaatste (init lijst) ++ [last lijst]

voegIn :: Int -> [Int] -> [Int]
voegIn a lijst | null lijst = [a]
               | head lijst > a = [a] ++ lijst
               | head lijst <= a = [head lijst] ++ voegIn a (tail lijst)

insertionSort :: [Int] -> [Int]
insertionSort lijst | null lijst = []
                    | otherwise = voegIn (head lijst) (insertionSort tail lijst)


slaPlat :: [[Int]] -> [Int]
slaPlat lijst | foldr (++) lijst
