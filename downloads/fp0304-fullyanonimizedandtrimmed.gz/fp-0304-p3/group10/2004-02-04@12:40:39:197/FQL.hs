module FQL (module List, module FQL) where

import List

type
   Table = [[String]]

compilers :: Table
compilers = [["Compiler", "Universiteit/bedrijf"]
   ,["Helium", "Universiteit van Utrecht"]
   ,["NHC", "University of York"]
   ,["GHC", "Microsoft Research"]
   ,["Hugs", "Galois Connections"]
   ,["Hugs.NET", "Galois Connections"]
   ,["O'Haskell", "Oregon Graduate Institute"]
   ,["O'Haskell", "Chalmers University of Technology"]
   ,["HBC", "Chalmers University of Technology"]]

locaties :: Table
locaties = [["Universiteit/bedrijf", "Land", "Stad"]
   ,["Universiteit van Utrecht", "Nederland", "Utrecht"]
   ,["University of York", "Engeland", "York"]
   ,["Microsoft Research", "Engeland", "Cambridge"]
   ,["Galois Connections", "Verenigde Staten", "Beaverton"]
   ,["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
   ,["Chalmers University of Technology", "Zweden", "Goteborg"]]


soort :: Table
soort = [["Universiteit/bedrijf", "Soort"]
   ,["Universiteit van Utrecht", "Universiteit"]
   ,["University of York", "Universiteit"]
   ,["Microsoft Research", "Bedrijf"]
   ,["Galois Connections", "Bedrijf"]
   ,["Oregon Graduate Institute", "Universiteit"]
   ,["Chalmers University of Technology", "Universiteit"]]


query :: Table
query = project ["Compiler"]
   (select "Soort" (eqString "Universiteit")
   (join compilers (join locaties soort)))




maxKolombreedte :: [String] -> Int
maxKolombreedte kolom = foldr (max) 0 (map length kolom)




maxKolombreedtes :: Table -> [Int]
maxKolombreedtes tabel | null tabel = []
                       | otherwise = maxKolombreedte (head tabel) : maxKolombreedtes (tail tabel)




scheiding :: [Int] -> String
scheiding kolomBreedtes | null kolomBreedtes = "+\n"
                        | otherwise = "+" ++ concat (replicate (head kolomBreedtes) "-") ++ scheiding (tail kolomBreedtes)




scheidingVelden :: [String] -> [Int] -> String
scheidingVelden velden kolomBreedtes | null velden = "|\n"
                                     | otherwise = "|" ++
                                                   (head velden) ++
                                                   concat(replicate ((head kolomBreedtes)-(length (head velden))) " ") ++
                                                   scheidingVelden (tail velden) (tail kolomBreedtes)






kolommen :: Table -> [Int] -> String
kolommen tabel kolomBreedtes = scheiding kolomBreedtes ++ scheidingVelden (head tabel) kolomBreedtes ++ scheiding kolomBreedtes









gegevens :: Table -> [Int] -> String
gegevens tabel kolomBreedtes | null tabel = scheiding kolomBreedtes
                             | otherwise = scheidingVelden (head tabel) kolomBreedtes ++ gegevens (tail tabel) kolomBreedtes

writeTable :: Table -> String
writeTable tabel = kolommen tabel kolomBreedtes ++ gegevens (tail tabel) kolomBreedtes
   where kolomBreedtes = maxKolombreedtes (transpose tabel)




vindKolom :: String -> Table -> [String]
vindKolom kolom tabel | null tabel = []
                      | eqString kolom (head(head tabel)) = tail (head tabel)
                      | otherwise = vindKolom kolom (tail tabel)





vindKolommen :: [String] -> Table -> Table
vindKolommen kolomNamen tabel | null kolomNamen  = []
                              | otherwise = vindKolom (head kolomNamen) (transpose tabel) : vindKolommen (tail kolomNamen) tabel

project :: [String] -> Table -> Table
project kolomNamen tabel = head tabel : transpose (vindKolommen kolomNamen tabel)




voerUitFunctie :: String -> (String -> Bool) -> Table -> [String]
voerUitFunctie kolom functie tabel = [velden | velden <- vindKolom kolom (transpose tabel), functie velden]






vindVelden :: String -> Table -> Table
vindVelden kolomNaam tabel = [velden | velden <- tabel, functie velden]
   where functie veldNaam = elemBy eqString kolomNaam veldNaam




alsVeldBestaat :: [String] -> String -> Bool
alsVeldBestaat velden veldNaam = elemBy eqString veldNaam velden




distinct :: [String] -> [String]
distinct velden | null velden = []
                | alsVeldBestaat(tail velden) (head velden) = distinct (tail velden)
                | otherwise = (head velden) : distinct(tail velden)

select :: String -> (String -> Bool) -> Table -> Table
select kolomNaam functie tabel = head tabel : concatMap vindGegevens (distinct(voerUitFunctie kolomNaam functie tabel))
   where vindGegevens velden = vindVelden velden tabel






vergelijkKolom :: String -> [String] -> String
vergelijkKolom kolomNaam kolomNamen | null kolomNamen = []
                                    | eqString kolomNaam (head kolomNamen) = head kolomNamen
                                    | otherwise = vergelijkKolom kolomNaam (tail kolomNamen)




vergelijkKolommen :: [String] -> [String] -> String
vergelijkKolommen kolommen1 kolommen2 | null kolommen1 = []
                                      | eqString (head kolommen1) (vergelijkKolom (head kolommen1) kolommen2) = (head kolommen1)
                                      | otherwise = vergelijkKolommen (tail kolommen1) kolommen2




vindPositie :: [String] -> String -> Int
vindPositie kolomNamen kolomNaam | null kolomNamen = 0
                                 | eqString (head kolomNamen) kolomNaam = 0
                                 | otherwise = 1 + vindPositie (tail kolomNamen) kolomNaam














voegTabellenSamen :: Table -> Table -> Table
voegTabellenSamen linkertabel rechtertabel =  [links++rechts | links <- linkertabel, rechts <- rechtertabel, eqString (links !! index1) (rechts !! index2)]
   where gemeenschappelijk = vergelijkKolommen (head linkertabel) (head rechtertabel)
         index1 = vindPositie (head linkertabel) gemeenschappelijk
         index2 = vindPositie (head rechtertabel) gemeenschappelijk












verwijderKolom :: Table -> String -> Table
verwijderKolom tabel kolomNaam | null tabel = []
                               | eqString (head (head tabel)) kolomNaam = tail tabel
                               | otherwise = (head tabel) : verwijderKolom (tail tabel) kolomNaam

join :: Table -> Table -> Table
join linkertabel rechtertabel = transpose (verwijderKolom (transpose(voegTabellenSamen linkertabel rechtertabel)) gemeenschappelijk)
        where gemeenschappelijk =  vergelijkKolommen (head linkertabel) (head rechtertabel)
