a :: [[Int]]
a = [[1,2,3],[],[4,5]]






slaPlat b |null b = []
              | otherwise = head b ++ slaPlat (tail b)
