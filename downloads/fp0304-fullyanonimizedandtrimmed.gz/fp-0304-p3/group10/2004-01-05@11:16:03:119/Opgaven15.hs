lijst :: [Int]
lijst = [1, 3, 5, 0, 2, 6, 0, 9, 8, 7, 0, 6, 5, 4]

totEerste :: [Int] -> [Int]
totEerste lijst | null lijst = []
                | head lijst == 0 = totEerste ([])
                | otherwise = head lijst : totEerste (tail lijst)
