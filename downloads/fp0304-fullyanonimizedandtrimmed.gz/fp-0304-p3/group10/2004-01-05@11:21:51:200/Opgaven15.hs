rij :: [Int]
rij = [1, 3, 5, 0, 2, 0, 6, 9, 8, 0, 7, 6, 5, 4]

totEerste :: [Int] -> [Int]
totEerste lijst | null lijst = []
                | head lijst == 0 = totEerste ([])
                | otherwise = head lijst : totEerste (tail lijst)

naEerste :: [Int] -> [Int]
naEerste lijst | null lijst = []
               | head lijst == 0 = (tail lijst)
               | otherwise = naEerste (tail lijst)


zonder :: [Int] -> [Int]
zonder lijst | null lijst = []
             | head lijst == 0 = zonder (tail lijst)
             | otherwise = head lijst : zonder (tail lijst)

vanafLaatste :: [Int] -> [Int]
vanafLaatste lijst | null lijst = []
                   | last lijst == 0 = vanafLaatste (init lijst)
                   | otherwise = last lijst : vanafLaatste (init lijst)
