a :: [[Int]]
a = [[1,2,3],[],[4,5]]

slaPlat :: [[Int]] -> [Int]
slaPlat b | b == [[]] = []
              | otherwise = init b + slaPlat (tail b)
