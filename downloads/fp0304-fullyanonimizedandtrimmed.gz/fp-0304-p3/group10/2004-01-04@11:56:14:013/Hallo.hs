hello n = concat (replicate n "hello 10")
