hello n = concat (replicate n "hello ")
