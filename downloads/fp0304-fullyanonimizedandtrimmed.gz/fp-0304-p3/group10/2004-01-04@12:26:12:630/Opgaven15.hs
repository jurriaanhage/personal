a :: [[Int]]
a = [[1,2,3],[],[4,5]]









slaPlat2 :: [[Int]] -> [Int]

slaPlat2 b = concat  a
