data Prop
  = En [Prop]
  | Of [Prop]
  | Niet Prop
  | Prop :-> Prop
  | Var String
  | Bool Bool

type
   Bedeling = [String]

evalueer :: Prop -> Bedeling -> Bool

evalueer (Bool b) bedeling        =  b
evalueer (Var v) bedeling         = elemBy eqString v bedeling
evalueer (Niet p) bedeling        = not (evalueer p bedeling)
evalueer (En p) bedeling        = and [evalueer p1 bedeling | p1 <- p]
