aantal0pl a b c = a*x*x + b*x + c
