module FQL (module List, module FQL) where

import List

type
   Table = [[String]]








compilers :: Table
compilers = [["Compiler", "Universiteit/bedrijf"]
   ,["Helium", "Universiteit van Utrecht"]
   ,["NHC", "University of York"]
   ,["GHC", "Microsoft Research"]
   ,["Hugs", "Galois Connections"]
   ,["Hugs.NET", "Galois Connections"]
   ,["O'Haskell", "Oregon Graduate Institute"]
   ,["O'Haskell", "Chalmers University of Technology"]
   ,["HBC", "Chalmers University of Technology"]]

locaties :: Table
locaties = [["Universiteit/bedrijf", "Land", "Stad"]
   ,["Universiteit van Utrecht", "Nederland", "Utrecht"]
   ,["University of York", "Engeland", "York"]
   ,["Microsoft Research", "Engeland", "Cambridge"]
   ,["Galois Connections", "Verenigde Staten", "Beaverton"]
   ,["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
   ,["Chalmers University of Technology", "Zweden", "Goteborg"]]

soort :: Table
soort = [["Universiteit/bedrijf", "Soort"]
   ,["Universiteit van Utrecht", "Universiteit"]
   ,["University of York", "Universiteit"]
   ,["Microsoft Research", "Bedrijf"]
   ,["Galois Connections", "Bedrijf"]
   ,["Oregon Graduate Institute", "Universiteit"]
   ,["Chalmers University of Technology", "Universiteit"]]



columnWidths :: [String] -> [Int]

columnWidths aList = map length aList

maxColumnWidth :: [String] -> Int

maxColumnWidth aColumn = foldr (max) 0 (columnWidths aColumn)

maxColumnWidths :: Table -> [Int]

maxColumnWidths aTable | null aTable = []
                       | otherwise = maxColumnWidth (head aTable) : maxColumnWidths (tail aTable)

separator :: [Int] -> String

separator aColumnWidths | null aColumnWidths = "+\n"
                        | otherwise = "+" ++ concat (replicate (head aColumnWidths) "-") ++ separator (tail aColumnWidths)

separateField :: [String] -> [Int] -> String

separateField aFields aColumnWidths | null aFields = "|\n"
                                    | otherwise = "|" ++ (head aFields) ++ concat(replicate ((head aColumnWidths)-(length (head aFields))) " ") ++ separateField (tail aFields) (tail aColumnWidths)

writeFieldDefs :: Table -> [Int] -> String

writeFieldDefs aFieldDefs aColumnWidths = separator aColumnWidths ++ separateField (head aFieldDefs) aColumnWidths ++ separator aColumnWidths

writeDataSet :: Table -> [Int] -> String

writeDataSet aDataSet aColumnWidths | null aDataSet = separator aColumnWidths
                                    | otherwise = separateField (head aDataSet) aColumnWidths ++ writeDataSet (tail aDataSet) aColumnWidths

writeTable :: Table -> String
writeTable aTable = writeFieldDefs aTable aColumnWidths ++ writeDataSet (tail aTable) aColumnWidths
   where aColumnWidths = maxColumnWidths (transpose aTable)


findField :: String -> Table -> [String]

findField aColumnName aTable | null aTable = []
                             | eqString aColumnName (head (head aTable)) = head aTable
                             | otherwise = findField aColumnName (tail aTable)

findFields :: [String] -> Table -> Table

findFields aColumns aTable | null aColumns  = []
                           | otherwise = findField (head aColumns) (transpose aTable) : findFields (tail aColumns) aTable

project :: [String] -> Table -> Table
project aColumns aTable = transpose (findFields aColumns aTable)

execQuery :: String -> (String -> Bool) -> Table

execQuery aField aQuery | aQuery aField = [[aField]]
                        | otherwise = []

column :: [String] -> (String -> Bool) -> Table

column aColumn aQuery | null aColumn = []
                      | otherwise = execQuery (head aColumn) aQuery ++ column (tail aColumn) aQuery

columns :: String -> [String] -> (String -> Bool) -> Table

columns aColumnName aFields aQuery | null aFields = []
                                   | eqString (head aFields) aColumnName = column (tail aFields) aQuery
                                   | otherwise = []

getDataSet :: String -> Table -> (String -> Bool) -> Table

getDataSet aColumnName aTable aQuery | null aTable = []
                                     | otherwise = columns aColumnName (head (aTable)) aQuery ++ getDataSet aColumnName (tail (aTable)) aQuery

compareFieldNames :: String -> [String] -> String

compareFieldNames aFieldName aFieldNames | null aFieldNames = []
                                         | eqString aFieldName (head aFieldNames) = head aFieldNames
                                         | otherwise = compareFieldNames aFieldName (tail aFieldNames)

findDataSet :: Table -> [String] -> Table

findDataSet aTable aFieldNames | null aTable = []
                               | eqString (head aFieldNames) (compareFieldNames (head aFieldNames) (head aTable)) = [head aTable]
                               | otherwise = findDataSet (tail aTable) aFieldNames

select :: String -> (String -> Bool) -> Table -> Table
select aColumnName aQuery aTable = head aTable : concatMap completeDataSet (getDataSet aColumnName (transpose aTable) aQuery)
   where completeDataSet aFieldNames = findDataSet aTable aFieldNames


compareFieldDefs [String] -> [String] -> String
compareFieldDefs lijst1 lijst2 | null lijst1 = []
                               | eqString (head lijst1) (compareFieldNames (head lijst1) lijst2) = (head lijst1)
                               | otherwise = compareFieldDefs (tail lijst1) lijst2
