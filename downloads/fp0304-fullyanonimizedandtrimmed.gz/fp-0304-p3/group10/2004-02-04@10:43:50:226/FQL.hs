module FQL (module List, module FQL) where

import List

type
   Table = [[String]]

compilers :: Table
compilers = [["Compiler", "Universiteit/bedrijf"]
   ,["Helium", "Universiteit van Utrecht"]
   ,["NHC", "University of York"]
   ,["GHC", "Microsoft Research"]
   ,["Hugs", "Galois Connections"]
   ,["Hugs.NET", "Galois Connections"]
   ,["O'Haskell", "Oregon Graduate Institute"]
   ,["O'Haskell", "Chalmers University of Technology"]
   ,["HBC", "Chalmers University of Technology"]]

locaties :: Table
locaties = [["Universiteit/bedrijf", "Land", "Stad"]
   ,["Universiteit van Utrecht", "Nederland", "Utrecht"]
   ,["University of York", "Engeland", "York"]
   ,["Microsoft Research", "Engeland", "Cambridge"]
   ,["Galois Connections", "Verenigde Staten", "Beaverton"]
   ,["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
   ,["Chalmers University of Technology", "Zweden", "Goteborg"]]


soort :: Table
soort = [["Universiteit/bedrijf", "Soort"]
   ,["Universiteit van Utrecht", "Universiteit"]
   ,["University of York", "Universiteit"]
   ,["Microsoft Research", "Bedrijf"]
   ,["Galois Connections", "Bedrijf"]
   ,["Oregon Graduate Institute", "Universiteit"]
   ,["Chalmers University of Technology", "Universiteit"]]


query :: Table
query = project ["Compiler"]
   (select "Soort" (eqString "Universiteit")
   (join compilers (join locaties soort)))




maxcw :: [String] -> Int
maxcw c = foldr (max) 0 (map length c)




maxcws :: Table -> [Int]
maxcws t | null t = []
         | otherwise = maxcw (head t) : maxcws (tail t)




sep :: [Int] -> String
sep cws | null cws = "+\n"
        | otherwise = "+" ++ concat (replicate (head cws) "-") ++ sep (tail cws)




sepf :: [String] -> [Int] -> String
sepf fs cws | null fs = "|\n"
            | otherwise = "|" ++ (head fs) ++ concat(replicate ((head cws)-(length (head fs))) " ") ++ sepf (tail fs) (tail cws)






wcs :: Table -> [Int] -> String
wcs cs cws = sep cws ++ sepf (head cs) cws ++ sep cws









wds :: Table -> [Int] -> String
wds ds cws | null ds = sep cws
           | otherwise = sepf (head ds) cws ++ wds (tail ds) cws

writeTable :: Table -> String
writeTable t = wcs t cws ++ wds (tail t) cws
   where cws = maxcws (transpose t)




s2 :: String -> Table -> [String]
s2 c t | null t = []
       | eqString c (head(head t)) = tail (head t)
       | otherwise = s2 c (tail t)





s4 :: [String] -> Table -> Table
s4 cs t | null cs  = []
        | otherwise = s2 (head cs) (transpose t) : s4 (tail cs) t

project :: [String] -> Table -> Table
project cs t = transpose (s4 cs t)




s1 :: String -> (String -> Bool) -> Table -> [String]
s1 c f t = [x | x <- s2 c (transpose t), f x]






s3 :: String -> Table -> Table
s3 c t = [x | x <- t, f x]
   where f y = elemBy eqString c y

select :: String -> (String -> Bool) -> Table -> Table
select c f t = head t : concatMap g (s1 c f t)
   where g x = s3 x t






cmpfns :: String -> [String] -> String
cmpfns fn fns | null fns = []
              | eqString fn (head fns) = head fns
              | otherwise = cmpfns fn (tail fns)




cmpfds :: [String] -> [String] -> String
cmpfds fd1 fd2 | null fd1 = []
               | eqString (head fd1) (cmpfns (head fd1) fd2) = (head fd1)
               | otherwise = cmpfds (tail fd1) fd2




pos :: [String] -> String -> Int
pos cs c | null cs = 0
         | eqString (head cs) c = 0
         | otherwise = 1 + pos (tail cs) c














jntt :: Table -> Table -> Table
jntt lt rt =  [l++r | l <- lt, r <- rt, eqString (l !! i1) (r !! i2)]
   where cm = cmpfds (head lt) (head rt)
         i1 = pos (head lt) cm
         i2 = pos (head rt) cm












rmv :: Table -> String -> Table
rmv t f | null t = []
        | eqString (head (head t)) f = tail t
        | otherwise = (head t) : rmv (tail t) f

join :: Table -> Table -> Table
join lt rt = transpose (rmv (transpose(jntt lt rt)) f)
        where f =  cmpfds (head lt) (head rt)
