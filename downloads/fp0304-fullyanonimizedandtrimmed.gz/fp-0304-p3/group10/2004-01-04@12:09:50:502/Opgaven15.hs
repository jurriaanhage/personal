Int a = 2
Int b = 5
Int c = 7

aantal0pl :: Int -> Int
aantal0pl x = a*x*x + b*x + c
