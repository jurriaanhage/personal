module FQL (module List, module FQL) where

import List

type
   Table = [[String]]

compilers :: Table
compilers = [["Compiler", "Universiteit/bedrijf"]
   ,["Helium", "Universiteit van Utrecht"]
   ,["NHC", "University of York"]
   ,["GHC", "Microsoft Research"]
   ,["Hugs", "Galois Connections"]
   ,["Hugs.NET", "Galois Connections"]
   ,["O'Haskell", "Oregon Graduate Institute"]
   ,["O'Haskell", "Chalmers University of Technology"]
   ,["HBC", "Chalmers University of Technology"]]

locaties :: Table
locaties = [["Universiteit/bedrijf", "Land", "Stad"]
   ,["Universiteit van Utrecht", "Nederland", "Utrecht"]
   ,["University of York", "Engeland", "York"]
   ,["Microsoft Research", "Engeland", "Cambridge"]
   ,["Galois Connections", "Verenigde Staten", "Beaverton"]
   ,["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
   ,["Chalmers University of Technology", "Zweden", "Goteborg"]]


soort :: Table
soort = [["Universiteit/bedrijf", "Soort"]
   ,["Universiteit van Utrecht", "Universiteit"]
   ,["University of York", "Universiteit"]
   ,["Microsoft Research", "Bedrijf"]
   ,["Galois Connections", "Bedrijf"]
   ,["Oregon Graduate Institute", "Universiteit"]
   ,["Chalmers University of Technology", "Universiteit"]]


query :: Table
query = project ["Compiler"]
   (select "Soort" (eqString "Universiteit")
   (join compilers (join locaties soort)))




maxKolombreedte :: [String] -> Int
maxKolombreedte kolom = foldr (max) 0 (map length kolom)




maxKolombreedtes :: Table -> [Int]
maxKolombreedtes tabel | null tabel = []
                       | otherwise = maxKolombreedte (head tabel) : maxKolombreedtes (tail tabel)




scheiding :: [Int] -> String
scheiding kolomBreedtes | null kolomBreedtes = "+\n"
                        | otherwise = "+" ++ concat (replicate (head kolomBreedtes) "-") ++ scheiding (tail kolomBreedtes)




scheidingVelden :: [String] -> [Int] -> String
scheidingVelden velden kolomBreedtes | null velden = "|\n"
                                     | otherwise = "|" ++
                                                   (head velden) ++
                                                   concat(replicate ((head kolomBreedtes)-(length (head velden))) " ") ++
                                                   scheidingVelden (tail velden) (tail kolomBreedtes)






kolommen :: Table -> [Int] -> String
kolommen tabel kolomBreedtes = scheiding kolomBreedtes ++ scheidingVelden (head tabel) kolomBreedtes ++ scheiding kolomBreedtes









gegevens :: Table -> [Int] -> String
gegevens tabel kolomBreedtes | null tabel = scheiding kolomBreedtes
                             | otherwise = scheidingVelden (head tabel) kolomBreedtes ++ gegevens (tail tabel) kolomBreedtes

writeTable :: Table -> String
writeTable tabel = kolommen tabel kolomBreedtes ++ gegevens (tail tabel) kolomBreedtes
   where kolomBreedtes = maxKolombreedtes (transpose tabel)




vindKolom :: String -> Table -> [String]
vindKolom kolom tabel | null tabel = []
                      | eqString kolom (head(head tabel)) = tail (head tabel)
                      | otherwise = vindKolom kolom (tail tabel)





vindKolommen :: [String] -> Table -> Table
vindKolommen kolomNamen tabel | null kolomNamen  = []
                              | otherwise = vindKolom (head kolomNamen) (transpose tabel) : vindKolommen (tail kolomNamen) tabel

project :: [String] -> Table -> Table
project kolomNamen tabel = transpose (vindKolommen kolomNamen tabel)




voerUitFunctie :: String -> (String -> Bool) -> Table -> [String]
voerUitFunctie kolom functie tabel = [velden | velden <- vindKolom kolom (transpose tabel), functie velden]






vindVelden :: String -> Table -> Table
vindVelden kolomNaam tabel = [velden | velden <- tabel, functie velden]
   where functie veldNaam = elemBy eqString kolomNaam veldNaam

select :: String -> (String -> Bool) -> Table -> Table
select kolomNaam functie tabel = head tabel : concatMap vindGegevens (voerUitFunctie kolomNaam functie tabel)
   where vindGegevens velden = vindVelden velden tabel






cmpfns :: String -> [String] -> String
cmpfns fn fns | null fns = []
              | eqString fn (head fns) = head fns
              | otherwise = cmpfns fn (tail fns)




cmpfds :: [String] -> [String] -> String
cmpfds fd1 fd2 | null fd1 = []
               | eqString (head fd1) (cmpfns (head fd1) fd2) = (head fd1)
               | otherwise = cmpfds (tail fd1) fd2




pos :: [String] -> String -> Int
pos cs c | null cs = 0
         | eqString (head cs) c = 0
         | otherwise = 1 + pos (tail cs) c














jntt :: Table -> Table -> Table
jntt lt rt =  [l++r | l <- lt, r <- rt, eqString (l !! i1) (r !! i2)]
   where cm = cmpfds (head lt) (head rt)
         i1 = pos (head lt) cm
         i2 = pos (head rt) cm












rmv :: Table -> String -> Table
rmv t f | null t = []
        | eqString (head (head t)) f = tail t
        | otherwise = (head t) : rmv (tail t) f

join :: Table -> Table -> Table
join lt rt = transpose (rmv (transpose(jntt lt rt)) f)
        where f =  cmpfds (head lt) (head rt)
