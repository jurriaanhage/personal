a = 2
b = 5
c = 7

aantal0pl x= a*x*x + b*x + c
