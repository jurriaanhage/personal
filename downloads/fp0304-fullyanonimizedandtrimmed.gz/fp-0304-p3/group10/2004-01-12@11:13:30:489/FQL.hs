module FQL (module List, module FQL) where

import List


type Table = [[String]]

compilers :: Table
compilers =
  [ ["Compiler", "Universiteit/bedrijf"]
  , ["Helium", "Universiteit van Utrecht"]
  , ["NHC", "University of York"]
  , ["GHC", "Microsoft Research"]
  , ["Hugs", "Galois Connections"]
  , ["Hugs.NET", "Galois Connections"]
  , ["O'Haskell", "Oregon Graduate Institute"]
  , ["O'Haskell", "Chalmers University of Technology"]
  , ["HBC", "Chalmers University of Technology"]
  ]

locaties :: Table
locaties =
  [ ["Universiteit/bedrijf", "Land", "Stad"]
  , ["Universiteit van Utrecht", "Nederland", "Utrecht"]
  , ["University of York", "Engeland", "York"]
  , ["Microsoft Research", "Engeland", "Cambridge"]
  , ["Galois Connections", "Verenigde Staten", "Beaverton"]
  , ["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
  , ["Chalmers University of Technology", "Zweden", "Goteborg"]
  ]

listLength :: [String] -> [Int]
listLength lijst = map length lijst

maxColumnWidth :: [String] -> Int
maxColumnWidth column = foldr (max) 0 (listLength column)

maxColumnWidths :: [[String]] -> [Int]
maxColumnWidths lijst  | null lijst = []
                       | otherwise = maxColumnWidth (head lijst) : maxColumnWidths (tail lijst)

newLine :: [Int] -> String
newLine lijst | null lijst = ""
              | otherwise = "+" ++ concat (replicate (head lijst)  "-") ++ newLine (tail lijst)

newEntry :: [String] -> [Int] -> String
newEntry lijst1 lijst2 | null lijst1 = "|"
                       | otherwise = "|" ++ (head lijst1) ++ concat(replicate ((head lijst2) - (length (head lijst1))) " ") ++ newEntry (tail lijst1) (tail lijst2)
