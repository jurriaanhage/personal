lijst :: [Int]
lijst = [1, 3, 5, 0, 2, 6, 0, 9, 8, 7, 0, 6, 5, 4]

totEerste :: [Int] -> [Int]
totEerste lijst | head lijst == 0 = 0
                | otherwise = head lijst + totEerste (tail lijst)

naEerste :: [Int] -> [Int]
naEerste lijst | head lijst == 0 = 0
               | otherwise = head lijst + naEerste (tail Lijst)

zonder :: [Int] -> [Int]
zonder Lijst | Lijst == [] = []
             | head Lijst == 0 = zonder (tail Lijst)
             | otherwise = head Lijst + zonder (tail Lijst)

vanafLaatste :: [Int] -> [Int]
vanafLaatste Lijst | Lijst == [] = []
                   | last Lijst == 0 = vanafLaatste (init Lijst)
                   | otherwise = last Lijst + vanafLaatste (init Lijst)
