data Boom a = Tak a (Boom a) (Boom a)
              | Blad

klinker :: Char -> Int
klinker x | elemBy eqChar x ['a','i','u','o','e'] = 1
          | otherwise = 0


telKlinkers Tak a x y = klinker a + telKlinkers x + telKlinkers y
telKlinkers Blad = 0
