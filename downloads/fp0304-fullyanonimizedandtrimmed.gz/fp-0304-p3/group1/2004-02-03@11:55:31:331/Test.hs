test :: [[a]] -> [[a]]
test [[]] = [[]]
test (x:xs) = map (eqList (==) x )xs
