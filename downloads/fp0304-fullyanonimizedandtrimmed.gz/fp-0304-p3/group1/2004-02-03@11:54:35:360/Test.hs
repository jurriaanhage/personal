test :: [[a]] -> [[a]]
test [[]] = [[]]
test (x:xs) = filter x
                    where map (eqList (==) x )xs = True
