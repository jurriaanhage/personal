test :: [[Int]] -> [[Bool]]
test [] = []
test (x:xs) = map (eqList (==) x) xs : test xs
