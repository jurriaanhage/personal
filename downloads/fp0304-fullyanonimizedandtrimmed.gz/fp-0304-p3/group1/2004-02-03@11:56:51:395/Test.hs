test :: [[a]] -> [[a]]
test [[]] = [[]]
test (x:xs) = filter y
                     where y = map (eqList (==) x )xs
