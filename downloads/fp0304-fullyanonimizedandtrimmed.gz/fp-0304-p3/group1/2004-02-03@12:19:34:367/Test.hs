test :: [[Int]] -> [[Bool]]
test [] = []
test (x:xs) = map (eqList (==) x) xs : test xs

test2 :: [[Int]] -> [Int]
test2 [] = []
test2 (x:xs) = if test (x:xs) == True then filter x
               else []
