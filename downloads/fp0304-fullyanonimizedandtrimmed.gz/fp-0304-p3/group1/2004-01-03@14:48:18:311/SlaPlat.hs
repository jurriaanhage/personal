slaPlat :: [[Int]]->[Int]
slaPlat []=[]
slaPlat (a:b) = a ++ slaPlat b

voegIn :: Int -> [Int] -> [Int]
voegIn a[] = a:[]
voegIn a (b:c) | a<=b a:(b:c)
               | a>b voegIn a c
