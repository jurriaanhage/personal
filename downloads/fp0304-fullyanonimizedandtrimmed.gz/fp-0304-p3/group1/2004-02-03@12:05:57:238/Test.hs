test :: [[a]] -> Bool
test (x:xs) = (map (eqList (==) x]) xs)
