test :: [Int] -> [Int]
test [] = []
test (x:xs) = filter (/=x) xs : x ++ test xs
