test :: [[Int]] -> [Bool]
test (x:xs) = map (eqList (==) x) xs ++ test xs
