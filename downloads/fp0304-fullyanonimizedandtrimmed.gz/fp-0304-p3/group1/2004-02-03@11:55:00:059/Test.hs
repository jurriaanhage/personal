test :: [[a]] -> [[a]]
test [[]] = [[]]
test (x:xs) = filter x
                    where x = map (eqList (==) x )xs = True
