module Fqlprac(module List, module Fqlprac) where

import List


type Table = [[String]]


compilers :: Table
compilers =
  [ ["Compiler", "Universiteit/bedrijf"]
  , ["Helium", "Universiteit van Utrecht"]
  , ["NHC", "University of York"]
  , ["GHC", "Microsoft Research"]
  , ["Hugs", "Galois Connections"]
  , ["Hugs.NET", "Galois Connections"]
  , ["O'Haskell", "Oregon Graduate Institute"]
  , ["O'Haskell", "Chalmers University of Technology"]
  , ["HBC", "Chalmers University of Technology"]
  ]

locaties :: Table
locaties =
  [ ["Universiteit/bedrijf", "Land", "Stad"]
  , ["Universiteit van Utrecht", "Nederland", "Utrecht"]
  , ["University of York", "Engeland", "York"]
  , ["Microsoft Research", "Engeland", "Cambridge"]
  , ["Galois Connections", "Verenigde Staten", "Beaverton"]
  , ["Oregon Graduate Institute", "Verenigde Staten", "Beaverton"]
  , ["Chalmers University of Technology", "Zweden", "Goteborg"]
  ]























writeTable :: Table -> String

writeTable [] = ""
writeTable [[]] = ""
writeTable (nField:record) =
              drawEasyLine transTable ++ writeRow transTable nField ++ drawEasyLine transTable ++
              writeMoreRows transTable record

                where transTable = transpose (nField:record)


























writeRow :: Table -> [String] -> String

writeRow (_:_) [] = ""
writeRow [] (_:_) = ""

writeRow [] []                        = "|\n"
writeRow (transHColumn:transTColumn)
         (x:xs)                       = "|" ++ drawSingle ' ' transHColumn x ++ writeRow transTColumn xs





























writeMoreRows :: Table -> Table -> String

writeMoreRows transTable []           = drawEasyLine transTable
writeMoreRows transTable (x:xs)       = writeRow transTable x ++ writeMoreRows transTable xs

















drawSingle :: Char -> [String] -> String -> String

drawSingle token transColumn word = word ++ replicate number token
                                 where number = getWidth transColumn - length word












getWidth :: [String] -> Int

getWidth []           = 0
getWidth (x:xs)       = max (length x) (getWidth xs)



















drawEasyLine :: Table -> String

drawEasyLine []                          = "+\n"
drawEasyLine (transHColumn:transTColumn) = "+" ++ drawSingle '-' transHColumn "" ++
                                            drawEasyLine transTColumn


































project :: [String] -> Table -> Table
project fields table = transpose (map (columnScan (transpose table)) fields)

























columnScan :: Table -> String -> [String]

columnScan table nField   | eqString (head currentColumn) nField = currentColumn
                          | otherwise                            = columnScan tableRemainder nField
                                  where currentColumn = head table
                                        tableRemainder = tail table




















select :: String -> (String -> Bool) -> Table -> Table

select field condition table = head table :
                             getRow (tail table) condition (tagColumn heads field)

                                      where heads = map head (transpose table)






















tagColumn :: [String] -> String -> Int

tagColumn heads field   | eqString (head heads) field = 1
                        | otherwise                   = 1 + tagColumn (tail heads) field

































getRow :: Table -> (String -> Bool) -> Int -> Table

getRow [] _ _                 = []
getRow table condition columnN  | condition a     = head table : getRow (tail table) condition columnN
                                | otherwise       = getRow (tail table) condition columnN
                                        where a   = (!!) (head table) (columnN-1)






















searchField :: [String] -> [String] -> String

searchField fieldNamesX fieldNamesY | elemBy (eqString) (head fieldNamesX) fieldNamesY = head fieldNamesX
                                    | otherwise                           = searchField (tail fieldNamesX)
                                                                                         fieldNamesY





































together :: [String] -> [String] -> [String]

together recordsX []  = recordsX
together recordsX recordsY | notElemBy (eqString) (head recordsY) recordsX =
                             together (reverse ((head recordsY) : (reverse recordsX))) (tail recordsY)
                           | otherwise = together recordsX (tail recordsY)



join :: Table -> Table -> Table
join a b = together((transpose a) ++ ( transpose b))
