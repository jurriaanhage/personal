data Prop = En [Prop]
          | Of [Prop]
          | Niet Prop
          | Prop :-> Prop
          | Var String
          | Bool Bool

type Bedeling = [String]
type Comb     = (Bool, [String])


evalueer :: Prop -> Bedeling -> Bool


evalueer (En (hProp:tProp)) listVar = evalueer hProp listVar && evalueer (En tProp) listVar
evalueer (En []) _ = True


evalueer (Of (hProp:tProp)) listVar = evalueer hProp listVar || evalueer (Of tProp) listVar
evalueer (Of []) _ = False


evalueer (Var s) listVar  | elemBy (eqString) s listVar = True
                          | otherwise = False


evalueer (Bool b) _ | b && True = True
                    | otherwise = False


evalueer (Niet a) listVar = not (evalueer a listVar)


evalueer (a :-> b) listVar = not (evalueer a listVar) || evalueer b listVar





vervulbaar :: Prop -> [Bedeling]

vervulbaar (Var s)  = zoekTupel (zip (map (evalueer(Var s)) (subs[s])) (subs[s])) True

vervulbaar (En a)     = zoekTupel (zip (map (evalueer(En a)) (subs (extract a))) (subs(extract a))) True
vervulbaar (Of a)     = zoekTupel (zip (map (evalueer(Of a)) (subs (extract a))) (subs(extract a))) True
vervulbaar (Niet a)   = zoekTupel (zip (map (evalueer(a)) (subs (filtreer a))) (subs(filtreer a))) False
vervulbaar ( a :-> b) = zoekTupel (zip (map (evalueer (a :-> b)) (subs (filtreer (a :-> b)))) (subs (filtreer (a :-> b)))) True

zoekTupel :: [Comb] -> Bool -> [Bedeling]

zoekTupel [] _              = []
zoekTupel ((bl,strng):rest) b | eqBool b bl = strng : zoekTupel rest b
                              | otherwise = zoekTupel rest b



extract :: [Prop] -> [String]

extract (hProp:tProp) = filtreer hProp ++ extract tProp
extract []            = []


filtreer :: Prop -> [String]

filtreer (Var s) = [s]
filtreer (En a) = (extract a)
filtreer (Of a) = (extract a)
filtreer (Niet a) = (filtreer a)
filtreer (a :-> b) = (filtreer a) ++  (filtreer b)
filtreer (Bool b) | b && True = []
                  | otherwise ["False"]



subs :: [a] -> [[a]]
subs [] = [[]]
subs (x:xs) = map (x:) subsxs ++ subsxs
         where subsxs = subs xs
