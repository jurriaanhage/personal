test :: [[Int]] -> [Bool]
test [[]] = True
test (x:xs) = map (eqList (==) x) xs ++ test xs
