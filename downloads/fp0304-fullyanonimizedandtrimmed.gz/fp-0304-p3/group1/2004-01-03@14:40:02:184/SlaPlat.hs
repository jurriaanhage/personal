slaPlat :: [[Int]]->[Int]
slaPlat []=[]
slaPlat (a:b) = a ++ slaPlat b
