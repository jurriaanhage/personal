test :: [Int] -> [Int]
test [] = []
test (x:xs) = x: filter (/=x) xs : test xs
