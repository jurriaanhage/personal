voegIn :: Int -> [Int] -> [Int]
voegIn a (b:c) | a<=b = a:(b:c)
               | a>b
