test :: [[Int]] -> [[Int]]
test (x:xs) | map (eqList (==) x) xs : test xs == True = filter x
