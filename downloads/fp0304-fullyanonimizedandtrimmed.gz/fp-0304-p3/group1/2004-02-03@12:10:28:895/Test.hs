test :: [[Int]] -> [[Bool]]
test [] = [[False]]
test (x:xs) = map (eqList (==) x) xs ++ test xs
