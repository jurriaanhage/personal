test :: [a] -> [a]
test [] = []
test (x:xs) = filter (/=x) xs
