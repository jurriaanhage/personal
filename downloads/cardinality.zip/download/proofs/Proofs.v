Require Export Dynamic.

Definition validAnn := fun a => a <> abottom.

Definition validState (s : State) : Prop :=
  AnnAndState validAnn s
.

Lemma AnnAndA_Replace : forall f p q a, AnnAndA f a = AnnAndA f (replaceAtomA p q a).
Proof.
  auto.
Qed.

Lemma AnnAnd_Replace : forall f p q,
  (forall m, AnnAndM f m = AnnAndM f (replaceAtomM p q m)) /\
  (forall r, AnnAndR f r = AnnAndR f (replaceAtomR p q r)) /\
  (forall v, AnnAndV f v = AnnAndV f (replaceAtomV p q v)) /\
  (forall ls, AnnAndMLets f ls = AnnAndMLets f (replaceAtomLets p q ls)) /\
  (forall cs, AnnAndMCases f cs = AnnAndMCases f (replaceAtomCases p q cs)).
Proof.
  intros.
  apply MRV_ind; intros.
    simpl. rewrite H0. rewrite H. auto.
    simpl. rewrite H0. rewrite H. auto.
    apply (AnnAndA_Replace f p q).
    simpl. rewrite H. auto.
    simpl. apply AnnAndA_Replace.
    simpl. apply H.
    simpl. apply H.
    simpl. induction l.
      auto.
      simpl. rewrite IHl. auto.
    simpl. rewrite H. auto.
    simpl. auto.
    simpl. rewrite H. rewrite H0. auto.
    simpl. auto.
    simpl. rewrite H. rewrite H0. auto.
Qed.

Lemma AnnAndM_Replace : 
  forall f p q m, AnnAndM f m = AnnAndM f (replaceAtomM p q m).
Proof.
  apply AnnAnd_Replace.
Qed.

Lemma AnnAndM_Replaces :
  forall f x m, AnnAndM f m = AnnAndM f (replaceAtomMs x m).
Proof.
  intros. 
  induction x.
    auto.
    simpl. rewrite IHx. rewrite <- AnnAndM_Replace. auto.
Qed.

Lemma x_iff_True_and_x : forall x, x <-> True /\ x.
Proof.
  split; intros.
    apply conj; auto.
    inversion H. auto.
Qed.

Lemma NameMap_all_remove : 
  forall {A : Type} (m : NameMap.t A) P x, 
    NameMap_all P m -> NameMap_all P (NameMap.remove x m).
Proof.
  unfold NameMap_all.
  intros.
  apply (H k).
  apply (NameMap.remove_3) with (x := x).
  auto.
Qed.

Lemma MapsTo_add_eq :
  forall {A : Type} k v1 v2 (m : NameMap.t A),
    NameMap.MapsTo k v1 (NameMap.add k v2 m) -> v1 = v2.
Proof.
  intros.
  rewrite NameFacts.add_mapsto_iff in H. inversion H.
    inversion H0. auto.
    inversion H0. contradiction H1. auto.
Qed.

Lemma AnnAndMCases_1 :
  forall f cs,
    AnnAndMCases f cs -> NameMap_all (fun x => AnnAndM f (snd x)) (MCases_toNameMap cs).
Proof.
  unfold NameMap_all.
  intros.
  induction cs; simpl.
    inversion H0.
    simpl in H. inversion H. simpl in H0. generalize H0. intros. rewrite NameFacts.add_mapsto_iff in H3. inversion H3.
      inversion H4. rewrite <- H6. simpl. auto.
      apply IHcs.
        auto.
        inversion H4. apply NameMap.add_3 in H0; auto.
Qed.

Lemma AnnAndMLets_1 :
  forall f ls,
    AnnAndMLets f ls -> NameMap_all (fun x => f (fst (fst x)) /\ f (snd (fst x)) /\ AnnAndM f (snd x)) (MLets_toNameMap ls).
Proof.
  unfold NameMap_all.
  intros.
  induction ls; simpl.
    inversion H0.
    simpl in H. inversion H. inversion H2. inversion H4. simpl in H0. generalize H0. intros. rewrite NameFacts.add_mapsto_iff in H7. inversion H7.
      inversion H8. rewrite <- H10. simpl. auto.
      apply IHls.
        auto.
        inversion H8. apply NameMap.add_3 in H0; auto.
Qed.        

Lemma AnnAndMLets_2 :
  forall f ls, 
    AnnAndMLets f (MLets_fromNameMap ls) -> NameMap_all (fun x => f (fst (fst x)) /\ f (snd (fst x)) /\ AnnAndM f (snd x)) ls.
Proof.
  intros.
  remember (AnnAndMLets_1 f (MLets_fromNameMap ls)).
  admit.
Admitted.

Definition NameMap_disjoint {A B : Type} (m1 : NameMap.t A) (m2 : NameMap.t B) := 
  forall x,  
    (NameMap.In x m1 -> ~NameMap.In x m2) /\ 
    (NameMap.In x m2 -> ~NameMap.In x m1).

Lemma union_disjoint :
  forall {A : Type} P m1 m2,
    @NameMap_disjoint A A m1 m2 -> (NameMap_all P (NameMap_union m1 m2) <-> (NameMap_all P m1 /\ NameMap_all P m2)).
Proof.
Admitted.

(* use tactic 'generalize dependent' when variables are swapped *)

Lemma preservation_1 : 
  forall s1 s2 (step : Step s1 s2) (state : validState s1), validState s2.
Proof.
  intros s1 s2 step.
  inversion step; intros state; unfold validState; unfold AnnAndState; simpl; unfold validState in state; unfold AnnAndState in state; simpl in state.
    rewrite and_assoc in state. auto.
    inversion state. inversion H4. inversion H5. inversion H6. split.
      auto.
      split.
        inversion H0. 
          rewrite <- AnnAndM_Replace. rewrite <- H12 in H7. simpl in H7. auto.
          rewrite <- AnnAndM_Replaces. rewrite <- H13 in H9. simpl in H9. 
            unfold Cases_find in H11. apply AnnAndMCases_1 in H9. rewrite <- NameFacts.find_mapsto_iff in H11. 
            unfold NameMap_all in H9. apply H9 in H11. simpl in H11. auto.
          rewrite <- H11 in H9. simpl in H9. rewrite <- H13. auto.
        auto.
    rewrite H5. rewrite <- AnnAndM_Replaces. inversion state. inversion H9. inversion H10. split.
      apply union_disjoint.
        admit. (* -- *)
        split.
          auto.
          rewrite H4. rewrite H3. unfold NameMap_map_key. unfold NameMap_all. intros. apply AnnAndMLets_2 in H12. unfold NameMap_all in H12. apply (H12 k).
            admit. (* -- *)
      split; auto.
    inversion state. inversion H7. unfold AnnAndH in H6. unfold NameMap_all in H6. split.
      unfold AnnAndH. unfold NameMap_all. intros. apply NameMap.remove_3 in H10. apply (H6 k v H10).
      split.
        apply H6 in H. simpl in H. inversion H. inversion H11. auto.
        split.
          auto.
          split; auto.
    inversion state. inversion H4. inversion H5. inversion H6. inversion H10. split.
      unfold AnnAndH. unfold NameMap_all. intros. elim (Name_eq_dec x k).
        intros. rewrite a in H13. apply MapsTo_add_eq in H13. rewrite H13. simpl. split.
          auto.
          split.
            auto.
            split; auto.
        intros. apply NameMap.add_3 in H13. 
          unfold AnnAndH in H3. unfold NameMap_all in H3. apply H3 in H13. auto.
          auto.
      split.
        split; auto.
        auto.
Qed.

Lemma preservation_2 : forall h1 h2 e1 e2 s1 s2 sigma
  (step : Step (h1, ExprToM e1, s1) (h2, ExprToM e2, s2))
  (type : Static (NameMap.empty _) e1 sigma),
  Static (NameMap.empty _) e2 sigma.
Proof.
Admitted.

Lemma preservation : forall h1 h2 e1 e2 s1 s2 sigma,
  Static (NameMap.empty _) e1 sigma /\ validState (h1, ExprToM e1, s1) ->
  Step (h1, ExprToM e1, s1) (h2, ExprToM e2, s2) ->
  Static (NameMap.empty _) e2 sigma /\ validState (h2, ExprToM e2, s2).
Proof.
  intros. 
  inversion H. 
  split.
    apply (preservation_2 h1 h2 e1 e2 s1 s2); assumption.
    apply (preservation_1 (h1, ExprToM e1, s1) (h2, ExprToM e2, s2)); assumption.
Qed.
