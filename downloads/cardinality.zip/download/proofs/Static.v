Require Export Data.

Definition zipWith {X Y Z : Type} (f : X -> Y -> Z) (xs : list X) (ys : list Y) : (list Z) :=
  map (fun z => 
    match z with
    | (x, y) => f x y
    end) (combine xs ys)
.

Definition all (l : list Prop) : Prop := 
  fold_right (fun p e => p /\ e) True l
.

Inductive Static : Env -> Expr -> Sigma Tau -> Prop :=
  | SVar : forall g s name, 
      (g = NameMap_singleton name (RhoC s aone)) ->
      Static g (EVar name) s
  | SAbs : forall g s nu name rho body gamma sigma,
      (Static gamma body sigma) ->
      (g = env_times nu gamma) ->
      (s = SigmaC (TAbs rho sigma) nu) ->
      Static g (EAbs nu name rho body) s
  | SApp : forall g s f name gamma rho,
      (Sharing gamma f (SigmaC (TAbs rho s) aone)) ->
      (Diamond (NameMap_singleton name (RhoC (fst rho) aone)) (EVar name) (fst rho)) ->
      (env_plus gamma (NameMap_singleton name rho) g) ->
      Static g (EApp f name) s
  | SLet : forall g s defs names rhos bodies body gamma gammas sigmas deltas tmpgamma,
      (names = map (fun x => fst x) defs) ->
      (rhos = map (fun x => fst (snd x)) defs) ->
      (bodies = map (fun x => snd (snd x)) defs) ->
      (rhos = zipWith SigmaC sigmas deltas) ->
      (forall tmp, env_plus gamma tmp tmpgamma /\ (env_list_plus (zipWith env_guard deltas gammas) tmp)) ->
      (all (zipWith (fun name rho => 
        match NameMap.find name tmpgamma with
        | Some r => rho = r
        | None => True
        end) names rhos)) -> 
      (g = NameMap_removes names tmpgamma) ->
      (Static gamma body s) ->
      (Statics gammas bodies sigmas) ->
      Static g (ELet (ELets_fromNameMap (NameMap_fromList defs)) body) s
  | SSeq : forall g1 e1 tau1 g2 e2 g s,
      Sharing g1 e1 (SigmaC tau1 azero) ->
      Static g2 e2 s ->
      (env_plus g1 g2 g) ->
      Static g (ESeq e1 e2) s
with Statics : list Env -> list Expr -> list (Sigma Tau) -> Prop :=
  | SCons : forall g gs e es s ss,
      Static g e s ->
      Statics gs es ss ->
      Statics (g :: gs) (e :: es) (s :: ss)
  | SNil : Statics nil nil nil
(* sharing subtyping *)
with Sharing : Env -> Expr -> Sigma Tau -> Prop :=
  | SharingC : forall g e s nu,
      Static g e (SigmaC (fst s) nu) ->
      ann_le (snd s) nu ->
      Sharing g e s
(* uniqueness subtyping *)
with Uniqueness : Env -> Expr -> Sigma Tau -> Prop := 
  | UniquenessC : forall g e s,
      Static g e s ->
      Uniqueness g e s
(* instantiate with either sharing or uniqueness *)
with Diamond : Env -> Expr -> Sigma Tau -> Prop := 
  | DiamondC : forall g e s,
      Uniqueness g e s ->
      Diamond g e s
.

Definition infer : 
  forall e, { gs | Static (fst gs) e (snd gs) }.
Admitted.

