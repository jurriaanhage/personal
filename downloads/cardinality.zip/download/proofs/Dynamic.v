Require Export Static.

Definition set_fromList (vs : list Name) : set Name :=
  fold_right (@set_add _ Name_eq_dec) vs (empty_set _)
.

Definition set_disjoint (s1 s2 : set Name) : Prop :=
  set_inter Name_eq_dec s1 s2 = empty_set _
.

Definition list_unique (vs : list Name) : Prop :=
  length vs = length (set_fromList vs)
.

Definition r_use (r : R) : Nu :=
  match r with
  | RApp _ => aone
  | RCase _ => aone
  | RSeq _ => azero
  end
.

Fixpoint s_use (s : S) : Nu :=
  match s with
  | SEmpty => azero
  | SShallow r _ => r_use r
  | SVarUpdate (nu, delta) x s => ann_plus nu (s_use s)
  end
.

Definition h_dom (h : H) : set Name :=
  fold_right (@set_add _ Name_eq_dec) (map fst (NameMap_toList h)) (empty_set _)
.

Fixpoint s_dom (s : S) : set Name :=
  match s with
  | SShallow _ s' => s_dom s'
  | SVarUpdate (nu, delta) name s => @set_add _ Name_eq_dec name (s_dom s)
  | SEmtpy => (empty_set _)
  end
.

Inductive StepDelta : R -> V -> M -> Prop :=
  | SDApp : forall a m x,
      StepDelta (RApp a) (VAbs x m) (replaceAtomM (AVar x) a m)   
  | SDCase : forall cases k atoms xs m,
      (Cases_find k cases = Some (xs, m)) ->
      (length xs = length atoms) ->
      StepDelta (RCase cases) (VCon k atoms) (replaceAtomMs (combine (map AVar xs) atoms) m)
  | SDSeq : forall m v,
      StepDelta (RSeq m) v m
.

Definition NameMap_map_key {A : Type} (f : Name -> Name) (m : NameMap.t A) : NameMap.t A :=
  NameMap.fold (fun k v => NameMap.add (f k) v) (NameMap.empty _) m
.

Inductive Step : State -> State -> Prop :=
  | SUnwind : forall h r m s, 
      Step (h, MShallow m r, s) (h, m, SShallow r s)
  | SReduce : forall h v nu r s m,
      ann_le nu (r_use r) -> 
      StepDelta r v m ->
      Step (h, MValue v nu, SShallow r s) (h, m, s)
  | SLet : forall h xs ys phi body s defs defs' defs'',
      (xs = map fst (NameMap_toList defs)) ->
      (length xs = length ys) ->
      (list_unique ys) ->
      (set_disjoint (set_fromList ys) (set_union Name_eq_dec (h_dom h) (s_dom s))) ->
      (defs' = NameMap_map_key (fun x => match NameMap.find x (NameMap_fromList (combine xs ys)) with
                 | Some y => y
                 | None => x
               end) defs) ->
      (defs'' = NameMap.map (fun value => match value with
                  | (nu, delta, def) => (nu, delta, phi def)
                end) defs') ->
      (phi = replaceAtomMs (combine (map AVar xs) (map AVar ys))) ->
      Step (h, MLet (MLets_fromNameMap defs) body, s) (NameMap_union h defs'', phi body, s)
  | SLookup : forall h x s nu delta m nu' delta',
      (NameMap.MapsTo x (nu, delta, m) h) ->
      (nu' = ann_sub nu (s_use s)) ->
      (delta' = ann_sub delta aone) ->
      (nu' <> abottom) ->
      (delta' <> abottom) ->
      Step (h, MAtom (AVar x), s) (NameMap.remove x h, m, SVarUpdate (nu', delta') x s)
  | SUpdate : forall h v nu1 nu2 nu3 delta2 x s,
      (nu3 = ann_sub nu1 nu2) ->
      (nu3 <> abottom) ->
      Step (h, MValue v nu1, SVarUpdate (nu2, delta2) x s) (NameMap.add x (nu2, delta2, MValue v nu2) h, MValue v nu3, s)
.

