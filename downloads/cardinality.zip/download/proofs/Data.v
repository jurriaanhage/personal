Require Export Coq.Lists.ListSet.
Require Export Coq.Lists.List.
Require Export Coq.Program.Syntax.
Require Export Coq.FSets.FMapList.
Require Export Coq.Structures.OrderedTypeEx.
Require Export Coq.FSets.FMapFacts.

Definition eq_dec (A : Type) :=
  forall x y : A, {x = y} + {x <> y}
.

(* Counts *)

Inductive Count : Type :=
  | Zero : Count
  | One : Count
  | Omega : Count
.

Definition Count_eq_dec : eq_dec Count.
Proof.
  unfold eq_dec.
  intros.
  destruct x.
    destruct y.
      left. auto.
      right. intro F. inversion F.
      right. intro F. inversion F.
    destruct y.
      right. intro F. inversion F.
      left. auto.
      right. intro F. inversion F.
    destruct y.
      right. intro F. inversion F.
      right. intro F. inversion F.
      left. auto.
Qed.

Definition count_plus (x : Count) (y : Count) : Count :=
  match x, y with
  | Zero, y => y
  | x, Zero => x
  | _, _ => Omega
  end
.

(* Annotations *)

Definition Annotation := set Count.

Definition ann_sub (x : Annotation) (y : Annotation) : Annotation.
Admitted.

Definition ann_plus (x : Annotation) (y : Annotation) : Annotation := 
  set_fold_left (fun s x => 
    set_fold_left (fun s y => 
      set_add Count_eq_dec (count_plus x y) s
    ) y s
  ) x (empty_set Count)
.

Definition ann_meet (x : Annotation) (y : Annotation) : Annotation :=
  set_union Count_eq_dec x y
.

Definition ann_times (x : Annotation) (y : Annotation) : Annotation.
Admitted.
  
Definition ann_guard (x : Annotation) (y : Annotation) : Annotation.
Admitted.

Definition ann_le (x : Annotation) (y : Annotation) : Prop :=
  y = ann_meet x y
.  

Definition abottom : Annotation :=
  empty_set Count
.

Definition azero : Annotation := 
  set_add Count_eq_dec Zero (empty_set Count)
.

Definition aone : Annotation := 
  set_add Count_eq_dec One (empty_set Count)
.

(* Types *)

Module Name_as_OT := Nat_as_OT.
Definition Name := Name_as_OT.t.
Definition Names := list Name.
Definition Name_eq_dec := Name_as_OT.eq_dec.

Module NameMap := FMapList.Make Name_as_OT.
Module NameFacts := Facts NameMap.

Definition NameMap_singleton {A : Type} (k : Name) (v : A) : NameMap.t A :=
  NameMap.add k v (NameMap.empty _)
.

Definition NameMap_removes {A : Type} (ks : list Name) (m : NameMap.t A) : NameMap.t A :=
  fold_right (@NameMap.remove A) m ks
.

Definition NameMap_toList {A : Type} (m : NameMap.t A) : list (Name * A) :=
  NameMap.elements m
.

Definition NameMap_fromList {A : Type} (ls : list (Name * A)) : NameMap.t A :=
  fold_right (fun l r => NameMap.add (fst l) (snd l) r) (NameMap.empty _) ls 
.

Definition NameMap_all {A : Type} (P : A -> Prop) (m : NameMap.t A) : Prop := 
  forall k v, NameMap.MapsTo k v m -> P v
.

Definition NameMap_union {A : Type} (m1 m2 : NameMap.t A) : NameMap.t A :=
  NameMap.fold (@NameMap.add A) m2 m1
.

Definition Nu := Annotation.
Definition Delta := Annotation.

Definition Sigma (A : Type) := prod A Nu.
Definition Rho (A : Type) := prod (Sigma A) Delta.

Inductive Tau : Type :=
  | TAbs : Rho Tau -> Sigma Tau -> Tau
  | TData : Name -> list Annotation -> list Tau -> Tau
.

Definition SigmaC {A : Type} (a : A) (n : Nu) : Sigma A :=
  (a,n)
.
Definition RhoC {A : Type} (s : A * Nu) (d : Delta) : Rho A := 
  (s,d)
.

Definition tau_plus (t1 t2 t3 : Tau) : Prop :=
  t1 = t2 /\ t2 = t3
.

Definition sigma_plus {A : Type} (f : A -> A -> A -> Prop) (s1 s2 s3 : Sigma A) : Prop :=
  f (fst s1) (fst s2) (fst s3) /\ ann_plus (snd s1) (snd s2) = (snd s3)
.

Definition rho_plus {A : Type} (f : A -> A -> A -> Prop) (r1 r2 r3 : Rho A) : Prop :=
  sigma_plus f (fst r1) (fst r2) (fst r3) /\ ann_plus (snd r1) (snd r2) = (snd r3)
.

(* Environment *)

Definition Env := NameMap.t (Rho Tau).

Definition env_plus (g1 : Env) (g2 : Env) (g3 : Env) : Prop :=
  forall name, 
    (NameMap.find name g1 = None /\ NameMap.find name g2 = None -> NameMap.find name g3 = None) /\
    (forall x, NameMap.find name g1 = Some x /\ NameMap.find name g2 = None -> NameMap.find name g3 = Some x) /\
    (forall y, NameMap.find name g1 = None /\ NameMap.find name g2 = Some y -> NameMap.find name g3 = Some y) /\
    (forall x y z, NameMap.find name g1 = Some x /\ NameMap.find name g2 = Some y -> NameMap.find name g3 = Some z /\ rho_plus tau_plus x y z)
.

Definition env_list_plus (gs : list Env) (g : Env) : Prop.
Admitted.

Definition env_meet : Env -> Env -> Env.
Admitted.

Definition env_list_meet (es : list Env) : Env :=
  fold_right env_meet (NameMap.empty _) es
.

Definition env_times : Annotation -> Env -> Env.
Admitted.

Definition env_guard : Annotation -> Env -> Env.
Admitted.

(* Syntax static semantics *)

Inductive Expr : Type :=
  | EVar : Name -> Expr
  | ECon : Nu -> Name -> list Annotation -> list Tau -> list Name -> Expr
  | EAbs : Nu -> Name -> Rho Tau -> Expr -> Expr
  | EApp : Expr -> Name -> Expr
  | ECase : Expr -> Tau -> ECases -> Expr
  | ESeq : Expr -> Expr -> Expr
  | ELet : ELets -> Expr -> Expr
with ELets : Type :=
  | ELNil : ELets
  | ELCons : Name -> Rho Tau -> Expr -> ELets -> ELets
with ECases : Type :=
  | ECNil : ECases
  | ECCons : Name -> list Name -> Expr -> ECases -> ECases
.

Definition ECases_fromNameMap (l : NameMap.t (Names * Expr)) : ECases :=
  NameMap.fold (fun k v => ECCons k (fst v) (snd v)) l ECNil 
.

Fixpoint ECases_toNameMap (cs : ECases) : NameMap.t (Names * Expr) :=
  match cs with
  | ECNil => NameMap.empty _
  | ECCons name names m cs => NameMap.add name (names, m) (ECases_toNameMap cs)
  end
.

Definition ELets_fromNameMap (l : NameMap.t (Rho Tau * Expr)) : ELets :=
  NameMap.fold (fun k v => ELCons k (fst v) (snd v)) l ELNil
.

Fixpoint ELets_toNameMap (ls : ELets) : NameMap.t (Rho Tau * Expr) :=
  match ls with
  | ELNil => NameMap.empty _
  | ELCons name rho m ls => NameMap.add name (rho, m) (ELets_toNameMap ls)
  end
.

(* Syntax operational semantics *)

Inductive A : Type :=
  | AVar : Name -> A
.

Definition A_eq_dec : eq_dec A.
Proof.
  unfold eq_dec.
  intros.
  destruct x as [ name1 ]. 
  destruct y as [ name2 ].
  destruct (Name_eq_dec name1 name2) as [ H | H ].
    left. rewrite H. auto.
    right. intro F. apply H. inversion F. auto. 
Qed.

Inductive M : Type :=
  | MShallow : M -> R -> M
  | MLet : MLets -> M -> M
  | MAtom : A -> M
  | MValue : V -> Nu -> M
with R : Type :=
  | RApp : A -> R
  | RCase : MCases -> R
  | RSeq : M -> R
with V : Type :=
  | VCon : Name -> list A -> V
  | VAbs : Name -> M -> V
with MLets : Type :=
  | MLNil : MLets
  | MLCons : Name -> Nu -> Delta -> M -> MLets -> MLets
with MCases : Type :=
  | MCNil : MCases
  | MCCons : Name -> Names -> M -> MCases -> MCases
.

Scheme M_ind2 := Induction for M Sort Prop
with R_ind2 := Induction for R Sort Prop
with V_ind2 := Induction for V Sort Prop
with MLets_ind2 := Induction for MLets Sort Prop
with MCases_ind2 := Induction for MCases Sort Prop.

Combined Scheme MRV_ind from M_ind2, R_ind2, V_ind2, MLets_ind2, MCases_ind2.

Definition MCases_fromNameMap (l : NameMap.t (Names * M)) : MCases :=
  NameMap.fold (fun k v => MCCons k (fst v) (snd v)) l MCNil 
.

Fixpoint MCases_toNameMap (cs : MCases) : NameMap.t (Names * M) :=
  match cs with
  | MCNil => NameMap.empty _
  | MCCons name names m cs => NameMap.add name (names, m) (MCases_toNameMap cs)
  end
.

Definition MLets_fromNameMap (l : NameMap.t (Nu * Delta * M)) : MLets :=
  NameMap.fold (fun k v => MLCons k (fst (fst v)) (snd (fst v)) (snd v)) l MLNil
.

Fixpoint MLets_toNameMap (ls : MLets) : NameMap.t (Nu * Delta * M) :=
  match ls with
  | MLNil => NameMap.empty _
  | MLCons name nu delta m ls => NameMap.add name (nu, delta, m) (MLets_toNameMap ls)
  end
.

Definition Lets_add := fun k v ls => MLets_fromNameMap (NameMap.add k v (MLets_toNameMap ls)).
Definition Cases_find := fun k cs => NameMap.find k (MCases_toNameMap cs).

(* Additional datatypes for dynamic semantics *)

Definition H := NameMap.t (Nu * Delta * M).
Inductive S : Type :=
  | SEmpty : S
  | SShallow : R -> S -> S
  | SVarUpdate : Nu * Delta -> Name -> S -> S
.

Definition State := prod (prod H M) S.

(* Substition of atoms *)

Definition replaceAtomA (search : A) (replace : A) (a : A) : A :=
  match A_eq_dec search a with
  | left _ => replace
  | right _ => a
  end
.

Fixpoint replaceAtomM (search : A) (replace : A) (m : M) : M :=
  match m with
  | MShallow m r => MShallow (replaceAtomM search replace m) (replaceAtomR search replace r)
  | MLet defs body => MLet (replaceAtomLets search replace defs) (replaceAtomM search replace body)
  | MAtom a => MAtom (replaceAtomA search replace a)
  | MValue v nu => MValue (replaceAtomV search replace v) nu
  end
with replaceAtomR (search : A) (replace : A) (r : R) : R :=
  match r with
  | RApp a => RApp (replaceAtomA search replace a)
  | RCase arms => RCase (replaceAtomCases search replace arms)
  | RSeq m => RSeq (replaceAtomM search replace m)
  end
with replaceAtomV (search : A) (replace : A) (v : V) : V :=
  match v with
  | VCon name atoms => VCon name (map (replaceAtomA search replace) atoms)
  | VAbs name m => VAbs name (replaceAtomM search replace m)
  end
with replaceAtomLets (search : A) (replace : A) (l : MLets) : MLets := 
  match l with
  | MLNil => MLNil
  | MLCons x nu delta m ls => MLCons x nu delta (replaceAtomM search replace m) (replaceAtomLets search replace ls)
  end
with replaceAtomCases (search : A) (replace : A) (c : MCases) : MCases :=
  match c with
  | MCNil => MCNil
  | MCCons x names m cs => MCCons x names (replaceAtomM search replace m) (replaceAtomCases search replace cs)
  end
.

Definition replaceAtomMs (srs : list (A * A)) (m : M) : M :=
  fold_right (fun x => replaceAtomM (fst x) (snd x)) m srs.

Definition AnnAndA (f : Annotation -> Prop) (a : A) : Prop :=
  True
.

Fixpoint AnnAndM (f : Annotation -> Prop) (m : M) : Prop :=
  match m with
  | MShallow m r => AnnAndM f m /\ AnnAndR f r
  | MLet defs body => AnnAndMLets f defs /\ AnnAndM f body
  | MAtom a => AnnAndA f a
  | MValue v nu => AnnAndV f v /\ f nu
  end
with AnnAndR (f : Annotation -> Prop) (r : R) : Prop :=
  match r with
  | RApp a => AnnAndA f a
  | RCase alts => AnnAndMCases f alts
  | RSeq m => AnnAndM f m
  end
with AnnAndV (f : Annotation -> Prop) (v : V) : Prop :=
  match v with
  | VCon name atoms => fold_right (fun a c => AnnAndA f a /\ c) True atoms
  | VAbs x body => AnnAndM f body
  end
with AnnAndMLets (f : Annotation -> Prop) (ls : MLets) : Prop :=
  match ls with
  | MLNil => True
  | MLCons x nu delta m ls => f nu /\ f delta /\ AnnAndM f m /\ AnnAndMLets f ls
  end
with AnnAndMCases (f : Annotation -> Prop) (cs : MCases) : Prop :=
  match cs with
  | MCNil => True
  | MCCons name names m cs => AnnAndM f m /\ AnnAndMCases f cs
  end
.

Fixpoint AnnAndS (f : Annotation -> Prop) (s : S) : Prop :=
  match s with
  | SEmpty => True
  | SShallow r s => AnnAndR f r /\ AnnAndS f s
  | SVarUpdate (nu, delta) x s => f nu /\ f delta /\ AnnAndS f s
  end
.

Definition AnnAndH (f : Annotation -> Prop) (h : H) : Prop :=
  NameMap_all (fun x => f (fst (fst x)) /\ f (snd (fst x)) /\ AnnAndM f (snd x)) h
.

Definition AnnAndState (f : Annotation -> Prop) (s : State) : Prop :=
  AnnAndH f (fst (fst s)) /\ AnnAndM f (snd (fst s)) /\ AnnAndS f (snd s)
.  

(* Conversions *)

Fixpoint trans (h : H) (m : M) (s : S) : M :=
  match s with
  | SEmpty => MLet (MLets_fromNameMap h) m
  | SShallow r s => trans h (MShallow m r) s
  | SVarUpdate (nu, delta) x s => trans (NameMap.add x (nu, delta, m) h) (MAtom (AVar x)) s
  end
.

Definition StateToM (s : State) : M :=
  match s with
  | (h, m, s) => trans h m s
  end
.

Definition MToState (m : M) : State :=
  (NameMap.empty _, m, SEmpty)
.

Fixpoint ExprToM (e : Expr) : M :=
  match e with
  | EVar name => MAtom (AVar name)
  | ECon nu name anns taus names => MValue (VCon name (map AVar names)) nu
  | EAbs nu name rho body => MValue (VAbs name (ExprToM body)) (snd (fst rho))
  | EApp f name => MShallow (ExprToM f) (RApp (AVar name))
  | ECase p tau arms => 
      MShallow (ExprToM p) (RCase (ECasesToM arms))
  | ESeq e1 e2 => MShallow (ExprToM e1) (RSeq (ExprToM e2))
  | ELet defs body => 
      MLet (ELetsToM defs) (ExprToM body)
  end
with ELetsToM (lets : ELets) : MLets := 
  match lets with
  | ELNil => MLNil
  | ELCons name rho e lets => MLCons name (snd (fst rho)) (snd rho) (ExprToM e) (ELetsToM lets)
  end
with ECasesToM (cases : ECases) : MCases :=
  match cases with
  | ECNil => MCNil
  | ECCons name names e cases => MCCons name names (ExprToM e) (ECasesToM cases)
  end
.