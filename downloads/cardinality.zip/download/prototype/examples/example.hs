data Bool
  = True
  | False

data Either a b
  = Left a
  | Right b  

data Tuple a b
  = Pair a b

data Nat
  = Zero
  | Succ Nat

data List a
  = Nil
  | Cons a (List a)

{-
--- twice ---
-- twice h@[] = h@[]
-- twice h@(x:xs) = h@(x:(h@(x:xs)))
twice = \as -> case as of
                 Nil h -> Nil h
                 Cons h b bs -> let tb = twice bs
                                    chbt = Cons h b tb
                                in Cons h b chbt

main = twice                                
--}                                

--{-
--- swap ---
-- swap h@(a,b) = h@(b,a)
swap = \x -> case x of
               Pair h a b -> Pair h b a

main = swap
--}

{-
--- reverse ---
reverse = \as -> let rev = \bs -> \acc -> case bs of
                                            Nil 0 -> acc
                                            Cons h c cs -> let r = (Cons h c acc) 
                                                           in rev cs r
                     n = Nil 0
                 in rev as n

main = reverse                 
--}

{-
plus = \x -> \y -> case x of
                     Zero 0 -> y
                     Succ 0 z -> let r = plus z y in Succ 0 r

main = plus                     
--}

{-
--- default apply ---

main = \f -> \x -> f x
--}

{-
--- default const ---

main = \x -> \y -> x
--}

{-
--- default dup ---
dup = \x -> (x,x)

main = dup
--}

{-
--- evil dup ---
dup = \x ->
  let const = \x -> \y -> x
      cx = const x
      undefined = undefined
  in  (\f -> let r = f undefined in (r,r)) cx 

main = dup
--}

{-
--- plus ---

main = \x -> \y -> case x of
                     Zero -> y
                     Succ x' -> let r = main x' y in Succ r

--}

{-
plus = \x -> \y -> case x of
                     Zero 0 -> y
                     Succ 0 x' -> let r = plus x' y in Succ 0 r

sum = \as -> case as of
               Nil 0 -> 0
               Cons 0 b bs -> let r = sum bs in plus b r

length = \as -> case as of
                  Nil 0 -> 0
                  Cons 0 b bs -> let r = length bs in Succ 0 r

main = \as -> let sum' = sum as
                  length' = length as
              in plus sum' length'
--}

{-
plus1 = \x -> case x of
                Zero -> \y -> y
                Succ x' -> \y -> let r = plus1 x' y in Succ r

zero = 0

main = plus1 zero zero
--}

{-
plus2 = \x -> \y -> case x of
                      Zero -> y
                      Succ z -> let r = plus2 z y in Succ r

main = plus2
--}

{-
x = x

main = x
--}

{-
f = \x -> f x

zero = 0

main = f zero
--}

{-
f = \x -> g x
g = \y -> f y

zero = 0

main = f zero
--}