module Simplify where

import Data
import Control.Arrow (second)
import Data.Graph
import Data.Var
import Debug.Trace
import qualified Data.Set as S
import qualified Data.Map as M
import qualified Data.Foldable as F
import Utils

trace' :: Show a => a -> a
trace' x = trace (show x) x

progress :: Show b => String -> (b -> a) -> b -> a
progress s f cs' = trace (s ++ ": " ++ show cs') (f cs')

solve :: [Constraint] -> InfM [Constraint]
solve cs = do
  cs' <- simplify cs
  let m = possibleValues cs' M.empty
      (var,values) = M.elemAt 0 m
  if M.null m
    then return []
    else foldr (<|>) empty $ map (\value -> do substitute (AVar var) (AVal value)
                                               solve cs')
                                 (S.toList values)

simplify :: [Constraint] -> InfM [Constraint]
simplify cs = nub <$>  
  (iterateEqs $ reverse [
    (progress "instantiation" $ instantiation) >=>
    --(progress "typeOp1" $ typeOp1) >=>
    --(progress "typeOp2" $ typeOp2) >=>
    (progress "annRecoverEq" annRecoverEq) >=>
    (progress "annRemoveObsolete" annRemoveObsolete) >=>
    (progress "generalisation" generalisation)
  ]) cs >>= apply

liftToList :: (a ~ Constraint, m ~ InfM) => (a -> m ()) -> [a] -> m [a]
liftToList f = lTL where
  lTL [] = return []
  lTL (a:as) = do
    a' <- apply a
    as' <- intercept' (f a')
    if as' == [a'] 
      then (++) as' <$> lTL as
      else lTL $ as' ++ as

iterateEqs :: (a ~ [Constraint], m ~ InfM) => [a -> m a] -> a -> m a
iterateEqs [] = return
iterateEqs (f:fs) = iterateEq (iterateEqs fs >=> f >=> iterateEqs fs)

iterateEq :: (a ~ [Constraint], m ~ InfM) => (a -> m a) -> a -> m a
iterateEq f a = head <$> iterateUntil p f a where
  p (x:y:_) = x == y
  p _ = False

iterateUntil :: Monad m => ([a] -> Bool) -> (a -> m a) -> a -> m [a]
iterateUntil p f a = iU [a] where
  iU acc = 
    case p acc of
      True -> return acc
      False -> do
        x <- f (head acc)
        iU $ x : acc

split :: [a] -> [(a,[a])]
split [] = []
split (x:ys) = (x, ys) : map (second (x:)) (split ys)

choice :: Alternative f => [f a] -> f a
choice = foldr (<|>) empty

generalisation :: [Constraint] -> InfM [Constraint]
generalisation cs = do 
  let f (Generalise gamma (Rho (Sigma tau nu1) delta1) (Rho (Sigma scheme nu2) delta2), cs) = do
        let fvs' = (fvs tau) S.\\ ((fvs gamma) `S.union` (fvs $ S.fromList [nu1, delta1, nu2, delta2]))
            (cs_l, cs_r) = partition (\c -> S.null $ S.intersection (fvs c) fvs') cs
            checkConstraint (Instantiate _ _) = fail "instantiation constraints should not appear in a generalised type"
            checkConstraint _ = return ()
        mapM_ checkConstraint cs_r
        intercept' $ do
          scheme ~== (SForall fvs' cs_r tau)
          nu1 ~== nu2
          require cs_l
      f _ = fail "not a generalise constraint"
  cs' <- apply cs
  (choice $ map f $ split cs') <|> (return cs')

instantiation :: [Constraint] -> InfM [Constraint]
instantiation = liftToList i where
  -- Instantiate
  i (Instantiate tau1 (SForall vs cs tau2)) = do 
    ((tau2',cs'),_) <- runSubstitutionT $ do 
                      mapM_ (\v -> fresh >>= substitute v) $ S.toList vs
                      cs' <- apply cs
                      tau2' <- apply tau2
                      return (tau2', cs')
    tau1 ~== tau2'
    require cs'

  -- Catch-all
  i c = require [c]

typeOp1 :: [Constraint] -> InfM [Constraint]
typeOp1 = liftToList f where
  schemeBin :: Constraint -> (forall a. BinO a) -> Scheme -> Scheme -> Scheme -> InfM ()
  schemeBin _ op (SForall vs [] t1) s2 s3 | S.null vs = do
    t2 <- fresh
    t3 <- fresh
    (t1 ~==) =<< t2 `op` t3
    s2 ~== SForall S.empty [] t2
    s3 ~== SForall S.empty [] t3
  schemeBin c _ _ _ _ = require [c]
  schemeUn :: Constraint -> (forall a. Ann -> UnO a) -> Scheme -> Ann -> Scheme -> InfM ()
  schemeUn _ op (SForall vs [] t1) a s2 | S.null vs = do
    t2 <- fresh
    (t1 ~==) =<< a `op` t2
    s2 ~== SForall S.empty [] t1
  schemeUn c _ _ _ _ = require [c]
  tauBin :: Constraint -> (forall a. BinO a) -> Tau -> Tau -> Tau -> InfM ()
  tauBin _ op (TData s as1 ts1) t2 t3 = do
    as2 <- mapM (const fresh) as1
    as3 <- mapM (const fresh) as1
    zipWithM (~==) as1 =<< zipWithM op as2 as3
    ts2 <- return ts1
    ts3 <- return ts1
    t2 ~== TData s as2 ts2
    t3 ~== TData s as3 ts3
  tauBin _ op t1 (TData s as2 ts2) t3 = do
    as1 <- mapM (const fresh) as2
    as3 <- mapM (const fresh) as2
    zipWithM (~==) as1 =<< zipWithM op as2 as3
    ts1 <- return ts2
    ts3 <- return ts2
    t1 ~== TData s as1 ts1
    t3 ~== TData s as3 ts3
  tauBin _ op t1 t2 (TData s as3 ts3)= do
    as1 <- mapM (const fresh) as3
    as2 <- mapM (const fresh) as3
    zipWithM (~==) as1 =<< zipWithM op as2 as3
    ts1 <- return ts3
    ts2 <- return ts3
    t1 ~== TData s as1 ts1
    t2 ~== TData s as2 ts2
  tauBin c _ _ _ _ = require [c]
  tauUn :: Constraint -> (forall a. Ann -> UnO a) -> Tau -> Ann -> Tau -> InfM ()
  tauUn _ op (TData s as1 ts1) a t2 = do
    as2 <- mapM (const fresh) as1
    (zipWithM (~==) as1) =<< zipWithM op (repeat a) as2
    ts2 <- return ts1
    t2 ~== TData s as2 ts2
  tauUn _ op t1 a (TData s as2 ts2) = do
    as1 <- mapM (const fresh) as2
    (zipWithM (~==) as1) =<< zipWithM op (repeat a) as2
    ts1 <- return ts2
    t1 ~== TData s as1 ts1
  tauUn c _ _ _ _ = require [c]    
  f c@(SchemePlus s1 s2 s3) = schemeBin c (~+) s1 s2 s3
  f c@(SchemeAnd s1 s2 s3) = schemeBin c (~&) s1 s2 s3
  f c@(SchemeTimes s1 a s2) = schemeUn c (~*) s1 a s2
  f c@(SchemeGuard s1 a s2) = schemeUn c (~|>) s1 a s2
  f c@(TauPlus t1 t2 t3) = tauBin c (~+) t1 t2 t3
  f c@(TauAnd t1 t2 t3) = tauBin c (~&) t1 t2 t3
  f c@(TauTimes t1 a t2) = tauUn c (~*) t1 a t2
  f c@(TauGuard t1 a t2) = tauUn c (~|>) t1 a t2
  f c = require [c]

typeOp2 :: [Constraint] -> InfM [Constraint]
typeOp2 = liftToList f where
  bin a1 a2 a3 = do
    a1 ~== a2
    a1 ~== a3
  un a1 a a2 = do
    a1 ~== a2
  f (SchemePlus s1 s2 s3) = bin s1 s2 s3
  f (SchemeAnd s1 s2 s3) = bin s1 s2 s3
  f (SchemeTimes s1 a s2) = un s1 a s2
  f (SchemeGuard s1 a s2) = un s1 a s2
  f (TauPlus t1 t2 t3) = bin t1 t2 t3
  f (TauAnd t1 t2 t3) = bin t1 t2 t3
  f (TauTimes t1 a t2) = un t1 a t2
  f (TauGuard t1 a t2) = un t1 a t2
  f c = require [c]

-- | Use constraint analysis to find equalities in constraints.

annRecoverEq cs = do
  let m = possibleValues cs M.empty
      f c = case usageConstraint c of
              Just ((a1,a2,a3),f) -> 
                let table = functionTable' a1 a2 a3 f m
                    recover g h = when (and $ map (\(v1,v2,v3)-> g v1 v2 v3) table) h
                in do
                  recover (\v1 v2 v3 -> v1 == v2) (a1 ~== a2)
                  recover (\v1 v2 v3 -> v1 == v3) (a1 ~== a3)
                  recover (\v1 v2 v3 -> v2 == v3) (a2 ~== a3)
              _ -> return ()
      g (var, values) = 
        if S.size values == 1
        then (AVar var) ~== (AVal $ S.findMin values)
        else return ()
  mapM_ g $ M.toList m              
  mapM_ f cs
  apply cs

-- | Use constraint analysis to constraints that are obsolete

annRemoveObsolete cs = do
  let obsolete c =
        (S.size vars == 0) ||
        (S.size vars == 1 && lookupAnn' (AVar var) M.empty == (lookupAnn' (AVar var) m)) where
          m = possibleValues [c] M.empty
          vars = fvs c
          var = S.findMin vars
  return $ filter (not . obsolete) cs

-- | Constraint analysis functions

possibleValues :: [Constraint] -> Map Var (Set Lattice) -> Map Var (Set Lattice)
possibleValues cs = execState pvs where
  updateValues :: Ann -> Ann -> Ann -> (Lattice -> Lattice -> Lattice) -> State (Map Var (Set Lattice)) ()
  updateValues a1 a2 a3 f = do
      ls <- functionTable a1 a2 a3 f
      setAnn a1 $ S.fromList $ map (\(d1,_,_) -> d1) ls
      setAnn a2 $ S.fromList $ map (\(_,d2,_) -> d2) ls
      setAnn a3 $ S.fromList $ map (\(_,_,d3) -> d3) ls

  ps c = case usageConstraint c of
           Just ((a1, a2, a3),f) -> updateValues a1 a2 a3 f
           _ -> return ()

  pvs = do
    m <- get
    mapM ps cs
    m' <- get
    if m == m'
      then return ()
      else pvs

-- | Determine which variables influence the constraint and which are influenced by the constraint

influence :: Map Var (Set Lattice) -> Constraint -> (Set Var, Set Var)
influence m c = (vs,vs) where vs = fvs c                  
{-
influence m c = (S.filter (\v -> varInfluencesConstraints m v [c]) vs, 
                 S.filter (\v -> constraintsInfluencesVar m [c] v) vs) where
                  vs = fvs c
--}

-- does knowledge about v matter if we look at cs?
varInfluencesConstraints :: Map Var (Set Lattice) -> Var -> [Constraint] -> Bool
varInfluencesConstraints m v cs = 
  (M.delete v $ possibleValues cs M.empty) /= (M.delete v $ possibleValues cs $ M.singleton v $ lookupAnn' (AVar v) m)

-- do we gain knowledge about v if we look at cs?
constraintsInfluencesVar :: Map Var (Set Lattice) -> [Constraint] -> Var -> Bool
constraintsInfluencesVar m cs v =
  lookupAnn' (AVar v) (possibleValues cs (M.delete v m)) /= lookupAnn' (AVar v) M.empty

-- | Utility functions

lookupAnn' a = evalState (lookupAnn a)
functionTable' a1 a2 a3 f = evalState (functionTable a1 a2 a3 f)

lookupAnn :: Ann -> State (Map Var (Set Lattice)) (Set Lattice)
lookupAnn (AVal d) = return $ S.singleton d
lookupAnn (AVar v) = do
  m <- get
  return $ fromMaybe (S.fromList [minBound .. maxBound]) $ M.lookup v m

setAnn :: Ann -> (Set Lattice) -> State (Map Var (Set Lattice)) ()
setAnn (AVal d) c | c == S.singleton d = return ()
                  | otherwise          = error "setC: invariant doesn't hold"
setAnn (AVar v) c = modify $ M.insertWith S.intersection v c

functionTable :: Ann -> Ann -> Ann -> (Lattice -> Lattice -> Lattice) -> State (Map Var (Set Lattice)) [(Lattice, Lattice, Lattice)]
functionTable a1 a2 a3 f = do
    c1 <- lookupAnn a1
    c2 <- lookupAnn a2
    c3 <- lookupAnn a3
    return $
      [(d1,d2,d3) | d2 <- S.toList c2, 
                    d3 <- S.toList c3, 
                    let d1 = f d2 d3, 
                    d1 `S.member` c1,
                    if a1 == a2 then d1 == d2 else True,
                    if a1 == a3 then d1 == d3 else True,
                    if a2 == a3 then d2 == d3 else True ]

usageConstraint :: Constraint -> Maybe ((Ann, Ann, Ann), Lattice -> Lattice -> Lattice)
usageConstraint (AnnPlus  a1 a2 a3) | a3 < a2   = return ((a1, a3, a2), aPlus)
                                    | otherwise = return ((a1, a2, a3), aPlus)
usageConstraint (AnnAnd   a1 a2 a3) | a3 < a2   = return ((a1, a3, a2), aAnd)
                                    | otherwise = return ((a1, a2, a3), aAnd)
usageConstraint (AnnTimes a1 a2 a3) = return ((a1, a2, a3), aTimes)
usageConstraint (AnnGuard a1 a2 a3) = return ((a1, a2, a3), aGuard)
usageConstraint _                   = Nothing
  
  
