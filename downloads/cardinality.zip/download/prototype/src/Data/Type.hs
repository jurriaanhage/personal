module Data.Type where

import Control.Arrow
import Data.Lattice
import Data.Var
import Utils
import qualified Data.Map as M
import qualified Data.Set as S
import Data.Generics

-- | Inference Monad

type InfM = ErrorT String (WriterT [Constraint] (SubstitutionT Fresh))

-- | Free variables

fvs :: GenericQ (Set Var)
fvs x = fromMaybe (error "fvs") $ 
  (do SForall vs cs a <- cast x
      return $ ((fvs cs) `S.union` (fvs a)) S.\\ vs) <|>
  (do v@(Var _) <- cast x
      return $ S.singleton v) <|>
  (do return $ S.unions $ gmapQ fvs x)

-- | Environment

type Gamma = Map String (Rho Scheme)

instance FreshVal Gamma where
  fresh = return M.empty

instance Printable Gamma where
  pp p e = pp p $ map (first text) $ M.toList e

-- | Data type declarations

type DataDecl = ([Var], [Var], Map String [Rho Tau])
type DataDecls = Map String DataDecl

-- | annotation

data Ann
  = AVar Var
  | AVal Lattice
  deriving (Eq, Ord, Show, Data, Typeable)

instance FreshVal Ann where
  fresh = AVar <$> fresh

instance Printable Ann where
  pp _ (AVar v) = lText $ show v
  pp p (AVal d) = pp p d

-- | Normal type

data Tau
  = TVar Var
  | (Rho Tau) :-> (Sigma Tau)
  | TData String [Ann] [Tau]
  deriving (Eq, Show, Ord, Data, Typeable)

instance FreshVal Tau where
  fresh = TVar <$> fresh

instance Printable Tau where
  pp p (TVar v) = pp p v
  pp p (rho :-> sigma) = block (p > 0) $ pp 1 rho <> text "\\rightarrow" <> pp 0 sigma
  pp p (TData name as ts) = block (p > 0) $ lText name <> pp p as <> pp p ts

-- | Type scheme

data Scheme 
  = SVar Var
  | SForall (Set Var) [Constraint] Tau
  deriving (Eq, Show, Ord, Data, Typeable)

instance FreshVal Scheme where
  fresh = SVar <$> fresh

instance Printable Scheme where
  pp p (SVar v) = pp p v
  pp p (SForall vs cs tau) = 
    block (p > 0) $ text "\\forall" <> pp 0 vs <> text "." <> pp 0 cs <> text "\\Rightarrow" <> pp 0 tau

-- | Value type

type Nu = Ann

data Sigma a
  = Sigma a Nu
  deriving (Eq, Show, Ord, Data, Typeable)

instance FreshVal a => FreshVal (Sigma a) where
  fresh = Sigma <$> fresh <*> fresh

instance Printable a => Printable (Sigma  a) where  
  pp _ (Sigma tau nu) = block False $ pp 1 tau <> text "^" <> pp 0 nu

-- | Thunk type

type Delta = Ann

data Rho a
  = Rho (Sigma a) Delta
  deriving (Eq, Show, Ord, Data, Typeable)

instance FreshVal a => FreshVal (Rho a) where
  fresh = Rho <$> fresh <*> fresh

instance Printable a => Printable (Rho a) where
  pp _ (Rho (Sigma tau nu) delta) = block False $ pp 1 tau <> text "^" <> pp 0 (nu, delta)

-- | constraint

data Constraint 
  = AnnPlus Ann Ann Ann
  | AnnAnd Ann Ann Ann
  | AnnTimes Ann Ann Ann
  | AnnGuard Ann Ann Ann

  | TauPlus Tau Tau Tau
  | TauAnd Tau Tau Tau
  | TauTimes Tau Ann Tau
  | TauGuard Tau Ann Tau

  | SchemePlus Scheme Scheme Scheme
  | SchemeAnd Scheme Scheme Scheme
  | SchemeTimes Scheme Ann Scheme
  | SchemeGuard Scheme Ann Scheme

  | Generalise Gamma (Rho Tau) (Rho Scheme)
  | Instantiate Tau Scheme
  deriving (Eq, Show, Ord, Data, Typeable)

instance Printable Constraint where
  pp p (AnnPlus a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\oplus" <> pp p a3
  pp p (AnnAnd a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\sqcup" <> pp p a3
  pp p (AnnTimes a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\cdot" <> pp p a3
  pp p (AnnGuard a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\triangleright" <> pp p a3

  pp p (TauPlus a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\oplus" <> pp p a3
  pp p (TauAnd a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\sqcup" <> pp p a3
  pp p (TauTimes a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\cdot" <> pp p a3
  pp p (TauGuard a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\triangleright" <> pp p a3

  pp p (SchemePlus a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\oplus" <> pp p a3
  pp p (SchemeAnd a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\sqcup" <> pp p a3
  pp p (SchemeTimes a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\cdot" <> pp p a3
  pp p (SchemeGuard a1 a2 a3) = block False $ pp p a1 <> text "\\equiv" <> pp p a2 <> text "\\triangleright" <> pp p a3

  pp p (Generalise gamma rho1 rho2) = block True $ pp p gamma <> pp p (rho1, rho2)
  pp p (Instantiate t1 t2) = block False $ pp p t1 <> text "\\preccurlyeq" <> pp p t2

require :: MonadWriter w m => w -> m ()
require = tell

intercept :: MonadWriter w m => m a -> m (a, w)
intercept m = censor (const mempty) (listen m)

intercept' :: MonadWriter w m => m () -> m w
intercept' = (liftM snd) . intercept