module Data.Analysis where

import Data.Lattice
import Data.Type
import Debug.Trace
import Utils
import qualified Data.Set as S
import Data.Foldable (foldrM)
import qualified Data.Map as M
import qualified Data.Traversable as T

defaultD :: Usage a => a -> a -> InfM ()
defaultD = diamond (undefined :: Lattice)

uniquenessD :: Usage a => a -> a -> InfM ()
uniquenessD = (~==)

sharingD :: Usage a => a -> a -> InfM ()
sharingD = (~<=)

hasN :: Analysis l => Count -> l -> Bool
hasN n l = n `S.member` (fromL l)

isN :: Analysis l => Count -> l -> Bool
isN n l = S.singleton n == fromL l

hasZero :: Analysis l => l -> Bool
hasZero = hasN Zero

isZero :: Analysis l => l -> Bool
isZero = isN Zero

hasOne :: Analysis l => l -> Bool
hasOne = hasN One

isOne :: Analysis l => l -> Bool
isOne = isN One

hasOmega :: Analysis l => l -> Bool
hasOmega = hasN Omega

isOmega :: Analysis l => l -> Bool
isOmega = isN Omega

isTop :: (Bounded l, Eq l) => l -> Bool
isTop = (==) maxBound

zeroL :: Analysis l => l
zeroL = toL $ S.singleton 0

oneL :: Analysis l => l
oneL = toL $ S.singleton 1

omegaL :: Analysis l => l
omegaL = toL $ S.singleton 2

topL :: (Bounded l, Analysis l) => l
topL = maxBound

toL' :: Counts -> Lattice
toL' = toL

fromL' :: Lattice -> Counts
fromL' = fromL

aIn :: Analysis l => l -> l -> Bool
aIn = inCounts `on` fromL

aPlus :: Analysis l => l -> l -> l
aPlus x y = toL $ (plusCounts `on` fromL) x y

aAnd :: Analysis l => l -> l -> l
aAnd x y = toL $ (andCounts `on` fromL) x y

aTimes :: Analysis l => l -> l -> l
aTimes x y = toL $ (timesCounts `on` fromL) x y

aGuard :: Analysis l => l -> l -> l
aGuard x y = toL $ (guardCounts `on` fromL) x y

class (Ord l) => Analysis l where
  toL :: Counts -> l
  fromL :: l -> Counts

  diamond :: Usage a => l -> a -> a -> InfM ()

-- | Counts

instance Analysis Counts where
  toL = id
  fromL = id

  diamond _ = undefined

-- | Sharing

instance Analysis Sharing where
  toL s | hasOmega s = Sharing Omega
        | otherwise  = Sharing One
  fromL (Sharing Omega) = S.fromList [Zero,One,Omega]
  fromL (Sharing One)   = S.fromList [Zero,One]
  fromL _               = error "Sharing.fromL: invalid sharing value"

  diamond _ = sharingD

-- | SharingZero

instance Analysis SharingZero where
  toL s | hasOmega s = SharingZero Omega
        | hasOne s   = SharingZero One
        | otherwise  = SharingZero Zero
  fromL (SharingZero Omega) = S.fromList [Zero,One,Omega]
  fromL (SharingZero One)   = S.fromList [Zero,One]
  fromL (SharingZero Zero)  = S.fromList [Zero]
  
  diamond _ = sharingD

-- | SharingGeneric

instance Analysis SharingGeneric where
  toL = SharingGeneric
  fromL = fromSG

  diamond _ = sharingD

-- | Uniqueness

instance Analysis Uniqueness where
  toL s | hasOmega s = Uniqueness Omega
        | otherwise  = Uniqueness One
  fromL (Uniqueness Omega) = S.fromList [Zero,One,Omega]
  fromL (Uniqueness One)   = S.fromList [Zero,One]
  fromL _                  = error "Uniqueness.fromL: invalid uniqueness value"

  diamond _ = uniquenessD

-- | UniquenessZero

instance Analysis UniquenessZero where
  toL s | hasOmega s = UniquenessZero Omega
        | hasOne s   = UniquenessZero One
        | otherwise  = UniquenessZero Zero
  fromL (UniquenessZero Omega) = S.fromList [Zero,One,Omega]
  fromL (UniquenessZero One)   = S.fromList [Zero,One]
  fromL (UniquenessZero Zero)  = S.fromList [Zero]
  
  diamond _ = uniquenessD

-- | UniquenessGeneric

instance Analysis UniquenessGeneric where
  toL = UniquenessGeneric
  fromL = fromUG

  diamond _ = uniquenessD

-- | utility functions

foldrM1 :: Monad m => (a -> a -> m a) -> [a] -> m a
foldrM1 _ []     = error "foldrM1: list is empty"
foldrM1 f (x:xs) = foldrM f x xs

(~===) :: Usage a => a -> a -> InfM a
a ~=== b = do
  a ~== b
  return a

bigEq :: Usage a => [a] -> InfM a
bigEq [] = fresh
bigEq as = foldrM1 (~===) as

bigPlus :: Usage a => [a] -> InfM a
bigPlus [] = zeroU
bigPlus as = foldrM1 (~+) as

bigAnd :: Usage a => [a] -> InfM a
bigAnd [] = zeroU
bigAnd as = foldrM1 (~&) as

oper :: FreshVal c => (c -> a -> b -> Constraint) -> a -> b -> InfM c
oper f a b = do
  c <- fresh
  require [f c a b]
  return c

annEq :: Ann -> Ann -> InfM ()
annEq = g where
  f a1 a2 | a1 == a2 = return ()
  f a1@(AVar _) a2   = substitute a1 a2
  f a1 a2@(AVar _)   = substitute a2 a1
  f a1 a2            = 
    fail $ printf "annEq failed: %s /= %s" (show a1) (show a2)
  g a1 a2 = do
    a1' <- apply a1
    a2' <- apply a2
    f a1' a2'

binaryTau :: (forall b. Usage b => b -> b -> InfM b) -> Tau -> Tau -> InfM Tau
binaryTau op = g where
  f t1@(TVar a) (TVar b) | a == b = do
    return t1
  f t1@(TVar _) t2 = do
    substitute t1 t2
    return t1
  f t1 t2@(TVar _) = do
    substitute t2 t1
    return t2
  f (rho1 :-> sigma1) (rho2 :-> sigma2) = do
    rho <- rho2 `op` rho1
    sigma <- sigma1 `op` sigma2
    return $ rho :-> sigma
  f (TData s1 as1 ts1) (TData s2 as2 ts2) | s1 == s2 = do
    as <- zipWithM op as1 as2
    ts <- zipWithM op ts1 ts2
    return $ TData s1 as ts
  f t1 t2 =
    fail $ printf "binaryTau failed: %s /= %s" (show t1) (show t2)
  g t1 t2 = do
    t1' <- apply t1
    t2' <- apply t2
    f t1' t2'

-- TODO: is this correct?
unaryTau :: (forall b. Usage b => b -> InfM b) -> Tau -> InfM Tau
unaryTau op = g where
  f t1@(TVar _) = do
    return t1
  f (rho :-> sigma) = do
    rho' <- op rho
    sigma' <- op sigma
    return $ rho' :-> sigma'
  f (TData s as ts) = do
    as' <- mapM op as
    ts' <- mapM op ts
    return $ TData s as' ts'
  g t = do
    t' <- apply t
    f t'

binaryScheme :: (forall b. Usage b => b -> b -> InfM b) -> Scheme -> Scheme -> InfM Scheme
binaryScheme op = g where
  f s1 s2 | s1 == s2 = do
    return s1
  f s1@(SVar _) s2   = do
    substitute s1 s2
    return s1
  f s1 s2@(SVar _)   = do
    substitute s2 s1
    return s2
  f s1 s2            = 
    fail $ printf "binaryScheme failed: %s /= %s" (show s1) (show s2)
  g s1 s2 = do
    s1' <- apply s1
    s2' <- apply s2
    f s1' s2'

unaryScheme :: (forall b. Usage b => b -> InfM b) -> Scheme -> InfM Scheme
unaryScheme op = g where
  f s@(SVar _) = do
    return s
  f s = 
    fail $ printf "unaryScheme failed: %s" (show s)
  g s = do
    s' <- apply s
    f s'

type BinO a = Usage a => a -> a -> InfM a
type UnO a = Usage a => a -> InfM a

-- | Usage class
class FreshVal a => Usage a where
  zeroU :: InfM a
  binary :: (forall b. BinO b) -> BinO a
  unary :: (forall b. UnO b) -> UnO a

  (~==) :: a -> a -> InfM ()
  a ~== b = binary (\a1 a2 -> do a1 ~== a2 >> return a1) a b >> return ()
  
  (~<=) :: a -> a -> InfM ()
  a ~<= b = binary (\a1 a2 -> do a1 ~<= a2 >> return a1) a b >> return ()
  
  (~+) :: BinO a
  (~+) = binary (~+)
  
  (~&) :: BinO a
  (~&) = binary (~&)
  
  (~*) :: Ann -> UnO a
  (~*) = \a -> unary (a ~*)

  (~|>) :: Ann -> UnO a
  (~|>) = \a -> unary (a ~|>)

instance Usage Ann where
  zeroU = return $ AVal $ zeroL
  binary f = f
  unary f = f

  (~==) = annEq
  (~<=) = \a b -> require [AnnAnd b a b]
  (~+) = oper AnnPlus
  (~&) = oper AnnAnd
  (~*) = oper AnnTimes
  (~|>) = oper AnnGuard

instance Usage Tau where
  zeroU = fresh
  binary = binaryTau
  unary = unaryTau

  {-(~+) = oper TauPlus
  (~&) = oper TauAnd
  (~*) = oper TauTimes
  (~|>) = oper TauGuard-}

instance Usage Scheme where
  zeroU = fresh
  binary = binaryScheme
  unary = unaryScheme

  {-(~+) = oper SchemePlus
  (~&) = oper SchemeAnd
  (~*) = oper SchemeTimes
  (~|>) = oper SchemeGuard-}

instance Usage a => Usage (Sigma a) where
  zeroU = Sigma <$> zeroU <*> zeroU
  binary op (Sigma a1 nu1) (Sigma a2 nu2) = Sigma <$> op a1 a2 <*> op nu1 nu2
  unary op (Sigma a nu) = Sigma <$> op a <*> op nu

instance Usage a => Usage (Rho a) where
  zeroU = Rho <$> zeroU <*> zeroU
  binary op (Rho a1 delta1) (Rho a2 delta2) = Rho <$> op a1 a2 <*> op delta1 delta2
  unary op (Rho a delta) = Rho <$> op a <*> op delta

instance Usage Gamma where
  zeroU = return M.empty
  binary op gamma1 gamma2 = T.sequence $ M.mergeWithKey (\_ rho1 rho2 -> Just $ op rho1 rho2) f f gamma1 gamma2 where
    f = M.map (\rho -> zeroU >>= op rho)    
  unary op gamma = T.sequence $ M.map op gamma

