module Data.Lattice where

import qualified Data.Set as S
import qualified Data.Map as M
import Data.Ratio
import Utils

type Lattice = UniquenessZero

type Counts = Set Count

newtype Sharing = Sharing Count deriving (Eq,Show,Data,Typeable,Printable)
newtype SharingZero = SharingZero Count deriving (Eq,Show,Data,Typeable,Printable)
newtype SharingGeneric = SharingGeneric { fromSG :: Counts } deriving (Eq,Show,Data,Typeable,Printable)

newtype Uniqueness = Uniqueness Count deriving (Eq,Show,Data,Typeable,Printable)
newtype UniquenessZero = UniquenessZero Count deriving (Eq,Show,Data,Typeable,Printable)
newtype UniquenessGeneric = UniquenessGeneric { fromUG :: Counts } deriving (Eq,Show,Data,Typeable,Printable)


inCounts :: Counts -> Counts -> Bool 
inCounts = S.isSubsetOf

plusCounts :: Counts -> Counts -> Counts 
plusCounts x y = S.fromList [ a + b | a <- S.toList x, b <- S.toList y]

andCounts :: Counts -> Counts -> Counts 
andCounts = S.union

timesCounts :: Counts -> Counts -> Counts 
timesCounts x y = S.unions $ S.toList $ S.map f x where
  f z = S.fromList $ sum <$> replicateM (fromIntegral z) (S.toList y)

guardCounts :: Counts -> Counts -> Counts 
guardCounts x y = S.unions $ S.toList $ S.map (\z -> if z == 0 then S.singleton 0 else y) x

-- | Count

data Count 
  = Zero
  | One
  | Omega
  deriving (Eq, Ord, Show, Enum, Data, Typeable, Bounded)

instance Num Count where
  x + y = fromInteger $ (toInteger x) + (toInteger y)
  x * y = fromInteger $ (toInteger x) + (toInteger y)

  fromInteger 0 = Zero
  fromInteger 1 = One
  fromInteger _ = Omega

  abs = id

  signum = fromInteger . abs . toInteger 

instance Real Count where
  toRational x = toInteger x % 1

instance Integral Count where
  quotRem x y = 
    let x' = toInteger x
        y' = toInteger y
    in (fromIntegral $ x' `quot` y', fromIntegral $ x' `rem` y')

  toInteger Zero  = 0
  toInteger One   = 1
  toInteger Omega = 2

instance Printable Count where
  pp _ Zero = text "{\\mathbb{0}}"
  pp _ One = text "{\\mathbb{1}}"
  pp _ Omega = text "\\omega"

-- | Items  

class Items a where
  items :: [a]

toEnum' :: Items a => Int -> a
toEnum' i = fromMaybe (error "index does not exist") $ M.lookup i $ M.fromList $ zip [0..] items

fromEnum' :: (Eq a, Items a) => a -> Int
fromEnum' a = fromMaybe (error "value does not exist") $ lookup a $ zip items [0..]

compare' :: (Eq a, Items a) => a -> a -> Ordering
compare' = compare `on` fromEnum'

minBound' :: Items a => a
minBound' = head items

maxBound' :: Items a => a
maxBound' = last items

-- | Sharing  

instance Items Sharing where
  items = [f 1, f 2] where f = Sharing 

instance Ord Sharing where
  compare = compare'

instance Bounded Sharing where
  minBound = minBound'
  maxBound = maxBound'

instance Enum Sharing where
  toEnum = toEnum'
  fromEnum = fromEnum'  

-- | SharingZero  

instance Items SharingZero where
  items = [f 0, f 1, f 2] where f = SharingZero 

instance Ord SharingZero where
  compare = compare'

instance Bounded SharingZero where
  minBound = minBound'
  maxBound = maxBound'

instance Enum SharingZero where
  toEnum = toEnum'
  fromEnum = fromEnum'  

-- | SharingGeneric

instance Items SharingGeneric where
  items = [f [0]  , f [1] , f [2] ,
           f [0,1], f[0,2], f[1,2],
           f [0,1,2]] where f = SharingGeneric . S.fromList

instance Ord SharingGeneric where
  compare = compare'

instance Bounded SharingGeneric where
  minBound = minBound'
  maxBound = maxBound'

instance Enum SharingGeneric where
  toEnum = toEnum'
  fromEnum = fromEnum'

-- | Uniqueness  

instance Items Uniqueness where
  items = [f 1, f 2] where f = Uniqueness 

instance Ord Uniqueness where
  compare = compare'

instance Bounded Uniqueness where
  minBound = minBound'
  maxBound = maxBound'

instance Enum Uniqueness where
  toEnum = toEnum'
  fromEnum = fromEnum'

-- | UniquenessZero

instance Items UniquenessZero where
  items = [f 0, f 1, f 2] where f = UniquenessZero

instance Ord UniquenessZero where
  compare = compare'

instance Bounded UniquenessZero where
  minBound = minBound'
  maxBound = maxBound'

instance Enum UniquenessZero where
  toEnum = toEnum'
  fromEnum = fromEnum'

-- | UniquenessGeneric

instance Items UniquenessGeneric where
  items = [f [0]  , f [1] , f [2] ,
           f [0,1], f[0,2], f[1,2],
           f [0,1,2]] where f = UniquenessGeneric . S.fromList

instance Ord UniquenessGeneric where
  compare = compare'

instance Bounded UniquenessGeneric where
  minBound = minBound'
  maxBound = maxBound'

instance Enum UniquenessGeneric where
  toEnum = toEnum'
  fromEnum = fromEnum'

