{-# LANGUAGE DeriveDataTypeable #-}

module Data.Var where

import Utils

data Var 
  = Var { fromVar :: Int }
  deriving (Eq, Ord, Data, Typeable)

instance Show Var where
  show (Var i) = show i  

instance FreshVal Var where
  fresh = Var <$> fresh

instance Printable Var where
  pp _ v = lText $ show v