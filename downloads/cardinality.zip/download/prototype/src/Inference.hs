module Inference where

import Data
import qualified Data.Var as V
import Datatypes 
import Data.Function
import Data.Graph hiding (edges)
import Data.Generics
import qualified Data.Map as M
import qualified Data.Set as S
import Language.Haskell.Exts hiding (name, alt)
import Simplify
import Utils
import qualified Utils.Substitution as SS
import qualified Data.Traversable as T
import System.FilePath

{-
assumptions on the input:
- a lambda has only a single pattern: a variable
- pattern matches don't exist (translated to case .. of)
- case .. of constructs unravel only one datatype at a time
- no conflicting names in the same scope (alpha-renaming is applied)
- second argument to an application is a variable
-}

topLevel :: InfM Result -> InfM Result
topLevel m = do
  (r, cs) <- intercept $ do
    r <- subsumeSharing =<< m
    let Sigma _ nu = _sigma r
    (AVal oneL) ~== nu
    
    --(AVal oneL) ~== (AVar $ V.Var 130)
    --(AVal oneL) ~== (AVar $ V.Var 136)
    --(AVal oneL) ~== (AVar $ V.Var 197)
    --(AVal oneL) ~== (AVar $ V.Var 472)
    --(AVal oneL) ~<= (AVar $ V.Var 186)
    --(AVal oneL) ~<= (AVar $ V.Var 187)
    --(AVal oneL) ~<= (AVar $ V.Var 190)
    --(AVal oneL) ~<= (AVar $ V.Var 191)
    --(AVar $ V.Var 196) ~<= (AVal oneL)
    
    return r
  
  --cs' <- solve cs
  cs' <- simplify cs
  --cs' <- return cs
  require cs'
  return r

subsume :: Result -> InfM Result
subsume = subsume' defaultD

subsumeSharing :: Result -> InfM Result
subsumeSharing = subsume' sharingD

subsumeUniqueness :: Result -> InfM Result
subsumeUniqueness = subsume' uniquenessD

subsume' :: (Nu -> Nu -> InfM ()) -> Result -> InfM Result
subsume' f r = do 
  let Sigma tau nu2 = _sigma r
  nu1 <- fresh
  f nu1 nu2
  return $ Result "subsume" (_gamma r) (Sigma tau nu1) (_exp r) [r]

infer' :: InfM DataDecls -> Exp -> String -> IO ()
infer' dts e file = do
  let x :: ((Either String Result, [Constraint]), Substs)
      x@((_, cs), ss) = runFresh $ runSubstitutionT $ runWriterT $ runErrorT $ topLevel $ do
        dts' <- dts
        infer dts' e
      r = either error id $ fst $ fst x
      ds = [minBound .. maxBound] :: [Lattice]
--  tests
  writeFile (replaceExtension file "tex") $ show $ nest 2 $ 
    (lPreview $ ppM 0 $ SS.apply ss r) $~$
    (lPreview $ lGraph $ constraintGraph cs) $~$
    (lPreview $ lText $ show $ length cs) $~$
    (lPreview $ ppM 0 $ lArray $ M.toList $ possibleValues cs M.empty) $~$
    (lPreview $ lMath $ table (text "\\oplus") aPlus ds) $~$
    (lPreview $ lMath $ table (text "\\sqcup") aAnd ds) $~$
    (lPreview $ lMath $ table (text "\\cdot") aTimes ds) $~$ 
    (lPreview $ lMath $ table (text "\\triangleright") aGuard ds) 

infer :: DataDecls -> Exp -> InfM Result
infer _ e@(Var (UnQual (Ident name_))) = do
  nu <- fresh
  tau1 <- fresh
  tau2 <- fresh
  let sigma1 = Sigma tau1 nu
      sigma2 = Sigma tau2 nu
  require [Instantiate tau1 tau2]
  return $ Result "var" (M.singleton name_ (Rho sigma2 (AVal oneL))) sigma1 e []

infer dts e | Just (name_, names) <- maybeCon e = inferCon dts name_ names

infer dts e@(Lit (Int _)) = do
  r <- infer dts (App (Con (UnQual (Ident "Zero"))) (Lit (Int 0)))
  return $ r { _exp = e }

infer dts (Tuple [e1,e2]) = do  
  infer dts (App (App (App (Con (UnQual (Ident "Pair"))) (Lit (Int 0))) e1) e2)

infer dts e@(App (App (Var (UnQual (Ident "seq"))) e1) e2) = do
  r1 <- subsumeSharing =<< infer dts e1
  let gamma1 = _gamma r1
      Sigma _ nu1 = _sigma r1
  nu1 ~== (AVal zeroL)

  r2 <- infer dts e2
  let gamma2 = _gamma r2
      sigma2 = _sigma r2
  
  rgamma <- gamma1 ~+ gamma2
  return $ Result "seq" rgamma sigma2 e [r1, r2]

infer dts e@(App e1 e2@(Var (UnQual (Ident name_)))) = do
  r1 <- subsumeSharing =<< infer dts e1
  let gamma1 = _gamma r1
      Sigma tau1 nu1 = _sigma r1
  nu1 ~== (AVal oneL)

  r2 <- subsume =<< infer dts e2
  let gamma2 = _gamma r2
      sigma2 = _sigma r2
  
  delta2 <- fresh
  sigma3 <- fresh
  tau1 ~== ((Rho sigma2 delta2) :-> sigma3)
  rgamma <- gamma1 ~+ (M.adjust (\(Rho sigma4 _) -> Rho sigma4 delta2) name_ gamma2)
  return $ Result "app" rgamma sigma3 e [r1]

infer dts e@(Lambda _ [PVar (Ident name_)] body) = do
  r <- infer dts body
  let gamma = _gamma r
      sigma = _sigma r
  nu <- fresh
  tau <- fresh
  Rho (Sigma scheme nu') delta' <- maybe fresh return $ M.lookup name_ gamma
  scheme ~== SForall S.empty [] tau
  gamma' <- nu ~* (M.delete name_ gamma)
  return $ Result "abs" gamma' (Sigma ((Rho (Sigma tau nu') delta') :-> sigma) nu) e [r]

--{-
infer dts e@(Case e1 as) = do
  let pat (PVar (Ident name)) = name
      pat _ = ""
      alt (Alt _ (PApp (UnQual (Ident name)) args) (UnGuardedAlt e) _) | length args > 0 = 
        let names = map pat args
        in (name, names, e)
      alt a = error $ printf "invalid case alternative: %s" (show a)
      getData a = do
        let (name,_,_) = alt a
        findDataByConName' dts name
  (dt, (avs,tvs,cons)) <- getData $ head as
  (favs,ftvs,fcons) <- freshData (avs,tvs,cons)
  
  r1 <- infer dts e1
  let gamma1 = _gamma r1
      Sigma tau1 nu1 = _sigma r1
  tau1 ~== (TData dt (map AVar favs) (map TVar ftvs))
  (AVal oneL) ~<= nu1

  rsigma <- fresh
  let inferAlt a = do
        let (name, names', e) = alt a
            names = tail names'
            label = head names'
        con <- findConByName' fcons name
        when (length con /= length names) $
          fail "invalid number of arguments for constructor"
        
        let rhoFromName name = M.lookup name $ (M.fromList $ zip names $ map toScheme con)
        r <- infer dts e
        _sigma r ~== rsigma
        M.traverseWithKey (\name rho -> maybe (return ()) (~== rho) (rhoFromName name)) (_gamma r)
        when (label /= "" && (M.member label $ _gamma r)) $ do
          let Rho (Sigma scheme nu) _ = fromMaybe (error "infer Case fromMaybe") $ M.lookup label (_gamma r)
          nu ~<= (AVal oneL)
          nu1 ~<= (AVal oneL)
          scheme ~== (SForall S.empty [] (TData ("@" ++ name) [] []))
        return $ Result "case-arm" (deletes names' $ _gamma r) rsigma e [r]
  rs <- mapM inferAlt as
  let gammas = map _gamma rs
  rgamma <- (~+) gamma1 =<< bigAnd gammas
  return $ Result "case" rgamma rsigma e (r1:rs)
--}

infer dts (Paren e) = infer dts e  

infer dts (Let (BDecls ds) body) = do
  let bindingGroups = stronglyConnComp $ map toGraphElement ds
      toGraphElement d = 
        (d,
         fst $ binding d,
         S.toList $ usesVariables $ snd $ binding d)
  inferLet dts bindingGroups body

infer _ e = error $ printf "infer: unknown expression '%s'." (show e)

binding :: Decl -> (String, Exp)
binding (PatBind _ (PVar (Ident name_)) _ (UnGuardedRhs body) _) = (name_, body)
binding _ = error "malformed binding"

maybeCon :: Exp -> Maybe (String, [String])
maybeCon = mC [] where
  mC names (Con (UnQual (Ident name_))) = return (name_,names)
  mC names (App e1 (Var (UnQual (Ident name_)))) = mC (name_:names) e1
  mC names (App e1 _) = mC ("":names) e1
  mC _ _ = Nothing

inferCon :: DataDecls -> String -> [String] -> InfM Result
inferCon dts name names' = do
  let names = tail names'
      label = head names'
  (dt, (avs,tvs,cons)) <- findDataByConName' dts name
  (favs,ftvs,fcons) <- freshData (avs,tvs,cons)
  con <- findConByName' fcons name
  when (length con /= length names) $
    fail "invalid number of arguments for constructor"

  nu <- fresh
  let sigma = Sigma (TData dt (map AVar favs) (map TVar ftvs)) nu
  
  rs <- inferConParams dts $ zip names con
  let gammas = map _gamma rs
  rgamma <- bigPlus gammas
  let r1 = Result "con" rgamma sigma (Var $ UnQual $ Ident $ intercalate " " (name : names)) rs
  
  if label == "" 
    then return r1
    else do
      r2 <- subsumeSharing =<< (infer dts $ Var $ UnQual $ Ident label)
      (Sigma (TData ("@" ++ name) [] []) (AVal oneL)) ~== _sigma r2
      rgamma <- _gamma r1 ~+ _gamma r2
      let results = r2 : _results r1
      return $ r1 {_gamma = rgamma, _results = results}


inferConParams :: DataDecls -> [(String, Rho Tau)] -> InfM [Result]
inferConParams dts = mapM (inferConParam dts)

inferConParam :: DataDecls -> (String, Rho Tau) -> InfM Result
inferConParam dts (name, Rho sigma delta) = do
  r <- infer dts $ Var $ UnQual $ Ident name
  _sigma r ~== sigma
  return $ r {_gamma = M.map (\(Rho sigma' _) -> Rho sigma' delta) (_gamma r)}

inferLet :: DataDecls -> [SCC Decl] -> Exp -> InfM Result
inferLet dts [] e = infer dts e

inferLet dts (AcyclicSCC d : dss) e = do
  inferLet dts (CyclicSCC [d] : dss) e

inferLet dts (CyclicSCC ds : dss) e = do
  let names = map (fst . binding) ds
      bodies = map (snd . binding) ds
      partitionNames = M.partitionWithKey (\name _ -> name `elem` names)
      findName a name = maybe (error $ printf "name '%s' not found" name) id $ M.lookup name a
  deltas <- mapM (const fresh) names

  rs <- mapM (infer dts) bodies
  let gammas = map _gamma rs
      (gammas_l, gammas_r) = unzip $ map partitionNames gammas
      sigmas = map _sigma rs
      rhos :: [Rho Tau]
      rhos = zipWith Rho sigmas deltas
      rhos' = M.fromList $ zip names rhos
  r <- inferLet dts dss e
  let gamma = _gamma r 
      (gamma_l, gamma_r) = partitionNames gamma
      sigma = _sigma r
  
  gamma_l' <- T.traverse freshScheme gamma_l
  lgamma <- (~+) gamma_l' =<< bigPlus =<< zipWithM (~|>) deltas gammas_l
  _ <- zipWithM (~==) (map toScheme rhos) (map (lgamma `findName`) names)
  rgamma <- (~+) gamma_r =<< bigPlus =<< zipWithM (~|>) deltas gammas_r

  _ <- M.traverseWithKey (\name rho -> require [Generalise rgamma (rhos' `findName` name) rho]) gamma_l

  rs' <- mapM (\(name, rho@(Rho sigma' _), r') -> do 
                rho' <- freshScheme rho
                return $ Result "let-def" (M.singleton name rho') sigma' (Var (UnQual (Ident name))) [r']
              ) $ zip3 names rhos rs
  return $ 
    Result "let" rgamma sigma (Let (BDecls ds) (_exp r)) (rs' ++ [r])

-- | Utilities

updateRho :: (a -> b) -> Rho a -> Rho b
updateRho f (Rho (Sigma a nu) delta) = Rho (Sigma (f a) nu) delta

freshScheme :: FreshVal b => Rho a -> InfM (Rho b)
freshScheme rho = (\scheme -> updateRho (const scheme) rho) <$> fresh

toScheme :: Rho Tau -> Rho Scheme
toScheme = updateRho (\tau -> SForall S.empty [] tau)

constraintGraph :: [Constraint] -> [(Doc, Int, [Int])]
constraintGraph cs = runFresh $ do
  let newIndex :: Ord a => [a] -> Fresh (Map a Int)
      newIndex as = do
        ls <- mapM (\a -> do i <- fresh; return (a,i)) as
        return $ M.fromList ls
      toGraph :: Ord a => [(a,b)] -> [(a, [b])]
      toGraph edges = map (\ls -> (fst $ head ls, map snd ls)) $ 
                      groupBy ((==) `on` fst) $ 
                      sortBy (compare `on` fst) edges
      flipPair (a,b) = (b,a)
      flipList = map flipPair
      flipMap = M.fromList . flipList . M.toList
      
  constraintIndex <- newIndex cs
  varIndex <- newIndex (S.toList $ fvs cs)
  
  let m = possibleValues cs M.empty
      edges = concatMap (\c -> let (from, to) = influence m c 
                               in [ (varIndex M.! f, constraintIndex M.! c) | f <- S.toList from ] ++
                                  [ (constraintIndex M.! c, varIndex M.! t) | t <- S.toList to ]) cs
      docs = (M.map (ppM 0) $ flipMap constraintIndex) `M.union` (M.map (ppM 0) $ flipMap varIndex)
      graph = M.fromList $ toGraph edges
      result = M.mergeWithKey (\_ a b -> Just (a,b)) (M.map (\d -> (d,[]))) undefined docs graph
  
  return $ map (\(i, (d, is)) -> (d, i, is)) $ M.toList result

table :: Printable a => Doc -> (a -> a -> a) -> [a] -> Doc
table symbol f as = lArray $ (symbol : map (pp 0) as) : (map (map (pp 0)) [ y : [ f x y | x <- as ] | y <- as ])

usesVariables :: GenericQ (Set String)
usesVariables x = fromMaybe (error "usesVariables") $
  (do (Var (UnQual (Ident name_))) <- cast x
      return $ S.singleton name_) <|>
  (do return $ S.unions $ gmapQ usesVariables x)

data Result 
  = Result {
      _rule :: String,
      _gamma :: Gamma,
      _sigma :: Sigma Tau,
      _exp :: Exp,
      _results :: [Result]
    }
  deriving (Typeable, Data, Show)

instance Printable Result where
  pp p r = (text "\\infrule[" <> text (_rule r) <> text "]{") $$
           (nest 2 $ vcat $ punctuate (text "\\quad") $ map (pp p) (_results r)) $$
           (text "}{") $$
           (nest 2 $ (pp p $ _gamma r) <> text "\\vdash" <> (pp p $ _exp r) <> text ":" <> (pp p $ _sigma r)) $$
           (text "}")

instance Printable Exp where
  pp _ (Var (UnQual (Ident name_))) 
    = lText name_
  pp _ (Lit (Int n)) 
    = text $ show n
  pp _ (App (App (Var (UnQual (Ident "both"))) _) _) 
    = lText "both \\_ \\_"
  pp _ (App _ (Var (UnQual (Ident name_)))) 
    = lText $ "\\_ " ++ name_
  pp _ (Lambda _ [PVar (Ident name_)] _) 
    = text "\\lambda" <> (lText $ name_ ++ ". \\_")
  pp _ (Let (BDecls ds) _)
    = text "\\textbf{let }" <> (hcat $ punctuate (text "; ") $ map ((\x -> lText $ x ++ " = \\_") . fst . binding) ds) <> text "\\textbf{ in }" <> lText "\\_"
  pp _ _ 
    = text ""