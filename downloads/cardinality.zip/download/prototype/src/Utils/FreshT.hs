module Utils.FreshT where

import Utils.CommonImports

newtype FreshT m a 
  = FreshT (StateT [Integer] m a)
  deriving (Functor, Applicative, Monad)

instance MonadTrans FreshT where
  lift = FreshT . lift  

runFreshT :: Functor m => FreshT m a -> m a
runFreshT (FreshT x) = fst <$> runStateT x [1..]

type Fresh = FreshT Identity

runFresh :: Fresh a -> a
runFresh = runIdentity . runFreshT

freshInteger :: Monad m => FreshT m Integer
freshInteger = FreshT $ do
  (x:xs) <- get
  put xs
  return x