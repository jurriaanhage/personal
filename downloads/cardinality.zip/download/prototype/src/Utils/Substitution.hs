module Utils.Substitution (
  Substs,
  append, 
  empty, 
  apply) where

import Data.Generics (GenericQ, geq, gshows, gzipWithQ, everywhere)
import Data.Data
import Data.Monoid
import Text.Printf
import Utils.CommonImports (fromMaybe)

data Value where
  Value :: (Data a) => a -> Value
  
instance Eq Value where
  (Value a) == (Value b) = fromMaybe False $ do
    a' <- cast a
    return $ geq a' b
  
deriving instance Ord ConstrRep  
  
gord :: Data a => a -> a -> Ordering  
gord = gord' where
  gord' :: GenericQ (GenericQ Ordering)
  gord' x y = (compare (constrRep $ toConstr x) (constrRep $ toConstr y)) `mappend` (mconcat $ gzipWithQ gord' x y) 

instance Ord Value where
  compare (Value a) (Value b) = fromMaybe (compare (typeOf a) (typeOf b)) $ do
    a' <- cast a
    return $ gord a' b  
    
instance Show Value where
  showsPrec _ (Value a) = gshows a    
  
type Substs = [(Value, Value)]

contains :: (Data a, Data b) => a -> b -> Bool
contains a b = geq' a b || or (gmapQ (`contains` b) a) where
  geq' x y = fromMaybe False $ 
    (do y' <- cast y
        return $ geq x y')

append :: (Monad m, Data a, Show a) => a -> a -> Substs -> m Substs
append x y ss = do
  let x' = apply ss x
      y' = apply ss y
  if x' `geq` y'
    then return ss
    else if y' `contains` x'
      then fail $ printf "failure: append '%s' '%s' '%s'" (show x') (show y') (show ss)
      else return $ (Value x, Value y) : ss

empty :: Substs
empty = []

apply :: Data a => Substs -> a -> a
apply ss x = foldr (\(Value a, Value b) -> everywhere (\y -> 
               fromMaybe y (do a' <- cast a
                               if geq y a'
                                 then cast b
                                 else return y))) x ss
