module Utils.MonadSubstitution where

import GHC.Exts
import Utils.CommonImports
import Utils.SubstitutionT
import Utils.FreshT
import qualified Utils.Substitution as SS

class Monad m => MonadSubstitution m where
  type Substitute m a :: Constraint
  type Apply m a :: Constraint
  substitute :: Substitute m a => a -> a -> m ()
  apply :: Apply m a => a -> m a

instance Monad m => MonadSubstitution (SubstitutionT m) where
  type Substitute (SubstitutionT m) a = (Data a, Show a)
  type Apply (SubstitutionT m) a = Data a
  substitute x y = SubstitutionT $ do 
    ss1 <- get
    ss2 <- SS.append x y ss1
    put ss2
  apply x = SubstitutionT $ do
    ss <- get
    return $ SS.apply ss x

instance MonadSubstitution m => MonadSubstitution (StateT s m) where
  type Substitute (StateT s m) a = Substitute m a
  type Apply (StateT s m) a = Apply m a
  substitute x y = lift $ substitute x y
  apply x = lift $ apply x

instance MonadSubstitution m => MonadSubstitution (ReaderT r m) where
  type Substitute (ReaderT r m) a = Substitute m a
  type Apply (ReaderT r m) a = Apply m a
  substitute x y = lift $ substitute x y
  apply x = lift $ apply x

instance (Monoid w, MonadSubstitution m) => MonadSubstitution (WriterT w m) where
  type Substitute (WriterT w m) a = Substitute m a
  type Apply (WriterT w m) a = Apply m a
  substitute x y = lift $ substitute x y
  apply x = lift $ apply x

instance (Error e, MonadSubstitution m) => MonadSubstitution (ErrorT e m) where
  type Substitute (ErrorT e m) a = Substitute m a
  type Apply (ErrorT e m) a = Apply m a
  substitute x y = lift $ substitute x y
  apply x = lift $ apply x

instance MonadSubstitution m => MonadSubstitution (FreshT m) where
  type Substitute (FreshT m) a = Substitute m a
  type Apply (FreshT m) a = Apply m a
  substitute x y = lift $ substitute x y
  apply x = lift $ apply x