module Utils.SubstitutionT where

import Utils.CommonImports
import qualified Utils.Substitution as SS

newtype SubstitutionT m a 
  = SubstitutionT (StateT SS.Substs m a)
  deriving (Functor, Applicative, Monad)

instance MonadTrans SubstitutionT where
  lift = SubstitutionT . lift

runSubstitutionT :: Monad m => SubstitutionT m a -> m (a, SS.Substs)
runSubstitutionT (SubstitutionT v) = runStateT v SS.empty

type Substitution = SubstitutionT Identity

runSubstitution :: Substitution a -> (a, SS.Substs)
runSubstitution = runIdentity . runSubstitutionT

  
