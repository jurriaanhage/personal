module Utils.Printable where

import qualified Data.Set as S
import Utils.CommonImports

block :: Bool -> Doc -> Doc
block b = braces . (if b then parens else id)

lText' :: Doc -> Doc
lText' d = text "\\text{" <> d <> text "}"

lPreview :: Doc -> Doc
lPreview d = text "\\begin{preview}" $$
             nest 2 d $$
             text "\\end{preview}"

lText :: String -> Doc
lText = lText' . text

($~$) :: Doc -> Doc -> Doc
d1 $~$ d2 = d1 $$
            text " " $$
            d2
 
lGraph :: [(Doc, Int, [Int])] -> Doc
lGraph graph =
  let node i = text $ "n" ++ show i
      nodes = vcat $ map (\(d, i, _) -> node i <+> text "[texlbl=\"" <> d <> text "\"];") graph
      edges = vcat $ map (\(_, i, is) -> vcat $ map (\i' -> node i <+> text "->" <+> node i' <> text ";") is) graph
  in  text "\\begin{dot2tex}[dot,options=-tmath --autosize]" $$
      nest 2 (
        text "digraph G {" $$
        nest 2 (
          text "concentrate=true" $$
          nodes $$ 
          edges
          ) $$ 
        text "}") $$
      text "\\end{dot2tex}"

class ArrayLine l where
  ppHeader :: [l] -> Doc
  ppLine :: l -> Doc

instance ArrayLine [Doc] where
  ppHeader ls = text $ replicate (length $ head ls) 'c'
  ppLine l = cat $ punctuate (text " & ") l

instance ArrayLine Doc where
  ppHeader _ = text "l"
  ppLine = id  

instance (Printable a, Printable b) => ArrayLine (a,b) where
  ppHeader _ = text "ll"
  ppLine (a,b) = pp 0 a <> text " & " <> pp 0 b

instance ArrayLine (Doc,Doc,Doc) where
  ppHeader _ = text "lll"
  ppLine (a,b,c) = a <> text " & " <> b <> text " & " <> c

lArray :: ArrayLine l => [l] -> Doc
lArray ls = (text "\\begin{array}{" <> ppHeader ls <> text "}") $$
            (nest 2 $ vcat $ map ((<> text " \\\\") . ppLine) ls) $$
            (text "\\end{array}")

lMath :: Doc -> Doc
lMath d = text "$" <> d <> text "$"            

ppM :: Printable a => Int -> a -> Doc
ppM p a = lMath $ pp p a

class Printable a where
  pp :: Int -> a -> Doc

instance Printable a => Printable [a] where
  pp _ ls = braces $ brackets $ hcat $ punctuate (text ",") $ map (pp 0) ls  

instance (Printable a, Printable b) => Printable (a, b) where  
  pp _ (a,b) = braces $ parens $ pp 0 a <> text "," <> pp 0 b

instance (Printable a, Printable b, Printable c) => Printable (a, b, c) where  
  pp _ (a,b,c) = braces $ parens $ pp 0 a <> text "," <> pp 0 b <> text "," <> pp 0 c

instance Printable a => Printable (Set a) where
  pp _ ls = braces $ (\x -> text "\\{" <> x <> text "\\}") $ hcat $ punctuate (text ",") $ map (pp 0) $ S.toList ls      

instance Printable Doc where
  pp _ d = d