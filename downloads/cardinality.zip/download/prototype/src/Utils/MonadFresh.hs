module Utils.MonadFresh where

import Utils.CommonImports
import qualified Utils.FreshT as F
import Utils.SubstitutionT

class (Monad m, Applicative m) => MonadFresh m where
  freshInteger :: m Integer

instance (Monad m, Functor m) => MonadFresh (F.FreshT m) where
  freshInteger = F.freshInteger

instance MonadFresh m => MonadFresh (StateT s m) where
  freshInteger = lift freshInteger

instance MonadFresh m => MonadFresh (ReaderT r m) where
  freshInteger = lift freshInteger

instance (Monoid w, MonadFresh m) => MonadFresh (WriterT w m) where
  freshInteger = lift freshInteger

instance (Error e, MonadFresh m) => MonadFresh (ErrorT e m) where
  freshInteger = lift freshInteger

instance MonadFresh m => MonadFresh (SubstitutionT m) where
  freshInteger = lift freshInteger

class FreshVal a where
  fresh :: (MonadFresh m) => m a

freshNum :: (MonadFresh m, Functor m, Num a) => m a
freshNum = fromInteger <$> freshInteger

instance FreshVal () where
  fresh = return ()

instance FreshVal Int where
  fresh = freshNum

instance (FreshVal a, FreshVal b) => FreshVal (a,b) where
  fresh = (,) <$> fresh <*> fresh    

instance (FreshVal a, FreshVal b, FreshVal c) => FreshVal (a,b,c) where
  fresh = (,,) <$> fresh <*> fresh <*> fresh