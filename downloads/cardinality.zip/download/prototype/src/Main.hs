module Main where

import Inference
import Datatypes
import Language.Haskell.Exts
import Utils
import System.Environment

find' :: (a -> Bool) -> [a] -> Maybe (a, [a])
find' f as = 
  case partition f as of
    ([x],ys) -> Just (x,ys)
    _ -> Nothing

main :: IO ()
main = do
  [file] <- getArgs
  modul_ <- fromParseResult <$> parseFile file
  let dts = dataDecls modul_
      e = declsToExp $ valueDecls modul_
  infer' dts e file

declsToExp :: [Decl] -> Exp
declsToExp ds = Let (BDecls ds) (Var $ UnQual $ Ident "main")

valueDecls :: Module -> [Decl]
valueDecls (Module _ _ _ _ _ _ ds) = 
  let maybeValue d@(PatBind _ _ _ _ _) = Just d
      maybeValue _ = Nothing
  in mapMaybe maybeValue ds 