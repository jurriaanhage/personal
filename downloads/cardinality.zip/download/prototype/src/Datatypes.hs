module Datatypes where

import Language.Haskell.Exts
import Data.Monoid (mappend, mempty)
import Utils
import Data
import Data.Var as V
import qualified Data.Map as M

findDataByConName dts name = 
  fmap fst $ M.minViewWithKey $ M.filter (\(_,_,cs) -> not $ M.null $ M.filterWithKey (\k _ -> k == name) cs) dts

findDataByConName' dts name = 
  maybe (fail "datatype not found") return $ findDataByConName dts name

findConByName cs name = 
  M.lookup name cs

findConByName' cs name = 
  maybe (fail "constructor not found") return $ findConByName cs name

deletes keys m = M.mergeWithKey (\k a b -> Nothing) (const M.empty) id (M.fromList $ zip keys $ repeat ()) m

freshData (avs, tvs, cs) = do
  favs <- mapM (const fresh) avs
  ftvs <- mapM (const fresh) tvs
  let (fcs,_) = runSubstitution $ do
                  zipWithM substitute avs favs
                  zipWithM substitute tvs ftvs
                  apply cs
  return (favs, ftvs, fcs)
  
dataDecls :: Module -> InfM DataDecls
dataDecls _ = do
  a' <- fresh
  nu_a' <- fresh
  delta_a' <- fresh
  let a = TVar a'
      nu_a = AVar nu_a'
      delta_a = AVar delta_a'
  
  b' <- fresh
  nu_b' <- fresh
  delta_b' <- fresh
  let b = TVar b'
      nu_b = AVar nu_b'
      delta_b = AVar delta_b'
  
  nu_rec' <- fresh
  delta_rec' <- fresh
  let nu_rec = AVar nu_rec'
      delta_rec = AVar delta_rec'
  
  let boolD = M.singleton "Bool" ([],[],trueD `mappend` falseD) where
        trueD = M.singleton "True" []
        falseD = M.singleton "False" []
      eitherD = M.singleton "Either" ([nu_a', delta_a', nu_b', delta_b'],[a', b'],leftD `mappend` rightD) where
        leftD = M.singleton "Left" [Rho (Sigma a nu_a) delta_a]
        rightD = M.singleton "Right" [Rho (Sigma b nu_b) delta_b]
      tupleD = M.singleton "Tuple" ([nu_a', delta_a', nu_b', delta_b'],[a', b'],pairD) where
        pairD = M.singleton "Pair" [Rho (Sigma a nu_a) delta_a, Rho (Sigma b nu_b) delta_b]
      natD = M.singleton "Nat" ([nu_rec',delta_rec'],[],zeroD `mappend` succD) where
        zeroD = M.singleton "Zero" []
        succD = M.singleton "Succ" [Rho (Sigma (TData "Nat" [nu_rec,delta_rec] []) nu_rec) delta_rec]
      listD = M.singleton "List" ([nu_a',delta_a',nu_rec',delta_rec'],[a'],nilD `mappend` consD) where
        nilD = M.singleton "Nil" []
        consD = M.singleton "Cons" [Rho (Sigma a nu_a) delta_a, Rho (Sigma (TData "List" [nu_a,delta_a,nu_rec,delta_rec] [a]) nu_rec) delta_rec]

  return $ boolD `mappend` eitherD `mappend` tupleD `mappend` natD `mappend` listD