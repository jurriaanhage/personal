aantalOpl a b c  [ (d >. 0.0  = 2)
                 , (d ==. 0.0 = 1)
                 , (d <. 0.0  = 0)
                 ]
                 where d = (b*.b-.4.0*.a*.c)


