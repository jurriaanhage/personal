aantalOpl :: Float -> Float -> Float -> Int

aantalOpl a b c  | d >. 0.0  = 2
                 | d <. 0.0  = 0
                 otherwise = 1
                 where d = b*.b-.4.0*.a*.c



