module Pfp where

import List

type Table = [[String]]
type Kolom = [String]
type Rij   = [String]

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]



writeTable :: Table -> String
writeTable []  = ""
writeTable tab = " " ++ writePartLine tab 0 ++ "  " ++ header ++ " " ++ writePartLine tab 0 ++ "  " ++ concat rest ++ " " ++ writePartLine tab 0
                                  where (header : rest) = writeRijen tab

writePartLine :: Table -> Int -> String
writePartLine tab kolomnr = if kolomnr == aantalKolom tab then ""
                      else replicate (breedteKolom ( pakKolom tab kolomnr )) '-' ++ " " ++ writePartLine tab ( kolomnr + 1 )
                      

writeRij :: Table -> Int -> Rij -> String
writeRij tab n rij = if n == aantalKolom tab then " " ++ "  "
                     else " " ++ (!!) rij n ++ replicate (breedteKolom ( pakKolom tab n) - length ((!!) rij n) ) ' ' ++ writeRij tab (n + 1) rij

writeRijen :: Table -> [String]
writeRijen tab = map (writeRij tab 0 ) tab

aantalRijen :: Table -> Int
aantalRijen tab = length ( head (transpose tab ))

aantalKolom :: Table -> Int
aantalKolom tab = length ( head tab )

breedteKolom :: Kolom -> Int
breedteKolom kol = maximum ( map length kol)

pakKolom :: Table -> Int -> Kolom
pakKolom tab n = (!!) (transpose tab) n

pakRij :: Table -> Int -> Rij
pakRij tab n = (!!) tab n

project :: [String] -> Table -> Table
project kol tab =  head kol == head (pakKolom tab kolomnr) then
                                                           else head (pakKolom tab (kolomnr + 1 ))























