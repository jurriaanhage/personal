module Pfp where

import List

type Table = [[String]]
type Kolom = [String]
type Rij   = [String]

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]



writeLine :: Table -> String
writeLine tab = " " ++ writePartLine tab 0 ++ "  " ++ " "

writePartLine :: Table -> Int -> String
writePartLine tab n = if n == aantalKolom tab then ""
                      else replicate (breedteKolom ( pakKolom tab n )) '-' ++ " " ++ writePartLine tab ( n + 1 )
                      

writeRij :: Table -> Int -> String
writeRij tab n = if n == ( aantalRijen tab + 3) then ""
                 else replicate ( breedteKolom (pakKolom tab n)) ' ' ++ " " ++ writePartLine tab (n + 1)



aantalRijen :: Table -> Int
aantalRijen tab = length ( head (transpose tab ))

aantalKolom :: Table -> Int
aantalKolom tab = length ( head tab )

breedteKolom :: Kolom -> Int
breedteKolom kol = maximum ( map length kol)

pakKolom :: Table -> Int -> Kolom
pakKolom tab n = (!!) (transpose tab) n

pakRij :: Table -> Int -> Rij
pakRij tab n = (!!) tab n























