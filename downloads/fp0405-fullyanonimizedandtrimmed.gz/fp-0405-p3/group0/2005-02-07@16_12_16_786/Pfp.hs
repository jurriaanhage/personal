module Pfp where

import List

type Table = [[String]]
type Kolom = [String]

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]


{-                    -        
                

                   -        
                " "    -    -}

aantalKolom :: Table -> Int
aantalKolom tab = length ( head tab )

breedteKolom :: Table -> Int -> Int
breedteKolom tab n = maximum ( map length ( head ( drop n ( transpose tab ))))























