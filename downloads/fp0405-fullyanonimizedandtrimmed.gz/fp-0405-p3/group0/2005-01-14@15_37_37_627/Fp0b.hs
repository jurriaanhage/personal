totEerste :: [Int] -> [Int]

totEerste [] = []
totEerste (x:xs) | x == 0 = []
                 | otherwise = x : totEerste xs


naEerste :: [Int] -> [Int]

naEerste [] = []
naEerste (x:xs) | x == 0 = xs
                | otherwise = naEerste xs



