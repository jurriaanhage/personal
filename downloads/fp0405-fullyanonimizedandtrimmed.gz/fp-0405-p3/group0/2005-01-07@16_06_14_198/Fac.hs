aantal0pl a b c = [ b*.b-.4.0*.a*.c > 0 ]


