totEerste :: Int -> Int

totEerste [] = []
totEerste (x:xs) | x == 0 = []
                 | otherwise = x : totEerste xs


