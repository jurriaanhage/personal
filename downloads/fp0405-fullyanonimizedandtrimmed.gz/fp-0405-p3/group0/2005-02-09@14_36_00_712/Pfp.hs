module Pfp where

import List

type Table = [[String]]
type Kolom = [String]
type Rij   = [String]

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]



writeTable :: Table -> String
writeTable []  = ""
writeTable tab = " " ++ writePartLine tab 0 ++ "  " ++ header ++ " " ++ writePartLine tab 0 ++ "  " ++ concat rest ++ " " ++ writePartLine tab 0
                                  where (header : rest) = writeRijen tab

writePartLine :: Table -> Int -> String
writePartLine tab kolomnr = if kolomnr == aantalKolom tab then ""
                      else replicate (breedteKolom ( pakKolom tab kolomnr )) '-' ++ " " ++ writePartLine tab ( kolomnr + 1 )
                      

writeRij :: Table -> Int -> Rij -> String
writeRij tab n rij = if n == aantalKolom tab then " " ++ "  "
                     else " " ++ (!!) rij n ++ replicate (breedteKolom ( pakKolom tab n) - length ((!!) rij n) ) ' ' ++ writeRij tab (n + 1) rij

writeRijen :: Table -> [String]
writeRijen tab = map (writeRij tab 0 ) tab

aantalRijen :: Table -> Int
aantalRijen tab = length ( head (transpose tab ))

aantalKolom :: Table -> Int
aantalKolom tab = length ( head tab )

breedteKolom :: Kolom -> Int
breedteKolom kol = maximum ( map length kol)

pakKolom :: Table -> Int -> Kolom
pakKolom tab n = (!!) (transpose tab) n

pakRij :: Table -> Int -> Rij
pakRij tab n = (!!) tab n

project :: [String] -> Table -> Table
project string tab = transpose (projectBijna string tab)

projectBijna :: [String] -> Table -> Table
projectBijna [] _ = []
projectBijna (x:xs) tab = projectKlein x tab : projectBijna xs tab

projectKlein :: String -> Table -> Kolom
projectKlein string tab = pakKolom tab ( hoeVeelste ( transpose tab ) string 0 )

hoeVeelste :: Table -> String -> Int -> Int
hoeVeelste [] _ _ = -1
hoeVeelste ((y:_):yss) string n = if y `eqString` string then n
                                                  else hoeVeelste yss string (n+1)

selectBijna :: String -> (String -> Bool) -> Table -> [String]
selectBijna string functie tab = string : filter functie (tail(projectKlein string tab))

projectGroot:: String -> Table -> Kolom
projectGroot string tab = pakRij tab ( hoeVeelste ( tab ) string 0 )

projectB :: [String] -> Table -> Table
projectB [] _ = []
projectB (x:xs) tab = projectGroot x tab : projectB xs tab

select :: String -> (String -> Bool) -> Table -> Table
select string functie tab = projectB (selectBijna string functie (tab)) (tab)

{-
                                                                                                                                             
                                                                                                                                              
                                                                                                                                            
                                                          -                                                                                 
                                                                                                                                           
                                                            


              -        -       

                                                                                                                                               
              


                                                       
 --------- --------------------------------- ---------------- --------- 
                                                                        
 --------- --------------------------------- ---------------- --------- 
                                                                        
                                                                        
                                                                        
                                                                        
                                                                        
                                                                        
                                                                        
                                                                        
 --------- --------------------------------- ---------------- --------- 


      

                                                                                       
                    

                                                                                          
                                                                         
 " " " " " "   " " " " " "                                                       

              -        -       
                                 

                 
-}


titel :: Table -> [String]
titel tab = pakRij tab 0

vergelijk :: [String] -> [String] -> [String] -> String
vergelijk (_:x) [] y = vergelijk x y y
vergelijk [] _ _ = []
vergelijk (x:xs) (y:ys) r = if x `eqString` y then x
                                              else vergelijk (x:xs) ys r

{-                                     -}
gedoe :: Table -> Table -> String
gedoe tab tabt = vergelijk (titel tab) (titel tabt) (titel tabt)

erUit :: [String] -> String -> [String] -> [String]
erUit (x:xs) string lijst = if x `eqString` string then xs : lijst
                                             else erUit xs string lijst
















