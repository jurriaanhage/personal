aantalOpl2 a b c = [ (b*.b-.4.0*.a*.c) >. 0.0 

aantalOpl a b c  |(b*.b-.4.0*.a*.c) >. 0.0  = 2
                 |(b*.b-.4.0*.a*.c) =. 0.0  = 1
                 |(b*.b-.4.0*.a*.c) <. 0.0  = 0


