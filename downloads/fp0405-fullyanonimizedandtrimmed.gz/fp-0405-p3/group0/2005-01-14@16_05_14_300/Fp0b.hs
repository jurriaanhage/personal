totEerste :: [Int] -> [Int]
totEerste [] = []
totEerste (x:xs) | x == 0 = []
                 | otherwise = x : totEerste xs

naEerste :: [Int] -> [Int]
naEerste [] = []
naEerste (x:xs) | x == 0 = xs
                | otherwise = naEerste xs

zonder :: [Int] -> [Int]
zonder [] = []
zonder (x:xs) | x == 0 = zonder xs
              | otherwise = x : zonder xs
             
naLaatste :: [Int] -> [Int]
naLaatste = reverse . totEerste . reverse


aantalJaar :: Float -> a -> b -> Float

aantalJaar r k e = (log (e/k) ) / (log r)


