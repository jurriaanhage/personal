Int -> int

totEerste [] = []
totEerste x:xs | x == 0 -> []
               | Else x ++ totEerste xs  


