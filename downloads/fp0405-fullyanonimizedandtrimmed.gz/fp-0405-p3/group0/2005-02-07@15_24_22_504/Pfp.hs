module Pfp where

import List

type Table = [[String]]

compilers :: Table
compilers =
  [ ["        ", "                    "]
  , ["      ", "                    "]
  , ["   ", "                  "]
  , ["   ", "                  "]
  , ["    ", "                  "]
  , ["        ", "                  "]
  , ["         ", "                         "]
  , ["         ", "                                 "]
  , ["   ", "                                 "]
  ]

locaties :: Table
locaties =
  [ ["                    ", "    ", "    "]
  , ["                    ", "         ", "       "]
  , ["                  ", "        ", "    "]
  , ["                  ", "        ", "         "]
  , ["                  ", "                ", "         "]
  , ["                         ", "                ", "         "]
  , ["                                 ", "      ", "        "]
  ]




