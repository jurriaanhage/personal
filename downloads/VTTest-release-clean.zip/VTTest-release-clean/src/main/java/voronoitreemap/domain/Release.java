package voronoitreemap.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.NaturalId;

@Entity
public class Release implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false)
	private Long majorVersion;
	
	@Column(nullable = false)
	private Long minorVersion;
	
	@Column(nullable = false)
	private Long buildNumber;
	
	@Column(nullable = true)
	private String description;
	
	@ManyToOne(optional = false)
	private Project project;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "release")
	private Set<AnalysisResultGraph> analysisResultGraphs;
	
	public Release() {
		super();
	}
	
	public Release(Long majorVersion, Long minorVersion, Long buildNumber, String description, Project project) {
		super();
		
		this.majorVersion = majorVersion;
		this.minorVersion = minorVersion;
		this.buildNumber = buildNumber;
		this.description = description;
		this.project = project;
	}

	public Long getId() {
		return id;
	}

	public Long getMajorVersion() {
		return majorVersion;
	}

	public Long getMinorVersion() {
		return minorVersion;
	}

	public Long getBuildNumber() {
		return buildNumber;
	}

	public String getDescription() {
		return description;
	}
	
	public Project getProject() {
		return project;
	}

	public Set<AnalysisResultGraph> getAnalysisResultGraphs() {
		return analysisResultGraphs;
	}
	
	
	
	

}
