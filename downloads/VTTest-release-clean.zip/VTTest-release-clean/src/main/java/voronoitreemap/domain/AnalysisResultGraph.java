package voronoitreemap.domain;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.NaturalId;

@Entity
public class AnalysisResultGraph implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false, columnDefinition = "LONGVARCHAR")
	private String gefxString;
	
	@Column(nullable = false)
	private String description;
	
	@Column(nullable = false)
	private String fileName;
	
	@ManyToOne(optional = false)
	private Release release;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "originGraph")
	private Set<Visualisation> visualisations;
	
	public AnalysisResultGraph(){
		super();
	}

	public AnalysisResultGraph(Release release, String gefxString, String fileName, String description) {
		super();
		
		this.release = release;
		this.gefxString = gefxString;
		this.fileName = fileName;
		this.description = description;
	}
	
	public Long getId() {
		return id;
	}

	public Set<Visualisation> getVisualisations() {
		return visualisations;
	}

	public String getGefxString() {
		return gefxString;
	}
	
	public String getFileName() {
		return fileName;
	}
	
	public String getDescription() {
		return description;
	}

	public Release getRelease() {
		return release;
	}

}
