package voronoitreemap.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.NaturalId;

@Entity
public class Visualisation implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false, columnDefinition = "LONGVARCHAR")
	private String visData;
	
	@Column(nullable = false)
	private String description;
	
	@Column(nullable = false)
	private String sortAttribute;
	
	@Column(nullable = false)
	private String sizeAttribute;
	
	@ManyToOne(optional = false)
	private AnalysisResultGraph originGraph;
	
	public Visualisation(){
		super();
	}
	
	public Visualisation(AnalysisResultGraph originGraph, String visData, String description, String sortAttribute, String sizeAttribute){
		super();
		
		this.originGraph = originGraph;
		this.visData = visData;
		this.description = description;
		this.sortAttribute = sortAttribute;
		this.sizeAttribute = sizeAttribute;
	}

	public Long getId() {
		return id;
	}

	public String getVisData() {
		return visData;
	}

	public String getDescription() {
		return description;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getSortAttribute() {
		return sortAttribute;
	}

	public String getSizeAttribute() {
		return sizeAttribute;
	}

	public AnalysisResultGraph getOriginGraph() {
		return originGraph;
	}
	
	
}
