package voronoitreemap.gephi;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

import org.gephi.data.attributes.api.AttributeColumn;
import org.gephi.data.attributes.api.AttributeController;
import org.gephi.data.attributes.api.AttributeModel;
import org.gephi.data.attributes.api.AttributeType;
import org.gephi.graph.api.GraphController;
import org.gephi.graph.api.GraphModel;
import org.gephi.graph.api.HierarchicalDirectedGraph;
import org.gephi.graph.api.Node;
import org.gephi.graph.api.NodeIterable;
import org.gephi.io.importer.api.Container;
import org.gephi.io.importer.api.EdgeDefault;
import org.gephi.io.importer.api.ImportController;
import org.gephi.io.importer.plugin.file.ImporterBuilderGEXF;
import org.gephi.io.processor.plugin.DefaultProcessor;
import org.gephi.project.api.Workspace;
import org.openide.util.Lookup;

public class Util {

	public static HierarchicalDirectedGraph getGraph(String gefxString)
			throws UnsupportedEncodingException {
		// Init a project - and therefore a workspace
		org.gephi.project.api.ProjectController pc = Lookup.getDefault()
				.lookup(org.gephi.project.api.ProjectController.class);
		pc.newProject();
		Workspace workspace = pc.getCurrentWorkspace();

		ImportController importController = Lookup.getDefault().lookup(
				ImportController.class);
		GraphModel graphModel = Lookup.getDefault()
				.lookup(GraphController.class).getModel();

		// Import file
		Container container;
		container = importController.importFile(new ByteArrayInputStream(
				gefxString.getBytes("UTF-8")), new ImporterBuilderGEXF()
				.buildImporter());
		container.getLoader().setEdgeDefault(EdgeDefault.DIRECTED); // Force
																	// DIRECTED

		// Append imported data to GraphAPI
		importController.process(container, new DefaultProcessor(), workspace);

		// See if graph is well imported
		return graphModel.getHierarchicalDirectedGraph();
	}
	
	public static String getId(Node node) {
		return node.getAttributes().getValue("id").toString();
	}
	
	public static String getLabel(Node node) {
		return node.getAttributes().getValue("label").toString();
	}

	public static Node getRootNode(HierarchicalDirectedGraph graph) {

		NodeIterable ni = graph.getTopNodes();
		return ni.toArray()[0];

	}

	/*
	 * INT(Integer.class), LONG(Long.class), FLOAT(Float.class),
	 * DOUBLE(Double.class), BOOLEAN(Boolean.class), CHAR(Character.class),
	 * STRING(String.class),
	 */

	public static Comparator<Node> createNodeComparitor(
			String nodeAttributeName, HierarchicalDirectedGraph graph) {
		AttributeController ac = Lookup.getDefault().lookup(
				AttributeController.class);
		AttributeModel model = ac.getModel();

		switch (model.getNodeTable().getColumn(nodeAttributeName).getType()) {
		case STRING: // Fall through
		case CHAR:
			return new Comparator<Node>() {
				@Override
				public int compare(Node arg0, Node arg1) {
					String val0 = arg0.getAttributes()
							.getValue(nodeAttributeName).toString();
					String val1 = arg1.getAttributes()
							.getValue(nodeAttributeName).toString();

					return val0.compareToIgnoreCase(val1);
				}
			};
		case INT:
			return new Comparator<Node>() {
				@Override
				public int compare(Node arg0, Node arg1) {
					int val0 = Integer.valueOf(arg0.getAttributes()
							.getValue(nodeAttributeName).toString());
					int val1 = Integer.valueOf(arg1.getAttributes()
							.getValue(nodeAttributeName).toString());

					return Integer.compare(val0, val1);
				}
			};
		case FLOAT: //Fall through
		case DOUBLE: 
			return new Comparator<Node>() {
				@Override
				public int compare(Node arg0, Node arg1) {
					double val0 = Double.valueOf(arg0.getAttributes()
							.getValue(nodeAttributeName).toString());
					double val1 = Double.valueOf(arg1.getAttributes()
							.getValue(nodeAttributeName).toString());

					return Double.compare(val0, val1);
				}
			};
		default:
			 return null;
		}
	}
	
	public static Function<Node, Double> createAreaFractionFunction(String nodeAttributeName, HierarchicalDirectedGraph graph) {
		AttributeController ac = Lookup.getDefault().lookup(
				AttributeController.class);
		AttributeModel model = ac.getModel();

		switch (model.getNodeTable().getColumn(nodeAttributeName).getType()) {
			case FLOAT: //Fall through
			case DOUBLE:
			case INT:
				return node -> {
					Node parent = graph.getParent(node);
					double parentVal = Double.valueOf(parent.getAttributes()
							.getValue(nodeAttributeName).toString());
					double nodeVal = Double.valueOf(node.getAttributes()
							.getValue(nodeAttributeName).toString());
					return parentVal == 0 ? 0 : (nodeVal) / (parentVal);
				};
			default:
				return node -> {
					Node parent = graph.getParent(node);
					return 1.0 / graph.getChildrenCount(parent);
					};
		}
	}
	
	public static Function<Node, List<Node>> getChildNodes(HierarchicalDirectedGraph graph){
		return node -> {ArrayList<Node> childNodes = new ArrayList<Node>();
		
		NodeIterable children = graph.getChildren(node);
		
		for(Node child : children) {
			childNodes.add(child);
		}
		
		return childNodes;
		};
	}

}
