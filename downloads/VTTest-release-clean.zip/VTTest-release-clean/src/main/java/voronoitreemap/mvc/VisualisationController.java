package voronoitreemap.mvc;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.validation.Valid;

import org.gephi.graph.api.HierarchicalDirectedGraph;
import org.gephi.graph.api.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.text.List;

import voronoi.ConvexPolygon;
import voronoi.Point;
import voronoi.TreeSite;
import voronoitreemap.domain.AnalysisResultGraph;
import voronoitreemap.domain.Release;
import voronoitreemap.domain.Visualisation;
import voronoitreemap.gephi.Util;
import voronoitreemap.mvc.dto.AnalysisResultGraphAddDto;
import voronoitreemap.mvc.dto.AnalysisResultGraphViewDto;
import voronoitreemap.mvc.dto.VisualisationAddDto;
import voronoitreemap.mvc.dto.VisualisationViewDto;
import voronoitreemap.mvc.dto.VisualisationViewJsonDto;
import voronoitreemap.service.AnalysisResultGraphService;
import voronoitreemap.service.VisualisationService;
import voronoitreemap.treemap.Treemap;

@Controller
@RequestMapping("/visualisation")
public class VisualisationController {
	
	private final VisualisationService visualisationService;
	private final AnalysisResultGraphService analysisResultGraphService;
	
	@Autowired
	public VisualisationController(VisualisationService visualisationService, 
			AnalysisResultGraphService analysisResultGraphService){
		this.visualisationService = visualisationService;
		this.analysisResultGraphService = analysisResultGraphService;
	}
	
	@RequestMapping(value = "/json", produces="application/json")
	@ResponseBody
	public String xml(@RequestParam String id) {
		Visualisation visualisation = visualisationService
				.getVisualisation(Long.valueOf(id));
		
		return visualisation.getVisData();
	}
	
	@RequestMapping(value = "/view")
	public ModelAndView view(@RequestParam String id) throws UnsupportedEncodingException {

		Visualisation visualisation = visualisationService
				.getVisualisation(Long.valueOf(id));
		
		VisualisationViewDto viewDto = new VisualisationViewDto(visualisation);
		
		ModelAndView mav = new ModelAndView("/visualisation/view",
				"visualisation", viewDto);

		return mav;
	}
	
	@RequestMapping(value = "/compare")
	public ModelAndView compare(@RequestParam String id, @RequestParam String compareWithId, @RequestParam String attribute) throws UnsupportedEncodingException {

		Visualisation visualisation = visualisationService
				.getVisualisation(Long.valueOf(id));
		
		Visualisation oldVisualisation = visualisationService
				.getVisualisation(Long.valueOf(compareWithId));
		
		VisualisationViewDto viewDto = new VisualisationViewDto(visualisation);
		VisualisationViewDto oldViewDto = new VisualisationViewDto(oldVisualisation);
		
		ModelAndView mav = new ModelAndView("/visualisation/compare",
				"visualisation", viewDto);
		
		mav.addObject("oldVisualisation", oldViewDto);
		mav.addObject("attribute", attribute);

		return mav;
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add(@RequestParam String resultGraphId,
			@ModelAttribute VisualisationAddDto visualisationAddDto) throws UnsupportedEncodingException {
		AnalysisResultGraph resultGraph = analysisResultGraphService.getAnalysisResultGraph(Long.valueOf(resultGraphId));
		
		
		AnalysisResultGraphViewDto visDto = new AnalysisResultGraphViewDto(resultGraph
				.getGefxString());
		
		ModelAndView mav = new ModelAndView("/visualisation/add", "resultGraph", resultGraph);
		mav.addObject("visDto", visDto);
		
		return mav;
	}
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView add(@RequestParam String resultGraphId,
			@Valid VisualisationAddDto visualisationAddDto,
			BindingResult result, RedirectAttributes redirect) throws UnsupportedEncodingException, JsonProcessingException {
		
		AnalysisResultGraph resultGraph = analysisResultGraphService.getAnalysisResultGraph(Long.valueOf(resultGraphId));		
		AnalysisResultGraphViewDto visDto = new AnalysisResultGraphViewDto(resultGraph
				.getGefxString());
		
		if (result.hasErrors()) {
			ModelAndView errorMav = new ModelAndView(
					"/visualisation/add", "formErrors",
					result.getAllErrors());
			errorMav.addObject("resultGraph", resultGraph);
			errorMav.addObject("visDto", visDto);
			return errorMav;
		}
		
		ConvexPolygon area = new ConvexPolygon(new ArrayList<Point>(){{add(new Point(1,1)); add(new Point(2048.0, 0)); add(new Point(2047.0, 1535.0)); add(new Point(0, 1536.0));}});
		
		HierarchicalDirectedGraph graph = Util.getGraph(resultGraph.getGefxString());
		Node rootNode = Util.getRootNode(graph);
		
		TreeSite<Node> tms = Treemap.Create(area, rootNode, Util.getChildNodes(graph), Util.createAreaFractionFunction(visualisationAddDto.getSizeAttribute(), graph), Util.createNodeComparitor(visualisationAddDto.getSortAttribute(), graph));
		VisualisationViewJsonDto viewDto = new VisualisationViewJsonDto(tms);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(viewDto);
		
		Visualisation visualisation = new Visualisation( resultGraph, 
				json, 
				visualisationAddDto.getDescription(), 
				visualisationAddDto.getSizeAttribute(), 
				visualisationAddDto.getSortAttribute()
				);
		
		visualisationService.save(visualisation);
		
		return new ModelAndView("redirect:/visualisation/view/?id="
				+ visualisation.getId());
		
	}

}
