package voronoitreemap.mvc;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.mvc.dto.ProjectDto;
import voronoitreemap.service.ProjectService;
import voronoitreemap.service.ReleaseService;
import voronoitreemap.service.dto.ReleaseSummaryDto;


@Controller
@RequestMapping("/project")
public class ProjectController {
	
	private final ProjectService projectService;
	private final ReleaseService releaseService;
	
	@Autowired
	public ProjectController(ProjectService projectService,
			ReleaseService releaseService) {
		this.projectService = projectService;
		this.releaseService = releaseService;
	}
	
	@RequestMapping("{id}")
	public ModelAndView view(@PathVariable("id") String id) {
		Project project = projectService.getProject(Long.valueOf(id));
		Iterable<Release> releases = releaseService.allReleasesByProject(project);
		
		ModelAndView mav = new ModelAndView("/project/view");
		mav.addObject("project", project);
		mav.addObject("releases", releases);
		
		return mav;
	}
	
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String add(@ModelAttribute ProjectDto projectDto) {
		return "/project/add";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView add(@Valid ProjectDto projectDto, BindingResult result,
			RedirectAttributes redirect) {
		if (result.hasErrors()) {
			return new ModelAndView("/project/add", "formErrors", result.getAllErrors());
		}
		
		Project project = new Project(projectDto.getName(), projectDto.getDescription());
		projectService.save(project);
		
		return new ModelAndView("redirect:/");
	}

}
