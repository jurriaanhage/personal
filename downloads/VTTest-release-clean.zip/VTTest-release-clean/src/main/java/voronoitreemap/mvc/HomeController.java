package voronoitreemap.mvc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import voronoitreemap.domain.Project;
import voronoitreemap.service.ProjectService;

@Controller
@RequestMapping("/")
public class HomeController {
	
	@Autowired
	private ProjectService projectService;
	
	@RequestMapping
	public ModelAndView list() {
		Iterable<Project> projects = projectService.allProjects();
		return new ModelAndView("home", "projects", projects);
	}

}
