package voronoitreemap.mvc.dto;

import java.util.ArrayList;

import org.gephi.graph.api.Node;

import voronoi.Point;
import voronoi.TreeSite;
import voronoitreemap.gephi.Util;

public class VisualisationViewJsonDto {
	
	private NodeDto root;

	public VisualisationViewJsonDto() {
		
	}
	
	public VisualisationViewJsonDto(TreeSite<Node> rootTSNode) {
		
		root = new NodeDto(rootTSNode, 0);
	}

	public NodeDto getRoot() {
		return root;
	}

	public void setRoot(NodeDto root) {
		this.root = root;
	}

	public class NodeDto {
		private ArrayList<PointDto> points;
		private PointDto centerOfWeight;
		private String id;
		private String label;
		private int level;
		private ArrayList<NodeDto> children;
		private double weight;
		
		public NodeDto(){
			
		}
		
		public NodeDto(TreeSite<Node> tsNode, int level) {
			this.centerOfWeight = new PointDto(tsNode.getX(), tsNode.getY());
			this.id = Util.getId(tsNode.getData());
			this.label = Util.getLabel(tsNode.getData());
			this.level = level;
			this.weight = tsNode.getWeight();
			
			points = new ArrayList<PointDto>();
			
			for(Point p : tsNode.getBoundingPolygon().getPoints()) {
				PointDto pd = new PointDto(p.getX(), p.getY());
				points.add(pd);
			}
			
			children = new ArrayList<NodeDto>();
			
			for(TreeSite<Node> child : tsNode.getChildren()) {
				children.add(new NodeDto(child, level +1));
			}			
		}
		
		public ArrayList<PointDto> getPoints() {
			return points;
		}
		public void setPoints(ArrayList<PointDto> points) {
			this.points = points;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		public PointDto getCenterOfWeight() {
			return centerOfWeight;
		}
		public void setCenterOfWeight(PointDto centerOfWeight) {
			this.centerOfWeight = centerOfWeight;
		}
		public int getLevel() {
			return level;
		}
		public void setLevel(int level) {
			this.level = level;
		}
		public double getWeight() {
			return weight;
		}
		public void setWeight(double weight) {
			this.weight = weight;
		}
		public ArrayList<NodeDto> getChildren() {
			return children;
		}
		public void setChildren(ArrayList<NodeDto> children) {
			this.children = children;
		}
	}
	
	public class PointDto {
		private double x;
		private double y;
		
		public PointDto() {
			
		}
		
		public PointDto(double x, double y){
			this.x = x;
			this.y = y;
		}
		
		public double getX() {
			return x;
		}
		public void setX(double x) {
			this.x = x;
		}
		public double getY() {
			return y;
		}
		public void setY(double y) {
			this.y = y;
		}
		
	}

}
