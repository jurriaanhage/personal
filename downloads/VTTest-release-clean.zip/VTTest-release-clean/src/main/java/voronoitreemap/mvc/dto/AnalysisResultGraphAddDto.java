package voronoitreemap.mvc.dto;

import java.io.StringWriter;

import javax.servlet.annotation.MultipartConfig;

import org.apache.commons.io.IOUtils;
import org.gephi.io.importer.api.Container;
import org.gephi.io.importer.api.EdgeDefault;
import org.gephi.io.importer.api.ImportController;
import org.gephi.io.importer.plugin.file.ImporterBuilderGEXF;
import org.gephi.project.api.Workspace;
import org.openide.util.Lookup;
import org.springframework.web.multipart.MultipartFile;
@MultipartConfig(maxFileSize = 52428800, maxRequestSize=52428800)
public class AnalysisResultGraphAddDto {
	

	private MultipartFile gefxFile;
	
	private String description;

	public MultipartFile getGefxFile() {
		return gefxFile;
	}

	public void setGefxFile(MultipartFile gefxFile) {
		this.gefxFile = gefxFile;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String GetGefxString() {
		// Init a project - and therefore a workspace
				org.gephi.project.api.ProjectController pc = Lookup.getDefault()
						.lookup(org.gephi.project.api.ProjectController.class);
				pc.newProject();
				ImportController importController = Lookup.getDefault().lookup(
						ImportController.class);

				// Import file
				Container container;
				String theString = null;
				try {
					container = importController.importFile(gefxFile.getInputStream(),
							new ImporterBuilderGEXF().buildImporter());
					container.getLoader().setEdgeDefault(EdgeDefault.DIRECTED); // Force
																				// DIRECTED
					StringWriter writer = new StringWriter();
					IOUtils.copy(gefxFile.getInputStream(), writer, "UTF-8");
					theString = writer.toString();
				} catch (Exception ex) {
					ex.printStackTrace();
					return theString;
				}

				return theString;
	}

}
