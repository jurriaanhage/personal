package voronoitreemap.mvc;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.annotation.MultipartConfig;
import javax.validation.Valid;

import org.apache.commons.io.IOUtils;
import org.gephi.data.attributes.api.AttributeController;
import org.gephi.data.attributes.api.AttributeModel;
import org.gephi.graph.api.GraphController;
import org.gephi.graph.api.GraphModel;
import org.gephi.graph.api.HierarchicalDirectedGraph;
import org.gephi.io.importer.api.Container;
import org.gephi.io.importer.api.EdgeDefault;
import org.gephi.io.importer.api.ImportController;
import org.gephi.io.importer.plugin.file.ImporterBuilderGEXF;
import org.gephi.io.processor.plugin.DefaultProcessor;
import org.gephi.project.api.Workspace;
import org.openide.util.Lookup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import voronoitreemap.domain.AnalysisResultGraph;
import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.mvc.dto.AnalysisResultGraphAddDto;
import voronoitreemap.mvc.dto.AnalysisResultGraphViewDto;
import voronoitreemap.mvc.dto.ReleaseDto;
import voronoitreemap.service.AnalysisResultGraphService;
import voronoitreemap.service.ReleaseService;

@Controller
@RequestMapping("/analysisResultGraph")
@MultipartConfig(maxFileSize = 52428800, maxRequestSize=52428800)
public class AnalysisResultGraphController {

	private final ReleaseService releaseService;
	private final AnalysisResultGraphService analysisResultGraphService;

	@Autowired
	public AnalysisResultGraphController(
			AnalysisResultGraphService analysisResultGraphService,
			ReleaseService releaseService) {
		this.analysisResultGraphService = analysisResultGraphService;
		this.releaseService = releaseService;
	}
	
	@RequestMapping(value = "/xml", produces="text/plain")
	@ResponseBody
	public String xml(@RequestParam String id) {
		AnalysisResultGraph analysisResultGraph = analysisResultGraphService
				.getAnalysisResultGraph(Long.valueOf(id));
		
		return analysisResultGraph.getGefxString();
	}

	@RequestMapping(value = "/view")
	public ModelAndView view(@RequestParam String id) throws UnsupportedEncodingException {

		AnalysisResultGraph analysisResultGraph = analysisResultGraphService
				.getAnalysisResultGraph(Long.valueOf(id));

		AnalysisResultGraphViewDto visDto = new AnalysisResultGraphViewDto(analysisResultGraph
				.getGefxString());
		
		ModelAndView mav = new ModelAndView("/analysisResultGraph/view",
				"analysisResultGraph", analysisResultGraph);
		
		mav.addObject("visDto", visDto);

		return mav;
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView add(@RequestParam String releaseId,
			@ModelAttribute AnalysisResultGraphAddDto analysisResultGraphDto) {
		Release release = releaseService.getRelease(Long.valueOf(releaseId));
		return new ModelAndView("/analysisResultGraph/add", "release", release);
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	
	public ModelAndView add(@RequestParam String releaseId,
			@Valid AnalysisResultGraphAddDto analysisResultGraphDto,
			BindingResult result, RedirectAttributes redirect) {

		Release release = releaseService.getRelease(Long.valueOf(releaseId));
		if (result.hasErrors()) {
			ModelAndView errorMav = new ModelAndView(
					"/analysisResultGraph/add", "formErrors",
					result.getAllErrors());
			errorMav.addObject("release", release);
			return errorMav;
		}

		String gefxString = analysisResultGraphDto.GetGefxString();

		AnalysisResultGraph arg = new AnalysisResultGraph(release, gefxString,
				analysisResultGraphDto.getGefxFile().getOriginalFilename(),
				analysisResultGraphDto.getDescription());

		analysisResultGraphService.save(arg);

		return new ModelAndView("redirect:/project/"
				+ release.getProject().getId());
	}



}
