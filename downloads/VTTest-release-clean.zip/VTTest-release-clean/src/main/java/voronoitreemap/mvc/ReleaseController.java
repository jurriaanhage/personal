package voronoitreemap.mvc;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.mvc.dto.ProjectDto;
import voronoitreemap.mvc.dto.ReleaseDto;
import voronoitreemap.service.ProjectService;
import voronoitreemap.service.ReleaseService;
import voronoitreemap.service.dto.ReleaseSummaryDto;


@Controller
@RequestMapping("/release")
public class ReleaseController {
	
	private final ReleaseService releaseService;
	private final ProjectService projectService;
	
	@Autowired
	public ReleaseController(ReleaseService releaseService,
			ProjectService projectService) {
		this.releaseService = releaseService;
		this.projectService = projectService;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView add(@RequestParam String projectId,@ModelAttribute ReleaseDto releaseDto) {
		Project project = projectService.getProject(Long.valueOf(projectId));
		return new ModelAndView("/release/add", "project", project);
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView add(@RequestParam String projectId, @Valid ReleaseDto releaseDto, BindingResult result,
			RedirectAttributes redirect) {
		if (result.hasErrors()) {
			return new ModelAndView("/release/add", "formErrors", result.getAllErrors());
		}
		
		Project project = projectService.getProject(Long.valueOf(projectId));
		Release release = new Release(releaseDto.getMajorVersion(), 
				releaseDto.getMinorVersion(), 
				releaseDto.getBuildNumber(), 
				releaseDto.getDescription(), 
				project);
		
		releaseService.save(release);
		
		return new ModelAndView("redirect:/project/"+projectId);
	}

}
