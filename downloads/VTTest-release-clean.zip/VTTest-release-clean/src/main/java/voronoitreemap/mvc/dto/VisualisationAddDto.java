package voronoitreemap.mvc.dto;

public class VisualisationAddDto {
	
	private String sortAttribute;
	private String sizeAttribute;
	private String description;
	
	public String getSortAttribute() {
		return sortAttribute;
	}
	
	public void setSortAttribute(String sortAttribute) {
		this.sortAttribute = sortAttribute;
	}
	
	public String getSizeAttribute() {
		return sizeAttribute;
	}
	
	public void setSizeAttribute(String sizeAttribute) {
		this.sizeAttribute = sizeAttribute;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
