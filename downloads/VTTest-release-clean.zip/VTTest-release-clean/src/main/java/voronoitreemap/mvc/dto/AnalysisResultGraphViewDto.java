package voronoitreemap.mvc.dto;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;

import org.gephi.data.attributes.api.AttributeColumn;
import org.gephi.data.attributes.api.AttributeController;
import org.gephi.data.attributes.api.AttributeModel;
import org.gephi.graph.api.Attributes;
import org.gephi.graph.api.GraphController;
import org.gephi.graph.api.GraphModel;
import org.gephi.graph.api.HierarchicalDirectedGraph;
import org.gephi.graph.api.Node;
import org.gephi.graph.api.NodeIterable;
import org.gephi.io.importer.api.Container;
import org.gephi.io.importer.api.EdgeDefault;
import org.gephi.io.importer.api.ImportController;
import org.gephi.io.importer.plugin.file.ImporterBuilderGEXF;
import org.gephi.io.processor.plugin.DefaultProcessor;
import org.gephi.project.api.Workspace;
import org.openide.util.Lookup;

public class AnalysisResultGraphViewDto {

	private NodeDto rootNode;
	private ArrayList<AttributeDto> nodeAttributes = new ArrayList<AttributeDto>();

	public AnalysisResultGraphViewDto(HierarchicalDirectedGraph graph,
			AttributeModel model) {

		NodeIterable ni = graph.getTopNodes();
		Node root = ni.toArray()[0];

		rootNode = new NodeDto(graph, root);

		for (AttributeColumn col : model.getNodeTable().getColumns()) {
			nodeAttributes.add(new AttributeDto(col.getTitle(), col.getType()
					.getTypeString()));
		}

	}

	public AnalysisResultGraphViewDto(String gefxString)
			throws UnsupportedEncodingException {
		// Init a project - and therefore a workspace
		org.gephi.project.api.ProjectController pc = Lookup.getDefault()
				.lookup(org.gephi.project.api.ProjectController.class);
		pc.newProject();
		Workspace workspace = pc.getCurrentWorkspace();

		ImportController importController = Lookup.getDefault().lookup(
				ImportController.class);
		GraphModel graphModel = Lookup.getDefault()
				.lookup(GraphController.class).getModel();

		// Import file
		Container container;
		container = importController.importFile(new ByteArrayInputStream(
				gefxString.getBytes("UTF-8")), new ImporterBuilderGEXF()
				.buildImporter());
		container.getLoader().setEdgeDefault(EdgeDefault.DIRECTED); // Force
																	// DIRECTED

		// Append imported data to GraphAPI
		importController.process(container, new DefaultProcessor(), workspace);

		// See if graph is well imported
		HierarchicalDirectedGraph graph = graphModel
				.getHierarchicalDirectedGraph();

		// List node columns
		AttributeController ac = Lookup.getDefault().lookup(
				AttributeController.class);
		AttributeModel model = ac.getModel();

		NodeIterable ni = graph.getTopNodes();
		Node root = ni.toArray()[0];

		rootNode = new NodeDto(graph, root);

		for (AttributeColumn col : model.getNodeTable().getColumns()) {
			nodeAttributes.add(new AttributeDto(col.getTitle(), col.getType()
					.getTypeString()));
		}
	}

	public NodeDto getRootNode() {
		return rootNode;
	}

	public void setRootNode(NodeDto rootNode) {
		this.rootNode = rootNode;
	}

	public Collection<AttributeDto> getNodeAttributes() {
		return nodeAttributes;
	}

	public void setAttributes(Collection<AttributeDto> attributes) {
		nodeAttributes.clear();
		nodeAttributes.addAll(attributes);
	}

	public class NodeDto {

		private ArrayList<NodeDto> children = new ArrayList<NodeDto>();
		private String name;
		private String id;

		public NodeDto(HierarchicalDirectedGraph graph, Node node) {
			NodeIterable children = graph.getChildren(node);
			Attributes a = node.getAttributes();
			this.id = a.getValue("Id").toString();
			this.name = a.getValue("Label").toString();

			for (Node child : children) {
				this.children.add(new NodeDto(graph, child));
			}
		}

		public Collection<NodeDto> getChildren() {
			return children;
		}

		public void setChildren(Collection<NodeDto> children) {
			children.clear();
			children.addAll(children);
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

	}

	public class AttributeDto {
		private String name;
		private String type;

		public AttributeDto(String name, String type) {
			this.name = name;
			this.type = type;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

	}

}
