package voronoitreemap.mvc.dto;

import voronoitreemap.domain.Visualisation;

public class VisualisationViewDto {
	
	public Long id;
	public Long analysisResultGraphId;
	public String description;
	public String sizeAttribute;
	public String sortAttribute;
	
	public VisualisationViewDto(Visualisation visualisation){
		this.id = visualisation.getId();
		this.analysisResultGraphId = visualisation.getOriginGraph().getId();
		this.description = visualisation.getDescription();
		this.sizeAttribute = visualisation.getSizeAttribute();
		this.sortAttribute = visualisation.getSortAttribute();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getAnalysisResultGraphId() {
		return analysisResultGraphId;
	}

	public void setAnalysisResultGraphId(Long analysisResultGraphId) {
		this.analysisResultGraphId = analysisResultGraphId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSizeAttribute() {
		return sizeAttribute;
	}

	public void setSizeAttribute(String sizeAttribute) {
		this.sizeAttribute = sizeAttribute;
	}

	public String getSortAttribute() {
		return sortAttribute;
	}

	public void setSortAttribute(String sortAttribute) {
		this.sortAttribute = sortAttribute;
	}

}
