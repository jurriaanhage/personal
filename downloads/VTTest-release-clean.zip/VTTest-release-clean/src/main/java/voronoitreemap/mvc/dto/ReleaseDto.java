package voronoitreemap.mvc.dto;

public class ReleaseDto {
	
	private Long majorVersion;
	

	private Long minorVersion;
	

	private Long buildNumber;
	

	private String description;


	public Long getMajorVersion() {
		return majorVersion;
	}


	public void setMajorVersion(Long majorVersion) {
		this.majorVersion = majorVersion;
	}


	public Long getMinorVersion() {
		return minorVersion;
	}


	public void setMinorVersion(Long minorVersion) {
		this.minorVersion = minorVersion;
	}


	public Long getBuildNumber() {
		return buildNumber;
	}


	public void setBuildNumber(Long buildNumber) {
		this.buildNumber = buildNumber;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
