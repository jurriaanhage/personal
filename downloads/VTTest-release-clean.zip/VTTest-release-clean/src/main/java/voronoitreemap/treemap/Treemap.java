package voronoitreemap.treemap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

import voronoi.AWPTreeMapVoronoi;
import voronoi.ConvexPolygon;
import voronoi.HilbertCurve;
import voronoi.Point;
import voronoi.TreeSite;

public class Treemap {

	private static double totalFactor = 100000;

	public static <T> TreeSite<T> Create(ConvexPolygon area, T rootNode,
			Function<T, List<T>> getChildrenFunction,
			Function<T, Double> getNodeAreaFraction, Comparator<T> sortNode) {

		Point rootLocation = area.getCenterOfWeight();
		TreeSite<T> rootTreemapSite = new TreeSite<T>(rootNode,
				rootLocation.getX(), rootLocation.getY(), 1.0, 1.0);
		rootTreemapSite.setBoundingPolygon(area);

		List<TreeSite<T>> children = ChildrenCreate(area, rootNode,
				getChildrenFunction, getNodeAreaFraction, sortNode, true);
		rootTreemapSite.addChildren(children);

		return rootTreemapSite;
	}

	private static <T> List<TreeSite<T>> ChildrenCreate(ConvexPolygon area,
			T node, Function<T, List<T>> getChildrenFunction,
			Function<T, Double> getNodeAreaFraction, Comparator<T> sortNode,
			boolean doChildren) {

		ArrayList<TreeSite<T>> children = new ArrayList<TreeSite<T>>();
		List<T> childNodes = getChildrenFunction.apply(node);
		Collections.sort(childNodes, sortNode);

		if (area.getPoints().size() < 3) {
			return children;
		}

		ConvexPolygon translatedArea = resizeAndTranslatePolygon(area);

		HilbertCurve hilbertCurve = new HilbertCurve(translatedArea,
				childNodes.size());

		for (T childNode : childNodes) {
			double areaFraction = getNodeAreaFraction.apply(childNode);

			if (areaFraction < 0.001) {
				continue;
			}
			double weight = getWeight(translatedArea, areaFraction);
			Point p = hilbertCurve.getForPointSite(areaFraction);
			children.add(new TreeSite<T>(childNode, p.getX(), p.getY(), weight,
					areaFraction));
		}

		for (TreeSite<T> s : children) {
			System.out.println("sites.add(new TreeSite(\"\", " + s.getX()
					+ ", " + s.getY() + ", " + s.getWeight()
					+ ", Double.parseDouble(\"" + s.getDesiredAreaFraction()
					+ "\")));");
		}
		if (children.size() > 0) {
			ArrayList<TreeSite<T>> dummies = new ArrayList<TreeSite<T>>();
			dummies = getDummySites(translatedArea);
			children.addAll(dummies);
			AWPTreeMapVoronoi.create(children, translatedArea, 0.02, 200);
			children.removeAll(dummies);
		}

		translateAndResizePointsToOriginal(children, area);
		/*
		 * for(TreeSite<T> s : children){
		 * System.out.println("sites.add(new TreeSite(\"\", "
		 * +s.getX()*0.5+", "+s
		 * .getY()*0.5+", "+s.getWeight()*0.5+", Double.parseDouble(\""+
		 * s.getDesiredAreaFraction()+"\")));"); }
		 */
		if (!doChildren) {
			return children;
		}

		boolean printSites = false;// true;
		for (TreeSite<T> child : children) {
			if (child.getBoundingPolygon().getPoints().size() < 3) {
				printSites = true;
			}
			child.addChildren(ChildrenCreate(child.getBoundingPolygon(),
					child.getData(), getChildrenFunction, getNodeAreaFraction,
					sortNode, true));
		}

		if (printSites) {
			for (TreeSite<T> s : children) {
				System.out.println("sites.add(new TreeSite(\"\", " + s.getX()
						+ ", " + s.getY() + ", " + s.getWeight()
						+ ", Double.parseDouble(\""
						+ s.getDesiredAreaFraction() + "\")));");
			}
		}

		return children;
	}

	private static <T> ArrayList<TreeSite<T>> getDummySites(
			ConvexPolygon translatedArea) {
		double minX = Double.MAX_VALUE;
		double minY = Double.MAX_VALUE;
		double maxX = Double.MIN_VALUE;
		double maxY = Double.MIN_VALUE;
		double width;
		double height;

		for (Point p : translatedArea.getPoints()) {
			double x = p.getX();
			double y = p.getY();
			if (x < minX) {
				minX = x;
			}
			if (y < minY) {
				minY = y;
			}
			if (x > maxX) {
				maxX = x;
			}
			if (y > maxY) {
				maxY = y;
			}
		}

		width = maxX - minX;
		height = maxY - minY;

		ArrayList<TreeSite<T>> result = new ArrayList<TreeSite<T>>();
		TreeSite<T> s1 = new TreeSite<T>(null, minX - 2 - width, minY - 1
				- height, 0, 0);
		s1.setDummy(true);
		TreeSite<T> s2 = new TreeSite<T>(null, maxX + 1 + width, minY - 2
				- height, 0, 0);
		s2.setDummy(true);
		TreeSite<T> s3 = new TreeSite<T>(null, maxX + 2 + width, maxY + 1
				+ height, 0, 0);
		s3.setDummy(true);
		TreeSite<T> s4 = new TreeSite<T>(null, minX - 1 - width, maxY + 2
				+ height, 0, 0);
		s4.setDummy(true);
		result.add(s1);
		result.add(s2);
		result.add(s3);
		result.add(s4);
		return result;
	}

	private static ConvexPolygon resizeAndTranslatePolygon(
			ConvexPolygon original) {
		ArrayList<Point> points = new ArrayList<Point>();

		double minX = Double.MAX_VALUE;
		double minY = Double.MAX_VALUE;
		double maxX = Double.MIN_VALUE;
		double maxY = Double.MIN_VALUE;

		for (Point p : original.getPoints()) {
			double x = p.getX();
			double y = p.getY();
			if (x < minX) {
				minX = x;
			}
			if (x > maxX) {
				maxX = x;
			}
			if (y < minY) {
				minY = y;
			}
			if (y > maxY) {
				maxY = y;
			}
		}

		double factor = 1;
		if (maxY - minY > maxX - minX) {
			factor = totalFactor / (maxY - minY);
		} else {
			factor = totalFactor / (maxX - minX);
		}

		for (Point o : original.getPoints()) {
			Point p = new Point(((o.getX() - minX) * factor),
					((o.getY() - minY) * factor));
			points.add(p);
		}

		return new ConvexPolygon(points);
	}

	private static <T> void translateAndResizePointsToOriginal(
			List<TreeSite<T>> sites, ConvexPolygon original) {
		double minX = Double.MAX_VALUE;
		double minY = Double.MAX_VALUE;
		double maxX = Double.MIN_VALUE;
		double maxY = Double.MIN_VALUE;

		for (Point p : original.getPoints()) {
			double x = p.getX();
			double y = p.getY();
			if (x < minX) {
				minX = x;
			}
			if (x > maxX) {
				maxX = x;
			}
			if (y < minY) {
				minY = y;
			}
			if (y > maxY) {
				maxY = y;
			}
		}

		double factor = 1;
		if (maxY - minY > maxX - minX) {
			factor = (maxY - minY) / totalFactor;
		} else {
			factor = (maxX - minX) / totalFactor;
		}

		for (TreeSite<T> s : sites) {
			translateAndResizePointsToOriginal(s, minX, minY, factor);
		}
	}

	private static <T> void translateAndResizePointsToOriginal(
			TreeSite<T> site, double minX, double minY, double factor) {
		site.setX(site.getX() * factor + minX);
		site.setY(site.getY() * factor + minY);
		site.setWeight(site.getWeight() * factor);

		for (Point p : site.getBoundingPolygon().getPoints()) {
			p.setX((p.getX()) * factor + minX);
			p.setY((p.getY()) * factor + minY);
		}
	}

	private static double getWeight(ConvexPolygon area, double areaFraction) {
		return Math.sqrt(area.getSize()) * areaFraction;
	}

}
