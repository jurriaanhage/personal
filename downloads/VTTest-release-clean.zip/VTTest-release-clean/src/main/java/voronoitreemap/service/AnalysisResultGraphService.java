package voronoitreemap.service;

import voronoitreemap.domain.AnalysisResultGraph;

public interface AnalysisResultGraphService {
	
	AnalysisResultGraph getAnalysisResultGraph(Long id);
	
	AnalysisResultGraph save(AnalysisResultGraph analysisResultGraph);

}
