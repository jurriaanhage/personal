package voronoitreemap.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import voronoitreemap.domain.Project;

public interface ProjectService {
	
	Page<Project> findProjects(ProjectSearchCriteria criteria, Pageable pageable);
	
	Iterable<Project> allProjects();
	
	Project getProject(Long id);
	
	Project save(Project project);

}
