package voronoitreemap.service;

import org.springframework.data.repository.CrudRepository;

import voronoitreemap.domain.Visualisation;


public interface VisualisationRepository extends CrudRepository<Visualisation, Long> {

}
