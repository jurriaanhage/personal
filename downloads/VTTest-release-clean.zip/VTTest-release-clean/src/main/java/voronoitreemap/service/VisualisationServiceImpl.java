package voronoitreemap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import voronoitreemap.domain.Visualisation;

@Component("visualisationService")
@Transactional
public class VisualisationServiceImpl implements VisualisationService{
	
	private final VisualisationRepository visualisationRepository;
	
	@Autowired
	public VisualisationServiceImpl(VisualisationRepository visualisationRepository) {
		this.visualisationRepository = visualisationRepository;
	}

	@Override
	public Visualisation getVisualisation(Long id) {
		return visualisationRepository.findOne(id);
	}

	@Override
	public Visualisation save(Visualisation visualisation) {
		return visualisationRepository.save(visualisation);
	}

}
