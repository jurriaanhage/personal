package voronoitreemap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import voronoitreemap.domain.AnalysisResultGraph;

@Component("analysisResultGraphService")
@Transactional
public class AnalysisResultGraphServiceImpl implements
		AnalysisResultGraphService {
	
	private final AnalysisResultGraphRepository analysisResultGraphRepository;
	
	@Autowired
	public AnalysisResultGraphServiceImpl(AnalysisResultGraphRepository analysisResultGraphRepository){
		this.analysisResultGraphRepository = analysisResultGraphRepository;
	}

	@Override
	public AnalysisResultGraph getAnalysisResultGraph(Long id) {
		return analysisResultGraphRepository.findOne(id);
	}

	@Override
	public AnalysisResultGraph save(AnalysisResultGraph analysisResultGraph) {
		return analysisResultGraphRepository.save(analysisResultGraph);
	}

}
