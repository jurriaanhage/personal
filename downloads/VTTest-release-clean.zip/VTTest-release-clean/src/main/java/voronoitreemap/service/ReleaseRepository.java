package voronoitreemap.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.service.dto.ReleaseSummaryDto;

public interface ReleaseRepository extends CrudRepository<Release, Long> {
	
	Page<Release> findAll(Pageable pageable);
	
	Iterable<Release> findByProject(Project project);
	
	Page<Release> findByProject(Project project, Pageable pageable);
	
	/*@Query("select new voronoitreemap.service.dto.ReleaseSummaryDto(r.majorVersion, r.minorVersion, r.buildNumber, r.description, a) "
			+ "from Release r left outer join r.analysisResultGraphs a where r.project = ?1 group by r")
	Iterable<ReleaseSummaryDto> findSummariesByProject(Project project);*/


}
