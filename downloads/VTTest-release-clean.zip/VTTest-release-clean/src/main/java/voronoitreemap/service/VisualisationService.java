package voronoitreemap.service;

import voronoitreemap.domain.Visualisation;

public interface VisualisationService {
	
	Visualisation getVisualisation(Long id);
	
	Visualisation save(Visualisation visualisation);

}
