package voronoitreemap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.service.dto.ReleaseSummaryDto;

@Component("releaseService")
@Transactional
public class ReleaseServiceImpl implements ReleaseService{
	
	public final ReleaseRepository releaseRepository;
	
	@Autowired
	public ReleaseServiceImpl(ReleaseRepository releaseRepository){
		this.releaseRepository = releaseRepository;
	}

	@Override
	public Iterable<Release> allReleases() {
		return releaseRepository.findAll();
	}

	@Override
	public Iterable<Release> allReleasesByProject(Project project) {
		return releaseRepository.findByProject(project);
	}

	@Override
	public Release getRelease(Long id) {
		return releaseRepository.findOne(id);
	}

	@Override
	public Release save(Release release) {
		return releaseRepository.save(release);
	}


}
