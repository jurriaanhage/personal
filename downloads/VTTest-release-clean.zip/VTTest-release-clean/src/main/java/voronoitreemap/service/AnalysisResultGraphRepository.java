package voronoitreemap.service;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import voronoitreemap.domain.AnalysisResultGraph;

public interface AnalysisResultGraphRepository extends CrudRepository<AnalysisResultGraph, Long> {
}
