package voronoitreemap.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import voronoitreemap.domain.Project;

public interface ProjectRepository extends CrudRepository<Project, Long> {

	
	Page<Project> findAll(Pageable pageable);
	
	Page<Project> findByNameContainingAllIgnoringCase(String name, Pageable pageable);
}
