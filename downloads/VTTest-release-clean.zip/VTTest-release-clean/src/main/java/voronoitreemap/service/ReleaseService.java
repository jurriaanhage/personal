package voronoitreemap.service;

import org.springframework.data.repository.Repository;

import voronoitreemap.domain.Project;
import voronoitreemap.domain.Release;
import voronoitreemap.service.dto.ReleaseSummaryDto;

public interface ReleaseService{
	
	Iterable<Release> allReleases();
	
	Iterable<Release> allReleasesByProject(Project project);
	
	Release getRelease(Long id);
	
	Release save(Release release);


}
