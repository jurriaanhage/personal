package voronoitreemap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import voronoitreemap.domain.Project;

@Component("projectService")
@Transactional
public class ProjectServiceImpl implements ProjectService {
	
	private final ProjectRepository projectRepository;
	
	@Autowired
	public ProjectServiceImpl(ProjectRepository projectRepository) {
		this.projectRepository = projectRepository;
	}

	@Override
	public Project getProject(Long id) {
		return projectRepository.findOne(id);
	}

	@Override
	public Page<Project> findProjects(ProjectSearchCriteria criteria,
			Pageable pageable) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Project> allProjects() {
		return projectRepository.findAll();
	}

	@Override
	public Project save(Project project) {
		return projectRepository.save(project);
	}

}
