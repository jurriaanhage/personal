package voronoitreemap.service.dto;



public class ReleaseSummaryDto {
	
	private Long majorVersion;
	
	private Long minorVersion;
	
	private Long buildNumber;
	
	private String description;
	
	private Object blaat;
	
	public ReleaseSummaryDto(Long majorVersion, Long minorVersion, Long buildNumber, String description, Object blaat) {
		this.majorVersion = majorVersion;
		this.minorVersion = minorVersion;
		this.buildNumber = buildNumber;
		this.description = description;
		this.blaat = blaat;
	}

	public Long getMajorVersion() {
		return majorVersion;
	}

	public void setMajorVersion(Long majorVersion) {
		this.majorVersion = majorVersion;
	}

	public Long getMinorVersion() {
		return minorVersion;
	}

	public void setMinorVersion(Long minorVersion) {
		this.minorVersion = minorVersion;
	}

	public Long getBuildNumber() {
		return buildNumber;
	}

	public void setBuildNumber(Long buildNumber) {
		this.buildNumber = buildNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Object getBlaat() {
		return blaat;
	}

	public void setBlaat(Object blaat) {
		this.blaat = blaat;
	}

}
