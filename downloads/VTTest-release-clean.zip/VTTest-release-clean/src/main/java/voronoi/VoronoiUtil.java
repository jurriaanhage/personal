/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import static java.lang.Math.hypot;

/**
 *
 * @author rinseh
 */
public class VoronoiUtil {

//    public static Point getMidPointSites(Site s1, Site s2) {
////        if(s1.getX() < s2.getX()){
////            Site temp = s1;
////            s2 = s1;
////            s1 = temp;
////        }
//
//        double s1x = s1.getX();
//        double s1y = s1.getY();
//        double s1w = s1.getWeight();
//
//        double s2x = s2.getX();
//        double s2y = s2.getY();
//        double s2w = s2.getWeight();
//
//        double s1s2x = s2x - s1x;
//        double s1s2y = s2y - s1y;
//
//        if (s1y == s2y) {
//            double distance = Math.sqrt(s1s2x * s1s2x) - (Math.sqrt(s1w) + Math.sqrt(s2w));
//            return new Point(s1x + Math.sqrt(s1w) + (distance / 2), s1y);
//        }
//        if (s1x == s2x) {
//            double distance = Math.sqrt(s1s2x * s1s2x) - (Math.sqrt(s1w) + Math.sqrt(s2w));
//            return new Point(s1x, s1y + Math.sqrt(s1w) + (distance / 2));
//        }
//
//        double dist = Math.sqrt((s1s2x * s1s2x) + (s1s2y * s1s2y));
//        double weightedDist = dist - (Math.sqrt(s1w) + Math.sqrt(s2w));
//        double factor = (Math.sqrt(s1w) + (weightedDist / 2)) / dist;
//
//        return new Point(s1x + (s1s2x * factor), s1y + (s1s2y * factor));
//    }
    
        public static Point getMidPointSites(Site s1, Site s2) {
//        if(s1.getX() < s2.getX()){
//            Site temp = s1;
//            s2 = s1;
//            s1 = temp;
//        }
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double s2x = s2.getX();
        double s2y = s2.getY();
        double s2w = s2.getWeight();

        double s1s2x = s2x - s1x;
        double s1s2y = s2y - s1y;

//        if (s1y == s2y) {
//            double distance = Math.sqrt(s1s2x * s1s2x) - (s1w + s2w);
//            return new Point(s1x + s1w + (distance / 2), s1y);
//        }
//        if (s1x == s2x) {
//            double distance = Math.sqrt(s1s2x * s1s2x) - (s1w + s2w);
//            return new Point(s1x, s1y + s1w + (distance / 2));
//        }

        double dist = (s1s2x * s1s2x) + (s1s2y * s1s2y);
        double weightedDist = dist - (s1w + s2w);
        double factor = (s1w + (weightedDist / 2)) / dist;

        return new Point(s1x + (s1s2x * factor), s1y + (s1s2y * factor));
    }
        
        public static Point getMidPointSitesHACK(Site s1, Site s2) {
          double s1x = s1.getX();
          double s1y = s1.getY();
          double s1w = s1.getWeight();

          double s2x = s2.getX();
          double s2y = s2.getY();
          double s2w = s2.getWeight();

          double s1s2x = s2x - s1x;
          double s1s2y = s2y - s1y;

          double dist = (s1s2x * s1s2x) + (s1s2y * s1s2y);
          double weightedDist = dist - (s1w + s2w);
          double factor = (s1w + (weightedDist / 2)) / dist;
          
          if(factor >= 1.0) {
        	  factor = 0.99;
          } else if (factor <= 0.0) {
        	  factor = 0.01;
          }

          return new Point(s1x + (s1s2x * factor), s1y + (s1s2y * factor));
      }

    public static Point getIntersection(HalfEdge edge, Point p1, Point p2) {
        Point p = null;

//        if (edge.getStart() != null && edge.getEnd() != null) {
//            p = getIntersection(edge.getStart(), edge.getEnd(), p1, p2);
//        } else {
        Site s1 = edge.getSite();
        Site s2 = edge.getEdge().getLeft() == s1 ? edge.getEdge().getRight() : edge.getEdge().getLeft();
        p = getInterseciont(s1, s2, edge.getStart(), edge.getEnd(), p1, p2);
//        }

        return p;
    }

//    public static Point getInterseciont(Site s1, Site s2, Point start, Point end, Point p1, Point p2) {
//        Point p = getInterseciont(s1, s2, p1, p2, true);
//
//        if (p == null) {
//            return p;
//        }
//
//        if (start != null && end != null) {
//            if (doLineSegmentsIntersect(start, end, p1, p2)) {
//                return p;
//            } else {
//                return null;
//            }
//
//        } else if (start != null) {
//            if (ccw(start, s1, p) >= 0) {
//                p = null;
//            }
//        } else if (end != null) {
//            if (ccw(p, s1, end) >= 0) {
//                p = null;
//            }
//        }
//
//        return p;
//    }
    //http://stackoverflow.com/questions/4543506/algorithm-for-intersection-of-2-lines
//    public static Point getIntersection(Point p1, Point p2, Point p3, Point p4) {
//    //FIALS
//        if (doLineSegmentsIntersect(p1, p2, p3, p4)) {
//            double a1 = p2.getY() - p1.getY();
//            double b1 = p2.getX() - p1.getX();
//            double c1 = a1 * p1.getX() + b1 * p1.getY();
//
//            double a2 = p4.getY() - p3.getY();
//            double b2 = p4.getX() - p3.getX();
//            double c2 = a2 * p3.getX() + b2 * p3.getY();
//
//            double det = a1 * b2 - a2 * b1;
//            if (Math.abs(det) <= 0.0001) {
//                return null;
//            }
//
//            double x = (b2 * c1 - b1 * c2) / det;
//            double y = (a1 * c2 - a2 * c1) / det;
//
//            return new Point(Math.abs(x), Math.abs(y));
//        }
//
//        return null;
//    }
    //http://bryceboe.com/2006/10/23/line-segment-intersection-algorithm/
    //http://stackoverflow.com/questions/563198/how-do-you-detect-where-two-line-segments-intersect
    //http://www.geeksforgeeks.org/check-if-two-given-line-segments-intersect/
    public static boolean doLineSegmentsIntersect(Point p1, Point p2, Point p3, Point p4) {

        return ccw(p1, p3, p4) != ccw(p2, p3, p4) && ccw(p1, p2, p3) != ccw(p1, p2, p4);

//        double a1 = p2.getY() - p1.getY();
//        double b1 = p2.getX() - p1.getX();
//
//        double a2 = p4.getY() - p3.getY();
//        double b2 = p4.getX() - p3.getX();
//        
//        double a3 = p3.getY() - p1.getY();
//        double b3 = p3.getX() - p1.getX();
//
//        double det = a1 * b2 - a2 * b1;
//
//	if (det == 0.0 || det == -0.0) {
//		// lines are paralell
//		return false;
//	}
//
//        double uNum = a3 * b1 - a1 * b3;
//	double u = uNum / det;
//	double t = a3 * b2 - a2 * b3 / det;
//
//	return (t >= -0.0001) && (t <= 1.0001) && (u >= -0.0001) && (u <= 1.0001);
    }

    public static Point getInterseciont(Site s1, Site s2, Point end, Point start, Point p1, Point p2) { 
        //Get negative reciprocal        
        double a1 = (s2.getX() - s1.getX());
        double b1 = (s2.getY() - s1.getY());
        Point ps = VoronoiUtil.getMidPointSites(s1, s2);
        double c1 = a1 * ps.getX() + b1 * ps.getY();

        double a2 = -(p2.getY() - p1.getY());
        double b2 = p2.getX() - p1.getX();
        double c2 = a2 * p1.getX() + b2 * p1.getY();      
        
        
        double bla1 = a1 * b2;
        double bla2 = a2 * b1;

        double det = bla1 - bla2;
        if (Math.abs(det) <= 0.000001) {
            return null;
        }
        
//        double t = ((ps.getY() - p1.getY()) * b2 - 
//				(ps.getX() - p1.getX()) * a2) / det;
//        Point hmm = new Point(p1.getX() + t * b1, p1.getY() + t * a1);

        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;

        Point p = new Point(x, y);
        
        //{{qx - px, qy - py}, {rx - px, ry - py}},
        double detP = (p1.getX() - p2.getX()) * (p.getY() - p2.getY()) - (p1.getY() - p2.getY()) * (p.getX() - p2.getX()); 

        if (distanceLineSegment(p1, p2, p) > 0.000001) {
            return null;
        }

        if (start != null && end != null) {
            if (!doLineSegmentsIntersect(start, end, p1, p2)) {
                return null;
            }

        } else if (start != null) {
            if (ccw(start, s1, p) <= 0) {
                return null;
            }
        } else if (end != null) {
            if (ccw(p, s1, end) <= 0) {
                return null;
            }
        }

        return p;
    }
    public static double getPowerDistance(Site s1, Site s2, Point p) { 
        //Get negative reciprocal        
        double a1 = (s2.getX() - s1.getX());
        double b1 = (s2.getY() - s1.getY());
        Point ps = VoronoiUtil.getMidPointSites(s1, s2);
        double c1 = a1 * ps.getX() + b1 * ps.getY();

        double a2 = -(s2.getY() - s1.getY());
        double b2 = s2.getX() - s1.getX();
        double c2 = a2 * p.getX() + b2 * p.getY();      
        
        
        double bla1 = a1 * b2;
        double bla2 = a2 * b1;

        double det = bla1 - bla2;
        if (Math.abs(det) <= 0.0001) {
            return Double.NaN;
        }
        
        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;

        Point intersect = new Point(x, y);


        return powerWeightedDistance(p, intersect);
    }

    public static double distanceLineSegment(Point start, Point end, Point p) {
        double length = distance(start, end);

        if (length == 0.0) {
            return distance(start, p);
        }

        if (end.getY() == start.getY()) {

        }

        double dist = crossProduct(start, end, p) / length;

        double dot1 = dotProduct(start, end, p);
        if (dot1 > 0) {
            return distance(end, p);
        }

        double dot2 = dotProduct(end, start, p);
        if (dot2 > 0) {
            return distance(start, p);
        }

        return Math.abs(dist);
    }

    //http://www.topcoder.com/tc?d1=tutorials&d2=geometry1&module=Static
    private static double dotProduct(Point p1, Point p2, Point p3) {
        double abx = p2.getX() - p1.getX();
        double aby = p2.getY() - p1.getY();
        double bcx = p3.getX() - p2.getX();
        double bcy = p3.getY() - p2.getY();

        return (abx * bcx) + (aby * bcy);
    }

    //http://www.topcoder.com/tc?d1=tutorials&d2=geometry1&module=Static
    private static double crossProduct(Point p1, Point p2, Point p3) {

        double abx = p2.getX() - p1.getX();
        double aby = p2.getY() - p1.getY();
        double acx = p3.getX() - p1.getX();
        double acy = p3.getY() - p1.getY();

        return (abx * acy) - (aby * acx);
    }

    public static int ccw(Point p0, Point p1, Point p2) {
        double x0 = p0.getX();
        double y0 = p0.getY();
        double dx1 = p1.getX() - x0;
        double dy1 = p1.getY() - y0;
        double dx2 = p2.getX() - x0;
        double dy2 = p2.getY() - y0;

        if (dx1 * dy2 > dy1 * dx2) {
            return +1;
        }
        if (dx1 * dy2 < dy1 * dx2) {
            return -1;
        }
        if ((dx1 * dx2 < 0) || (dy1 * dy2 < 0)) {
            return -1;
        }
        if (Math.hypot(dx1, dy1) < Math.hypot(dx2, dy2)) {
            return +1;
        }
        return 0;
    }

    //http://stackoverflow.com/questions/4543506/algorithm-for-intersection-of-2-lines
    //http://community.topcoder.com/tc?module=Static&d1=tutorials&d2=geometry2
    public static Point getIntersection(Site s1, Site s2, Site s3) {
        Site lc = s1;
        Site mc = s2;
        Site rc = s3;

        //Get negative reciprocal
        double a1 = (mc.getX() - lc.getX());
        double b1 = (mc.getY() - lc.getY());
        Point p1 = VoronoiUtil.getMidPointSites(lc, mc);
        double c1 = a1 * p1.getX() + b1 * p1.getY();

        double a2 = (rc.getX() - mc.getX());
        double b2 = (rc.getY() - mc.getY());
        Point p2 = VoronoiUtil.getMidPointSites(rc, mc);
        double c2 = a2 * p2.getX() + b2 * p2.getY();

        double det = a1 * b2 - a2 * b1;

        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;

        return new Point(x, y);

    }
    
    //http://stackoverflow.com/questions/4543506/algorithm-for-intersection-of-2-lines
    //http://community.topcoder.com/tc?module=Static&d1=tutorials&d2=geometry2
    public static Point getIntersection(Site s1, Point s1s2, Site s2, Point s2s3, Site s3) {
        Site lc = s1;
        Site mc = s2;
        Site rc = s3;

        //Get negative reciprocal
        double a1 = (mc.getX() - lc.getX());
        double b1 = (mc.getY() - lc.getY());
        Point p1 = s1s2;
        double c1 = a1 * p1.getX() + b1 * p1.getY();

        double a2 = (rc.getX() - mc.getX());
        double b2 = (rc.getY() - mc.getY());
        Point p2 = s2s3;
        double c2 = a2 * p2.getX() + b2 * p2.getY();

        double det = a1 * b2 - a2 * b1;

        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;

        return new Point(x, y);

    }

    public static Point getIntersection2(Site s1, Site s2, Site s3) {
        Point a = getIntersection(s1, s2, s3);
        Point b = getIntersection(s2, s1, s3);
        Point c = getIntersection(s1, s3, s2);

        double dx, dy, d, ex, ey, e, f, px, py, qx, qy;
        dx = b.getX() - a.getX();
        dy = b.getY() - a.getY();
        d = dx * dx + dy * dy;
        ex = c.getX() - a.getX();
        ey = c.getY() - a.getY();
        e = ex * ex + ey * ey;
        f = (dx * ey) - (ex * dy);
        if (f == 0) {
            //Colinear
            return null;
        } else {
            px = (d * ey - e * dy) / (2 * f);
            py = (dx * e - ex * d) / (2 * f);
            qx = a.getX() + px;
            qy = a.getY() + py;

            return new Point(qx, qy);
        }
    }
    public static Point getIntersection4(Site s1, Site s2, Site s3) {
        Point a = getIntersection(s1, s2, s2, s3);
        Point b = getIntersection(s2, s1, s1, s3);
        Point c = getIntersection(s1, s3, s3, s2);
        
        double bcx = b.getX() + ((b.getX() - c.getX()) / 2);
        double bcy = b.getY() + ((b.getY() - c.getY()) /2);
        
        double x = a.getX()+((bcx-a.getX())*(2/3));
        double y = a.getY()+((bcy-a.getY())*(2/3));
        
        return new Point(x, y);

    }

    public static Point getIntersection(Site s1, Site s2, Site s3, Site s4) {

        //Get negative reciprocal
        double a1 = (s2.getX() - s1.getX());
        double b1 = (s2.getY() - s1.getY());
        Point p1 = VoronoiUtil.getMidPointSites(s1, s2);
        double c1 = a1 * p1.getX() + b1 * p1.getY();

        double a2 = (s4.getX() - s3.getX());
        double b2 = (s4.getY() - s3.getY());
        Point p2 = VoronoiUtil.getMidPointSites(s3, s4);
        double c2 = a2 * p2.getX() + b2 * p2.getY();

        double det = a1 * b2 - a2 * b1;

        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;
        return new Point(x, y);

    }

    public static Point getIntersectionTwoBisectors(Site site1, Site site2, Site site3, Site site4) {
        double s1y = site1.getY();
        double s1x = site1.getX();
        double s1w = site1.getWeight();

        double s2y = site2.getY();
        double s2x = site2.getX();
        double s2w = site2.getWeight();

        double s3y = site3.getY();
        double s3x = site3.getX();
        double s3w = site3.getWeight();

        double s4y = site4.getY();
        double s4x = site4.getX();
        double s4w = site4.getWeight();

        double x = ((s1w - Math.pow(s1x, 2.0) - s2w + Math.pow(s2x, 2.0)) * (s3y - s4y) + Math.pow(s1y, 2.0) * (-s3y + s4y)
                + s1y * (-s3w + Math.pow(s3x, 2.0) + Math.pow(s3y, 2.0) + s4w - Math.pow(s4x, 2.0) - Math.pow(s4y, 2.0))
                + s2y * (s3w - Math.pow(s3x, 2.0) + s2y * s3y - Math.pow(s3y, 2.0) - s4w + Math.pow(s4x, 2.0) - s2y * s4y
                + Math.pow(s4y, 2.0))) / (2 * ((s1y - s2y) * (s3x - s4x) - (s1x - s2x) * (s3y - s4y)));
        
        double xx = getIntersectionThreeParabolasX(site1, site2, site4);
        
        Point z = getInterseciont(site3, site4, null, null, new Point(x, -10000000000000.0), new Point(x, 100000000000.0));

        double y = (-s1w + Math.pow(s1x, 2) + Math.pow(s1y, 2) + s2w - Math.pow(s2x, 2) + 2 * x * (-s1x + s2x) - Math.pow(s2y, 2)) / (2 * (s1y - s2y));

        return z;//new Point(x, y);
    }
    
    public static Double getIntersectionThreeParabolasX(Site site1, Site site2, Site site3) {
        Double s1y = site1.getY();
        Double s1x = site1.getX();
        Double s1w = site1.getWeight();

        Double s2y = site2.getY();
        Double s2x = site2.getX();
        Double s2w = site2.getWeight();

        Double s3y = site3.getY();
        Double s3x = site3.getX();
        Double s3w = site3.getWeight();

        return ((s1w - Math.pow(s1x,2)) * (s2y - s3y) + (s2w - Math.pow(s2x,2)) * s3y +
            Math.pow(s1y,2) * (-s2y + s3y) +
            s1y * (-s2w + Math.pow(s2x,2) + Math.pow(s2y,2) + s3w - Math.pow(s3x,2) - Math.pow(s3y,2)) +
            s2y * (-s3w + Math.pow(s3x,2) + s3y * (-s2y + s3y)))/(2 * (s1y * (s2x - s3x) +
            s2y * s3x - s2x * s3y + s1x * (-s2y + s3y)));
    }

    //Calculate intersection between two bisectors using the sites that define
    // them. Bisectors are between site1 <-> site2 and site3 <-> site4.
    // Bisectors are calculated by getting the slope of the perpendicular
    // bisector and the point where it intersects with the line segment of the
    // two sites that it bisects. This we use to find the intersection 
    // between the two bisectors.
    private static Point getIntersectionTwoBisectors2(Site s1, Site s2, Site s3, Site s4) {
        //Get negative reciprocal
        double a1 = s2.getX() - s1.getX();
        double b1 = s2.getY() - s1.getY();

        double a2 = s4.getX() - s3.getX();
        double b2 = s4.getY() - s3.getY();
        if (a1 < 0 && b1 < 0) {
            b1 = Math.abs(b1);
            a1 = Math.abs(a1);

        }

        double slope1 = (0 - a1) / b1;
        if (a2 < 0 && b2 < 0) {
            b2 = Math.abs(b2);
            a2 = Math.abs(a2);

        }
        double slope2 = (0 - a2) / b2;

        if ((slope1 - slope2) == 0.0) {
            //Do something;
        }

        Point p1 = VoronoiUtil.getMidPointSites(s1, s2);
        Point p2 = VoronoiUtil.getMidPointSites(s3, s4);
        double offset1 = p1.getY() - (slope1 * p1.getX());
        double offset2 = p2.getY() - (slope2 * p2.getX());
        double intersectX = (offset2 - offset1) / (slope1 - slope2);
        return new Point(intersectX, slope2 * intersectX + offset2);
    }

    public static double distance(Point p, Site s) {
        double px = p.getX();
        double py = p.getY();

        double sx = s.getX();
        double sy = s.getY();
        double sw = s.getWeight();
        return Math.sqrt(Math.pow(px - sx, 2) + Math.pow(py - sy, 2)) - Math.sqrt(sw);
    }
    
    public static double distance2(Point p, Site s) {
        double px = p.getX();
        double py = p.getY();

        double sx = s.getX();
        double sy = s.getY();
        double sw = s.getWeight();
        return Math.sqrt(Math.pow(px - sx, 2) + Math.pow(py - sy, 2)) - sw;
    }

    public static double distance(Point p, Point s) {
        double px = p.getX();
        double py = p.getY();

        double sx = s.getX();
        double sy = s.getY();
        return Math.sqrt(Math.pow(px - sx, 2) + Math.pow(py - sy, 2));
    }

    public static double distance(Site s1, Site s2) {
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double s2x = s2.getX();
        double s2y = s2.getY();
        double s2w = s2.getWeight();
        return Math.sqrt(Math.pow(s1x - s2x, 2) + Math.pow(s1y - s2y, 2)) - (Math.sqrt(s1w) + Math.sqrt(s2w));
    }
    
    public static double weightedDistance(Site s1, Site s2){
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double s2x = s2.getX();
        double s2y = s2.getY();
        double s2w = s2.getWeight();
        return Math.sqrt(Math.pow(s1x - s2x, 2) + Math.pow(s1y - s2y, 2)) - (Math.sqrt(s1w) + Math.sqrt(s2w));
    }
    
    public static double weightedDistance(Site s1, Point p2){
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double p2x = p2.getX();
        double p2y = p2.getY();
        return Math.sqrt(Math.pow(s1x - p2x, 2) + Math.pow(s1y - p2y, 2)) - (Math.sqrt(s1w));
    }
    
    public static double weightedDistance(Point p1, Point p2){
        return distance(p1, p2);
    }
    
    public static double powerWeightedDistance(Site s1, Site s2){
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double s2x = s2.getX();
        double s2y = s2.getY();
        double s2w = s2.getWeight();
        return Math.pow(s1x - s2x, 2) + Math.pow(s1y - s2y, 2) - (s1w + s2w);
    }
    
    public static double powerWeightedDistance(Site s1, Point p2){
        double s1x = s1.getX();
        double s1y = s1.getY();
        double s1w = s1.getWeight();

        double p2x = p2.getX();
        double p2y = p2.getY();
        return Math.pow(s1x - p2x, 2) + Math.pow(s1y - p2y, 2) - s1w;
    }
    
    public static double powerWeightedDistance(Point p1, Point p2){
    	double s1x = p1.getX();
        double s1y = p1.getY();

        double s2x = p2.getX();
        double s2y = p2.getY();
        return Math.pow(s1x - s2x, 2) + Math.pow(s1y - s2y, 2);
    }
    
    public static double getSweepX(Site s1, Site s2, double sweep){
        double x1 = s1.getX();
        double y1 = s1.getY();
        double x2 = s2.getX();
        double y2 = s2.getY();
        double w1 = s1.getWeight();
        double w2 = s2.getWeight();
        
        double x  = ((((sweep)*(x1))+((sweep)*(x2)*(-1))+((x2)*(y1))+((x1)*(y2)*(-1))+(Math.pow(((Math.pow((sweep),2)*Math.pow((x1),2))+(Math.pow((sweep),2)*(x1)*(x2)*(-2))+(Math.pow((sweep),2)*Math.pow((x2),2))+((sweep)*Math.pow((y1),3)*(-1))+(((sweep)+((y1)*(-1)))*Math.pow((y2),3)*(-1))+((Math.pow((sweep),2)+(w2))*Math.pow((y1),2))+((Math.pow((sweep),2)+((sweep)*(y1))+(Math.pow((y1),2)*(-2))+(w1))*Math.pow((y2),2))+((((sweep)*Math.pow((x1),2))+((sweep)*(x1)*(x2)*(-2))+((sweep)*Math.pow((x2),2))+((sweep)*(w1)*(-1))+((sweep)*(w2)))*(y1)*(-1))+((((sweep)*Math.pow((x1),2))+((sweep)*(x1)*(x2)*(-2))+((sweep)*Math.pow((x2),2))+((sweep)*Math.pow((y1),2)*(-1))+(Math.pow((y1),3)*(-1))+((sweep)*(w1))+((sweep)*(w2)*(-1))+(((Math.pow((sweep),2)*2)+(Math.pow((x1),2)*(-1))+((x1)*(x2)*2)+(Math.pow((x2),2)*(-1))+(w1)+(w2))*(y1)))*(y2)*(-1))),(1/2))*(-1)))*Math.pow(((y1)+((y2)*(-1))),(-1)));
        System.out.println(x);
        return ((((sweep)*(x1))+((sweep)*(x2)*(-1))+((x2)*(y1))+((x1)*(y2)*(-1))+(Math.pow(((Math.pow((sweep),2)*Math.pow((x1),2))+(Math.pow((sweep),2)*(x1)*(x2)*(-2))+(Math.pow((sweep),2)*Math.pow((x2),2))+((sweep)*Math.pow((y1),3)*(-1))+(((sweep)+((y1)*(-1)))*Math.pow((y2),3)*(-1))+((Math.pow((sweep),2)+((w2)*(-1)))*Math.pow((y1),2))+((Math.pow((sweep),2)+((sweep)*(y1))+(Math.pow((y1),2)*(-2))+((w1)*(-1)))*Math.pow((y2),2))+((((sweep)*Math.pow((x1),2))+((sweep)*(x1)*(x2)*(-2))+((sweep)*Math.pow((x2),2))+((sweep)*(w1))+((sweep)*(w2)*(-1)))*(y1)*(-1))+((((sweep)*Math.pow((x1),2))+((sweep)*(x1)*(x2)*(-2))+((sweep)*Math.pow((x2),2))+((sweep)*Math.pow((y1),2)*(-1))+(Math.pow((y1),3)*(-1))+((sweep)*(w1)*(-1))+((sweep)*(w2))+(((Math.pow((sweep),2)*2)+(Math.pow((x1),2)*(-1))+((x1)*(x2)*2)+(Math.pow((x2),2)*(-1))+((w1)*(-1))+((w2)*(-1)))*(y1)))*(y2)*(-1))),(1/2))*(-1)))*Math.pow(((y1)+((y2)*(-1))),(-1)));
    }

}
