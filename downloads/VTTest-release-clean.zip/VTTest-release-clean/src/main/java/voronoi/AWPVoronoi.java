/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.PriorityQueue;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author rinseh
 */
public class AWPVoronoi {

    
    public static <T, S extends Site<T>> ArrayList<Edge<S>> create(ArrayList<S> sites){
        
        for(S s : sites){
            s.clear();
        }
        
        PriorityQueue<S> siteQueue = new PriorityQueue<S>(sites);
        ArrayList<Edge<S>> edges = new ArrayList<Edge<S>>();
        TreeSet<Circle<S>> circles = new TreeSet<Circle<S>>();
        BeachLine beachLine = new BeachLine(circles, edges);
        SweepLine sweepLine = new SweepLine(sites);

        
        boolean done = false;
        S currentSite = siteQueue.poll();
        sweepLine.setSweepY(currentSite);
        
        while(!done){
            Circle currentCircle = sweepLine.getNextCircleEvent(circles);
            if(currentCircle != null){
                //System.out.println("circle: "+currentCircle + " :: " + (currentCircle.getCy()));
                beachLine.removeBeach(currentCircle.getArc());
            } else if (currentSite != null){
                //System.out.println("site: "+currentSite + " :: " + currentSite.getY());
                beachLine.AddSite(currentSite, sweepLine);
                currentSite = siteQueue.poll();
                sweepLine.setSweepY(currentSite);
            } else {
                done = true;
            }
            //System.out.println(beachLine);
            //System.out.println("--");
        }
        
        return edges;
        
        /*PriorityQueue<S> siteQueue = new PriorityQueue<S>();
        TreeMap<Circle<S>, Circle<S>> circles = new TreeMap<Circle<S>, Circle<S>>();
        ArrayList<Edge<S>> edges = new ArrayList<Edge<S>>();
        BeachLine<T,S> beachLine = new BeachLine<T,S>(circles, edges);
        Collections.sort(sites);
        
        siteQueue.addAll(sites);
        
        boolean done = false;
        
        S currentSite = siteQueue.poll();     
        
        while(!done) {
            Circle<S> currentCircle = circles.size() > 0 ? circles.firstKey() : null;
            if(currentSite != null  
                    && (currentCircle == null || (currentSite.getY() * currentSite.getY() - currentSite.getWeight()) < (currentCircle.getY() * currentCircle.getY())
                        || ((currentSite.getY() * currentSite.getY() - currentSite.getWeight()) == (currentCircle.getY() * currentCircle.getY())
                            && currentSite.getX() < currentCircle.getX()))) {
            	//System.out.println("site: "+currentSite);
                beachLine.AddSite(currentSite);                
                currentSite = siteQueue.poll();
                
            } else if (currentCircle != null) {
            	//System.out.println("circle: "+currentCircle);
                beachLine.removeBeach(currentCircle.getArc());
                
            } else {
                done  = true;
            }
            //System.out.println(beachLine);
            //System.out.println("--");
        }
        
        return edges;*/
    }
    
}
