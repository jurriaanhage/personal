/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

/**
 *
 * @author rinseh
 */
public class Circle<S extends Site<?>> implements Comparable<Circle<S>> {
    private double x;
    private double y;
    private S site;
    private BeachArc<S> arc;
    private double cy;
    
    public Circle(S site, double x, double y, double cy, BeachArc<S> arc){
        this.site = site;
        this.x = x;
        this.y = y;
        this.cy = cy;
        this.arc = arc;
    }

    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(double y) {
        this.y = y;
    }

    /**
     * @return the site
     */
    public S getSite() {
        return site;
    }

    /**
     * @param site the site to set
     */
    public void setSite(S site) {
        this.site = site;
    }

    /**
     * @return the arc
     */
    public BeachArc<S> getArc() {
        return arc;
    }

    /**
     * @param arc the arc to set
     */
    public void setArc(BeachArc<S> arc) {
        this.arc = arc;
    }

    /**
     * @return the cy
     */
    public double getCy() {
        return cy;
    }

    /**
     * @param cy the cy to set
     */
    public void setCy(double cy) {
        this.cy = cy;
    }

    @Override
    public int compareTo(Circle<S> t) {
        if(this.getY() != t.getY()) {
            return (int)Math.signum(this.getY() - t.getY());
        } else {
            return (int)Math.signum(this.getX() - t.getX());
        }
        
    }
    
    @Override
    public String toString(){
        return "("+x+","+cy+")@"+y;
    }
    
}
