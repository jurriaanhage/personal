/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author rinseh
 */
public class TreeSite<T> extends Site<T> {
    
    private double desiredAreaFraction;
    private ArrayList<TreeSite<T>> children;
    private double minSiteDist;
    private double minEdgeDist;
    
    
    public TreeSite(T data, double x, double y, double weight, double areaFraction) {
        super(data, x, y, weight);
        this.desiredAreaFraction = areaFraction;
        this.children = new ArrayList<TreeSite<T>>();
        this.minSiteDist = Double.MAX_VALUE;
        this.setMinEdgeDist(Double.MAX_VALUE);
    }

    /**
     * @return the desiredAreaFraction
     */
    public double getDesiredAreaFraction() {
        return desiredAreaFraction;
    }

    /**
     * @param desiredAreaFraction the desiredAreaFraction to set
     */
    public void setDesiredAreaFraction(double desiredAreaFraction) {
        this.desiredAreaFraction = desiredAreaFraction;
    }

    /**
     * @return the children
     */
    public ArrayList<TreeSite<T>> getChildren() {
        return children;
    }

    /**
     * @param children the children to set
     */
    public void setChildren(ArrayList<TreeSite<T>> children) {
        this.children = children;
    }
    
    public void addChild(TreeSite<T> child){
        this.children.add(child);
    }
    
    public void addChildren(Collection<TreeSite<T>> children){
        this.children.addAll(children);
    }
    
    @Override
    public void clear(){
    	super.clear();
    	minSiteDist = Double.MAX_VALUE;
    	minEdgeDist = Double.MAX_VALUE;
    }

	double getMinSiteDist() {
		return minSiteDist;
	}

	void setMinSiteDist(double minSiteDist) {
		this.minSiteDist = minSiteDist;
	}

	double getMinEdgeDist() {
		return minEdgeDist;
	}

	void setMinEdgeDist(double minEdgeDist) {
		this.minEdgeDist = minEdgeDist;
	}
    
    
    
}
