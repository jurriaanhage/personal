/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

/**
 *
 * @author rinseh
 */
public class Edge<S extends Site<?>> {
    private S left;
    private S right;
    private Point a;
    private Point b;
    private double clipped;
    
    public Edge(S left, S right) {
        this.left = left;
        this.right = right;
    }
    
    public Edge(S left, S right, Point a, Point b) {
        this.left = left;
        this.right = right;
        this.a = a;
        this.b = b;
    }
    
    public void setEdgeEnd(S lSite, S rSite, Point vertex){
        if(a == null && b == null) {
            a = vertex;
            left = lSite;
            right = rSite;
        } else if (left == rSite) {
            b = vertex;
        } else {
            a = vertex;
        }
    }

    /**
     * @return the left
     */
    public S getLeft() {
        return left;
    }

    /**
     * @param left the left to set
     */
    public void setLeft(S left) {
        this.left = left;
    }

    /**
     * @return the right
     */
    public S getRight() {
        return right;
    }

    /**
     * @param right the right to set
     */
    public void setRight(S right) {
        this.right = right;
    }

    /**
     * @return the a
     */
    public Point getA() {
        return a;
    }

    /**
     * @param a the a to set
     */
    public void setA(Point a) {
        this.a = a;
    }

    /**
     * @return the b
     */
    public Point getB() {
        return b;
    }

    /**
     * @param b the b to set
     */
    public void setB(Point b) {
        this.b = b;
    }

    /**
     * @return the clipped
     */
    public double getClipped() {
        return clipped;
    }

    /**
     * @param clipped the clipped to set
     */
    public void setClipped(double clipped) {
        this.clipped = clipped;
    }
    
}
