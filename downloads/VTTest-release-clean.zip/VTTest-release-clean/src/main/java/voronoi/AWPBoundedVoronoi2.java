/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

/**
 *
 * @author rinseh
 */
public class AWPBoundedVoronoi2 {

    public static <T, S extends Site<T>> ArrayList<Edge<S>> create(ArrayList<S> sites, ConvexPolygon boundingPolygon) {
    	
    	
    	ArrayList<Edge<S>> edges = AWPVoronoi.create(sites);
        bind(sites, boundingPolygon);
        return edges;
    }

    public static <T, S extends Site<T>> void bind(ArrayList<S> sites, ConvexPolygon boundingPolygon) {
    	if(sites.size() == 1){
    		sites.get(0).setBoundingPolygon(boundingPolygon);
    		return;
    	}

        for (S site : sites) {
            ConvexPolygon poly = intersectSiteConvexPolygon(site, boundingPolygon);
            site.setBoundingPolygon(poly);
        }
    }

    private static <T, S extends Site<T>> ConvexPolygon intersectSiteConvexPolygon(S site, ConvexPolygon convexPolygon) {
    	if(site.isDummy()){
    		return null;
    	}
        HashSet<Point> points = new HashSet<Point>();
        ArrayList<HalfEdge<? extends Site<T>>> edges = site.getEdges();
        
        if(edges.size() == 0){
        	System.out.println("No edges found");
        }

        Collections.sort(edges, new halfEdgeComperator<T>());
        
        double totalNumIntersections = 0;

        IntersectionPolygonEdge endIntersection = null;
        IntersectionPolygonEdge startIntersection = null;
        for (int i = 0; i < edges.size(); i++) {
            HalfEdge<? extends Site<T>> edge = edges.get(i);
            ArrayList<IntersectionPolygonEdge> intersections = getIntersections(edge, convexPolygon);
            
            totalNumIntersections += intersections.size();
            if(intersections.size() > 2){
            	System.out.println("Error more than two intersections found!");
            }

            if (intersections.size() == 1) {
                if (edge.getEnd() != null && convexPolygon.inside(edge.getEnd())) {
                	Point p = edge.getEnd();
                    points.add(new Point(p.getX(), p.getY()));
                    if(endIntersection != null) {
                        points.addAll(walkPolygonEndToStart(endIntersection, intersections.get(0), convexPolygon));
                        points.add(intersections.get(0).getIntersection());
                        endIntersection = null;
                    } else if (startIntersection == null) {
                            startIntersection = intersections.get(0);
                    } else {
                    	System.out.println("Error in intersect polygon0 "+ totalNumIntersections);
                    }
                } else {
                    points.add(intersections.get(0).getIntersection());
                    endIntersection = intersections.get(0);
                }
            } else if (intersections.size() == 2) {
                if (endIntersection == null && startIntersection == null) {
                    startIntersection = getStartIntersection(edge, intersections);
                    endIntersection = getEndIntersection(edge, intersections);
                    points.add(endIntersection.getIntersection());
                } else if (endIntersection != null && startIntersection == null) {
                	IntersectionPolygonEdge tempStart = getStartIntersection(edge, intersections);
                    points.addAll(walkPolygonEndToStart(endIntersection, tempStart, convexPolygon));
                    points.add(tempStart.getIntersection());
                    endIntersection = getEndIntersection(edge, intersections);
                    points.add(endIntersection.getIntersection());
                } else if (endIntersection == null && startIntersection != null) {
                	System.out.println("Error in intersect polygon1 "+ totalNumIntersections);
                	/*IntersectionPolygonEdge tempEnd = getEndIntersection(edge, intersections);
                    points.add(tempEnd.getIntersection());
                    
                    points.addAll(walkPolygonEndToStart(tempEnd, getStartIntersection(edge, intersections), convexPolygon));
                    startIntersection = getStartIntersection(edge, intersections);*/
                } else {
                    IntersectionPolygonEdge tempEnd = getEndIntersection(edge, intersections);
                    IntersectionPolygonEdge tempStart = getStartIntersection(edge, intersections);
                    points.addAll(walkPolygonEndToStart(endIntersection, tempStart, convexPolygon));
                    points.add(tempStart.intersection);
                    points.add(tempEnd.intersection);
                    endIntersection = tempEnd;
                }
            } else {
                if (edge.getEnd() != null && convexPolygon.inside(edge.getEnd())) {
                	Point p = edge.getEnd();
                    points.add(new Point(p.getX(), p.getY()));
                }
            }
        }
        if (startIntersection != null && endIntersection != null) {
            points.addAll(walkPolygonEndToStart(endIntersection, startIntersection, convexPolygon));
            points.add(startIntersection.intersection);
        } else if(startIntersection != null || endIntersection != null){
        	System.out.println("Error in intersect polygon2 "+ totalNumIntersections);
        }
        return new ConvexPolygon(new ArrayList<Point>(points));
    }

    private static ArrayList<Point> walkPolygonEndToStart(IntersectionPolygonEdge end, IntersectionPolygonEdge start, ConvexPolygon polygon) {
        ArrayList<Point> points = new ArrayList<Point>();
        ArrayList<Point> polygonPoints = polygon.getPoints();
        int nverts = polygonPoints.size();

        for (int i = (end.polygonIndex + 1) % nverts; i != (start.polygonIndex + 1) % nverts; i = (i + 1) % nverts) {
        	Point p = polygonPoints.get(i);
            points.add(new Point(p.getX(), p.getY()));
        }
        
        return points;
    }

    private static <S extends Site<?>> IntersectionPolygonEdge getStartIntersection(HalfEdge<S> edge, ArrayList<IntersectionPolygonEdge> intersections) {
        Collections.sort(intersections, new IntersectionPolygonEdgeComparator<S>(edge.getSite()));
        return intersections.get(0);
    }

    private static <S extends Site<?>> IntersectionPolygonEdge getEndIntersection(HalfEdge<S> edge, ArrayList<IntersectionPolygonEdge> intersections) {
        Collections.sort(intersections, new IntersectionPolygonEdgeComparator<S>(edge.getSite()));
        return intersections.get(1);
    }

    private static <S extends Site<?>> ArrayList<IntersectionPolygonEdge> getIntersections(HalfEdge<S> edge, ConvexPolygon polygon) {
        ArrayList<IntersectionPolygonEdge> intersections = new ArrayList<IntersectionPolygonEdge>();
        ArrayList<Point> points = polygon.getPoints();

        int i;
        int j;
        int nvert = points.size();

        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            Point pi = points.get(i);
            Point pj = points.get(j);
            Point intersection = VoronoiUtil.getIntersection(edge, pi, pj);
            if (intersection != null) {
                intersections.add(new IntersectionPolygonEdge(j, intersection));
            }

        }
        
        ArrayList<IntersectionPolygonEdge> result = new ArrayList<IntersectionPolygonEdge>();
        
        if(intersections.size() > 2){
        	for (i = 0, j = intersections.size() -1; i < intersections.size(); j = i++){
        		IntersectionPolygonEdge i1 = intersections.get(j);
            	IntersectionPolygonEdge i2 = intersections.get(i);
            	if(VoronoiUtil.distance(i1.getIntersection(), i2.getIntersection()) > 0.0001){
            		result.add(i1);
            	}        		
        	}
        	
        } else if(intersections.size() == 2) {
        	IntersectionPolygonEdge i1 = intersections.get(0);
        	IntersectionPolygonEdge i2 = intersections.get(1);
        	if(VoronoiUtil.distance(i1.getIntersection(), i2.getIntersection()) < 0.0001){
        		result.add(i2);
        	} else {
        		result.add(i1);
        		result.add(i2);
        	}
        } else {
        	result.addAll(intersections);
        }
        
        if(result.size() > 2){
        	System.out.println("shit3");
        }

        return result;
    }

    private static class IntersectionPolygonEdge {

        private int polygonIndex;
        private Point intersection;

        IntersectionPolygonEdge(int polygonIndex, Point intersection) {
            this.intersection = intersection;
            this.polygonIndex = polygonIndex;
        }

        /**
         * @return the polygonIndex
         */
        public int getPolygonIndex() {
            return polygonIndex;
        }

        /**
         * @return the intersection
         */
        public Point getIntersection() {
            return intersection;
        }
    }

    private static class halfEdgeComperator<T> implements Comparator<HalfEdge<? extends Site<T>>> {

        @Override
        public int compare(HalfEdge<? extends Site<T>> a, HalfEdge<? extends Site<T>> b) {
        	Site<T> mainSite = a.getSite();
        	Site<T> neighborSite1 = a.getEdge().getLeft() == mainSite ? a.getEdge().getRight() : a.getEdge().getLeft();
        	Site<T> neighborSite2 = b.getEdge().getLeft() == mainSite ? b.getEdge().getRight() : b.getEdge().getLeft();
            
            return VoronoiUtil.ccw(mainSite, neighborSite2, neighborSite1);
        }
    }

    private static class IntersectionPolygonEdgeComparator<S extends Site<?>> implements Comparator<IntersectionPolygonEdge> {

        private S site;

        public IntersectionPolygonEdgeComparator(S site) {
            this.site = site;
        }

        @Override
        public int compare(IntersectionPolygonEdge ia, IntersectionPolygonEdge ib) {
            Point a = ia.intersection;
            Point b = ib.intersection;
            
            return VoronoiUtil.ccw(site, b, a);
        }
    }

}
