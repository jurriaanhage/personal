/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;


import voronoi.redblacktree.RedBlackTreeNode;

/**
 *
 * @author rinseh
 */
public class BeachArc<S extends Site<?>> extends RedBlackTreeNode<BeachArc<S>> {
    private Edge<S> edge;
    private S site;
    private Circle<S> circle;
    
    public BeachArc(){
    }
    
    public BeachArc(S site){
        this.site = site;
    }
    
    public double getLeftBreakPoint(SweepLine sweepLine) {
        S rSite = site;

        SweepArc<S> rSA = sweepLine.getSweepY(rSite);
        
        if (rSite.getY() >= rSA.getSweepY()) {
                return rSite.getX();
            }

        if (this.getPrevious() == null) {
            return Double.NEGATIVE_INFINITY;

        }

        S lSite = this.getPrevious().getSite();


        SweepArc<S> lSA = sweepLine.getSweepY(lSite);
        
        if (lSite.getY() >= lSA.getSweepY()) {
                return lSite.getX();
            }
        
        if(lSite.getY() == rSite.getY()){
            return VoronoiUtil.getMidPointSites(lSite, rSite).getX();
        }


        double s2x = rSite.getX();
        double s2y = rSite.getY();
        double s2w = rSite.getWeight();
        double s1x = lSite.getX();
        double s1y = lSite.getY();
        double s1w = lSite.getWeight();

        double directrix = Math.max(rSA.getSweepY(), lSA.getSweepY());
        
        if(this.getNext() != null && this.getNext().getSite().getX() < s1x){
            directrix = sweepLine.getSweepY();
        }
        
        if(this.getPrevious().getPrevious() != null && this.getPrevious().getPrevious().getSite().getX() > s2x){
            directrix = sweepLine.getSweepY();
        }


        double x = 1 / (s1y - s2y) * (s1y * s2x - s1x * s2y + s1x * directrix
                - s2x * directrix + Math.sqrt((s1y
                        - s2y) * ((s2w
                        - Math.pow(s2x, 2) + (s1y - s2y) * (s2y - directrix)) * (s1y
                        - directrix) - (s1w - Math.pow(s1x, 2)) * (s2y
                        - directrix)) + Math.pow((s1y * s2x - s2x * directrix
                                + s1x * (-s2y + directrix)), 2)));
        
        if(sweepLine.getSweepY(x).getSweepY() == sweepLine.getSweepY()){
            directrix = sweepLine.getSweepY();
            
            x = 1 / (s1y - s2y) * (s1y * s2x - s1x * s2y + s1x * directrix
                - s2x * directrix + Math.sqrt((s1y
                        - s2y) * ((s2w
                        - Math.pow(s2x, 2) + (s1y - s2y) * (s2y - directrix)) * (s1y
                        - directrix) - (s1w - Math.pow(s1x, 2)) * (s2y
                        - directrix)) + Math.pow((s1y * s2x - s2x * directrix
                                + s1x * (-s2y + directrix)), 2)));
        }

        return x;

    }
    
    
    
    /*public double getLeftBreakPoint(SweepLine sweepLine){
        S siteTempR = site;
        double s2x = siteTempR.getX();
        double s2y = siteTempR.getY();
        double s2w = 0;//siteTempR.getWeight();
        BeachArc<S> lArc = this.getPrevious();

        
        double directrixR = sweepLine.getSweepY(siteTempR);

        if (directrixR <= s2y) {
            return s2x;
        }else if (lArc == null) {
            return Double.NEGATIVE_INFINITY;
        }
        
        if(directrixR < s2y + Math.sqrt(s2w)){
            directrixR = s2y + Math.sqrt(s2w);
        }
        
        S siteTempL = lArc.site;
        double s1x = siteTempL.getX();
        double s1y = siteTempL.getY();
        double s1w = 0;//siteTempL.getWeight();
        
        double directrixL = sweepLine.getSweepY(siteTempL);

        if (directrixL <= s1y) {
            return s1x;
        } 
        if(directrixL < s1y + Math.sqrt(s1w)){
            directrixL = s1y + Math.sqrt(s1w);
        }
        
        double directrix = Math.max(directrixL, directrixR);

        if (s1y == s2y) {
            return VoronoiUtil.getMidPointSites(siteTempR, siteTempL).getX();
        }
        
        if (directrix < s1y + Math.sqrt(s1w) || directrix < s2y + Math.sqrt(s2w)) {
            directrix = Math.max(s1y + Math.sqrt(s1w), s2y + Math.sqrt(s2w));
        }
        
        double x = 1 / (s1y - s2y) * (s1y * s2x - s1x * s2y + s1x * directrix
                - s2x * directrix + Math.sqrt((s1y
                        - s2y) * ((s2w
                        - Math.pow(s2x, 2) + (s1y - s2y) * (s2y - directrix)) * (s1y
                        - directrix) - (s1w - Math.pow(s1x, 2)) * (s2y
                        - directrix)) + Math.pow((s1y * s2x - s2x * directrix
                                + s1x * (-s2y + directrix)), 2)));


        
        return x;
    }*/
    
//    public double getLeftBreakPoint2(double directrix){
//        Site siteTemp = site;
//        double rfocx = siteTemp.getX();
//        double rfocy = siteTemp.getY();
//        double pby2 = rfocy - directrix;
//        
//        if(pby2 == 0.0 || pby2 == -0.0) {
//            System.out.println("BreakPoint: " + (rfocx));
//            return rfocx;
//        }
//        
//        BeachArc lArc = this.getPrevious();
//        if(lArc == null) {
//            System.out.println("BreakPoint: " + (Double.NEGATIVE_INFINITY));
//            return Double.NEGATIVE_INFINITY;
//        }
//        
//        siteTemp = lArc.site;
//        double lfocx = siteTemp.getX();
//        double lfocy = siteTemp.getY();
//        double plby2 = lfocy - directrix;
//        
//        if(plby2 == 0.0 || plby2 == -0.0){
//            System.out.println("BreakPoint: " + (lfocx));
//            return lfocx;
//        }
//        
//        double hl = lfocx - rfocx;
//        double aby2 = 1 / pby2 - 1 /plby2;
//        double b = hl / plby2;
//        
//        if(aby2 == 0.0 || aby2 == -0.0){
//            System.out.println("BreakPoint: " + ((-b + Math.sqrt(b * b - 2 * aby2 * (hl * hl / (-2 * plby2) - lfocy + plby2 / 2 + rfocy - pby2 / 2))) / aby2 + rfocx));
//            return (-b + Math.sqrt(b * b - 2 * aby2 * (hl * hl / (-2 * plby2) - lfocy + plby2 / 2 + rfocy - pby2 / 2))) / aby2 + rfocx;
//        }
//        
//        System.out.println("BreakPoint: " + ((rfocx + lfocx) / 2));
//        return (rfocx + lfocx) / 2;
//    }
//    
    
    public double getRightBreakPoint(SweepLine sweepLine) {
        BeachArc<S> rArc = this.getNext();
        S siteTempR = site;
        double s2x = siteTempR.getX();
        double s2y = siteTempR.getY();
        double s2w = siteTempR.getWeight();
        double directrix = sweepLine.getSweepY();
        if (directrix <= s2y) {
            return s2x;
        }
        /*else if((rArc == null 
         || rArc.getSite().getX() > s2x + Math.sqrt(s2w)
         || (rArc.getSite().getX() - Math.sqrt(rArc.getSite().getWeight()) < s2x
         && rArc.getSite().getX() > s2x + Math.sqrt(s2w))) 
         && directrix <= s2y + Math.sqrt(s2w)){
         return s2x + Math.sqrt(s2w);
         } */ //else 
        if (rArc != null) {
            return rArc.getLeftBreakPoint(sweepLine);
        } else {
            return Double.POSITIVE_INFINITY;
        }
    }
    /*public double getRightBreakPoint(SweepLine sweepLine){
        BeachArc<S> rArc = this.getNext();
        S siteTempR = site;
        double s2x = siteTempR.getX();
        double s2y = siteTempR.getY();
        double s2w = siteTempR.getWeight();
        double directrix = sweepLine.getSweepY(siteTempR);
        if (directrix <= s2y) {
            return s2x;
        } else if (rArc != null) {
            return rArc.getLeftBreakPoint(sweepLine);
        } else {
            return Double.POSITIVE_INFINITY;
        }
    }*/

    /**
     * @return the edge
     */
    public Edge<S> getEdge() {
        return edge;
    }

    /**
     * @param edge the edge to set
     */
    public void setEdge(Edge<S> edge) {
        this.edge = edge;
    }

    /**
     * @return the site
     */
    public S getSite() {
        return site;
    }

    /**
     * @param site the site to set
     */
    public void setSite(S site) {
        this.site = site;
    }

    /**
     * @return the circle
     */
    public Circle<S> getCircle() {
        return circle;
    }

    /**
     * @param circle the circle to set
     */
    public void setCircle(Circle<S> circle) {
        this.circle = circle;
    }
    
    @Override
    public String toString(){
        return "\\"  + this.site.toString() + "/";
    }
}
