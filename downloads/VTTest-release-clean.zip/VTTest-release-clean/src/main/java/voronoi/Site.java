/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

import java.util.ArrayList;

/**
 *
 * @author rinseh
 */
public class Site<T> extends Point implements Comparable<Site<T>>{
    
    private ArrayList<HalfEdge<? extends Site<T>>> edges;
    private double weight;
    private T data;
    private ConvexPolygon boundingPolygon;
    private boolean isDummy;
    private ArrayList<? extends Site<T>> neighbours;
    
    public Site(T data, double x, double y){
        this(data, x, y, 0.0);
    }

    public Site(T data,double x, double y, double weight) {
        super(x, y);        
        this.weight = weight < 1 ? 1 : weight;
        this.edges = new ArrayList<HalfEdge<? extends Site<T>>>();
        this.data = data;
        this.isDummy = false;
        this.setNeighbours(new ArrayList<>());
    }
    
    public void clear() {
        edges = new ArrayList<HalfEdge<? extends Site<T>>>();
        setNeighbours(new ArrayList<>());
        boundingPolygon = null;
    }

    @Override
    public int compareTo(Site<T> t) {
    	/*if((this.getY() * this.getY() - this.getWeight()) != (t.getY() * t.getY() - t.getWeight())) {
            return (int)Math.signum((this.getY() * this.getY() - this.getWeight()) - (t.getY() * t.getY() - t.getWeight()));
        } else {
            return (int)Math.signum(this.getX() - t.getX());
        }*/
    	/*double specialCase = (this.getY() - Math.sqrt(this.getWeight())) - (t.getY() -Math.sqrt(t.getWeight()));
    	if(specialCase < 0.0001 || specialCase > -0.0001){
    		return (int)Math.signum(specialCase);
    	}*/
        if(this.getY() != t.getY()) {
            return (int)Math.signum(this.getY() - t.getY());
        } else {
            return (int)Math.signum(this.getX() - t.getX());
        }
        /*if((this.getY()- Math.sqrt(this.getWeight())) != (t.getY() - Math.sqrt(t.getWeight()))) {
            return (int)Math.signum((this.getY()- Math.sqrt(this.getWeight())) - (t.getY() - Math.sqrt(t.getWeight())));
        } else {
            return (int)Math.signum((this.getX()- Math.sqrt(this.getWeight())) - (t.getX() - Math.sqrt(t.getWeight())));
        }*/
    }

    /**
     * @return the edges
     */
    public ArrayList<HalfEdge<? extends Site<T>>> getEdges() {
        return edges;
    }

    /**
     * @param edges the edges to set
     */
    public void setEdges(ArrayList<HalfEdge<? extends Site<T>>> edges) {
        this.edges = edges;
    }
    
    public void addEdge(HalfEdge<? extends Site<T>> edge){
        this.edges.add(edge);
    }
    
    public String toString(){
        return "("+super.toString()+","+weight+")";
                
    }

    /**
     * @return the weight
     */
    public double getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(double weight) {
        this.weight = weight < 1 ? 1 : weight;
    }

    /**
     * @return the data
     */
    public T getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(T data) {
        this.data = data;
    }
    
    public boolean isBound() {
        return boundingPolygon != null;
    }

    /**
     * @return the boundingPolygon
     */
    public ConvexPolygon getBoundingPolygon() {
        return boundingPolygon;
    }

    /**
     * @param boundingPolygon the boundingPolygon to set
     */
    public void setBoundingPolygon(ConvexPolygon boundingPolygon) {
        this.boundingPolygon = boundingPolygon;
    }

	public boolean isDummy() {
		return isDummy;
	}

	public void setDummy(boolean isDummy) {
		this.isDummy = isDummy;
	}

	public ArrayList<? extends Site<T>> getNeighbours() {
		return neighbours;
	}

	public void setNeighbours(ArrayList<? extends Site<T>> neighbours) {
		this.neighbours = neighbours;
	}

    
}
