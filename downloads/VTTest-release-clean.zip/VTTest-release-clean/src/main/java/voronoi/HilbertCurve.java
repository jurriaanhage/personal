/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author rinseh
 */
public class HilbertCurve {
    
    //Hilbert curve order 1 prime
    private static Point[] curve1Points = { new Point(0.25,0.25), new Point(0.25, 0.5), new Point(0.25,0.75), new Point(0.5, 0.75), new Point(0.75,0.75),
        new Point(0.75, 0.5), new Point(0.75,0.25) };
    
    private static Point[] curve2Points = { new Point(0.125,0.125),new Point(0.375,0.125),new Point(0.375,0.375),new Point(0.125,0.375),new Point(0.125,0.625),
        new Point(0.125,0.875),new Point(0.375,0.875),new Point(0.375,0.625),new Point(0.625,0.625),new Point(0.625,0.875),
        new Point(0.875,0.875),new Point(0.875,0.625),new Point(0.875,0.375),new Point(0.625,0.375),new Point(0.625,0.125),
        new Point(0.875,0.125) };
    
    private static Point[] curve3Points = { new Point(0.0625,0.0625),new Point(0.0625,0.1875),new Point(0.1875,0.1875),new Point(0.1875,0.0625),new Point(0.3125,0.0625),
        new Point(0.4375,0.0625),new Point(0.4375,0.1875),new Point(0.3125,0.1875),new Point(0.3125,0.3125),new Point(0.4375,0.3125),
        new Point(0.4375,0.4375),new Point(0.3125,0.4375),new Point(0.1875,0.4375),new Point(0.1875,0.3125),new Point(0.0625,0.3125),
        new Point(0.0625,0.4375),new Point(0.0625,0.5625),new Point(0.1875,0.5625),new Point(0.1875,0.6875),new Point(0.0625,0.6875),
        new Point(0.0625,0.8125),new Point(0.0625,0.9375),new Point(0.1875,0.9375),new Point(0.1875,0.8125),new Point(0.3125,0.8125),
        new Point(0.3125,0.9375),new Point(0.4375,0.9375),new Point(0.4375,0.8125),new Point(0.4375,0.6875),new Point(0.3125,0.6875),
        new Point(0.3125,0.5625),new Point(0.4375,0.5625),new Point(0.5625,0.5625),new Point(0.6875,0.5625),new Point(0.6875,0.6875),
        new Point(0.5625,0.6875),new Point(0.5625,0.8125),new Point(0.5625,0.9375),new Point(0.6875,0.9375),new Point(0.6875,0.8125),
        new Point(0.8125,0.8125),new Point(0.8125,0.9375),new Point(0.9375,0.9375),new Point(0.9375,0.8125),new Point(0.9375,0.6875),
        new Point(0.8125,0.6875),new Point(0.8125,0.5625),new Point(0.9375,0.5625),new Point(0.9375,0.4375),new Point(0.9375,0.3125),
        new Point(0.8125,0.3125),new Point(0.8125,0.4375),new Point(0.6875,0.4375),new Point(0.5625,0.4375),new Point(0.5625,0.3125),
        new Point(0.6875,0.3125),new Point(0.6875,0.1875),new Point(0.5625,0.1875),new Point(0.5625,0.0625),new Point(0.6875,0.0625),
        new Point(0.8125,0.0625),new Point(0.8125,0.1875),new Point(0.9375,0.1875),new Point(0.9375,0.0625) };

    //Precalculated points for hilbert curve level 5, gives 1024 points
    private static Point[] curve5Points = {
        new Point(0.015625, 0.015625), new Point(0.015625, 0.046875), new Point(0.046875, 0.046875), new Point(0.046875, 0.015625), new Point(0.078125, 0.015625),
        new Point(0.109375, 0.015625), new Point(0.109375, 0.046875), new Point(0.078125, 0.046875), new Point(0.078125, 0.078125), new Point(0.109375, 0.078125),
        new Point(0.109375, 0.109375), new Point(0.078125, 0.109375), new Point(0.046875, 0.109375), new Point(0.046875, 0.078125), new Point(0.015625, 0.078125),
        new Point(0.015625, 0.109375), new Point(0.015625, 0.140625), new Point(0.046875, 0.140625), new Point(0.046875, 0.171875), new Point(0.015625, 0.171875),
        new Point(0.015625, 0.203125), new Point(0.015625, 0.234375), new Point(0.046875, 0.234375), new Point(0.046875, 0.203125), new Point(0.078125, 0.203125),
        new Point(0.078125, 0.234375), new Point(0.109375, 0.234375), new Point(0.109375, 0.203125), new Point(0.109375, 0.171875), new Point(0.078125, 0.171875),
        new Point(0.078125, 0.140625), new Point(0.109375, 0.140625), new Point(0.140625, 0.140625), new Point(0.171875, 0.140625), new Point(0.171875, 0.171875),
        new Point(0.140625, 0.171875), new Point(0.140625, 0.203125), new Point(0.140625, 0.234375), new Point(0.171875, 0.234375), new Point(0.171875, 0.203125),
        new Point(0.203125, 0.203125), new Point(0.203125, 0.234375), new Point(0.234375, 0.234375), new Point(0.234375, 0.203125), new Point(0.234375, 0.171875),
        new Point(0.203125, 0.171875), new Point(0.203125, 0.140625), new Point(0.234375, 0.140625), new Point(0.234375, 0.109375), new Point(0.234375, 0.078125),
        new Point(0.203125, 0.078125), new Point(0.203125, 0.109375), new Point(0.171875, 0.109375), new Point(0.140625, 0.109375), new Point(0.140625, 0.078125),
        new Point(0.171875, 0.078125), new Point(0.171875, 0.046875), new Point(0.140625, 0.046875), new Point(0.140625, 0.015625), new Point(0.171875, 0.015625),
        new Point(0.203125, 0.015625), new Point(0.203125, 0.046875), new Point(0.234375, 0.046875), new Point(0.234375, 0.015625), new Point(0.265625, 0.015625),
        new Point(0.296875, 0.015625), new Point(0.296875, 0.046875), new Point(0.265625, 0.046875), new Point(0.265625, 0.078125), new Point(0.265625, 0.109375),
        new Point(0.296875, 0.109375), new Point(0.296875, 0.078125), new Point(0.328125, 0.078125), new Point(0.328125, 0.109375), new Point(0.359375, 0.109375),
        new Point(0.359375, 0.078125), new Point(0.359375, 0.046875), new Point(0.328125, 0.046875), new Point(0.328125, 0.015625), new Point(0.359375, 0.015625),
        new Point(0.390625, 0.015625), new Point(0.390625, 0.046875), new Point(0.421875, 0.046875), new Point(0.421875, 0.015625), new Point(0.453125, 0.015625),
        new Point(0.484375, 0.015625), new Point(0.484375, 0.046875), new Point(0.453125, 0.046875), new Point(0.453125, 0.078125), new Point(0.484375, 0.078125),
        new Point(0.484375, 0.109375), new Point(0.453125, 0.109375), new Point(0.421875, 0.109375), new Point(0.421875, 0.078125), new Point(0.390625, 0.078125),
        new Point(0.390625, 0.109375), new Point(0.390625, 0.140625), new Point(0.390625, 0.171875), new Point(0.421875, 0.171875), new Point(0.421875, 0.140625),
        new Point(0.453125, 0.140625), new Point(0.484375, 0.140625), new Point(0.484375, 0.171875), new Point(0.453125, 0.171875), new Point(0.453125, 0.203125),
        new Point(0.484375, 0.203125), new Point(0.484375, 0.234375), new Point(0.453125, 0.234375), new Point(0.421875, 0.234375), new Point(0.421875, 0.203125),
        new Point(0.390625, 0.203125), new Point(0.390625, 0.234375), new Point(0.359375, 0.234375), new Point(0.328125, 0.234375), new Point(0.328125, 0.203125),
        new Point(0.359375, 0.203125), new Point(0.359375, 0.171875), new Point(0.359375, 0.140625), new Point(0.328125, 0.140625), new Point(0.328125, 0.171875),
        new Point(0.296875, 0.171875), new Point(0.296875, 0.140625), new Point(0.265625, 0.140625), new Point(0.265625, 0.171875), new Point(0.265625, 0.203125),
        new Point(0.296875, 0.203125), new Point(0.296875, 0.234375), new Point(0.265625, 0.234375), new Point(0.265625, 0.265625), new Point(0.296875, 0.265625),
        new Point(0.296875, 0.296875), new Point(0.265625, 0.296875), new Point(0.265625, 0.328125), new Point(0.265625, 0.359375), new Point(0.296875, 0.359375),
        new Point(0.296875, 0.328125), new Point(0.328125, 0.328125), new Point(0.328125, 0.359375), new Point(0.359375, 0.359375), new Point(0.359375, 0.328125),
        new Point(0.359375, 0.296875), new Point(0.328125, 0.296875), new Point(0.328125, 0.265625), new Point(0.359375, 0.265625), new Point(0.390625, 0.265625),
        new Point(0.390625, 0.296875), new Point(0.421875, 0.296875), new Point(0.421875, 0.265625), new Point(0.453125, 0.265625), new Point(0.484375, 0.265625),
        new Point(0.484375, 0.296875), new Point(0.453125, 0.296875), new Point(0.453125, 0.328125), new Point(0.484375, 0.328125), new Point(0.484375, 0.359375),
        new Point(0.453125, 0.359375), new Point(0.421875, 0.359375), new Point(0.421875, 0.328125), new Point(0.390625, 0.328125), new Point(0.390625, 0.359375),
        new Point(0.390625, 0.390625), new Point(0.390625, 0.421875), new Point(0.421875, 0.421875), new Point(0.421875, 0.390625), new Point(0.453125, 0.390625),
        new Point(0.484375, 0.390625), new Point(0.484375, 0.421875), new Point(0.453125, 0.421875), new Point(0.453125, 0.453125), new Point(0.484375, 0.453125),
        new Point(0.484375, 0.484375), new Point(0.453125, 0.484375), new Point(0.421875, 0.484375), new Point(0.421875, 0.453125), new Point(0.390625, 0.453125),
        new Point(0.390625, 0.484375), new Point(0.359375, 0.484375), new Point(0.328125, 0.484375), new Point(0.328125, 0.453125), new Point(0.359375, 0.453125),
        new Point(0.359375, 0.421875), new Point(0.359375, 0.390625), new Point(0.328125, 0.390625), new Point(0.328125, 0.421875), new Point(0.296875, 0.421875),
        new Point(0.296875, 0.390625), new Point(0.265625, 0.390625), new Point(0.265625, 0.421875), new Point(0.265625, 0.453125), new Point(0.296875, 0.453125),
        new Point(0.296875, 0.484375), new Point(0.265625, 0.484375), new Point(0.234375, 0.484375), new Point(0.234375, 0.453125), new Point(0.203125, 0.453125),
        new Point(0.203125, 0.484375), new Point(0.171875, 0.484375), new Point(0.140625, 0.484375), new Point(0.140625, 0.453125), new Point(0.171875, 0.453125),
        new Point(0.171875, 0.421875), new Point(0.140625, 0.421875), new Point(0.140625, 0.390625), new Point(0.171875, 0.390625), new Point(0.203125, 0.390625),
        new Point(0.203125, 0.421875), new Point(0.234375, 0.421875), new Point(0.234375, 0.390625), new Point(0.234375, 0.359375), new Point(0.203125, 0.359375),
        new Point(0.203125, 0.328125), new Point(0.234375, 0.328125), new Point(0.234375, 0.296875), new Point(0.234375, 0.265625), new Point(0.203125, 0.265625),
        new Point(0.203125, 0.296875), new Point(0.171875, 0.296875), new Point(0.171875, 0.265625), new Point(0.140625, 0.265625), new Point(0.140625, 0.296875),
        new Point(0.140625, 0.328125), new Point(0.171875, 0.328125), new Point(0.171875, 0.359375), new Point(0.140625, 0.359375), new Point(0.109375, 0.359375),
        new Point(0.078125, 0.359375), new Point(0.078125, 0.328125), new Point(0.109375, 0.328125), new Point(0.109375, 0.296875), new Point(0.109375, 0.265625),
        new Point(0.078125, 0.265625), new Point(0.078125, 0.296875), new Point(0.046875, 0.296875), new Point(0.046875, 0.265625), new Point(0.015625, 0.265625),
        new Point(0.015625, 0.296875), new Point(0.015625, 0.328125), new Point(0.046875, 0.328125), new Point(0.046875, 0.359375), new Point(0.015625, 0.359375),
        new Point(0.015625, 0.390625), new Point(0.015625, 0.421875), new Point(0.046875, 0.421875), new Point(0.046875, 0.390625), new Point(0.078125, 0.390625),
        new Point(0.109375, 0.390625), new Point(0.109375, 0.421875), new Point(0.078125, 0.421875), new Point(0.078125, 0.453125), new Point(0.109375, 0.453125),
        new Point(0.109375, 0.484375), new Point(0.078125, 0.484375), new Point(0.046875, 0.484375), new Point(0.046875, 0.453125), new Point(0.015625, 0.453125),
        new Point(0.015625, 0.484375), new Point(0.015625, 0.515625), new Point(0.046875, 0.515625), new Point(0.046875, 0.546875), new Point(0.015625, 0.546875),
        new Point(0.015625, 0.578125), new Point(0.015625, 0.609375), new Point(0.046875, 0.609375), new Point(0.046875, 0.578125), new Point(0.078125, 0.578125),
        new Point(0.078125, 0.609375), new Point(0.109375, 0.609375), new Point(0.109375, 0.578125), new Point(0.109375, 0.546875), new Point(0.078125, 0.546875),
        new Point(0.078125, 0.515625), new Point(0.109375, 0.515625), new Point(0.140625, 0.515625), new Point(0.140625, 0.546875), new Point(0.171875, 0.546875),
        new Point(0.171875, 0.515625), new Point(0.203125, 0.515625), new Point(0.234375, 0.515625), new Point(0.234375, 0.546875), new Point(0.203125, 0.546875),
        new Point(0.203125, 0.578125), new Point(0.234375, 0.578125), new Point(0.234375, 0.609375), new Point(0.203125, 0.609375), new Point(0.171875, 0.609375),
        new Point(0.171875, 0.578125), new Point(0.140625, 0.578125), new Point(0.140625, 0.609375), new Point(0.140625, 0.640625), new Point(0.140625, 0.671875),
        new Point(0.171875, 0.671875), new Point(0.171875, 0.640625), new Point(0.203125, 0.640625), new Point(0.234375, 0.640625), new Point(0.234375, 0.671875),
        new Point(0.203125, 0.671875), new Point(0.203125, 0.703125), new Point(0.234375, 0.703125), new Point(0.234375, 0.734375), new Point(0.203125, 0.734375),
        new Point(0.171875, 0.734375), new Point(0.171875, 0.703125), new Point(0.140625, 0.703125), new Point(0.140625, 0.734375), new Point(0.109375, 0.734375),
        new Point(0.078125, 0.734375), new Point(0.078125, 0.703125), new Point(0.109375, 0.703125), new Point(0.109375, 0.671875), new Point(0.109375, 0.640625),
        new Point(0.078125, 0.640625), new Point(0.078125, 0.671875), new Point(0.046875, 0.671875), new Point(0.046875, 0.640625), new Point(0.015625, 0.640625),
        new Point(0.015625, 0.671875), new Point(0.015625, 0.703125), new Point(0.046875, 0.703125), new Point(0.046875, 0.734375), new Point(0.015625, 0.734375),
        new Point(0.015625, 0.765625), new Point(0.015625, 0.796875), new Point(0.046875, 0.796875), new Point(0.046875, 0.765625), new Point(0.078125, 0.765625),
        new Point(0.109375, 0.765625), new Point(0.109375, 0.796875), new Point(0.078125, 0.796875), new Point(0.078125, 0.828125), new Point(0.109375, 0.828125),
        new Point(0.109375, 0.859375), new Point(0.078125, 0.859375), new Point(0.046875, 0.859375), new Point(0.046875, 0.828125), new Point(0.015625, 0.828125),
        new Point(0.015625, 0.859375), new Point(0.015625, 0.890625), new Point(0.046875, 0.890625), new Point(0.046875, 0.921875), new Point(0.015625, 0.921875),
        new Point(0.015625, 0.953125), new Point(0.015625, 0.984375), new Point(0.046875, 0.984375), new Point(0.046875, 0.953125), new Point(0.078125, 0.953125),
        new Point(0.078125, 0.984375), new Point(0.109375, 0.984375), new Point(0.109375, 0.953125), new Point(0.109375, 0.921875), new Point(0.078125, 0.921875),
        new Point(0.078125, 0.890625), new Point(0.109375, 0.890625), new Point(0.140625, 0.890625), new Point(0.171875, 0.890625), new Point(0.171875, 0.921875),
        new Point(0.140625, 0.921875), new Point(0.140625, 0.953125), new Point(0.140625, 0.984375), new Point(0.171875, 0.984375), new Point(0.171875, 0.953125),
        new Point(0.203125, 0.953125), new Point(0.203125, 0.984375), new Point(0.234375, 0.984375), new Point(0.234375, 0.953125), new Point(0.234375, 0.921875),
        new Point(0.203125, 0.921875), new Point(0.203125, 0.890625), new Point(0.234375, 0.890625), new Point(0.234375, 0.859375), new Point(0.234375, 0.828125),
        new Point(0.203125, 0.828125), new Point(0.203125, 0.859375), new Point(0.171875, 0.859375), new Point(0.140625, 0.859375), new Point(0.140625, 0.828125),
        new Point(0.171875, 0.828125), new Point(0.171875, 0.796875), new Point(0.140625, 0.796875), new Point(0.140625, 0.765625), new Point(0.171875, 0.765625),
        new Point(0.203125, 0.765625), new Point(0.203125, 0.796875), new Point(0.234375, 0.796875), new Point(0.234375, 0.765625), new Point(0.265625, 0.765625),
        new Point(0.265625, 0.796875), new Point(0.296875, 0.796875), new Point(0.296875, 0.765625), new Point(0.328125, 0.765625), new Point(0.359375, 0.765625),
        new Point(0.359375, 0.796875), new Point(0.328125, 0.796875), new Point(0.328125, 0.828125), new Point(0.359375, 0.828125), new Point(0.359375, 0.859375),
        new Point(0.328125, 0.859375), new Point(0.296875, 0.859375), new Point(0.296875, 0.828125), new Point(0.265625, 0.828125), new Point(0.265625, 0.859375),
        new Point(0.265625, 0.890625), new Point(0.296875, 0.890625), new Point(0.296875, 0.921875), new Point(0.265625, 0.921875), new Point(0.265625, 0.953125),
        new Point(0.265625, 0.984375), new Point(0.296875, 0.984375), new Point(0.296875, 0.953125), new Point(0.328125, 0.953125), new Point(0.328125, 0.984375),
        new Point(0.359375, 0.984375), new Point(0.359375, 0.953125), new Point(0.359375, 0.921875), new Point(0.328125, 0.921875), new Point(0.328125, 0.890625),
        new Point(0.359375, 0.890625), new Point(0.390625, 0.890625), new Point(0.421875, 0.890625), new Point(0.421875, 0.921875), new Point(0.390625, 0.921875),
        new Point(0.390625, 0.953125), new Point(0.390625, 0.984375), new Point(0.421875, 0.984375), new Point(0.421875, 0.953125), new Point(0.453125, 0.953125),
        new Point(0.453125, 0.984375), new Point(0.484375, 0.984375), new Point(0.484375, 0.953125), new Point(0.484375, 0.921875), new Point(0.453125, 0.921875),
        new Point(0.453125, 0.890625), new Point(0.484375, 0.890625), new Point(0.484375, 0.859375), new Point(0.484375, 0.828125), new Point(0.453125, 0.828125),
        new Point(0.453125, 0.859375), new Point(0.421875, 0.859375), new Point(0.390625, 0.859375), new Point(0.390625, 0.828125), new Point(0.421875, 0.828125),
        new Point(0.421875, 0.796875), new Point(0.390625, 0.796875), new Point(0.390625, 0.765625), new Point(0.421875, 0.765625), new Point(0.453125, 0.765625),
        new Point(0.453125, 0.796875), new Point(0.484375, 0.796875), new Point(0.484375, 0.765625), new Point(0.484375, 0.734375), new Point(0.453125, 0.734375),
        new Point(0.453125, 0.703125), new Point(0.484375, 0.703125), new Point(0.484375, 0.671875), new Point(0.484375, 0.640625), new Point(0.453125, 0.640625),
        new Point(0.453125, 0.671875), new Point(0.421875, 0.671875), new Point(0.421875, 0.640625), new Point(0.390625, 0.640625), new Point(0.390625, 0.671875),
        new Point(0.390625, 0.703125), new Point(0.421875, 0.703125), new Point(0.421875, 0.734375), new Point(0.390625, 0.734375), new Point(0.359375, 0.734375),
        new Point(0.359375, 0.703125), new Point(0.328125, 0.703125), new Point(0.328125, 0.734375), new Point(0.296875, 0.734375), new Point(0.265625, 0.734375),
        new Point(0.265625, 0.703125), new Point(0.296875, 0.703125), new Point(0.296875, 0.671875), new Point(0.265625, 0.671875), new Point(0.265625, 0.640625),
        new Point(0.296875, 0.640625), new Point(0.328125, 0.640625), new Point(0.328125, 0.671875), new Point(0.359375, 0.671875), new Point(0.359375, 0.640625),
        new Point(0.359375, 0.609375), new Point(0.359375, 0.578125), new Point(0.328125, 0.578125), new Point(0.328125, 0.609375), new Point(0.296875, 0.609375),
        new Point(0.265625, 0.609375), new Point(0.265625, 0.578125), new Point(0.296875, 0.578125), new Point(0.296875, 0.546875), new Point(0.265625, 0.546875),
        new Point(0.265625, 0.515625), new Point(0.296875, 0.515625), new Point(0.328125, 0.515625), new Point(0.328125, 0.546875), new Point(0.359375, 0.546875),
        new Point(0.359375, 0.515625), new Point(0.390625, 0.515625), new Point(0.421875, 0.515625), new Point(0.421875, 0.546875), new Point(0.390625, 0.546875),
        new Point(0.390625, 0.578125), new Point(0.390625, 0.609375), new Point(0.421875, 0.609375), new Point(0.421875, 0.578125), new Point(0.453125, 0.578125),
        new Point(0.453125, 0.609375), new Point(0.484375, 0.609375), new Point(0.484375, 0.578125), new Point(0.484375, 0.546875), new Point(0.453125, 0.546875),
        new Point(0.453125, 0.515625), new Point(0.484375, 0.515625), new Point(0.515625, 0.515625), new Point(0.546875, 0.515625), new Point(0.546875, 0.546875),
        new Point(0.515625, 0.546875), new Point(0.515625, 0.578125), new Point(0.515625, 0.609375), new Point(0.546875, 0.609375), new Point(0.546875, 0.578125),
        new Point(0.578125, 0.578125), new Point(0.578125, 0.609375), new Point(0.609375, 0.609375), new Point(0.609375, 0.578125), new Point(0.609375, 0.546875),
        new Point(0.578125, 0.546875), new Point(0.578125, 0.515625), new Point(0.609375, 0.515625), new Point(0.640625, 0.515625), new Point(0.640625, 0.546875),
        new Point(0.671875, 0.546875), new Point(0.671875, 0.515625), new Point(0.703125, 0.515625), new Point(0.734375, 0.515625), new Point(0.734375, 0.546875),
        new Point(0.703125, 0.546875), new Point(0.703125, 0.578125), new Point(0.734375, 0.578125), new Point(0.734375, 0.609375), new Point(0.703125, 0.609375),
        new Point(0.671875, 0.609375), new Point(0.671875, 0.578125), new Point(0.640625, 0.578125), new Point(0.640625, 0.609375), new Point(0.640625, 0.640625),
        new Point(0.640625, 0.671875), new Point(0.671875, 0.671875), new Point(0.671875, 0.640625), new Point(0.703125, 0.640625), new Point(0.734375, 0.640625),
        new Point(0.734375, 0.671875), new Point(0.703125, 0.671875), new Point(0.703125, 0.703125), new Point(0.734375, 0.703125), new Point(0.734375, 0.734375),
        new Point(0.703125, 0.734375), new Point(0.671875, 0.734375), new Point(0.671875, 0.703125), new Point(0.640625, 0.703125), new Point(0.640625, 0.734375),
        new Point(0.609375, 0.734375), new Point(0.578125, 0.734375), new Point(0.578125, 0.703125), new Point(0.609375, 0.703125), new Point(0.609375, 0.671875),
        new Point(0.609375, 0.640625), new Point(0.578125, 0.640625), new Point(0.578125, 0.671875), new Point(0.546875, 0.671875), new Point(0.546875, 0.640625),
        new Point(0.515625, 0.640625), new Point(0.515625, 0.671875), new Point(0.515625, 0.703125), new Point(0.546875, 0.703125), new Point(0.546875, 0.734375),
        new Point(0.515625, 0.734375), new Point(0.515625, 0.765625), new Point(0.515625, 0.796875), new Point(0.546875, 0.796875), new Point(0.546875, 0.765625),
        new Point(0.578125, 0.765625), new Point(0.609375, 0.765625), new Point(0.609375, 0.796875), new Point(0.578125, 0.796875), new Point(0.578125, 0.828125),
        new Point(0.609375, 0.828125), new Point(0.609375, 0.859375), new Point(0.578125, 0.859375), new Point(0.546875, 0.859375), new Point(0.546875, 0.828125),
        new Point(0.515625, 0.828125), new Point(0.515625, 0.859375), new Point(0.515625, 0.890625), new Point(0.546875, 0.890625), new Point(0.546875, 0.921875),
        new Point(0.515625, 0.921875), new Point(0.515625, 0.953125), new Point(0.515625, 0.984375), new Point(0.546875, 0.984375), new Point(0.546875, 0.953125),
        new Point(0.578125, 0.953125), new Point(0.578125, 0.984375), new Point(0.609375, 0.984375), new Point(0.609375, 0.953125), new Point(0.609375, 0.921875),
        new Point(0.578125, 0.921875), new Point(0.578125, 0.890625), new Point(0.609375, 0.890625), new Point(0.640625, 0.890625), new Point(0.671875, 0.890625),
        new Point(0.671875, 0.921875), new Point(0.640625, 0.921875), new Point(0.640625, 0.953125), new Point(0.640625, 0.984375), new Point(0.671875, 0.984375),
        new Point(0.671875, 0.953125), new Point(0.703125, 0.953125), new Point(0.703125, 0.984375), new Point(0.734375, 0.984375), new Point(0.734375, 0.953125),
        new Point(0.734375, 0.921875), new Point(0.703125, 0.921875), new Point(0.703125, 0.890625), new Point(0.734375, 0.890625), new Point(0.734375, 0.859375),
        new Point(0.734375, 0.828125), new Point(0.703125, 0.828125), new Point(0.703125, 0.859375), new Point(0.671875, 0.859375), new Point(0.640625, 0.859375),
        new Point(0.640625, 0.828125), new Point(0.671875, 0.828125), new Point(0.671875, 0.796875), new Point(0.640625, 0.796875), new Point(0.640625, 0.765625),
        new Point(0.671875, 0.765625), new Point(0.703125, 0.765625), new Point(0.703125, 0.796875), new Point(0.734375, 0.796875), new Point(0.734375, 0.765625),
        new Point(0.765625, 0.765625), new Point(0.765625, 0.796875), new Point(0.796875, 0.796875), new Point(0.796875, 0.765625), new Point(0.828125, 0.765625),
        new Point(0.859375, 0.765625), new Point(0.859375, 0.796875), new Point(0.828125, 0.796875), new Point(0.828125, 0.828125), new Point(0.859375, 0.828125),
        new Point(0.859375, 0.859375), new Point(0.828125, 0.859375), new Point(0.796875, 0.859375), new Point(0.796875, 0.828125), new Point(0.765625, 0.828125),
        new Point(0.765625, 0.859375), new Point(0.765625, 0.890625), new Point(0.796875, 0.890625), new Point(0.796875, 0.921875), new Point(0.765625, 0.921875),
        new Point(0.765625, 0.953125), new Point(0.765625, 0.984375), new Point(0.796875, 0.984375), new Point(0.796875, 0.953125), new Point(0.828125, 0.953125),
        new Point(0.828125, 0.984375), new Point(0.859375, 0.984375), new Point(0.859375, 0.953125), new Point(0.859375, 0.921875), new Point(0.828125, 0.921875),
        new Point(0.828125, 0.890625), new Point(0.859375, 0.890625), new Point(0.890625, 0.890625), new Point(0.921875, 0.890625), new Point(0.921875, 0.921875),
        new Point(0.890625, 0.921875), new Point(0.890625, 0.953125), new Point(0.890625, 0.984375), new Point(0.921875, 0.984375), new Point(0.921875, 0.953125),
        new Point(0.953125, 0.953125), new Point(0.953125, 0.984375), new Point(0.984375, 0.984375), new Point(0.984375, 0.953125), new Point(0.984375, 0.921875),
        new Point(0.953125, 0.921875), new Point(0.953125, 0.890625), new Point(0.984375, 0.890625), new Point(0.984375, 0.859375), new Point(0.984375, 0.828125),
        new Point(0.953125, 0.828125), new Point(0.953125, 0.859375), new Point(0.921875, 0.859375), new Point(0.890625, 0.859375), new Point(0.890625, 0.828125),
        new Point(0.921875, 0.828125), new Point(0.921875, 0.796875), new Point(0.890625, 0.796875), new Point(0.890625, 0.765625), new Point(0.921875, 0.765625),
        new Point(0.953125, 0.765625), new Point(0.953125, 0.796875), new Point(0.984375, 0.796875), new Point(0.984375, 0.765625), new Point(0.984375, 0.734375),
        new Point(0.953125, 0.734375), new Point(0.953125, 0.703125), new Point(0.984375, 0.703125), new Point(0.984375, 0.671875), new Point(0.984375, 0.640625),
        new Point(0.953125, 0.640625), new Point(0.953125, 0.671875), new Point(0.921875, 0.671875), new Point(0.921875, 0.640625), new Point(0.890625, 0.640625),
        new Point(0.890625, 0.671875), new Point(0.890625, 0.703125), new Point(0.921875, 0.703125), new Point(0.921875, 0.734375), new Point(0.890625, 0.734375),
        new Point(0.859375, 0.734375), new Point(0.859375, 0.703125), new Point(0.828125, 0.703125), new Point(0.828125, 0.734375), new Point(0.796875, 0.734375),
        new Point(0.765625, 0.734375), new Point(0.765625, 0.703125), new Point(0.796875, 0.703125), new Point(0.796875, 0.671875), new Point(0.765625, 0.671875),
        new Point(0.765625, 0.640625), new Point(0.796875, 0.640625), new Point(0.828125, 0.640625), new Point(0.828125, 0.671875), new Point(0.859375, 0.671875),
        new Point(0.859375, 0.640625), new Point(0.859375, 0.609375), new Point(0.859375, 0.578125), new Point(0.828125, 0.578125), new Point(0.828125, 0.609375),
        new Point(0.796875, 0.609375), new Point(0.765625, 0.609375), new Point(0.765625, 0.578125), new Point(0.796875, 0.578125), new Point(0.796875, 0.546875),
        new Point(0.765625, 0.546875), new Point(0.765625, 0.515625), new Point(0.796875, 0.515625), new Point(0.828125, 0.515625), new Point(0.828125, 0.546875),
        new Point(0.859375, 0.546875), new Point(0.859375, 0.515625), new Point(0.890625, 0.515625), new Point(0.921875, 0.515625), new Point(0.921875, 0.546875),
        new Point(0.890625, 0.546875), new Point(0.890625, 0.578125), new Point(0.890625, 0.609375), new Point(0.921875, 0.609375), new Point(0.921875, 0.578125),
        new Point(0.953125, 0.578125), new Point(0.953125, 0.609375), new Point(0.984375, 0.609375), new Point(0.984375, 0.578125), new Point(0.984375, 0.546875),
        new Point(0.953125, 0.546875), new Point(0.953125, 0.515625), new Point(0.984375, 0.515625), new Point(0.984375, 0.484375), new Point(0.984375, 0.453125),
        new Point(0.953125, 0.453125), new Point(0.953125, 0.484375), new Point(0.921875, 0.484375), new Point(0.890625, 0.484375), new Point(0.890625, 0.453125),
        new Point(0.921875, 0.453125), new Point(0.921875, 0.421875), new Point(0.890625, 0.421875), new Point(0.890625, 0.390625), new Point(0.921875, 0.390625),
        new Point(0.953125, 0.390625), new Point(0.953125, 0.421875), new Point(0.984375, 0.421875), new Point(0.984375, 0.390625), new Point(0.984375, 0.359375),
        new Point(0.953125, 0.359375), new Point(0.953125, 0.328125), new Point(0.984375, 0.328125), new Point(0.984375, 0.296875), new Point(0.984375, 0.265625),
        new Point(0.953125, 0.265625), new Point(0.953125, 0.296875), new Point(0.921875, 0.296875), new Point(0.921875, 0.265625), new Point(0.890625, 0.265625),
        new Point(0.890625, 0.296875), new Point(0.890625, 0.328125), new Point(0.921875, 0.328125), new Point(0.921875, 0.359375), new Point(0.890625, 0.359375),
        new Point(0.859375, 0.359375), new Point(0.828125, 0.359375), new Point(0.828125, 0.328125), new Point(0.859375, 0.328125), new Point(0.859375, 0.296875),
        new Point(0.859375, 0.265625), new Point(0.828125, 0.265625), new Point(0.828125, 0.296875), new Point(0.796875, 0.296875), new Point(0.796875, 0.265625),
        new Point(0.765625, 0.265625), new Point(0.765625, 0.296875), new Point(0.765625, 0.328125), new Point(0.796875, 0.328125), new Point(0.796875, 0.359375),
        new Point(0.765625, 0.359375), new Point(0.765625, 0.390625), new Point(0.765625, 0.421875), new Point(0.796875, 0.421875), new Point(0.796875, 0.390625),
        new Point(0.828125, 0.390625), new Point(0.859375, 0.390625), new Point(0.859375, 0.421875), new Point(0.828125, 0.421875), new Point(0.828125, 0.453125),
        new Point(0.859375, 0.453125), new Point(0.859375, 0.484375), new Point(0.828125, 0.484375), new Point(0.796875, 0.484375), new Point(0.796875, 0.453125),
        new Point(0.765625, 0.453125), new Point(0.765625, 0.484375), new Point(0.734375, 0.484375), new Point(0.703125, 0.484375), new Point(0.703125, 0.453125),
        new Point(0.734375, 0.453125), new Point(0.734375, 0.421875), new Point(0.734375, 0.390625), new Point(0.703125, 0.390625), new Point(0.703125, 0.421875),
        new Point(0.671875, 0.421875), new Point(0.671875, 0.390625), new Point(0.640625, 0.390625), new Point(0.640625, 0.421875), new Point(0.640625, 0.453125),
        new Point(0.671875, 0.453125), new Point(0.671875, 0.484375), new Point(0.640625, 0.484375), new Point(0.609375, 0.484375), new Point(0.609375, 0.453125),
        new Point(0.578125, 0.453125), new Point(0.578125, 0.484375), new Point(0.546875, 0.484375), new Point(0.515625, 0.484375), new Point(0.515625, 0.453125),
        new Point(0.546875, 0.453125), new Point(0.546875, 0.421875), new Point(0.515625, 0.421875), new Point(0.515625, 0.390625), new Point(0.546875, 0.390625),
        new Point(0.578125, 0.390625), new Point(0.578125, 0.421875), new Point(0.609375, 0.421875), new Point(0.609375, 0.390625), new Point(0.609375, 0.359375),
        new Point(0.609375, 0.328125), new Point(0.578125, 0.328125), new Point(0.578125, 0.359375), new Point(0.546875, 0.359375), new Point(0.515625, 0.359375),
        new Point(0.515625, 0.328125), new Point(0.546875, 0.328125), new Point(0.546875, 0.296875), new Point(0.515625, 0.296875), new Point(0.515625, 0.265625),
        new Point(0.546875, 0.265625), new Point(0.578125, 0.265625), new Point(0.578125, 0.296875), new Point(0.609375, 0.296875), new Point(0.609375, 0.265625),
        new Point(0.640625, 0.265625), new Point(0.671875, 0.265625), new Point(0.671875, 0.296875), new Point(0.640625, 0.296875), new Point(0.640625, 0.328125),
        new Point(0.640625, 0.359375), new Point(0.671875, 0.359375), new Point(0.671875, 0.328125), new Point(0.703125, 0.328125), new Point(0.703125, 0.359375),
        new Point(0.734375, 0.359375), new Point(0.734375, 0.328125), new Point(0.734375, 0.296875), new Point(0.703125, 0.296875), new Point(0.703125, 0.265625),
        new Point(0.734375, 0.265625), new Point(0.734375, 0.234375), new Point(0.703125, 0.234375), new Point(0.703125, 0.203125), new Point(0.734375, 0.203125),
        new Point(0.734375, 0.171875), new Point(0.734375, 0.140625), new Point(0.703125, 0.140625), new Point(0.703125, 0.171875), new Point(0.671875, 0.171875),
        new Point(0.671875, 0.140625), new Point(0.640625, 0.140625), new Point(0.640625, 0.171875), new Point(0.640625, 0.203125), new Point(0.671875, 0.203125),
        new Point(0.671875, 0.234375), new Point(0.640625, 0.234375), new Point(0.609375, 0.234375), new Point(0.609375, 0.203125), new Point(0.578125, 0.203125),
        new Point(0.578125, 0.234375), new Point(0.546875, 0.234375), new Point(0.515625, 0.234375), new Point(0.515625, 0.203125), new Point(0.546875, 0.203125),
        new Point(0.546875, 0.171875), new Point(0.515625, 0.171875), new Point(0.515625, 0.140625), new Point(0.546875, 0.140625), new Point(0.578125, 0.140625),
        new Point(0.578125, 0.171875), new Point(0.609375, 0.171875), new Point(0.609375, 0.140625), new Point(0.609375, 0.109375), new Point(0.609375, 0.078125),
        new Point(0.578125, 0.078125), new Point(0.578125, 0.109375), new Point(0.546875, 0.109375), new Point(0.515625, 0.109375), new Point(0.515625, 0.078125),
        new Point(0.546875, 0.078125), new Point(0.546875, 0.046875), new Point(0.515625, 0.046875), new Point(0.515625, 0.015625), new Point(0.546875, 0.015625),
        new Point(0.578125, 0.015625), new Point(0.578125, 0.046875), new Point(0.609375, 0.046875), new Point(0.609375, 0.015625), new Point(0.640625, 0.015625),
        new Point(0.671875, 0.015625), new Point(0.671875, 0.046875), new Point(0.640625, 0.046875), new Point(0.640625, 0.078125), new Point(0.640625, 0.109375),
        new Point(0.671875, 0.109375), new Point(0.671875, 0.078125), new Point(0.703125, 0.078125), new Point(0.703125, 0.109375), new Point(0.734375, 0.109375),
        new Point(0.734375, 0.078125), new Point(0.734375, 0.046875), new Point(0.703125, 0.046875), new Point(0.703125, 0.015625), new Point(0.734375, 0.015625),
        new Point(0.765625, 0.015625), new Point(0.765625, 0.046875), new Point(0.796875, 0.046875), new Point(0.796875, 0.015625), new Point(0.828125, 0.015625),
        new Point(0.859375, 0.015625), new Point(0.859375, 0.046875), new Point(0.828125, 0.046875), new Point(0.828125, 0.078125), new Point(0.859375, 0.078125),
        new Point(0.859375, 0.109375), new Point(0.828125, 0.109375), new Point(0.796875, 0.109375), new Point(0.796875, 0.078125), new Point(0.765625, 0.078125),
        new Point(0.765625, 0.109375), new Point(0.765625, 0.140625), new Point(0.796875, 0.140625), new Point(0.796875, 0.171875), new Point(0.765625, 0.171875),
        new Point(0.765625, 0.203125), new Point(0.765625, 0.234375), new Point(0.796875, 0.234375), new Point(0.796875, 0.203125), new Point(0.828125, 0.203125),
        new Point(0.828125, 0.234375), new Point(0.859375, 0.234375), new Point(0.859375, 0.203125), new Point(0.859375, 0.171875), new Point(0.828125, 0.171875),
        new Point(0.828125, 0.140625), new Point(0.859375, 0.140625), new Point(0.890625, 0.140625), new Point(0.921875, 0.140625), new Point(0.921875, 0.171875),
        new Point(0.890625, 0.171875), new Point(0.890625, 0.203125), new Point(0.890625, 0.234375), new Point(0.921875, 0.234375), new Point(0.921875, 0.203125),
        new Point(0.953125, 0.203125), new Point(0.953125, 0.234375), new Point(0.984375, 0.234375), new Point(0.984375, 0.203125), new Point(0.984375, 0.171875),
        new Point(0.953125, 0.171875), new Point(0.953125, 0.140625), new Point(0.984375, 0.140625), new Point(0.984375, 0.109375), new Point(0.984375, 0.078125),
        new Point(0.953125, 0.078125), new Point(0.953125, 0.109375), new Point(0.921875, 0.109375), new Point(0.890625, 0.109375), new Point(0.890625, 0.078125),
        new Point(0.921875, 0.078125), new Point(0.921875, 0.046875), new Point(0.890625, 0.046875), new Point(0.890625, 0.015625), new Point(0.921875, 0.015625),
        new Point(0.953125, 0.015625), new Point(0.953125, 0.046875), new Point(0.984375, 0.046875), new Point(0.984375, 0.015625)
    };

    private ConvexPolygon boundingPolygon;
    private int currentIndex;
    private double usedArea; //The fraction of used space compared to perfect square that compasses the polygon
    private double minX;
    private double minY;
    private double width;
    private double height;
    private double numSites;
    private double currentFraction;
    private Random rand;

//        public HilbertCurve(double minX, double minY, double width, double height){
//            this.minX = minX;
//            this.minY = minY;
//            this.width = width;
//            this.height = height;
//            currentIndex = 0;
//            usedArea = 1;
//        }
    public HilbertCurve(ConvexPolygon boundingPolygon, double numSites) {
        this.currentIndex = 0;
        this.numSites = numSites;
        setMinXMinYWidthHeight(boundingPolygon);
        double temp = this.boundingPolygon.getSize();
        this.usedArea = (temp) / (width * height);
        this.currentFraction = 0.0;
        this.rand = new Random(System.currentTimeMillis());

    }

    public void setMinXMinYWidthHeight(ConvexPolygon boundingPolygon) {
        ArrayList<Point> vertices = boundingPolygon.getPoints();
        Point centroid = boundingPolygon.getCenterOfWeight();
        ArrayList<Point> newVertices = new ArrayList<Point>();

        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxX = Double.MIN_VALUE;
        double maxY = Double.MIN_VALUE;

        for (Point p : vertices) {
            double dx = centroid.getX() - p.getX();
            double dy = centroid.getY() - p.getY();
            double x = p.getX() + (dx * 0.015625);
            double y = p.getY() + (dy * 0.015625);
            
            //newVertices.add(new Point(x,y));

            if (x > maxX) {
                maxX = x;
            }
            if (x < minX) {
                minX = x;
            }
            if (y > maxY) {
                maxY = y;
            }
            if (y < minY) {
                minY = y;
            }
        }

        double tmpWith = maxX - minX;
        double tmpHeight = maxY - minY;
        double tmpx = 0;//(0.0015625*this.width);
        double tmpy = 0;//(0.0015625*this.height);
        this.minX = minX + tmpx;
        this.minY = minY + tmpy;
        this.width = Math.max(tmpWith, tmpHeight);
        this.height = Math.max(tmpWith, tmpHeight);
        
        
        this.boundingPolygon = boundingPolygon;//new ConvexPolygon(newVertices);

    }
    
    private Point getTopLeft(){
    	Point res = new Point(Double.MAX_VALUE, Double.MAX_VALUE);
    	for(Point p : boundingPolygon.getPoints()){
    		if(p.getY() < res.getY()){
    			res = p;
    		} else if(p.getY() == res.getY() && p.getX() < res.getX()){
    			res = p;    			
    		}
    	}
    		
    	return res;
    }
    
    private Point getBottomRight(){
    	Point res = new Point(Double.MIN_VALUE, Double.MIN_VALUE);
    	for(Point p : boundingPolygon.getPoints()){
    		if(p.getY() > res.getY()){
    			res = p;
    		} else if(p.getY() == res.getY() && p.getX() > res.getX()){
    			res = p;    			
    		}
    	}
    		
    	return res;
    }
    
    public Point getForPointSite2(double frac) {

        Point result = null;
        double startFrac = this.currentFraction;
        double fraction = (frac * usedArea) * 0.9;
        if(fraction > 0.2){ // 7
            int resIndex = getPoint(startFrac, fraction, curve1Points, 1);
            if(resIndex != -1){
                Point tempP = curve1Points[resIndex];
                result = new Point((tempP.getX() * width) + (minX) + ((rand.nextDouble() -0.5) * 0.0015625), (tempP.getY() * height) + (minY) + ((rand.nextDouble() -0.5) * 0.0015625));
                this.currentFraction = ((double)resIndex / curve1Points.length) + (fraction / 2);
            }
        }
        if(fraction > 0.075 && result == null){ //16
            int resIndex = getPoint(startFrac, fraction, curve2Points, 2);
            if(resIndex != -1){
                Point tempP = curve2Points[resIndex];
                result = new Point((tempP.getX() * width) + (minX) + ((rand.nextDouble() -0.5) * 0.0015625), (tempP.getY() * height) + (minY) + ((rand.nextDouble() -0.5) * 0.0015625));
                this.currentFraction = ((double)resIndex / curve2Points.length) + (fraction / 2);
            }
            
        }
        if(fraction > 0.016 && result == null){ //64
            int resIndex = getPoint(startFrac, fraction, curve3Points, 8);
            if(resIndex != -1){
                Point tempP = curve3Points[resIndex];
                result = new Point((tempP.getX() * width) + (minX) + ((rand.nextDouble() -0.5) * 0.0015625), (tempP.getY() * height) + (minY) + ((rand.nextDouble() -0.5) * 0.0015625));
                this.currentFraction = ((double)resIndex / curve3Points.length) + (fraction / 2);
            }
            
        }
        if(result == null){ //1024
            int resIndex = getPoint(startFrac, fraction, curve5Points, 512);
            if(resIndex != -1){
                Point tempP = curve5Points[resIndex];
                result = new Point((tempP.getX() * width) + (minX) + ((rand.nextDouble() -0.5) * 0.0015625), (tempP.getY() * height) + (minY) + ((rand.nextDouble() -0.5) * 0.0015625));
                this.currentFraction = ((double)resIndex / curve5Points.length) + (fraction / 2);
            }
        }
        
        return result;
    }
    
    private int getPoint(double startFrac, double frac, Point[] curve, int maxTries) {
        int result = -1;
        double index = (startFrac) * curve.length;
        
        for(int i = 1; i <= maxTries; i++){
            index = index + Math.max(1,frac / (i +1));
            Point p = curve[(int)index];
            Point res = new Point((p.getX() * width) + (minX), (p.getY() * height) + (minY));
            if(boundingPolygon.inside(res)){
                result = (int)index;
                break;
            }
        }
        
        return result;
    }

    public Point getForPointSite(double fraction) {
/*    	double aspectRatio = width/height;
    	System.out.println(aspectRatio);
    	if(aspectRatio < 0.5 || aspectRatio > 1.5) {
    		Point a = getBottomRight();
    		Point b = getTopLeft();
    		
    		double widthTemp = a.getX() - b.getX();
    		double heightTemp = a.getY() - b.getY();
    		double widthRatio = widthTemp/(numSites+1);
    		double heightRatio = heightTemp/(numSites+1);
    		currentIndex +=1;
    		return(new Point(b.getX()+(widthRatio*currentIndex), b.getY()+(heightRatio*currentIndex)));
    	}*/
    	
    	
        //double indexMove = Math.max(1, curvePoints.length * fraction * usedArea * (0.49));
    	double indexMove = Math.max(1, (curve5Points.length * fraction * usedArea * 0.5));
        if(Double.isNaN(indexMove)){
        	System.out.println("here");
    		indexMove = 1;
    	}
        
        double orgIndexMove = 1;//indexMove;
        //indexMove = 1;
        Point p;
        
        

        do {
        	
            currentIndex += Math.max(1, indexMove);
            if(currentIndex >= 1024){
            	System.out.println("bounding: "+boundingPolygon);
            	System.out.println("orgMove: "+orgIndexMove);
            	System.out.println("usedArea: "+usedArea);
            	System.out.println("numSites: "+numSites);
            }
            Point tempP = curve5Points[currentIndex];

            p = new Point((tempP.getX() * width) + (minX) + ((rand.nextDouble() -0.5) * 0.0015625), (tempP.getY() * height) + (minY) + ((rand.nextDouble() -0.5) * 0.0015625));
            indexMove = Math.max(1, indexMove * (0.25));

        } while (!boundingPolygon.inside(p));

        //currentIndex += (orgIndexMove);
                //p = new Point(minX + (Math.random() * width), minY + (Math.random() * height));

        return p;
    }

    private boolean inside(Point p) {
        return true;
    }

}
