/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

/**
 *
 * @author rinseh
 */
public class HalfEdge<S extends Site<?>> {
    private Edge<S> edge;
    private S site;
    //private double angle;
    
    public HalfEdge(Edge<S> edge, S lSite, S rSite){
        this.site = lSite;
        this.edge = edge;
        
        /*Point va = edge.getA();
        Point vb = edge.getB();
        
        if(rSite != null){
            this.angle = Math.atan2(rSite.getY() - lSite.getY(), rSite.getX() - lSite.getX());
        } else if (edge.getLeft() == lSite) {
            this.angle = Math.atan2(vb.getX() - va.getX(), va.getY()- vb.getY());
        } else {
            this.angle = Math.atan2(va.getX() - vb.getX(), vb.getY() - va.getY());
        }*/      
        
    }
    
    public Point getStart(){
        if(this.getEdge().getRight() == this.getSite()) {
            return this.getEdge().getA();
        }
        return this.getEdge().getB();
    }
    
    public Point getEnd(){
        if(this.getEdge().getRight() == this.getSite()) {
            return this.getEdge().getB();
        }
        return this.getEdge().getA();
    }

    /**
     * @return the edge
     */
    public Edge<S> getEdge() {
        return edge;
    }

    /**
     * @return the site
     */
    public S getSite() {
        return site;
    }
    
}
