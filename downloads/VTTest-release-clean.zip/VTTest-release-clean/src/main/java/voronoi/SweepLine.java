/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

/**
 *
 * @author rinseh
 */
public class SweepLine<T, S extends Site<T>> {

    TreeSet<S> sites = new TreeSet<S>(new Comparator<S>() {
        @Override
        public int compare(S t, S t1) {
            return (int) Math.signum((t.getY() - Math.sqrt(t.getWeight())) - (t1.getY() - Math.sqrt(t1.getWeight())));
        }
    });
    TreeSet<S> currentSweepSites = new TreeSet<S>(new Comparator<S>() {

        @Override
        public int compare(S t, S t1) {
            return (int) Math.signum(t.getX() - t1.getX());
        }
    });
    double currentSweepY;
    S currentSweepSite;

    public SweepLine(ArrayList<S> sites) {
        this.sites.addAll(sites);
    }
    
    public double getSweepY() {
    	return currentSweepY;
    }
    
    public SweepArc<S> getSweepY(S site){
        return getSweepY(site.getX());
    }
    
    public SweepArc<S> getSweepY(double x){
    	//return currentSweepSite.getY() - Math.sqrt(currentSweepSite.getWeight());
//        if(currentSweepSite.getX() - Math.sqrt(currentSweepSite.getWeight()) < site.getX() 
//                && site.getX() <currentSweepSite.getX() + Math.sqrt(currentSweepSite.getWeight())){
//            return Math.max(currentSweepY, site.getY() + Math.sqrt(site.getWeight()));
//        }
        
        double y = currentSweepY;
        S sweepSite = null;
        
        for(S s : currentSweepSites){
            if(s.getX() - Math.sqrt(s.getWeight()) < x 
                && x <s.getX() + Math.sqrt(s.getWeight())){
                double ydiff = Math.sqrt(s.getWeight() - Math.pow(x - s.getX(), 2));
                double currentY = s.getY() - ydiff;
                if(currentY < y){
                    y = currentY;
                    sweepSite = s;
                }
            }
        }
        //System.out.println("Y: "+y);
        return new SweepArc<S>(sweepSite, y);
    }
    
    public void setSweepY(S site){
    	this.currentSweepSite = site;
        if(site == null){
            setSweepY(Double.POSITIVE_INFINITY);
        } else {
            setSweepY(site.getY());
        }
    }

    private void setSweepY(double y) {
        this.currentSweepY = y;

        //Find all sites that have a top-y-coordinate that is above the sweepY
        if (sites.size() >= 1) {
            Iterator<S> sitesIterator = sites.iterator();
            S s = sitesIterator.next();

            while (s.getY() - Math.sqrt(s.getWeight()) < currentSweepY) {
                currentSweepSites.add(s);
                if(sitesIterator.hasNext()){
                    s = sitesIterator.next();
                } else {
                    break;
                }
            }
        }
        //Remove all the found sites from the collection of sites
        sites.removeAll(currentSweepSites);
        
        //Clean up currentSweepSites, remove the ones that have an y-coordinate above the sweepY
        currentSweepSites.removeIf(s -> s.getY() < currentSweepY);
    }
    
    public boolean isAboveSweepLine(Circle<S> circle){
        if(circle.getY() > currentSweepY){
            return false;
        } else {
            Point circleBottom = new Point(circle.getX(), circle.getY());
            for(S s : currentSweepSites){
                if(VoronoiUtil.powerWeightedDistance(s, circleBottom) < 0){
                    return false;
                }
            }
        }
        return true;
    }
    
    public Circle<S> getNextCircleEvent(TreeSet<Circle<S>> circles){
        for(Circle<S> c : circles){
            if(isAboveSweepLine(c)){
                return c;
            }
        }
        return null;
    }
}
