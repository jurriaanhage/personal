/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

/**
 *
 * @author rinseh
 */
public class SweepArc<S extends Site<?>> {
    public double sweepY;
    public S sweepSite;
    
    public SweepArc(S site, double y){
        this.sweepSite = site;
        this.sweepY = y;
    }

    /**
     * @return the sweepY
     */
    public double getSweepY() {
        return sweepY;
    }

    /**
     * @param sweepY the sweepY to set
     */
    public void setSweepY(double sweepY) {
        this.sweepY = sweepY;
    }

    /**
     * @return the sweepSite
     */
    public S getSweepSite() {
        return sweepSite;
    }

    /**
     * @param sweepSite the sweepSite to set
     */
    public void setSweepSite(S sweepSite) {
        this.sweepSite = sweepSite;
    }
    
}
