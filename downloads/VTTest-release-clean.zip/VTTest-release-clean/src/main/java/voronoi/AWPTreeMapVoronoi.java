/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

/**
 *
 * @author rinseh
 */
public class AWPTreeMapVoronoi {

	public static <T, S extends TreeSite<T>> void create(ArrayList<S> sites,
			ConvexPolygon boundingPolygon, double minError, double maxRounds)
			throws IllegalArgumentException {

		ArrayList<TreeSite<T>> toRemove = new ArrayList<TreeSite<T>>();

		double totalSize = 0;

		for (TreeSite<T> ts : sites) {
			// Set weight to 1.0 to do an initial run without potentially having
			// sites inside other sites
			if (ts.getDesiredAreaFraction() < 0.001 && !ts.isDummy()) {
				toRemove.add(ts);
			}
			//ts.setWeight(0);
			totalSize += ts.getDesiredAreaFraction();
		}

		System.out.println("Size: " + totalSize);

		for (TreeSite<T> ts : toRemove) {
			sites.remove(ts);
		}
		
		if (sites.size() == 5) {
			sites.get(0).setBoundingPolygon(boundingPolygon);
			return;
		}
		
		HashMap<S, TreeSite<T>> heen = new HashMap<>();
		HashMap<TreeSite<T>, S> weer = new HashMap<>();
		
		for(S ts : sites) {
			TreeSite<T> s = new TreeSite(ts.getData(), ts.getX(), ts.getY(), 0, 0);
			heen.put(ts, s);
			weer.put(s, ts);
		}
		
		

		double error = Double.MAX_VALUE;
		int rounds = 1;

		double parentArea = boundingPolygon.getSize();
		
		//doFirstRound(sites, boundingPolygon);
                startWeight(sites, boundingPolygon, parentArea, rounds);
		while (error > minError && rounds < maxRounds) {
			rounds++;
			adaptPositionAndWeights(sites, boundingPolygon, parentArea, rounds);
			System.out.println("Rounds.1: "+rounds);
			//if(rounds == 90) break;
			error = adaptWeight(sites, boundingPolygon, parentArea, rounds, heen, weer);
			System.out.println("Rounds.2: " + rounds + " Error: " + error);
			//System.out.println("Errors: "+error+" Rounds: "+rounds);
		}
		System.out.println("Rounds: " + rounds + " Error: " + error);
		

	}
	
	private static <T, S extends TreeSite<T>> double adaptWeight(
			ArrayList<S> sites, ConvexPolygon boundingPolygon, double parentArea, double rounds,
			HashMap<S, TreeSite<T>> heen, HashMap<TreeSite<T>, S> weer) {
		double currentError = 0.0;
		
		for(S ts : sites) {
			TreeSite<T> s = heen.get(ts);
			s.setWeight(1);
			s.setX(ts.getX());
			s.setY(ts.getY());
		}
		
		ArrayList<TreeSite<T>> dummies = new ArrayList<>(heen.values());
		
		ArrayList<Edge<TreeSite<T>>> edges = AWPBoundedVoronoi2.create(dummies,
				boundingPolygon);		

		setMinSiteDist(edges);
		//setMinSiteDist2(dummies);
		
		AWPBoundedVoronoi2.create(sites,
				boundingPolygon);
		
		for (S site : sites) {
			if(site.isDummy()){
				continue;
			}
			double currentArea = site.getBoundingPolygon().getSize();
			double desiredArea = parentArea * site.getDesiredAreaFraction();
			double factor = 1 +((desiredArea - currentArea)/ (desiredArea));
			
			currentError += Math.abs(currentArea - desiredArea);
			
			double newWeight = (site.getWeight() * factor);
			double maxWeight = heen.get(site).getMinSiteDist()-1;
                        //double maxWeight = site.getMinSiteDist();
			
			site.setWeight(Math.min(newWeight, maxWeight));
			
		}
		
		return currentError / (2 * parentArea);
		
	}
        
        private static <T, S extends TreeSite<T>> void startWeight(
			ArrayList<S> sites, ConvexPolygon boundingPolygon, double parentArea, int rounds) {
		
		ArrayList<Edge<S>> edges = AWPBoundedVoronoi2.create(sites,
				boundingPolygon);		
		
		moveGenerators(sites);
		setMinEdgeDist(sites);
                setMinSiteDist(edges);
		
		for (S site : sites) {
			if(site.isDummy()){
				continue;
			}
                        double currentArea = site.getBoundingPolygon().getSize();
			double desiredArea = parentArea * site.getDesiredAreaFraction();
			double factor = 1 +((desiredArea - currentArea)/ (desiredArea));
			site.setWeight(Math.min(site.getMinSiteDist() * factor, site.getMinSiteDist()-1));
		}
		
	}
	
	private static <T, S extends TreeSite<T>> void adaptPositionAndWeights(
			ArrayList<S> sites, ConvexPolygon boundingPolygon, double parentArea, int rounds) {
		
		AWPBoundedVoronoi2.create(sites,
				boundingPolygon);		
		
		moveGenerators(sites);
		setMinEdgeDist(sites);
		
		for (S site : sites) {
			if(site.isDummy()){
				continue;
			}
			site.setWeight(Math.min(site.getWeight(), site.getMinEdgeDist()-1));
		}
		
	}

	private static <T, S extends TreeSite<T>> double doFirstRound(
			ArrayList<S> sites, ConvexPolygon boundingPolygon) {
		double error = 0.0;
		
		AWPBoundedVoronoi2.create(sites,
				boundingPolygon);
		
		
		
		setMinSiteDistSites(sites);

		for (S site : sites) {
			if(site.isDummy()){
				continue;
			}
			site.setWeight(site.getMinSiteDist());
		}
		moveGenerators(sites);

		return error;
	}
	
	private static <T, S extends TreeSite<T>> void moveGenerators(ArrayList<S> sites){
		for (TreeSite<T> ts : sites) {
			if(ts.isDummy()){
				continue;
			}
			Point centroid = ts.getBoundingPolygon().getCenterOfWeight();
			ts.setX(centroid.getX());
			ts.setY(centroid.getY());
			
			/*if(ts.getWeight() < 1.01) {
			ArrayList<? extends Site<T>> neighbours = ts.getNeighbours();
				
				for(Site<T> n : neighbours) {
				if(n.isDummy()){
				continue;
			}
					
				}
			}*/
			
			
		}
	}
	
	private static <T, S extends TreeSite<T>> void setMinEdgeDist(ArrayList<S> sites){
		for(TreeSite<T> s : sites){
			if(s.isDummy()){
				continue;
			}
			ArrayList<Point> points = s.getBoundingPolygon().getPoints();

	        int i;
	        int j;
	        int nvert = points.size();
	        double minDist = Double.MAX_VALUE;

	        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
	            Point pi = points.get(i);
	            Point pj = points.get(j);
	            Point p = getInterseciont(pi, pj, (Point)s);
	            if(p == null){
	            	continue;
	            }
	            Double dist = VoronoiUtil.powerWeightedDistance(p, (Point) s);
	            if(dist < minDist){
	            	minDist = dist;
	            }

	        }
	        s.setMinEdgeDist(minDist);
		}
	}
	
	private static <T, S extends TreeSite<T>> void setMinEdgeDistFout(
			ArrayList<Edge<S>> edges) {

		for (Edge<S> e : edges) {
			TreeSite<T> s1 = e.getLeft();
			TreeSite<T> s2 = e.getRight();
			
			Point midPoint = VoronoiUtil.getMidPointSites(s1, s2);

			double dist1 = VoronoiUtil.powerWeightedDistance(midPoint, (Point)s1);
			double dist2 = VoronoiUtil.powerWeightedDistance(midPoint, (Point)s2);
			double siteDist = VoronoiUtil.powerWeightedDistance((Point)s1, (Point)s2);
			if(siteDist < dist2);{
				dist2 = siteDist * 0.9;
				//System.out.println("shit: " + siteDist+" | "+ dist2);
			}
			if(siteDist < dist1);{
				dist1 = siteDist * 0.9;
				//System.out.println("shit:" + siteDist+" | "+ dist1);
			}
			
			if (dist1 < s1.getMinEdgeDist()) {
				s1.setMinEdgeDist(dist1);
			}
			if (dist2 < s2.getMinEdgeDist()) {
				s2.setMinEdgeDist(dist2);
			}
		}
	}
	
	private static <T, S extends TreeSite<T>> void setMinSiteDistSites(
			ArrayList<S> sites) {

		for (S site : sites) {
			double minDist = Double.MAX_VALUE;
			for(Site<T> s : site.getNeighbours()) {
				if(s.isDummy()) {
					continue;
				}
				double siteDist = VoronoiUtil.powerWeightedDistance((Point)site, (Point)s);
				if(minDist > siteDist) {
					minDist = siteDist;
				}
			}
			site.setMinSiteDist(minDist);
		}
	}

	private static <T, S extends TreeSite<T>> void setMinSiteDist(
			ArrayList<Edge<S>> edges) {

		for (Edge<S> e : edges) {
			TreeSite<T> s1 = e.getLeft();
			TreeSite<T> s2 = e.getRight();

			double dist = VoronoiUtil.powerWeightedDistance((Point)s1, (Point)s2);
			if (dist < s1.getMinSiteDist()) {
				s1.setMinSiteDist(dist);
			}
			if (dist < s2.getMinSiteDist()) {
				s2.setMinSiteDist(dist);
			}
		}
	}
	
	private static <T, S extends TreeSite<T>> void setMinSiteDist2(
			ArrayList<S> sites) {

		for (S s : sites) {
			double minDist = Double.MAX_VALUE;
			ArrayList<? extends Site<T>> nbs = s.getNeighbours();
			for(Site<T> n : nbs) {
				double dist = VoronoiUtil.powerWeightedDistance((Point)s, (Point)n);
				if(dist < minDist) {
					minDist = dist;
				}
			}
			s.setMinSiteDist(minDist);
		}
	}
	
	private static Point getInterseciont(Point start, Point end, Point site) { 
        //Get negative reciprocal        
        double a1 = (end.getX() - start.getX());
        double b1 = (end.getY() - start.getY());
        Point ps = site;
        double c1 = a1 * ps.getX() + b1 * ps.getY();

        double a2 = -(end.getY() - start.getY());
        double b2 = end.getX() - start.getX();
        double c2 = a2 * start.getX() + b2 * start.getY();      
        
        
        double bla1 = a1 * b2;
        double bla2 = a2 * b1;

        double det = bla1 - bla2;
        if (Math.abs(det) <= 0.000001) {
            return null;
        }
        
//        double t = ((ps.getY() - p1.getY()) * b2 - 
//				(ps.getX() - p1.getX()) * a2) / det;
//        Point hmm = new Point(p1.getX() + t * b1, p1.getY() + t * a1);

        double x = (b2 * c1 - b1 * c2) / det;
        double y = (a1 * c2 - a2 * c1) / det;

        return new Point(x, y);
	}
}
