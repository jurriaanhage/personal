/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import static java.lang.Math.abs;
import static java.lang.Math.hypot;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author rinseh
 */
public class ConvexPolygon {

    private ArrayList<Point> points;

    public ConvexPolygon() {
        this.points = new ArrayList<Point>();
    }

    public ConvexPolygon(ArrayList<Point> points) {
        this.points = convexHull(points);
    }
    
    public ArrayList<Point> convexHull(ArrayList<Point> points) {
    	ArrayList<Point> toRemove = new ArrayList<Point>();
    	for(int i = 0; i < points.size(); i++){
    		for(int j = i+1; j < points.size(); j++){
    			Point a = points.get(i);
    			Point b = points.get(j);
    			if(Math.abs(a.getX() - b.getX()) < 0.0001 && Math.abs(a.getY() - b.getY()) < 0.0001){
    				toRemove.add(b);
    				System.out.println(a);
    				System.out.println(b);
    			}
    		}
    	}
    	
    	for(Point i: toRemove){
    		points.remove(i);
    	}
    	
    	
        int nbPoints = points.size();
        
        if(nbPoints < 3){
        	//System.out.println("less than 3 points in polygon "+nbPoints);
            return points;
        }
        
        // Find point with lowest y-coord
        Point lowestPoint = getLowestPoint(points);

        
        // build the comparator, using the lowest point
        Comparator<Point> comparator = 
            new CompareByPseudoAngle(lowestPoint);
        
        // create a sorted set
        ArrayList<Point> sorted = new ArrayList<Point>(nbPoints);
        sorted.addAll(points);
        Collections.sort(sorted, comparator);
        
        // main loop
        // i-> current vertex of point cloud
        // m-> current hull vertex
        int m = 2;
        for(int i=3; i<nbPoints; i++){
            while(VoronoiUtil.ccw(sorted.get(m), sorted.get(m-1), 
                    sorted.get(i))>=0){
                m--;
            	if(m < 1){
            		System.out.println("error in points in polygon");
            		return points;
            	}
            }
            m++;
            Collections.swap(sorted, m, i);
        }

        // Format result to return a polygon
        
        return new ArrayList<Point>(sorted.subList(0, Math.min(m+1, nbPoints)));
    }
    
    @Override
    public String toString(){
    	String result = "";
    	for(Point p : points){
    		result += p.toString();
    	}
    	return result;
    }
    
    public Point getCenterOfWeight()
    {
        double x = 0;
        double y = 0;
        double area = 0.0;
        int nvert = points.size();
        int i;
        int j;
        
        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            Point v1 = points.get(i);
            Point v2 = points.get(j);
            double commonFactor = (v1.getY() * v2.getX() - v1.getX() * v2.getY());
            area += (v1.getX()*v2.getY())-(v2.getX()*v1.getY());
            x += (v1.getX() + v2.getX()) * commonFactor;
            y += (v1.getY() + v2.getY()) * commonFactor;
            
	}
        area = Math.abs(area / 2);
        x /= (6 * area);
        y /= (6 * area);
        return new Point(x, y);
    }
    
    public double getSize()
    {
        double area = 0.0;
         int nvert = points.size();
        int i;
        int j;
        
        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            Point v1 = points.get(i);
            Point v2 = points.get(j);
            area += (v1.getX()*v2.getY())-(v2.getX()*v1.getY());
	}
        area /= 2;
        
        return Math.abs(area);
    }
    

    private class CompareByPseudoAngle implements Comparator<Point>{
        Point basePoint;
        public CompareByPseudoAngle(Point base) {
            this.basePoint = base;
        }
        
        /* (non-Javadoc)
         * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
         */
        public int compare(Point point1, Point point2) {
            double angle1 = pseudoAngle(basePoint, point1);
            double angle2 = pseudoAngle(basePoint, point2);
            
            if(angle1<angle2) return -1;
            if(angle1>angle2) return +1;
            //TODO: and what about colinear points ?
            if(point1.getX() < point2.getX()) return -1;
            if(point2.getX() < point1.getX()) return 1;
            if(point1.getY() < point2.getY()) return -1;
            if(point2.getY() < point1.getY()) return 1;
            System.out.println("two points that overlap in polygon");
            return 0;
        }
    }
    
    private double pseudoAngle(Point p1, Point p2) {
		double dx = p2.getX() - p1.getX();
		double dy = p2.getY() - p1.getY();
		double s = abs(dx) + abs(dy);
		double t = (s == 0) ? 0.0 : dy / s;
		if (dx < 0) {
			t = 2 - t;
		} else if (dy < 0) {
			t += 4;
		}
		return t * 90;
	}
    
/*    private class PointComparator implements Comparator<Point> {

        private Point lowerLeft;

        public PointComparator(Point lowerLeft) {
            this.lowerLeft = lowerLeft;
        }

        @Override
        public int compare(Point a, Point b) {

            double aTanA = Math.atan2(a.getY() - lowerLeft.getY(), a.getX() - lowerLeft.getX());
            double aTanB = Math.atan2(b.getY() - lowerLeft.getY(), b.getX() - lowerLeft.getX());

            //  Determine next point in Clockwise rotation
            if (aTanA > aTanB) {
                return -1;
            } else if (aTanA < aTanB) {
                return 1;
            }
            return 0;
        }
    }*/

    //http://stackoverflow.com/questions/11716268/point-in-polygon-algorithm
    //http://stackoverflow.com/questions/217578/point-in-polygon-aka-hit-test/2922778#2922778
    public boolean inside(Point p) {
        int i;
        int j;
        boolean c = false;
        int nvert = points.size();
        double testy = p.getY();
        double testx = p.getX();
        
        for (i = 0, j = nvert - 1; i < nvert; j = i++) {
            Point pi = points.get(i);
            Point pj = points.get(j);
            if (((pi.getY() > testy) != (pj.getY() > testy))
                    && (testx < (pj.getX() - pi.getX()) * (testy - pi.getY()) / (pj.getY() - pi.getY()) +pi.getX())) {
                c = !c;
            }
        }
        return c;
    }

    /*private void sortPoints(ArrayList<Point> points) {

        Point lowest = getLowestPoint(points);

        Collections.sort(points, new Comparator<Point>() {
            @Override
            public int compare(Point a, Point b) {

                if (a == b) {
                    return 0;
                }

                // use longs to guard against int-underflow
                double thetaA = Math.atan2((long) a.getY() - lowest.getY(), (long) a.getX() - lowest.getX());
                double thetaB = Math.atan2((long) b.getY() - lowest.getY(), (long) b.getX() - lowest.getX());

                if (thetaA < thetaB) {
                    return 1;
                } else if (thetaA > thetaB) {
                    return -1;
                } else {
                    // collinear with the 'lowest' point, let the point closest to it come first

                    // use longs to guard against int-over/underflow
                    double distanceA = Math.sqrt((((long) lowest.getX() - a.getX()) * ((long) lowest.getX() - a.getX()))
                            + (((long) lowest.getY() - a.getY()) * ((long) lowest.getY() - a.getY())));
                    double distanceB = Math.sqrt((((long) lowest.getX() - b.getX()) * ((long) lowest.getX() - b.getX()))
                            + (((long) lowest.getY() - b.getY()) * ((long) lowest.getY() - b.getY())));

                    if (distanceA < distanceB) {
                        return 1;
                    } else {
                        return -1;
                    }
                }
            }
        });
    }*/

    private Point getLowestPoint(ArrayList<Point> points) {

        Point lowest = points.get(0);

        for (int i = 1; i < points.size(); i++) {

            Point temp = points.get(i);

            if (temp.getY() < lowest.getY() || (temp.getY() == lowest.getY() && temp.getX() < lowest.getX())) {
                lowest = temp;
            }
        }

        return lowest;
    }

    public void addPoint(Point point) {
        this.points.add(point);
    }

    /**
     * @return the points
     */
    public ArrayList<Point> getPoints() {
        return points;
    }

}
