/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi.redblacktree;

/**
 *
 * @author rinseh
 */
public abstract class RedBlackTreeNode<T extends RedBlackTreeNode<T>> {
    
    private T parent;
    private boolean color; //true red, false black
    private T left;
    private T right;
    private T previous;
    private T next;

    /**
     * @return the parent
     */
    public T getParent() {
        return parent;
    }

    /**
     * @param parent the parent to set
     */
    public void setParent(T parent) {
        this.parent = parent;
    }

    /**
     * @return the color
     */
    public boolean isColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(boolean color) {
        this.color = color;
    }

    /**
     * @return the left
     */
    public T getLeft() {
        return left;
    }

    /**
     * @param left the left to set
     */
    public void setLeft(T left) {
        this.left = left;
    }

    /**
     * @return the right
     */
    public T getRight() {
        return right;
    }

    /**
     * @param right the right to set
     */
    public void setRight(T right) {
        this.right = right;
    }

    /**
     * @return the previous
     */
    public T getPrevious() {
        return previous;
    }

    /**
     * @param previous the previous to set
     */
    public void setPrevious(T previous) {
        this.previous = previous;
    }

    /**
     * @return the next
     */
    public T getNext() {
        return next;
    }

    /**
     * @param next the next to set
     */
    public void setNext(T next) {
        this.next = next;
    }
    
}
