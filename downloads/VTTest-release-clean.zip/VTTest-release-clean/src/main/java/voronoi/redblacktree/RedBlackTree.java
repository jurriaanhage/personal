/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package voronoi.redblacktree;

import java.util.ArrayList;

/**
 *
 * @author rinseh
 */
public class RedBlackTree<T extends RedBlackTreeNode<T>> {
    
    T root;
    
    public void insert(T after, T node){
        T leftMost = this.getFirst();
        T parent;
        T grandpa ;
        T uncle;
        
        if(after != null) {
            node.setPrevious(after);
            node.setNext(after.getNext());
            if(after.getNext() != null) {
                after.getNext().setPrevious(node);
            }
            after.setNext(node);
            
            if(after.getRight() != null) {
                after = after.getRight();
                while (after.getLeft() != null) {
                    after = after.getLeft();
                }
                after.setLeft(node);
            } else {
                after.setRight(node);
            }
            parent = after;
        } else if (this.root != null) {
            after = this.getFirst();
            node.setPrevious(null);
            node.setNext(after);
            after.setPrevious(node);
            after.setLeft(node);
            parent = after;
        } else {
            node.setNext(null);
            node.setPrevious(null);
            this.root = node;
            parent = null;
        }
        
        /*node.setLeft(null);
        node.setRight(null);
        node.setParent(parent);
        node.setColor(true);
        
        after = node;
        while(parent != null && parent.isColor()) {
            grandpa = parent.getParent();
            if(parent == grandpa.getLeft()) {
                uncle = grandpa.getRight();
                if (uncle != null && uncle.isColor()){
                    parent.setColor(false);
                    uncle.setColor(false);
                    grandpa.setColor(true);
                    after = grandpa;
                } else {
                    if (after == parent.getRight()) {
                        rotateLeft(parent);
                        after = parent;
                        parent = after.getParent();
                    }
                    parent.setColor(false);
                    grandpa.setColor(true);
                    rotateRight(grandpa);
                }
            } else {
                uncle = grandpa.getLeft();
                if(uncle != null && uncle.isColor()) {
                    parent.setColor(false);
                    uncle.setColor(false);
                    grandpa.setColor(true);
                    after = grandpa;
                } else {
                    if(after == parent.getLeft()) {
                        rotateRight(parent);
                        after = parent;
                        parent = after.getParent();
                    }
                    parent.setColor(false);
                    grandpa.setColor(true);
                    rotateLeft(grandpa);
                }
            }
            parent = after.getParent();
        }
        this.root.setColor(false);
        if(leftMost != this.getFirst()) {
            System.out.println("ERROR in insert");
            
        }
        checkRBInvariant("insert", this.root);*/
    }
    
    private void checkRBInvariant(String location, T node) {
        if(node != null && node.isColor()){
            if(node.getLeft() == null || node.getLeft().isColor()) {
                System.out.println("Error RB invariant "+location);
            }
            if(node.getRight() == null || node.getRight().isColor()) {
                System.out.println("Error RB invariant "+location);
            }
            checkRBInvariant(location, node.getLeft());
            checkRBInvariant(location, node.getRight());
        }
        if(node != null && !node.isColor()) {
            if(node.getLeft() != null && !node.getLeft().isColor()){
                System.out.println("Error RB invariant "+location);
            }
            if(node.getRight() != null && !node.getRight().isColor()){
                System.out.println("Error RB invariant "+location);
            }
            checkRBInvariant(location, node.getLeft());
            checkRBInvariant(location, node.getRight());
        }
    }
    
    public void remove(T node) {
        T leftMost = this.getFirst();
        if(node == root){
            if(node.getPrevious() != null){
                root = node.getPrevious();
            } else {
                root = node.getNext();
            }
        }
        if(node.getNext() != null) {
            node.getNext().setPrevious(node.getPrevious());
        }
        if(node.getPrevious() != null) {
            node.getPrevious().setNext(node.getNext());
        } 
        
        /*T parent = node.getParent();
        T sibling;
        T left = node.getLeft();
        T right = node.getRight();
        T next;
        boolean red;
        
        if(left == null) {
            next = right;
        } else if (right == null) {
            next = left;
        } else {
            next = right;
            while(next.getLeft() != null){
                next = next.getLeft();
            }
        }
        
        if(parent != null) {
            if (parent.getLeft() == node) {
                parent.setLeft(next);
            } else {
                parent.setRight(next);
            }
        } else {
            this.root = next;
        }
        
        if(left != null && right != null) {
            red = next.isColor();
            next.setColor(node.isColor());
            next.setLeft(left);
            left.setParent(next);
            if(next != right) {
                parent = next.getParent();
                next.setParent(node.getParent());
                node = next.getRight();
                parent.setLeft(node);
                next.setRight(right);
                right.setParent(next);
            } else {
                next.setParent(parent);
                parent = next;
                node = next.getRight();
            }
        } else {
            red = node.isColor();
            node = next;
        }
        
        if(node != null) {
            node.setParent(parent);
        }
        if(red) {
            return;
        }
        if(node != null && node.isColor()) {
            node.setColor(false);
            return;
        }
        
        do {
            if(node == this.root) {
                break;
            }
            if(node == parent.getLeft()) {
                sibling = parent.getRight();
                if(sibling.isColor()) {
                    sibling.setColor(false);
                    parent.setColor(true);
                    rotateLeft(parent);
                    sibling = parent.getRight();
                }
                if((sibling.getLeft() != null && sibling.getLeft().isColor())
                        || (sibling.getRight() != null && sibling.getRight().isColor())) {
                    if(sibling.getRight() == null || !sibling.getRight().isColor()) {
                        sibling.getLeft().setColor(false);
                        sibling.setColor(true);
                        rotateRight(sibling);
                        sibling = parent.getRight();
                    }
                    sibling.setColor(parent.isColor());
                    parent.setColor(false);
                    sibling.getRight().setColor(false);
                    rotateLeft(parent);
                    node = this.root;
                    break;
                }
            } else {
                sibling = parent.getLeft();
                if(sibling.isColor()){
                    sibling.setColor(false);
                    parent.setColor(true);
                    rotateRight(parent);
                    sibling = parent.getLeft();
                }
                if((sibling.getLeft() != null && sibling.getLeft().isColor())
                        || (sibling.getRight() != null && sibling.getRight().isColor())) {
                    if(sibling.getLeft() == null || !sibling.getLeft().isColor()) {
                        sibling.getRight().setColor(false);
                        sibling.setColor(true);
                        rotateLeft(sibling);
                        sibling = parent.getLeft();
                    }
                    sibling.setColor(parent.isColor());
                    parent.setColor(false);
                    sibling.getLeft().setColor(false);
                    rotateRight(parent);
                    node = this.root;
                    break;
                }
            }
            sibling.setColor(true);
            node = parent;
            parent = parent.getParent();
        } while (!node.isColor());
        if(leftMost != this.getFirst()) {
            System.out.println("ERROR in remeove");
        }
        checkRBInvariant("remove", this.root);*/
    }
    
    private void rotateLeft(T node) {
        T leftMost = this.getFirst();
        T p = node;
        T q = node.getRight();
        T parent = p.getParent();
        
        if(parent != null) {
            if(parent.getLeft() == p) {
                parent.setLeft(q);
            } else {
                parent.setRight(q);
            }
        } else {
            this.root = q;
        }
        
        q.setParent(parent);
        p.setParent(q);
        p.setRight(q.getLeft());
        if(p.getRight() != null) {
            p.getRight().setParent(p);
        }
        q.setLeft(p);
        if(leftMost != this.getFirst()) {
            System.out.println("ERROR in rotateleft");
        }
        checkRBInvariant("rotatoeleft", this.root);
    }
    
    private void rotateRight(T node){
        T leftMost = this.getFirst();
        T p = node;
        T q = node.getLeft();
        T parent = p.getParent();
        
        if(parent != null) {
            if(parent.getLeft() == p) {
                parent.setLeft(q);
            } else {
                parent.setRight(q);
            }
        } else {
            this.root = q;
        }
        
        q.setParent(parent);
        p.setParent(q);
        p.setLeft(q.getRight());
        if(p.getLeft() != null) {
            p.getLeft().setParent(p);
        }
        q.setRight(p);
        if(leftMost != this.getFirst()) {
            System.out.println("ERROR in rotateRight");
        }
        checkRBInvariant("rotaterigth", this.root);
    }
    
    public T getRoot() {
        return root;
    }
    
    public T getFirst() {
       T currentNode = this.root;
       if(currentNode == null) {
           return null;
       }
        while(currentNode.getLeft() != null) {
            currentNode = currentNode.getLeft();
        }
        return currentNode;
    }
    
}
