/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package voronoi;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.TreeSet;

import voronoi.redblacktree.RedBlackTree;

/**
 *
 * @author rinseh
 */
public class BeachLine<T,S extends Site<T>> {

    private double epsilon = 0.000001;

    private RedBlackTree<BeachArc<S>> beachTree = new RedBlackTree<BeachArc<S>>();
    private TreeSet<Circle<S>> circles;
    private ArrayList<Edge<S>> edges;

    public BeachLine(TreeSet<Circle<S>> circles, ArrayList<Edge<S>> edges) {
        this.circles = circles;
        this.edges = edges;
        
    }

    

    public void AddSite(S site, SweepLine sweepLine) {
        double x = site.getX();
        double directrix = site.getY();
        BeachArc<S> lArc = null;
        BeachArc<S> rArc = null;
        double dxl;
        double dxr;
        BeachArc<S> node = this.beachTree.getFirst();
       

        while (node != null) {
            //double left = node.getLeftBreakPoint(sweepLine);
            //System.out.println("left: "+left);
            //dxl = left - x;
            //if (dxl > epsilon) {
            //    if(node.getPrevious() == null) {
            //        rArc = node;
            //        break;
            //    }
            //    node = node.getPrevious();
            //} else {
                double right = node.getRightBreakPoint(sweepLine);
                //System.out.println("right: "+right);
                dxr = x - right;
                if (dxr > epsilon) {
                    if (node.getNext() == null) {
                        lArc = node;
                        break;
                    }
                    node = node.getNext();
                } else {
//                    if (dxl > -epsilon) {
//                        lArc = node.getPrevious();
//                        rArc = node;
//                    } else if (dxr > -epsilon) {
//                        lArc = node;
//                        rArc = node.getNext();
//                    } else {
                        lArc = node;
                        rArc = node;
//                    }
                    break;
                }
            //}
        }

        BeachArc<S> newArc = new BeachArc<S>(site);
        beachTree.insert(lArc, newArc);

        if (lArc == null && rArc == null) {
            return;
        }

        if (lArc == rArc) {
            this.detachCircle(lArc);
            rArc = new BeachArc<S>(lArc.getSite());
            beachTree.insert(newArc, rArc);
            Edge<S> edge = createEdge(lArc.getSite(), newArc.getSite(), null, null);
            newArc.setEdge(edge);
            rArc.setEdge(edge);
            this.attachCircle(lArc);
            this.attachCircle(rArc);
            return;
        }

        if (rArc == null) {
            Edge<S> edge = createEdge(lArc.getSite(), newArc.getSite(), null, null);
            newArc.setEdge(edge);
            return;
        }
        
        if(lArc == null) {
            Edge<S> edge = createEdge(newArc.getSite(), rArc.getSite(), null, null);
            newArc.setEdge(edge);
            rArc.setEdge(edge);
            return;
        }

        this.detachCircle(lArc);
        this.detachCircle(rArc);
        S lSite = lArc.getSite();
        S rSite = rArc.getSite();
        
        Point vertex = VoronoiUtil.getIntersection(lSite, site, rSite);        

        rArc.getEdge().setEdgeEnd(lSite, rSite, vertex);
        newArc.setEdge(createEdge(lSite, site, null, vertex));
        rArc.setEdge(createEdge(site, rSite, null, vertex));
        this.attachCircle(lArc);
        this.attachCircle(rArc);

    }
    
    

    private Edge<S> createEdge(S lSite, S rSite, Point va, Point vb) {
        Edge<S> edge = new Edge<S>(lSite, rSite);
        if (va != null) {
            edge.setEdgeEnd(lSite, rSite, va);
        }
        if (vb != null) {
            edge.setEdgeEnd(rSite, lSite, vb);
        }
        edges.add(edge);
        lSite.addEdge(new HalfEdge<S>(edge, lSite, rSite));
        rSite.addEdge(new HalfEdge<S>(edge, rSite, lSite));
        return edge;
    }
    
    private void destroyEdge(Edge<S> edge){
        if(edge == null){
            return;
        }
        S lSite = edge.getLeft();
        S rSite = edge.getRight();
        
        HalfEdge<? extends Site<T>> lHE = null;
        HalfEdge<? extends Site<T>> rHE = null;
        for(HalfEdge<? extends Site<T>> he : lSite.getEdges()){
            if(he.getEdge() == edge){
                lHE = he;
            }
        }
        
        for(HalfEdge<? extends Site<T>> he : rSite.getEdges()){
            if(he.getEdge() == edge){
                rHE = he;
            }
        }
        
        lSite.getEdges().remove(lHE);
        rSite.getEdges().remove(rHE);
        edge.setLeft(null);
        edge.setRight(null);
        edges.remove(edge);
    }

    public void removeBeach(BeachArc<S> beach) {
        Circle<S> circle = beach.getCircle();
        double x = circle.getX();
        double y = circle.getCy();
        Point vertex = new Point(x, y);
        BeachArc<S> previous = beach.getPrevious();
        BeachArc<S> next = beach.getNext();

        ArrayList<BeachArc<S>> disappearing = new ArrayList<BeachArc<S>>();
        disappearing.add(beach);

        this.detachBeach(beach);

        BeachArc<S> lArc = previous;
        while (lArc.getCircle() != null
                && Math.abs(x - lArc.getCircle().getX()) < epsilon
                && Math.abs(y - lArc.getCircle().getCy()) < epsilon) {
            previous = lArc.getPrevious();
            disappearing.add(0, lArc);
            this.detachBeach(lArc);
            lArc = previous;
        }

        disappearing.add(0, lArc);
        this.detachCircle(lArc);

        BeachArc<S> rArc = next;
        while (rArc.getCircle() != null
                && Math.abs(x - rArc.getCircle().getX()) < epsilon
                && Math.abs(y - rArc.getCircle().getCy()) < epsilon) {
            next = rArc.getNext();
            disappearing.add(rArc);
            this.detachBeach(rArc);
            rArc = next;
        }

        disappearing.add(rArc);
        this.detachCircle(rArc);

        int nArcs = disappearing.size();
        int iArc;
        for (iArc = 1; iArc < nArcs; ++iArc) {
            rArc = disappearing.get(iArc);
            lArc = disappearing.get(iArc - 1);
            rArc.getEdge().setEdgeEnd(lArc.getSite(), rArc.getSite(), vertex);
        }

        lArc = disappearing.get(0);
        rArc = disappearing.get(nArcs - 1);
        rArc.setEdge(createEdge(lArc.getSite(), rArc.getSite(), null, vertex));

        this.attachCircle(lArc);
        this.attachCircle(rArc);
    }

    private void detachBeach(BeachArc<S> beach) {
        this.detachCircle(beach);
        this.beachTree.remove(beach);
        beach.setLeft(null);
        beach.setNext(null);
        beach.setParent(null);
        beach.setPrevious(null);
        beach.setRight(null);

    }

    private void attachCircle(BeachArc<S> arc) {
        BeachArc<S> lArc = arc.getPrevious();
        BeachArc<S> rArc = arc.getNext();

        if (lArc == null || rArc == null) {
            return;
        }

        S lSite = lArc.getSite();
        S cSite = arc.getSite();
        S rSite = rArc.getSite();

        if (lSite == rSite) {
            return;
        }

        double bx = cSite.getX();
        double by = cSite.getY();
        double ax = lSite.getX() - bx;
        double ay = lSite.getY() - by;
        double cx = rSite.getX() - bx;
        double cy = rSite.getY() - by;

        double d = 2 * (ax * cy - ay * cx);
        if (d > -epsilon) {
            return;
        }
        
  
        Point vertex = VoronoiUtil.getIntersection(lSite, cSite, rSite);
        double dist = VoronoiUtil.powerWeightedDistance(cSite, vertex);

        //Intersection of 3 sites with weight will sometimes lie within all three sites
        //The distance can therefore be said to be zero
        if(dist < 0){
            dist = 0;
        }

        Circle<S> circle = new Circle<S>(cSite,
                vertex.getX(),
                vertex.getY() + Math.sqrt(dist),
                vertex.getY(),
                arc);

        arc.setCircle(circle);
        this.circles.add(circle);
    }

    private void detachCircle(BeachArc<S> beach) {
        Circle<S> circle = beach.getCircle();
        if (circle != null) {
            this.circles.remove(circle);
            beach.setCircle(null);
        }

    }

    @Override
    public String toString() {
        BeachArc<S> arc = this.beachTree.getFirst();
        String result = "";
        while (arc != null) {
            result += arc.toString();
            arc = arc.getNext();
        }
        return result;
    }

}
