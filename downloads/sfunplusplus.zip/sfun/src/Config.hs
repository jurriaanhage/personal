module Config where

import Type.Lattice
    
data Config = Config {
              mode :: Mode,
              debug :: Bool,
              test :: Bool,
              currentLattice :: Lattice
            }

data Mode = Echo | Parse | Pretty | Interactive | TypeInfer | Annotate | TypeCheck