module Graph.Graph where

import Type.Lattice
import Type.Annotation
import Syntax.SyntaxBase
import qualified Data.Map as M
import Data.Maybe (fromJust)

type EdgeMap = M.Map Ident ConstraintEnvironment
{-
A "Graph a" is a graph described by the Edges with result for any variable note of type a
the first set of edges describes relations to elements higher in the graph. The second to lower nodes
-}
data Graph a
    = Graph Lattice EdgeMap EdgeMap (M.Map Ident a) 
    
instance (Show a) => Show (Graph a) where
    show (Graph l e1 e2 m) = "Graph \n" ++ (show e1) ++ "\n\n" ++ (show e2) ++ "\n\n" ++ (show m) 

--Unfortunately explicit types cannot be really checked as they also refer to type variable a, 
--and then actually referring to exactly the same as in the one in the sig below
initializeGraph :: Lattice -> ConstraintEnvironment -> a -> Graph a
initializeGraph lat constraints initialresult = foldr (insertEdge initialresult) initGraph constraints
  where
    initGraph = Graph lat M.empty M.empty M.empty

getEdgeList :: EdgeMap -> Ident -> ConstraintEnvironment
getEdgeList m i = case (M.lookup i m) of
                    Nothing -> []
                    (Just a) -> a
    
insertEdge :: a -> Constraint -> Graph a -> Graph a
insertEdge initialresult c@(_, (SecVar l), (SecVar u), _)  (Graph la edgesUp edgesDown results) = 
                                                               let upList = M.insert l (insertConstraint c $ getEdgeList edgesUp l) edgesUp
                                                                   downList = M.insert u (insertConstraint c $ getEdgeList edgesDown u) edgesDown
                                                                in Graph la upList downList (updateResults l initialresult $ updateResults u initialresult results)
insertEdge initialresult c@(_, (SecVar l), _, _)           (Graph la edgesUp edgesDown results) = 
                                                               let upList = M.insert l (insertConstraint c $ getEdgeList edgesUp l) edgesUp
                                                                   downList = M.insert l (getEdgeList edgesDown l) edgesDown
                                                                in Graph la upList downList (updateResults l initialresult results)
insertEdge initialresult c@(_, _, (SecVar u), _)           (Graph la edgesUp edgesDown results) =
                                                              let upList = M.insert u (getEdgeList edgesUp u) edgesUp
                                                                  downList = M.insert u (insertConstraint c $ getEdgeList edgesDown u) edgesDown
                                                               in Graph la upList downList (updateResults u initialresult results)
insertEdge initialResult c@(_, l, u, _)                    g@(Graph la edgesup edgesDown results) = if ((lessOrEq la) l u) 
                                                                                                     then g
                                                                                                     else error "Jikes"

                                                                                                
                                                               
insertEdge' :: Constraint -> Graph (Annotation, Annotation) -> Graph (Annotation, Annotation)
insertEdge' c@(_, (SecVar l), (SecVar u), _)  (Graph la edgesUp edgesDown results) = 
                                                  let upList = M.insert l (c:getEdgeList edgesUp l) edgesUp
                                                      downList = M.insert u (c:getEdgeList edgesDown u) edgesDown
                                                   in Graph la upList downList  $ updateResults u (bottom la, top la)  $ updateResults l (bottom la, top la) results
insertEdge' c@(_, (SecVar l), _, _)           (Graph la edgesUp edgesDown results) = 
                                                  let upList = M.insert l (insertConstraint c $ getEdgeList edgesUp l) edgesUp
                                                      downList = M.insert l (getEdgeList edgesDown l) edgesDown
                                                   in Graph la upList downList $ updateResults l (bottom la, top la) results
insertEdge' c@(_, _, (SecVar u), _)           (Graph la edgesUp edgesDown results) =
                                                 let upList = M.insert u (getEdgeList edgesUp u) edgesUp
                                                     downList = M.insert u (insertConstraint c $ getEdgeList edgesDown u) edgesDown
                                                  in Graph la upList downList $ updateResults u (bottom la, top la) results
insertEdge' c@(_, l, u, _)                    g@(Graph la _ _ _) =
                                                    if ((lessOrEq la) l u)
                                                        then g
                                                        else error "Grap l65, TODO"
                                                        
updateResults :: Ident -> a -> M.Map Ident a -> M.Map Ident a
updateResults i initialresult r = case (M.lookup i r) of
                                    (Just _) -> r
                                    Nothing -> M.insert i initialresult r
                                    
getResult :: Graph a -> Ident -> Maybe a
getResult (Graph _ _ _ m) i = M.lookup i m
    
getResultValue :: Show a => Graph a -> Ident -> a
getResultValue g i = case (getResult g i) of
                                    (Just a) -> a
                                    Nothing -> error $ "getResultValue\n" ++ show g ++ "\n" ++ show i

getEdgesDown :: Graph a -> Ident -> ConstraintEnvironment
getEdgesDown (Graph _ _ d _) a = case (M.lookup a d) of
                                        (Just c) -> c
                                        Nothing -> []

getEdgesUp :: Graph a -> Ident -> ConstraintEnvironment
getEdgesUp (Graph _ u _ _) a = case (M.lookup a u) of
                                    (Just c) -> c
                                    Nothing -> []

updateResultValue :: Graph a -> Ident -> a -> Graph a
updateResultValue (Graph l u d r) i r' = Graph l u d $ M.insert i r' r 

getResults :: Graph a -> M.Map Ident a
getResults (Graph _ _ _ r) = r

emptyGraph :: Lattice -> Graph a
emptyGraph l = Graph l M.empty M.empty M.empty

singlePointGraph :: Lattice -> Annotation -> Graph (Annotation, Annotation)
singlePointGraph l (SecVar i) = Graph l M.empty M.empty $ M.insert i (bottom l, top l) M.empty

tsum :: [(Int, Int)] -> Int                                                                        
tsum l = (sum $ map fst l) + (sum $ map snd l)

                   
cleanupEdges :: EdgeMap -> EdgeMap
cleanupEdges e = M.map removeDoubles e

removeEdge :: Constraint -> Graph a -> Graph a
removeEdge c@(_,l', u', _) (Graph l u d r) =  Graph l nu nd r 
    where 
        nu = case l' of
                (SecVar i) -> let edges = fromJust $ M.lookup i u
                               in M.insert i (removeFromList edges c) u
                _          -> u
        nd = case u' of
                (SecVar i) -> let edges = fromJust $ M.lookup i d
                               in M.insert i (removeFromList edges c) d
                _          -> d

constraintGeneratedAt :: [Int] -> Graph a -> ConstraintEnvironment
constraintGeneratedAt p g@(Graph _ u d _) = constraintGen' p
   where
       allConstraints = concat $ (M.elems u) ++ (M.elems d)
       constraintGen' (i:is) = foldr insertConstraint (constraintGen' is) $ filter (\(ps, _, _, _) -> elem i (map fst ps)) allConstraints
       constraintGen' []     = [] 
        
removeFromList :: ConstraintEnvironment -> Constraint -> ConstraintEnvironment
removeFromList env c = filter (not . equal c) env

edgesFromGraph :: Graph a -> ConstraintEnvironment
edgesFromGraph (Graph _ u d _) = mergeCEnv up down
 where    
    up = concat $ M.elems u
    down = concat $ M.elems d