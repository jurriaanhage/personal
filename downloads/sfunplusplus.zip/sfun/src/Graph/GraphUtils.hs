{-# LANGUAGE FlexibleInstances  #-}
module Graph.GraphUtils where
    
import qualified Data.Map as M
import Data.Maybe (fromJust)
import Graph.Graph
import Type.Substitution
import Type.Annotation

instance Substitutable (Graph (Annotation, Annotation)) where
    apply' Id _ _ g = g
    apply' (_ :-> _) _ _ g = g
    apply' (s2 :*: s1) bt ba g = apply' s2 bt ba $ apply' s1 bt ba g
    apply' s@(i :@-> a) bt boundAnn g@(Graph l u d r) = 
        case a of
            (SimpleLevel a) -> let
                                {-
                                This case is quite simple, as all edges occur twice in the graph we can safely remove all edges that
                                are pointed to by i. The other version is still at the node pointed to/from. We apply the substitution
                                to these nodes. This will leave the graph in a somewhat strange state, but not inconsistent. Might want
                                to create a cleanup function to get rid of this "problem".
                                -}
                                results  = M.map (apply' s bt boundAnn) $ M.delete i r
                                downList = M.map (apply' s bt boundAnn) $ M.delete i d
                                upList   = M.map (apply' s bt boundAnn) $ M.delete i u
                               in Graph l upList downList r
            (SecVar i')     -> let
                                results = case (M.lookup i r) of
                                            (Just v) -> case (M.lookup i' r) of
                                                         (Just someR) -> M.map (apply' s bt boundAnn) $ M.delete i r
                                                         Nothing      -> M.map (apply' s bt boundAnn) $ M.delete i $ M.insert i' v r
                                            Nothing  -> r 
                                upList   = case (M.lookup i u) of
                                            (Just someE) -> apply' s bt boundAnn someE
                                            Nothing      -> []
                                downList = case (M.lookup i d) of
                                            (Just someE) -> apply' s bt boundAnn someE
                                            Nothing      -> []
                                g' = foldr insertEdge' (Graph l (M.map (apply' s bt boundAnn) $ M.delete i u) 
                                                                (M.map (apply' s bt boundAnn) $ M.delete i d) results) (upList ++ downList)
                               in g'
                                
    
