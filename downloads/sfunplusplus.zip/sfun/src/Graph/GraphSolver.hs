{-# LANGUAGE ScopedTypeVariables #-}
--The type system extension is needed to provide better type signatures for inner functions.
module Graph.GraphSolver where
    
import Graph.Graph
import Graph.GraphUtils
import Error.Error
import Type.Lattice
import Type.Annotation
import Syntax.SyntaxBase
import Type.Substitution

import System.IO.Unsafe

import qualified Data.Map as M
import qualified Data.List as L

simplify' :: [Ident] -> Graph (Annotation, Annotation) -> ConstraintEnvironment -> Computation (Graph (Annotation, Annotation), Substitution, ConstraintEnvironment)
simplify' active g cEnv = do
                              range <- variableRange g cEnv
                              simple <- (fromRangeToSimple $ determinePseudoActive active range)
                              let (g, s) = (retrieveSubstitution simple)
                              return (apply s range, s, apply s cEnv)

simplify :: Lattice -> [Ident] -> ConstraintEnvironment -> Computation (Graph (Annotation, Annotation), Substitution, ConstraintEnvironment)
simplify lat active cEnv = do
                            range <- variableRange (initializeGraph lat cEnv (lower, upper)) cEnv
                            simple <- fromRangeToSimple $ determinePseudoActive active range 
                            let (g, s) = retrieveSubstitution simple
                            return (apply s range, s, apply s cEnv)
  where 
    upper = top lat
    lower = bottom lat

workList :: forall a. Eq a => Graph a -> (Graph a -> Ident -> Annotation -> Computation (a, ConstraintEnvironment)) 
                            -> (Graph a -> Ident -> Annotation -> Computation (a, ConstraintEnvironment)) 
                            -> ConstraintEnvironment -> Computation (Graph a)
workList graph upWard downWard work = workList' graph work
  where 
    workList' :: Graph a -> ConstraintEnvironment -> Computation (Graph a)
    workList' g []     = return g
    workList' g (c:cs) = do 
                          (gr, w) <- case c of
                                      (_, a@(SimpleLevel l), SecVar i, _) -> do
                                                                            (r', w') <- upWard g i a
                                                                            return (updateResultValue g i r', w') 
                                      (_, SecVar i, a@(SimpleLevel r), _) -> do 
                                                                            (r', w') <- downWard g i a
                                                                            return (updateResultValue g i r', w')
                                      (_, l@(SecVar i), r@(SecVar i'), _)         -> do 
                                                                                   (r', w') <- upWard g i' l
                                                                                   let g' = updateResultValue g i' r'
                                                                                   (r'', w'') <- downWard g' i r
                                                                                   let g'' = updateResultValue g' i r''
                                                                                   return (g'', w' ++ w'')
                                      (_, _, _, _)                         -> return  (g, [])
                          workList' gr (w++cs)
                            
                            
variableRange :: Graph (Annotation, Annotation) -> ConstraintEnvironment -> Computation (Graph (Annotation, Annotation))
variableRange g@(Graph lat _ _ _) c = workList g up down c
    where
        isLess = lessOrEq lat
        leastUpper    = leastUpperBound lat
        greatestLower = greatestLowerBound lat
        --The up function propogates changes in lowerbounds upwards through the graph
        --It takes the graph, the node that it is applied to, proposed new level as arguments and returns
        -- a computation with new results and new work.
        up :: Graph (Annotation, Annotation) -> Ident -> Annotation   -> Computation ((Annotation, Annotation), ConstraintEnvironment)
        up g i n@(SimpleLevel _) = let  (l, u) = getResultValue g i
                                        newValue = leastUpper n l
                                    in case (l == newValue) of
                                         False ->  return ((newValue, u), getEdgesUp g i)
                                         True  -> return ((l, u), [])
        up g i n@(SecVar i')      = up g i $ fst (getResultValue g i')  
        --The down function propogates changes in upperbounds downwards through the graph
        --It takes the graph, the node that it is is applied to, proposed new level as arguments and returns
        -- a computation with new results and new work.
        down :: Graph (Annotation, Annotation) -> Ident -> Annotation -> Computation ((Annotation, Annotation), ConstraintEnvironment)
        down g i n@(SimpleLevel _) = let (l, u) = getResultValue g i
                                         newValue = greatestLower n u
                                      in case (u == newValue) of
                                             False -> return ((l, newValue), getEdgesDown g i)
                                             True  -> return ((l, u), [])
        down g i n@(SecVar i')     = down g i $ snd (getResultValue g i')    

determinePseudoActive :: [Ident] -> Graph (Annotation, Annotation) -> Graph (Annotation, Annotation, Bool)
determinePseudoActive active g@(Graph l u d r) = Graph l u d $ M.mapWithKey (\k (low, up) -> (low, up, isActive k [])) r
    where
        isActive :: Ident -> [Ident] -> Bool
        isActive i c | elem i active = True
                     | otherwise     = case (getEdgesDown g i) of
                                            [] -> False
                                            edges -> or $ map (\e -> case e of
                                                                        (_, (SecVar i'), _, _) -> (not $ elem i c) && (isActive i' (i:c))
                                                                        _                      -> False) edges


fromRangeToSimple :: Graph (Annotation, Annotation, Bool) -> Computation (Graph (Annotation, Substitution))
fromRangeToSimple g@(Graph l u d r) = graphResultMap convert g
    where
        isBelow :: Annotation -> Annotation -> Bool
        isBelow = lessOrEq l 
        convert :: Ident -> (Annotation, Annotation, Bool) -> Computation (Annotation, Substitution)
        convert i (l, u, a) | l == u      = return (l, i :@-> l)
                            | isBelow l u = case (a) of
                                            True -> return (SecVar i, Id)
                                            False -> return (l, i :@-> l)
                            | otherwise   = Left $ OutOfRange g i
        
                                            
graphResultMap :: (Ident -> (Annotation, Annotation, Bool) -> Computation b) -> Graph (Annotation, Annotation, Bool) -> Computation (Graph b)
graphResultMap f g@(Graph l u d r) = let r' = sequenceMap $ M.mapWithKey f r
                                      in case r' of
                                        (Right m) -> return (Graph l u d m)
                                        (Left err)  -> Left (GraphOutOfRange (case err of
                                                                                (MultipleErrors errs) -> errs
                                                                                _                     -> [err]) g)
   where
       sequenceMap :: M.Map Ident (Computation a) -> Computation (M.Map Ident a)
       sequenceMap m = foldr insertInMap (return M.empty) $ M.assocs m
       insertInMap :: (Ident, Computation a) -> Computation (M.Map Ident a) -> Computation (M.Map Ident a)
       insertInMap (i, (Right v))  (Right m)  = return $ M.insert i v m
       insertInMap (i, (Right v))  (Left m)   = Left m
       insertInMap (_, (Left v))   e@(Left m) = intoError e v
       insertInMap (_, (Left err)) _          = Left err

retrieveSubstitution :: Graph (Annotation, Substitution) -> (Graph Annotation, Substitution)
retrieveSubstitution (Graph l u d r) = (\(m, s) -> (Graph l u d m, s)) $ foldr (\(i, (v, s)) (l, s') -> (M.insert i v l, combineSubstitution s s')) (M.empty, Id) $ M.assocs r

combineSubstitution :: Substitution -> Substitution -> Substitution
combineSubstitution Id a = a
combineSubstitution a Id = a
combineSubstitution a s  = a :*: s

mergeGraphs :: Graph (Annotation, Annotation) -> Graph (Annotation, Annotation) -> Graph (Annotation, Annotation)
mergeGraphs (Graph l1 u1 d1 r1) (Graph l2 u2 d2 r2) = Graph l1 (mergeEdges u1 u2) (mergeEdges d1 d2) (mergeResults l1 r1 r2)

mergeEdges :: EdgeMap -> EdgeMap -> EdgeMap
mergeEdges e1 e2 = foldr addEdges e2 $ M.assocs e1 
  where 
   addEdges :: (Ident, [Constraint]) -> EdgeMap -> EdgeMap
   addEdges (i, cs) em = case M.lookup i em of
                            (Just l) -> M.insert i (foldr insertConstraint cs l) em
                            Nothing  -> M.insert i cs em

mergeResults :: Lattice -> M.Map Ident (Annotation, Annotation) -> M.Map Ident (Annotation, Annotation) -> M.Map Ident (Annotation, Annotation)
mergeResults l r1 r2 = M.unionWith (combine l) r1 r2
 where
  combine :: Lattice -> (Annotation, Annotation) -> (Annotation, Annotation) -> (Annotation, Annotation)
  combine l (l1, u1) (l2, u2) = (leastUpperBound l l1 l2, greatestLowerBound l u1 u2)