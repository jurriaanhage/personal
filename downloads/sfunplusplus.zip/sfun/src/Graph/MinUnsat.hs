module Graph.MinUnsat where
    
import Data.List as L

import Graph.Graph
import Graph.GraphSolver
import Error.Error
import Type.Annotation
import Type.Lattice

minUnsat :: Lattice -> ConstraintEnvironment -> ConstraintEnvironment
minUnsat lat cEnv = outer cEnv []
    where
        outer :: ConstraintEnvironment -> ConstraintEnvironment -> ConstraintEnvironment
        outer d m = let c = inner m d
                        m' = (head c):m
                     in if satisfiable m'    then outer c m' else m'
        inner :: ConstraintEnvironment -> ConstraintEnvironment -> ConstraintEnvironment
        inner c d = let c' = (head $ L.deleteFirstsBy cEq d c):c
                     in if satisfiable c' then inner c' d else c'
        satisfiable :: ConstraintEnvironment -> Bool
        satisfiable cEnv = isSuccess $ simplify lat [] cEnv
        cEq :: Constraint -> Constraint -> Bool
        cEq (_, l1, u1, _) (_, l2, u2, _) = l1 == l2 && u1 == u2
