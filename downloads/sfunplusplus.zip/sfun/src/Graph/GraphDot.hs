module Graph.GraphDot where
    
import Graph.Graph
import Type.Annotation
import Syntax.SyntaxBase
import System.Directory
import Type.Type
import qualified Data.Map as M
import qualified Data.List as L

fileExtension = "dot"
filePath = ""

class Attribute a where
    showAttribute :: ([Ident], [Ident]) -> (Ident, a) -> String
    
instance (Show a, Show b) => Attribute (a, b) where
    showAttribute (a, p) (i, (l, u)) = let color = case elem i a of
                                                    True  -> "red"
                                                    False -> case elem i p of
                                                                True  -> "blue"
                                                                False -> "black"
                                    in "\t" ++ i ++ " [shape=record," 
                                                ++ "color=" ++ color ++ "," 
                                                ++ "label=\"<f0> " 
                                                ++ (show l) ++ "|<f1> " 
                                                ++ i        ++ "|<f2> "
                                                ++ (show u) ++ "\"];"

writeGraph :: Graph a -> IO ()
writeGraph g@(Graph l u d r) = writeToFile "Dump" $ (graphHeader "Dump")
                 ++ (edges $ cleanupEdges d)
                 ++ graphClose

writeErrorGraph :: ConstraintEnvironment -> IO ()
writeErrorGraph cs = do
                        let graph = (graphHeader "Error")
                                     ++ edge' cs
                                     ++ graphClose
                        writeToFile "Error" graph

writeToFile :: Ident -> String -> IO ()
writeToFile i s = do
                    fileName <- makeFileName i 0
                    writeFile fileName s

writeGraphFile :: Attribute a => Ident -> Annotation -> Graph a -> TypeScheme -> IO ()
writeGraphFile i a g ts = do
                            let boundVar = boundAnnVar ts
                            writeToFile i $ makeGraph i a g boundVar

makeFileName :: String -> Int -> IO String
makeFileName f i = do
                    let fileName = filePath ++ f ++ show i ++ "." ++ fileExtension
                    e <- doesFileExist fileName
                    case e of
                        True  -> makeFileName f $ i + 1
                        False -> return fileName 

makeGraph :: Attribute a => Ident -> Annotation -> Graph a -> ([Ident],[Ident]) -> String
makeGraph function ann (Graph l u d r) b = (graphHeader function) 
                                            ++ nodeLabels r b
                                            ++ (edges $ cleanupEdges u)
                                            ++ graphClose 

nodeLabels :: Attribute a => M.Map Ident a -> ([Ident],[Ident]) -> String
nodeLabels m b = unlines $ map (showAttribute b) $ M.assocs m 

edges :: M.Map Ident ConstraintEnvironment -> String
edges e = unlines $ map edge $ M.assocs e
     
edge :: (Ident, ConstraintEnvironment) -> String
edge (i, cs) = edge' cs
    
edge' :: ConstraintEnvironment -> String
edge' ((p, l, u, w):cs) = show u ++ " -> " ++ show l ++ "[label=\"" ++ (show $ L.nub p) ++ " " ++ (show w) ++"\"];\n" ++ edge' cs  
edge' []             = ""

graphHeader :: Ident -> String
graphHeader name = "diGraph " ++ name ++ " { \n"

graphClose :: String
graphClose = "}"