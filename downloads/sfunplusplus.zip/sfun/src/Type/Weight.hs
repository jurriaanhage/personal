module Type.Weight where
    
data Weight
    = Infinite
    | Weight Int
 deriving (Eq, Show)

instance Ord Weight where
    compare Infinite (Weight _) = GT
    compare (Weight _) Infinite = LT
    compare (Weight x) (Weight y) = compare x y
    compare Infinite Infinite = EQ

instWeight = Weight instTrust
consWeight = Weight consTrust
appWeight = Weight appTrust
polyAppWeight = Weight polyAppTrust
letWeight = Infinite
ifWeight = Weight defaultTrust
thenWeight = Weight defaultTrust
elseWeight = Weight defaultTrust
opWeight = Weight defaultTrust
tupWeight = Weight defaultTrust
nullWeight = Weight defaultTrust
headWeight = Weight defaultTrust
tailWeight = Weight defaultTrust
declWeightO = Weight defaultTrust         -- The amount of trust in the result of declass
declWeightI = Weight declTrust -- The amount of trust in declassifying something that should not have had
protWeightO = Weight defaultTrust
protWeightI = Weight protTrust

instTrust = 10
consTrust = 7
appTrust = 2
declTrust = 4
protTrust = 4
defaultTrust = 4
polyAppTrust = 7

