module Type.TypeUtil where
    
import qualified Data.Set as S
import Data.Maybe (isJust)

import Type.Type
import Type.Substitution
import Type.Annotation
import Type.ContextReduction
import Error.Error
import Graph.Graph
import Graph.GraphUtils
import Type.TypeEnvironment
import Syntax.SyntaxBase
import Type.Lattice
import Type.Weight
import Syntax.SyntaxBase

class Unifiable a where
    unify :: a -> a -> Substitution

instance Unifiable Type where
 -- Unify two types
 --unify :: Type ->       Type ->            Substitution
  unify TyInt            TyInt            = Id
  unify TyBool           TyBool           = Id
  unify (TyList t1 a1)   (TyList t2 a2)   = let subst = (unify t1 t2)
                                                substa = unify (apply subst a1) (apply subst a2)
                                             in substa :*: subst 
  unify (TyPair t11 a11 t12 a12) (TyPair t21 a21 t22 a22) 
                                          = let subst1 = unify t11 t21
                                                substa1 = unify (apply subst1 a11) (apply subst1 a21)
                                                subst2 = unify (apply (substa1 :*: subst1) t12) (apply (substa1 :*: subst1) t22)
                                                substa2 = unify (apply (subst2 :*: substa1 :*: subst1) a12) (apply (subst2 :*: substa1 :*: subst1) a22)
                                             in substa2 :*: subst2 :*: substa1 :*: subst1
  unify (TyFn t11 a11 t12 a12) (TyFn t21 a21 t22 a22)   
                                          = let subst1 = unify t11 t21
                                                substa1 = unify (apply subst1 a11) (apply subst1 a21)
                                                subst2 = unify (apply (substa1 :*: subst1) t12) (apply (substa1 :*: subst1) t22)
                                                substa2 = unify (apply (subst2 :*: substa1 :*: subst1) a12) (apply (subst2 :*: substa1 :*: subst1) a22)
                                             in substa2 :*: subst2 :*: substa1 :*: subst1
  unify a                v@(TyVar i)      = if (v == a || i `S.notMember` (ftv a S.empty) ) 
                                                  then i :-> a
                                                  else error $ "Unification error: type variable in function" ++ (show a) ++ "**" ++ (show v)
  unify v@(TyVar i)        a              = if (v == a || i `S.notMember` (ftv a S.empty) ) 
                                                  then i :-> a
                                                  else error $ "Unification error: type variable in function" ++ (show a) ++ "**" ++ (show v)
  unify l                r                = error $ "Unification error: no more patterns " ++ (show l) ++ "**" ++ (show r)

instance Unifiable Annotation where
  unify (SimpleLevel i1) (SimpleLevel i2) | i1 == i2   = Id
                                          | otherwise  = error $ "Cannot unify annotations: " ++ i1 ++ " " ++ i2
  unify a                v@(SecVar i)     = i :@-> a
  unify v@(SecVar i)     a                = i :@-> a
--  unify l                r                = error $ "Unification error: no more patterns: " ++ (show l) ++ "**" ++ (show r)
  
--Instantiation and generalisation functions for types
--First argument is the unique variables supply
inst :: Int -> Int -> TypeScheme -> Graph (Annotation, Annotation) -> (QualType, Graph (Annotation, Annotation), Int)
inst node curr ty g = let (qt@(Qual cs _), subst, i) = inst' node (curr + 1) ty
                       in (qt, foldr insertEdge' (apply subst g) cs, i)
 where 
     inst' :: Int -> Int -> TypeScheme -> (QualType, Substitution, Int)
     inst' n unique (TySchUniQTy i t) = (rq, s :*: subst, c)
      where (curr, next) = (unique, unique + 1)
            subst = i :-> (TyVar $ "a" ++ (show curr))
            (rq, s, c) = inst' n next $ apply subst t
     inst' n unique (TySchUniQAnn i t) = (rq, s :*: subst, c)
      where (curr, next) = (unique, unique + 1)
            subst = i :@-> (SecVar $ "b" ++ (show curr))
            (rq, s, c) = inst' n next $ apply subst t
     inst' n unique (TySchExiAnn i t) = (rq, s :*: subst, c)
      where (curr, next) = (unique, unique + 1)
            subst = i :@-> (SecVar $ "b" ++ (show curr))
            (rq, s, c) = inst' n next $ apply subst t
     inst' n unique (TySchTy t)     = ((Qual (cs ++ cs1) ty'), Id, curr)
      where (cs, ty)  = (\(Qual cs ty) -> (cs, ty)) t
            (cs1, ty', curr) = instT n unique ty
     instT :: Int -> Int -> Type -> (ConstraintEnvironment, Type, Int)
     instT n u (TyFn t1 a1 t2 a2) = (c1 ++ c3, TyFn t1' a1 t2' a2, u3)
       where (c1, t1', u1) = instT n u t1
             (c3, t2', u3) = instT n u1 t2
     instT n u (TyPair t1 a1 t2 a2) = (c1 ++ c2 ++ c3 ++ c4, TyPair t1' a1' t2' a2', u4)
       where (c1, t1', u1) = instT n u t1
             (c2, a1', u2) = instA n u1 a1
             (c3, t2', u3) = instT n u2 t2
             (c4, a2', u4) = instA n u3 a2
     instT n u (TyList t1 a1) = (c1 ++ c2, TyList t1' a1', u2)
       where (c1, t1', u1) = instT n u t1
             (c2, a1', u2) = instA n u1 a1
     instT n u t = ([], t, u)
     instA :: Int -> Int -> Annotation -> (ConstraintEnvironment, Annotation, Int)
     instA n u c@(SimpleLevel l) = (cs, b, u')
      where
          b = SecVar $ "b" ++ (show u)
          cs = [([(n, NLetGen)], c, b, instWeight), ([(n, NLetGen)], b, c, instWeight)]
          u' = u+1
     instA _ u a = ([], a, u)
generaliseResults :: TypeEnvironment -> Annotation -> Type -> ConstraintEnvironment -> ReductionResult -> (TypeScheme, ConstraintEnvironment, Graph (Annotation, Annotation), Substitution, Annotation, Bool)
generaliseResults env ann ty cEnv (toTau, toGam, s, g) = 
                              let newTy  = apply s ty
                                  newEnv = apply s env
                                  newAnn = apply s ann
                                  envAnnVars = fav newEnv S.empty
                                  tyAUniVars = (fav newTy S.empty) S.\\ envAnnVars
                                  annAVar    = fav newTy S.empty 
                                  tyAExiVars = fav toTau $ (envAnnVars `S.union` tyAUniVars `S.union` annAVar)
                                  envVars = ftv newEnv S.empty
                                  tyVars = (ftv newTy S.empty) S.\\ envVars
                                  annS = instantiateAnn (envAnnVars `S.union` tyAUniVars) g newAnn
                                  tySch = foldr TySchUniQTy (
                                            foldr TySchUniQAnn (
                                              foldr TySchExiAnn (TySchTy $ Qual toTau newTy) $ S.toList tyAExiVars
                                                               ) $ S.toList tyAUniVars
                                                            ) $ S.toList tyVars
                              in (apply annS tySch, apply annS toGam, apply annS g, annS :*: s, apply annS newAnn, isPolyVariant tySch)
                         
instantiateAnn :: S.Set Ident -> Graph (Annotation, Annotation) -> Annotation -> Substitution
instantiateAnn bound g@(Graph l _ _ r) (SecVar i) = case S.member i bound of
                                                        True  -> Id
                                                        False -> case getResult g i of
                                                                    Nothing     -> i :@-> bottom l
                                                                    Just (a, b) -> i :@-> a
instantiateAnn _     _                 _          = Id
