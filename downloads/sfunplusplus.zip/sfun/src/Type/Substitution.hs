{-# LANGUAGE TypeSynonymInstances, FlexibleInstances #-}
module Type.Substitution where

import Data.Set (Set)
import qualified Data.Set as S

import Syntax.SyntaxBase
import Type.Type
import Type.Annotation

--Substitutions are constructed with infix constructors 
infixr 7 :*:
infix  8 :->
infix  8 :@->

--Datatype for substitutions 
data Substitution
      = Ident :-> Type
      | Ident :@-> Annotation
      | Substitution :*: Substitution
      | Id
     deriving Show
     
class Substitutable a where
    apply' :: Substitution -> Set Ident -> Set Ident -> a -> a


apply :: Substitutable a => Substitution -> a -> a
apply s env = apply' s S.empty S.empty env

instance Substitutable Annotation where
    apply' sub boundTy boundAnn l@(SimpleLevel _)     = l
    apply' sub boundTy boundAnn l@(SecVar i)    | S.member i boundAnn = l
                                                | otherwise           = doSubstitution sub boundTy boundAnn l
      where
          doSubstitution :: Substitution -> Set Ident -> Set Ident -> Annotation -> Annotation
          doSubstitution (s1 :*: s2) bT bA v        = apply' s1 bT bA $ doSubstitution s2 bT bA v
          doSubstitution Id          _  _  v        = v
          doSubstitution (_ :-> _)   _  _  v        = v
          doSubstitution (i :@-> a)  _  _  v@(SecVar i2) | i == i2   = a
                                                         | otherwise = v

instance (Substitutable a, Substitutable b) => Substitutable (a, b) where
    apply' sub boundTy boundAnn (a, b) = (apply' sub boundTy boundAnn a, apply' sub boundTy boundAnn b)
    
instance Substitutable Type where
     apply' sub boundTy boundAnn TyInt                = TyInt
     apply' sub boundTy boundAnn TyBool               = TyBool
     apply' sub boundTy boundAnn (TyFn t1 a1 t2 a2)   = TyFn (apply' sub boundTy boundAnn t1) (apply' sub boundTy boundAnn a1) (apply' sub boundTy boundAnn t2) (apply' sub boundTy boundAnn a2)
     apply' sub boundTy boundAnn (TyList t a)         = TyList (apply' sub boundTy boundAnn t) (apply' sub boundTy boundAnn a) 
     apply' sub boundTy boundAnn (TyPair t1 a1 t2 a2) = TyPair (apply' sub boundTy boundAnn t1) (apply' sub boundTy boundAnn a1) (apply' sub boundTy boundAnn t2) (apply' sub boundTy boundAnn a2)
     apply' sub boundTy boundAnn v@(TyVar i)          | S.member i boundTy = v
                                                      | otherwise          = doSubstitution sub boundTy boundAnn v
      where
         doSubstitution :: Substitution -> Set Ident -> Set Ident-> Type -> Type
         doSubstitution (s1 :*: s2) bT bA v                    = apply' s1 bT bA $ doSubstitution s2 bT bA v
         doSubstitution Id          _  _  v                    = v
         doSubstitution (_ :@-> _)  _  _  v                    = v
         doSubstitution (i :-> t)   _  _  v@(TyVar i2) | i == i2   = t
                                                       | otherwise = v

instance Substitutable TypeScheme where
    apply' sub boundTy boundAnn (TySchUniQTy i t)  = TySchUniQTy i $ apply' sub (S.insert i boundTy) boundAnn t
    apply' sub boundTy boundAnn (TySchUniQAnn i t) = TySchUniQAnn i $ apply' sub boundTy (S.insert i boundAnn) t
    apply' sub boundTy boundAnn (TySchExiAnn i t)  = TySchExiAnn i $ apply' sub boundTy (S.insert i boundAnn) t 
    apply' sub boundTy boundAnn (TySchTy t)        = TySchTy $ apply' sub boundTy boundAnn t
    
instance Substitutable QualType where
    apply' sub boundTy boundAnn (Qual cs t) = Qual (map (apply' sub boundTy boundAnn) cs) (apply' sub boundTy boundAnn t)
    
instance Substitutable Constraint where
    apply' sub boundTy boundAnn (p, c1, c2, w) = (p, apply' sub boundTy boundAnn c1, apply' sub boundTy boundAnn c2, w)
    
instance Substitutable ConstraintEnvironment where
    apply' sub boundTy boundAnn e = map (apply' sub boundTy boundAnn) e