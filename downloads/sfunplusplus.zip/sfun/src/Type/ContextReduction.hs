module Type.ContextReduction where

import qualified Data.Set as S
import qualified Data.Map as M
import qualified Data.List as L
import Data.Maybe
import Type.Annotation
import Type.Lattice
import Error.Error
import Type.Type
import Type.Substitution
import Syntax.SyntaxBase
import Graph.Graph
import Graph.GraphSolver
import Type.TypeEnvironment
import Util


import UU.Scanner.Position
import System.IO.Unsafe

type ReductionResult = (ConstraintEnvironment, ConstraintEnvironment, Substitution, Graph (Annotation, Annotation))

{-
In order not to have drag the lattice around through the rest of the application the currentLattice variable contains the
lattice the application will work with.
-}
partition :: [Ident] -> ConstraintEnvironment -> (ConstraintEnvironment, ConstraintEnvironment)
partition activeGam = foldr toPartition ([], []) 
  where   
      isGammaPartition :: Constraint -> Bool
      isGammaPartition (_, (SecVar i1), (SecVar i2), _) = elem i1 activeGam && elem i2 activeGam
      isGammaPartition (_, (SecVar i1), _, _)           = elem i1 activeGam
      isGammaPartition (_, _, (SecVar i2), _)           = elem i2 activeGam
      isGammaPartition _                                = False
      toPartition :: Constraint -> (ConstraintEnvironment, ConstraintEnvironment) -> (ConstraintEnvironment, ConstraintEnvironment)
      toPartition c (tau, gam) = if (isGammaPartition c) then (tau, c:gam) else (c:tau, gam)

contextReduction' :: TypeEnvironment -> ConstraintEnvironment -> Type -> Annotation -> Graph (Annotation, Annotation) -> Computation ReductionResult
contextReduction' gamma cEnv ty ann g@(Graph lat _ _ _) = do  
                                           let  
                                               freeInGam  = fav gamma S.empty
                                               freeIncEnv = fav cEnv S.empty
                                               freeInTy   = fav ty S.empty
                                               noDuplicates = removeDoubles cEnv
                                           --noTrivial <- removeTrivialConstraints lat cEnv
                                           (graph, subst, simplified) <- simplify' (S.toList $ S.union freeInGam freeInTy) g cEnv
                                           let noDoubles' = removeDoubles $ apply subst cEnv
                                               noTrivial' = removeTrivialConstraints lat noDoubles'
                                           let (toTau, toGam) = flip partition noTrivial' $ S.toList freeInGam
                                           return (toTau, toGam, subst, graph)

                      
getValue :: Annotation -> M.Map Ident (Either Annotation [Ident]) -> Either Annotation [Ident]
getValue v@(SimpleLevel _) _ = Left v
getValue (SecVar i)        m = case (M.lookup i m) of
                                    Nothing -> error $ "Error ContextReduction.hs line 109 when looking for value of " ++ (show i)
                                    (Just l@(Left _)) -> l
                                    (Just (Right _))  -> Right [i] 

-- Remove trivial constraints.
-- Trivial constraints are constraints (_, a, b) where
--              a == b
--              a == Bottom
--              b == Top
--              both a and b are non variable (either remove such a constraint or produce an error if a not below b)
-- it appears to be conventional to have the error in the left constructor

removeTrivialConstraints :: Lattice -> ConstraintEnvironment -> ConstraintEnvironment
removeTrivialConstraints lat cs = let filtered = [c | c <- cs, not $ removable c]
                                      nonVars = filter bothNonVariable filtered
                                   in filter (\v -> not $ bothNonVariable v) filtered

    where 
        removable = (\c -> isBottomBelowConstraint lat c || isBelowTopConstraint lat c || nonConstrainingConstraint c)
       
            
isBottomBelowConstraint :: Lattice -> Constraint -> Bool
isBottomBelowConstraint lat (_, a, _, _)   = a == (bottom lat)

isBelowTopConstraint :: Lattice -> Constraint -> Bool
isBelowTopConstraint lat (_, _, a, _)      = a == (top lat)

nonConstrainingConstraint :: Constraint -> Bool
nonConstrainingConstraint (_, a, b, _)    = a == b

bothNonVariable :: Constraint -> Bool
bothNonVariable (_, a, b, _)   = case (a, b) of
                                (SimpleLevel _, SimpleLevel _) -> True
                                (_,_)                          -> False  