{-# LANGUAGE TypeSynonymInstances, FlexibleInstances #-}
module Type.Type where

import Data.Map (Map, insert, empty)
import Data.Set (Set)
import Data.List(intersperse)
import qualified Data.Map as M
import qualified Data.Set as S


import Util
import Syntax.SyntaxBase
import Type.Annotation
    
--Data type that describes types        
data Type
    = TyInt
    | TyBool 
    | TyFn   Type Annotation Type Annotation
    | TyVar  Ident
    | TyList Type Annotation
    | TyPair Type Annotation Type Annotation
    deriving (Show, Eq)
    

data QualType
    = Qual [Constraint] Type
    deriving (Show, Eq)
    
--Datatype that describes type schemes
data TypeScheme
    = TySchUniQTy Ident TypeScheme
    | TySchUniQAnn Ident TypeScheme
    | TySchExiAnn Ident TypeScheme
    | TySchTy QualType
    deriving (Show, Eq)
    
--These function decompose function types
domain :: Type -> Type
domain (TyFn d _ _ _)   = d
domain _            = error "Not a function type"

domainAnn :: Type -> Annotation
domainAnn (TyFn _ a _ _) = a
domainAnn _              = error "Not a function type"
 
coDomain :: Type -> Type
coDomain (TyFn _ _ c _) = c
coDomain _          = error "Not a function type"

coDomainAnn :: Type -> Annotation
coDomainAnn (TyFn _ _ _ ca) = ca
coDomainAnn _               = error "Not a function type"

qualToTuple :: QualType -> ([Constraint], Type)
qualToTuple (Qual c qt) = (c, qt)

boundAnnVar :: TypeScheme -> ([Ident], [Ident])
boundAnnVar (TySchUniQTy _ t)   = boundAnnVar t
boundAnnVar (TySchUniQAnn i t)  = (\(a, p) -> (i:a, p)) (boundAnnVar t)
boundAnnVar (TySchExiAnn i t)   = (\(a, p) -> (a, i:p)) (boundAnnVar t)
boundAnnVar (TySchTy _)         = ([], [])     
   
isPolyVariant :: VarContainer a => a -> Bool
isPolyVariant a = isPolyVariant' a S.empty
      
class VarContainer a where
  ftv :: a -> Set Ident -> Set Ident
  fav :: a -> Set Ident -> Set Ident
  isPolyVariant' :: a -> Set Ident -> Bool
  

instance VarContainer ConstraintEnvironment where
    ftv _ _ = S.empty
    fav cEnv bound = S.unions $ map (\c -> fav c bound) cEnv
    isPolyVariant' cEnv b = all (flip isPolyVariant' b) cEnv
      
instance VarContainer Constraint where
    ftv _ _ = S.empty
    fav (_, a1, a2, _) bound = (fav a1 bound) `S.union` (fav a2 bound)
    isPolyVariant' (_, a1, a2, _) b = isPolyVariant' a1 b && isPolyVariant' a2 b
        
instance VarContainer Annotation where
 ftv _ _ = S.empty
 --fav
 fav (SimpleLevel _) bound = S.empty
 fav (SecVar i)      bound | S.member i bound = S.empty
                           | otherwise        = S.singleton i
 isPolyVariant' (SecVar i) b = S.member i b
 isPolyVariant' _          _ = False

instance VarContainer Type where
  ftv TyInt               bound = S.empty
  ftv TyBool              bound = S.empty
  ftv (TyFn t1 _ t2 _)    bound = S.union (ftv t1 bound) (ftv t2 bound)
  ftv (TyVar i)           bound | S.member i bound = S.empty
                                | otherwise        = S.singleton i
  ftv (TyList t _)        bound = ftv t bound
  ftv (TyPair t1 _ t2 _ ) bound = S.union (ftv t1 bound) (ftv t2 bound)
  --fav
  fav TyInt               bound = S.empty
  fav TyBool              bound = S.empty
  fav (TyFn t1 a1 t2 a2)  bound = (fav t1 bound) `S.union` (fav a1 bound) `S.union` (fav t2 bound) `S.union` (fav a2 bound)
  fav (TyVar _)           bound = S.empty
  fav (TyList t a)        bound = (fav t bound) `S.union` (fav a bound)
  fav (TyPair t1 a1 t2 a2) bound = (fav t1 bound) `S.union` (fav a1 bound) `S.union` (fav t2 bound) `S.union` (fav a2 bound)
  isPolyVariant' (TyFn t1 a1 t2 a2) b = isPolyVariant' t1 b && isPolyVariant' a1 b && isPolyVariant' t2 b && isPolyVariant' a2 b
  isPolyVariant' (TyList t a) b = isPolyVariant' t b && isPolyVariant' a b
  isPolyVariant' (TyPair t1 a1 t2 a2) b = isPolyVariant' t1 b && isPolyVariant' a1 b && isPolyVariant' t2 b && isPolyVariant' a2 b
  isPolyVariant' _ _ = True
  
  

instance VarContainer QualType where
    ftv (Qual _ t) bound = ftv t bound
    --fav
    fav (Qual c t) bound = S.unions $ (fav t bound):(map (\c -> fav c bound) c)
    isPolyVariant' (Qual c t) b = isPolyVariant' c b && isPolyVariant' t b 
    
instance VarContainer TypeScheme where
  ftv (TySchUniQTy i t)  bound = ftv t (S.insert i bound)
  ftv (TySchUniQAnn _ t) bound = ftv t bound
  ftv (TySchTy t)        bound = ftv t bound
  ftv (TySchExiAnn _ t)  bound = ftv t bound
  --fav
  fav (TySchUniQTy _ t)  bound = fav t bound
  fav (TySchUniQAnn i t) bound = fav t (S.insert i bound)
  fav (TySchTy t)        bound = fav t bound
  fav (TySchExiAnn i t)  bound = fav t (S.insert i bound) 
  --isPolyVariant
  isPolyVariant' (TySchUniQTy _ t) b = isPolyVariant' t b
  isPolyVariant' (TySchUniQAnn i t) b = isPolyVariant' t $ S.insert i b
  isPolyVariant' (TySchTy t) b = isPolyVariant' t b
  isPolyVariant' (TySchExiAnn i t) b = isPolyVariant' t $ S.insert i b  


{-Pretty -}


{-
= SimpleLevel Ident
| SecVar Ident
| SetLevel [Ident]
-}    
instance Syntax Annotation where
    syntax (SimpleLevel i)  = i
    syntax (SecVar i)       = i
    
instance Syntax TypeScheme where
 syntax (TySchUniQTy i t) = "forall " ++ i ++ ". " ++ (syntax t)
 syntax (TySchUniQAnn i t) = "forall " ++ i ++ ". " ++ syntax t
 syntax (TySchExiAnn i t) = "exists " ++ i ++ ". " ++ syntax t
 syntax (TySchTy t)     = syntax t 
 
instance Syntax Constraint where
    syntax (_, a1, a2, _) = (syntax a1) ++ " < " ++ (syntax a2)

instance Syntax QualType where
    syntax (Qual c q) = "(" ++ (unwords $ intersperse ", " (map syntax c)) ++ ") => " ++ syntax q
    
instance Syntax Type where
 syntax TyInt          = "Int"
 syntax TyBool         = "Bool"
 syntax (TyFn t1 a1 t2 a2)   = case (t1) of
                                TyFn _ _ _ _ -> "(" ++ (syntax t1) ++ ")"
                                _        -> syntax t1
                       ++ "@" ++ (syntax a1) ++ " -> " ++ (syntax t2) ++ "@" ++ (syntax a2)
 syntax (TyVar i)      = i
 syntax (TyList t a)     = "List " ++ (syntax t) ++ "@" ++ (syntax a)
 syntax (TyPair t1 a1 t2 a2) = "(" ++ (syntax t1) ++ "@" ++ (syntax a1) ++ ", " ++ (syntax t2) ++ "@" ++ (syntax a2) ++ ")"
 