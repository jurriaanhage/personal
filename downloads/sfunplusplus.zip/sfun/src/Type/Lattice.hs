module Type.Lattice where

import Type.Annotation

data Lattice = Lattice {lattice :: [(Annotation, Annotation)], 
                        bottom :: Annotation, 
                        top :: Annotation, 
                        lessOrEq :: Annotation -> Annotation -> Bool,
                        leastUpperBound :: Annotation -> Annotation -> Annotation,
                        greatestLowerBound :: Annotation -> Annotation -> Annotation}

constraintsExist :: Lattice -> ConstraintEnvironment -> Either ConstraintEnvironment ConstraintEnvironment
constraintsExist la cEnv = let illegal = filter (not . lessThen) cEnv
                           in case illegal of
                                []          -> Right cEnv
                                _           -> Left illegal
    where lessThen (_, (SecVar _), _, _) = True
          lessThen (_, _, (SecVar _), _) = True
          lessThen (_, l, u, _)          =  (lessOrEq la) l u
{-bit of a useless instance, but i need it for debugging purposes-}
instance Show Lattice where
    show _ = "Some lattice "

simpleLattice :: Lattice
simpleLattice = Lattice [(SimpleLevel "Low", SimpleLevel "High")] (SimpleLevel "Low")  (SimpleLevel "High") isBelow' leastUpper greatestLower
 where 
    isBelow' :: Annotation -> Annotation -> Bool
    isBelow' (SimpleLevel "Low")  (SimpleLevel "Low")  = True
    isBelow' (SimpleLevel "Low")  (SimpleLevel "High") = True
    isBelow' (SimpleLevel "High") (SimpleLevel "High") = True
    isBelow' _                    _                    = False
    leastUpper :: Annotation -> Annotation -> Annotation
    leastUpper (SimpleLevel "Low")  (SimpleLevel "Low")  = SimpleLevel "Low"
    leastUpper _                    _                    = SimpleLevel "High"
    greatestLower :: Annotation -> Annotation -> Annotation
    greatestLower (SimpleLevel "High") (SimpleLevel "High") = SimpleLevel "High"
    greatestLower _                    _                    = SimpleLevel "Low"
    
simpleLattice' :: Lattice
simpleLattice' = Lattice [(SimpleLevel "Low", SimpleLevel "Medium"), (SimpleLevel "Medium", SimpleLevel "High")] (SimpleLevel "Low") (SimpleLevel "High") isBelow' leastUpper greatestLower
  where
      isBelow' :: Annotation -> Annotation -> Bool
      isBelow' (SimpleLevel "Low")    (SimpleLevel _)        = True
      isBelow' (SimpleLevel "Medium") (SimpleLevel "Medium") = True
      isBelow' (SimpleLevel "Medium") (SimpleLevel "High")   = True
      isBelow' (SimpleLevel "High")   (SimpleLevel "High")   = True
      isBelow' _                      _                      = False
      leastUpper :: Annotation -> Annotation -> Annotation
      leastUpper (SimpleLevel "Low") x                       = x
      leastUpper x                   (SimpleLevel "Low")     = x
      leastUpper (SimpleLevel "Medium") x                    = x
      leastUpper x                   (SimpleLevel "Medium")  = x
      leastUpper (SimpleLevel "High") (SimpleLevel "High")   = SimpleLevel "High"
      leastUpper x                    y                      = error $ "The forgotten case: " ++ (show x) ++ (show y)
      greatestLower :: Annotation -> Annotation -> Annotation
      greatestLower l@(SimpleLevel "Low")    _                        = l
      greatestLower _                        l@(SimpleLevel "Low")    = l
      greatestLower l@(SimpleLevel "Medium") _                        = l
      greatestLower _                        l@(SimpleLevel "Medium") = l
      greatestLower _                        _                        = SimpleLevel "High"
      
otherLattice :: Lattice
otherLattice = Lattice [(SimpleLevel "Low", SimpleLevel "Medium"), 
                        (SimpleLevel "Medium", SimpleLevel "High"), 
                        (SimpleLevel "Low", SimpleLevel "W1"), 
                        (SimpleLevel "W1", SimpleLevel "W2"), 
                        (SimpleLevel "W2", SimpleLevel "High")]
                        (SimpleLevel "Low")
                        (SimpleLevel "High")
                        isBelow' 
                        leastUpper 
                        greatestLower
    where
        isBelow' :: Annotation -> Annotation -> Bool
        isBelow' (SimpleLevel "Low")    (SimpleLevel _)        = True
        isBelow' (SimpleLevel "W1")     (SimpleLevel "W2")     = True
        isBelow' (SimpleLevel "W1")     (SimpleLevel "High")   = True
        isBelow' (SimpleLevel "W1")     (SimpleLevel "W1")     = True
        isBelow' (SimpleLevel "W2")     (SimpleLevel "W2")     = True
        isBelow' (SimpleLevel "W2")     (SimpleLevel "High")   = True
        isBelow' (SimpleLevel "Medium") (SimpleLevel "Medium") = True
        isBelow' (SimpleLevel "Medium") (SimpleLevel "High")   = True
        isBelow' (SimpleLevel "High")   (SimpleLevel "High")   = True
        isBelow' _                      _                      = False
        leastUpper :: Annotation -> Annotation -> Annotation
        leastUpper (SimpleLevel "Low") x                       = x
        leastUpper x                   (SimpleLevel "Low")     = x
        leastUpper (SimpleLevel "High") _                      = SimpleLevel "High"
        leastUpper _                    (SimpleLevel "High")   = SimpleLevel "High"
        leastUpper (SimpleLevel "W1")  (SimpleLevel "Medium")  = SimpleLevel "High"
        leastUpper (SimpleLevel "W2")  (SimpleLevel "Medium")  = SimpleLevel "High"
        leastUpper (SimpleLevel "Medium") (SimpleLevel "W1")   = SimpleLevel "High"
        leastUpper (SimpleLevel "Medium") (SimpleLevel "W2")   = SimpleLevel "High"
        leastUpper (SimpleLevel "W1")   (SimpleLevel "W2")     = SimpleLevel "W2"
        leastUpper (SimpleLevel "W2")   (SimpleLevel "W1")     = SimpleLevel "W2"
        leastUpper (SimpleLevel "W1")   (SimpleLevel "W1")     = SimpleLevel "W1"
        leastUpper (SimpleLevel "W2")   (SimpleLevel "W2")     = SimpleLevel "W2"
        leastUpper (SimpleLevel "Medium") x                    = x
        leastUpper x                    (SimpleLevel "Medium") = x
        leastUpper x                    y                      = error $ "The forgotten case: " ++ (show x) ++ (show y)
        greatestLower :: Annotation -> Annotation -> Annotation
        greatestLower l@(SimpleLevel "Low")    _                        = l
        greatestLower _                        l@(SimpleLevel "Low")    = l
        greatestLower (SimpleLevel "W1")       l@(SimpleLevel "W1")     = l
        greatestLower (SimpleLevel "W2")       l@(SimpleLevel "W1")     = l
        greatestLower l@(SimpleLevel "W1")     (SimpleLevel "W2")       = l
        greatestLower (SimpleLevel "W2")       l@(SimpleLevel "W2")     = l
        greatestLower (SimpleLevel "W1")       (SimpleLevel "Medium")   = SimpleLevel "Low"
        greatestLower (SimpleLevel "W2")       (SimpleLevel "Medium")   = SimpleLevel "Low"
        greatestLower (SimpleLevel "Medium")   (SimpleLevel "W1")       = SimpleLevel "Low"
        greatestLower (SimpleLevel "Medium")   (SimpleLevel "W2")       = SimpleLevel "Low"
        greatestLower l@(SimpleLevel "Medium") _                        = l
        greatestLower _                        l@(SimpleLevel "Medium") = l
        greatestLower (SimpleLevel "High")     l                        = l
        greatestLower l                        (SimpleLevel "High")     = l
        -- greatestLower _                        _                        = SimpleLevel "High"
        