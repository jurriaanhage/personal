{-# LANGUAGE TypeSynonymInstances, FlexibleInstances #-}
module Type.TypeEnvironment where

import Type.Type
import Graph.Graph
import Type.Annotation
import Syntax.SyntaxBase
import Graph.GraphUtils
import Type.Substitution
import qualified Data.Set as S
    
type TypeEnvironment = [(Ident, (TypeScheme, Annotation, Graph (Annotation, Annotation), Bool))]

lookUp :: TypeEnvironment -> Ident -> (TypeScheme, Annotation, Graph (Annotation, Annotation), Bool)
lookUp env a = case (lookup a env) of
                   (Just t) -> t
                   Nothing  -> error $ "Identifier " ++ (show a) ++ " not found " ++ (show env)
                   
instance VarContainer TypeEnvironment where
 ftv env bound = foldr (\(_, (t, _, _, _)) v -> S.union (ftv t bound) v) S.empty env
 fav env bound = foldr (\(_, (t, a, _, _)) v -> S.union ((fav t bound) `S.union` (fav a bound)) v) S.empty env
 isPolyVariant' = error "Just don't ask stupid questions, of course this is not polyvariant"

instance Syntax TypeEnvironment where
 syntax ((i, (t, a, _, _)):ts) = i ++ " :: " ++ (syntax t) ++ "@" ++ (syntax a) ++ "\n" ++ (syntax ts)
 syntax []          = ""
 
instance Substitutable TypeEnvironment where
  apply' sub boundTy boundAnn env = map (\(i, (t, a, g, p)) -> (i, (apply' sub boundTy boundAnn t, apply' sub boundTy boundAnn a, apply' sub boundTy boundAnn g, p))) env