{-# LANGUAGE TypeSynonymInstances #-}
module Type.Annotation where
    
import Syntax.SyntaxBase
import Type.Weight

import qualified Data.List as L

data Annotation 
    = SimpleLevel Ident
    | SecVar Ident
 deriving (Eq, Ord)


addLabel :: (Int, NodeType) -> Constraint -> Constraint
addLabel i (p, l, u, w) = (i:p, l, u, w)  
 
increaseTrust :: Int -> Constraint -> Constraint
increaseTrust t (p, l, u, (Weight t')) = (p, l, u, Weight $ max t t')
increaseTrust _ c                      = c

rebase :: Int -> NodeType -> Constraint -> Constraint
rebase l t (_, a1, a2, w) = ([(l, t)], a1, a2, w)
    
instance Show Annotation where
    show (SimpleLevel i) = i
    show (SecVar i)      = i
     
type Constraint = ([(Int, NodeType)], Annotation, Annotation, Weight)

equal :: Constraint -> Constraint -> Bool
equal (_, l, u, _) (_, l', u', _) = l == l' && u == u'


lowerBound :: Constraint -> Annotation
lowerBound (_, a, _, _) = a

upperBound :: Constraint -> Annotation
upperBound (_, _, a, _) = a 

isLevel :: Annotation -> Bool
isLevel (SimpleLevel _) = True
isLevel _               = False

{-
instance Eq Constraint where
    (_, a1, a2) == (_, a3, a4) = a1 == a3 && a2 == a4
-}
type ConstraintEnvironment = [Constraint]

mergeCEnv :: ConstraintEnvironment -> ConstraintEnvironment -> ConstraintEnvironment
mergeCEnv = foldr insertConstraint 

-- Remove double constraints from the constraintEnvironment
removeDoubles :: ConstraintEnvironment -> ConstraintEnvironment
removeDoubles cEnv = foldr insertConstraint [] cEnv

-- Insert constraints, if an equal constraint already exists only the position of the constraint will be inserted
insertConstraint :: Constraint -> ConstraintEnvironment -> ConstraintEnvironment
insertConstraint c@(p, a1, a2, w1) (x@(ps, a3, a4, w2):xs) | a1 == a3 && a2 == a4 = (p ++ ps, a3, a4, max w1 w2):xs
                                                   | otherwise            = (:) x $ insertConstraint c xs
insertConstraint c             []                                         = [c]

emptyCEnv :: ConstraintEnvironment
emptyCEnv = []

