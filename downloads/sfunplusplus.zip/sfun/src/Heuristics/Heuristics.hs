module Heuristics.Heuristics where

import Heuristics.HeuristicTypes

import qualified Data.List as L
import qualified Data.Set as S
import qualified Data.Map as M
import Data.Maybe (fromJust)

import Type.Annotation
import Type.Weight
import Graph.Graph
import Graph.GraphSolver
import Type.Lattice
import Syntax
import Syntax.SyntaxBase
import Error.Error

heuristics :: Heuristics
heuristics = [ irrefutableConstraints,
               ifHeuristic,
               headHeuristic,
               appHeuristic,
               polyvariantConstraints,
               sibling,
               majority,
               leastTrustedConstraint,
               firstComeFirstBlamed  -- When this heuristic fires the error should have actually been a program slice.
             ]

--Tie braker
firstComeFirstBlamed :: Heuristic
firstComeFirstBlamed = Filter name function
    where
        name = "First Come First Blamed"
        function :: ErrorState -> Either Info ErrorState
        function e@(ErrorState g ast node minErr inf) = 
            let c@(ns, _, _, _) = head minErr
                (h, rc, _, l, cl, _) = getEndNodes e
             in case c of
                 (_, _, (SimpleLevel _), _) -> function (ErrorState g ast node (tail minErr ++ [head minErr]) inf)
                 _ -> Left $ BlamedConstraint c $ "The expression: " ++ (show $ ast M.! (fst $ head ns)) ++
                                          "\nIs protected at level: " ++ show h++
                                          "\nAn expression protected at level: " ++ show l ++ " was expected."

polyvariantConstraints :: Heuristic
polyvariantConstraints = dontBlamePropagate
        
dontBlamePropagate :: Heuristic
dontBlamePropagate = Filter name function
    where
        name = "Don't blame constraints that just propagate an annotation"
        function :: ErrorState -> Either Info ErrorState
        function e = let minset = minimalError e
                         minset' = filter notPropagateC minset
                         info' = [(c, Info "Excluded by don't blame propagate heuristic") | c <- filter propagateC minset]
                      in Right $ if null minset' then e else e {minimalError = minset', info = info' ++ (info e)}

propagateC :: Constraint -> Bool
propagateC = not . notPropagateC

notPropagateC :: Constraint -> Bool
notPropagateC (_, (SecVar _), (SecVar _), _) = False
notPropagateC _                              = True

{-

-- This version of don't blame propagate only removes constraints generated
-- at variable instantiation sites and from function application.
-- As an only filter before the sibling heuristic this doesn't suffice.

dontBlamePropagate :: Heuristic
dontBlamePropagate = Filter name function
    where
        name = "Don't blame constraints that just propagate an annotation"
        function :: ErrorState -> Either Info ErrorState
        function e = let minset = minimalError e
                         minset' = filter notPropagateC minset
                         info' = [(c, Info "Excluded by don't blame propagate heuristic") | c <- filter propagateC minset]
                      in Right $ if null minset' then e else e {minimalError = minset', info = info' ++ (info e)}

propagateC :: Constraint -> Bool
propagateC = not . notPropagateC

notPropagateC :: Constraint -> Bool
notPropagateC ([(_, t)], (SecVar _), (SecVar _), _) | t == NAppFn || t == NAppRes || t == NAppArg || t == NInstV = False
                                              | otherwise = True
notPropagateC _                              = True

-}
lowBound :: Constraint -> Bool
lowBound (_, (SimpleLevel _), _, _) = True
lowBound _                          = False

irrefutableConstraints :: Heuristic
irrefutableConstraints = dontBlameInfiniteTrust

dontBlameInfiniteTrust :: Heuristic
dontBlameInfiniteTrust = Filter name function
    where
        name = "Don't blame constraints with infinite trust"
        split :: ConstraintEnvironment -> (ConstraintEnvironment, ConstraintEnvironment)
        split c = L.partition (\(_, _, _, w) -> w == Infinite) c
        function :: ErrorState -> Either Info ErrorState
        function e = let minErr = minimalError e
                         (inf, nInf) = split minErr
                         infoInf = [(i, Info "This constraint has infinite trust") | i <- inf]
                      in case (nInf) of
                             [] -> Right e
                             [x] -> Left $ BlamedConstraint x "Remaining constraint"
                             _  -> Right $ e {minimalError = nInf, info = infoInf ++ (info e)}

appHeuristic :: Heuristic
appHeuristic = Filter name function
   where
       name = "Applicition of secure function heuristic"
       function :: ErrorState -> Either Info ErrorState
       function e@(ErrorState g ast node minErr inf) =
           let i = filter (\(ids, _, _, _) -> elem NAppFn (map snd ids)) minErr
               fnAnnCause = [(c, BlamedConstraint c $ "The function: " ++ getConditionalString e c ++
                                                   "\nin the application:\n" ++ 
                                                   (show $ ast M.! (fst ids))
                                                   ++ "\nis protected at level: " ++ show h ++ "." ++ 
                                                   "\nThis causes the result of the application to be protected at level: " ++ show h ++ "." ++
                                                   "\nInstead a value protected at level: " ++ show l ++ " that was expected by: " ++ cl ++ ".") | 
                                                   let (h, rc, _, l, cl, _) = getEndNodes e ,c@(([ids], _,_,_)) <- i, testSolvable g c]
            in case fnAnnCause of
                    [] -> Right e
                    [(c,b)] -> Left b
                    _       -> Right e {info = inf ++ fnAnnCause}

headHeuristic :: Heuristic
headHeuristic = Filter name function
    where
        name = "Head of list heuristic"
        function :: ErrorState -> Either Info ErrorState
        function e@(ErrorState g ast node minErr inf) =
            let i = filter (\(ids, _, _, _) -> elem NHeadEl (map snd ids)) minErr
                fnAnnCause = [(c, BlamedConstraint c $ "The structure of list: " ++ getConditionalString e c ++
                                                    "\napplied to head in the expression:\n" ++ 
                                                    (show $ ast M.! (fst ids))
                                                    ++ "\nis protected at level: " ++ show h ++ "." ++ 
                                                    "\nThis causes the result of the head operation to be protected at level: " ++ show h ++ "." ++
                                                    "\nInstead a value protected at level: " ++ show l ++ " that was expected by: " ++ cl ++ ".") | 
                                                    let (h, rc, _, l, cl, _) = getEndNodes e ,c@(([ids], _,_,_)) <- i, testSolvable g c]
             in case fnAnnCause of
                     [] -> Right e
                     [(c,b)] -> Left b
                     _       -> Right e {info = inf ++ fnAnnCause}


ifHeuristic :: Heuristic
ifHeuristic = Filter name function
    where
        name = "Conditional in if heuristic"
        function :: ErrorState -> Either Info ErrorState
        function e@(ErrorState g ast node minErr inf) =
            let (Right (Graph _ _ _ rs)) = variableRange g minErr
                i = filter (\(ids, _, _, _) -> elem NIfCond (map snd ids)) minErr
                causeCond = [(c, BlamedConstraint c $ "The  conditional: " ++ getConditionalString e c ++
                                                    "\nof the if statement:\n" ++ 
                                                    (show $ ast M.! (fst ids))
                                                    ++ "\nuses a value: '" ++ rc ++ "' protected at level: " ++ show h ++ "." ++ 
                                                    "\nThis causes the whole if expression: \n" ++ (show $ ast M.! (fst ids)) ++ 
                                                    "\nto be protected at level: " ++ show eh ++ "." ++
                                                    "\nInstead a value protected at level: " ++ show l ++ " was expected by: " ++ cl ++ ".") | 
                                                    let (h, rc, _, l, cl, _) = getEndNodes e ,c@(([ids], _,(SecVar ib),_)) <- i, testSolvable g c,
                                                    let (Just (eh, _)) = M.lookup ib rs]
             in case causeCond of
                    [] -> Right e
                    [(c,b)] -> Left b
                    _       -> Right e {info = inf ++ causeCond}
                    
getConditionalString :: ErrorState -> Constraint -> String
getConditionalString (ErrorState g ast node minErr inf) (_, i, _, _) = show $ ast M.! (fst $ head ids)
    where
     (ids, l, _, _)  = head $ filter (\(_, _, j, _) -> i == j) minErr

-- | This only works with complete minimal sets!
getEndNodes :: ErrorState -> (Annotation, String, Constraint, Annotation, String, Constraint)
getEndNodes (ErrorState g ast node minErr inf) = (l1, show $ ast M.! (fst $ head i1), c1, h2, getCollapsed $ ast M.! (fst $ head i2), c2)
  where    
    [n1, n2] = filter (\(_,l, h, _) -> isLevel l || isLevel h) minErr
    c1@(i1, l1, _, _) = if isLevel $ lowerBound n1 then n1 else n2
    c2@(i2, _, h2, _) = if isLevel $ upperBound n2 then n2 else n1
           

sibling ::  Heuristic 
sibling = Filter name function
    where
        name = "Declassify-Protect sibling heuristic !!!"
        function :: ErrorState -> Either Info ErrorState
        function e@(ErrorState g@(Graph l _ _ _) ast node minErr inf) = 
            case (minErr) of
                [c1, c2] -> maybe (Right e) Left $ siblingApplies c1 c2
                _        -> Right e
            where
        
                siblingApplies :: Constraint -> Constraint -> Maybe Info
                siblingApplies c1@([(o1, _)], _, l1@(SimpleLevel lev), _) c2@([(o2, _)], l2@(SimpleLevel lev2), _, _) | couldBeDeclass c2 && not (lessOrEq l l2 l1) = 
                                                                                    let (ns, ll', lr', _) = oneStepRight e c2
                                                                                     in
                                                                                    Just $ BlamedConstraint c2 $ "You try to declassify the expression: " ++ (show $ ast M.! (fst $ head ns))  ++ " to  level: " ++ lev2 
                                                                                                                ++ "\nBut the expression you are declassifying is protected at level: " ++ lev
                                                                                                                ++ "\nTry protect to assign the expression the level: " ++ lev2
                                                                                                            | couldBeProtect c1 && not (lessOrEq l l2 l1) =
                                                                                    let (ns, ll', lr', _) = oneStepLeft e c1
                                                                                        (_, h, _, _, _, _) = getEndNodes e
                                                                                     in 
                                                                                    Just $ BlamedConstraint c1 $ "You try to protect the expression: " ++  (show $ ast M.! (fst $ head ns))  ++ " to level: " ++ lev 
                                                                                                                ++ "\nBut the expression you are protecting is protected at level: " ++ lev2
                                                                                                                ++ " because: '" ++ h ++ "' is used."
                                                                                                                ++ "\nTry declassify to assign the expression the level: " ++ lev
                                                                                                            | otherwise         = Nothing
                siblingApplies c1@([o2], (SimpleLevel lev2), _, _) c2@([o1], _, (SimpleLevel lev), _) = siblingApplies c2 c1
                siblingApplies _ _                                                                    = Nothing
        
                isProtect, isDeclass :: Int -> Bool  
                isProtect i = isProtectFrag $ fromJust $ M.lookup i ast
                isDeclass i = isDeclassFrag $ fromJust $ M.lookup i ast
          
                couldBeProtect, couldBeDeclass :: Constraint -> Bool
                couldBeProtect ([(o, _)], _,(SimpleLevel _), _) = isProtect o
                couldBeProtect _                         = False
                couldBeDeclass ([(o, _)], (SimpleLevel _), _,_) = isDeclass o
                couldBeDeclass _                         = False

tryFixGraph :: Heuristic
tryFixGraph = Filter name function
 where
     name = "Try fix the graph"
     function :: ErrorState -> Either Info ErrorState
     function e@(ErrorState g ast node minErr inf) = case fix of
                                                    [x] -> Left $ BlamedConstraint x "This constraint fixes everything"
                                                    []  -> Right e
                                                    _   -> case (noFix) of
                                                            [] -> Right e
                                                            _  -> Right $ ErrorState g ast node fix nInf
         where
            (fix, noFix) = L.partition (testSolvable g) minErr
            nInf = [(c, Info "Is not on all error paths") | c <- noFix] ++ inf 

testSolvable :: Graph (Annotation, Annotation) -> Constraint -> Bool
testSolvable g c = let ng = removeEdge c g
                    in case simplify' [] ng (edgesFromGraph ng) of
                        (Left _) -> False
                        (Right _) -> True

majority :: Heuristic
majority = Filter name function
    where
        name = "The majority heuristic"
        function :: ErrorState -> Either Info ErrorState
        function e@(ErrorState g@(Graph l _ _ _) ast node minErr inf) = 
                     let leastConstr = head . leastTrusted $ minimalError e
                         cs = (\(p, _,_,_) -> p) leastConstr
                         subExpr = L.nub $ (map fst cs) ++ (concat $ map S.elems $ map (node M.!) (map fst cs))
                         constraints = filter lowBound $ filter notPropagateC $ constraintGeneratedAt subExpr g
                         groups = L.groupBy (\(_,b1,_,_) (_,b2,_,_) -> b1 == b2) constraints
                      in if (length groups == 2)
                             then let [g1, g2] = groups
                                      lg1 = length g1
                                      lg2 = length g2
                                      ((_, l1, _, _):_) = g1
                                      ((_, l2, _, _):_) = g2
                                      g1Smaller = (lessOrEq l) l1 l2
                                      in if g1Smaller 
                                          then if (lg2 * 4 <= lg1)
                                              then Left $ BlamedConstraint leastConstr $ message ast (head cs) l1 l2 $ map fst (foldr (\(p, _,_,_) t -> p ++ t) [] g2)
                                              else return e
                                           else if (lg1 * 4 <= lg2)
                                               then Left $ BlamedConstraint leastConstr $ message ast (head cs) l2 l1 $ map fst (foldr (\(p, _,_,_) t -> p ++ t) [] g1)
                                               else return e
                             else return e
            where
                message ast l u a exps = "Error in application: \n" ++ (show $ ast M.! (fst l)) ++
                                    "\nAn argument protected at at most level: " ++ (show u) ++ " is expected by: " ++ cl 
                                    ++ "\nThe argument provided: " ++ (show $ ast M.! (fst argC)) ++" is protected at level: " ++ (show a)
                                    ++ "\nBecause of the following sub-expressions: " ++
                                    (concatMap (\n -> "\n" ++ (show $ ast M.! n)) exps)
                (hL, hn, hc, lL, cl, lc) = getEndNodes e
                argC = (\(n, _, _, _) -> head n) $ oneStepLeft e lc
                                    
                                      
oneStepLeft :: ErrorState -> Constraint -> Constraint
oneStepLeft (ErrorState _ ast node minErr inf) (_, r, _, _) = fromJust $ L.find (\(_, _, l, _) -> r == l) (infC ++ minErr) 
                            where  
                              infC = map fst inf
                              
oneStepRight :: ErrorState -> Constraint -> Constraint
oneStepRight (ErrorState _ ast node minErr inf) (_, _, l, _) = fromJust $ L.find (\(_, r, _, _) -> r == l) (infC ++ minErr) 
                          where  
                            infC = map fst inf
--                      in (unsafePerformIO $ putStrLn (show constraints)) `seq` (unsafePerformIO $ putStrLn (show subExpr) )`seq` return e

--Testing        
tryBlameTheFifth :: Heuristic
tryBlameTheFifth = Filter name function
    where
        name = "Try blame the fifth"
        function :: ErrorState -> Either Info ErrorState
        function e = if ((length $ minimalError e) > 4)
                        then Left $ BlamedConstraint ((minimalError e)!!4) "It appeared to be the fifth constraint"
                        else Right e
                        
notTheFirst :: Heuristic
notTheFirst = Filter name function
    where
        name = "Not the first"
        function :: ErrorState -> Either Info ErrorState
        function e = if ((length $ minimalError e) > 1)
                        then Right $ e {minimalError = drop 1 $ minimalError e, info = ((minimalError e)!!0, Info "It couldn't be the first") : (info e)}
                        else Right $ e
     
                  
noChoice :: Vote
noChoice = Vote name function
    where 
        name = "No choice"
        function = (\_ -> Nothing)
        
chooseTheFifth :: Vote
chooseTheFifth = Vote name function
    where
        name = "Choose the fifth"
        function e = if length (minimalError e) > 4
                        then Just $ VoteConstraint 1 ((minimalError e)!!4) "It happend to be the fifth"
                        else Nothing

-- The least trusted constraint heuristic could be used with other voting heuristics.
-- as we only have one such heuristic we treat it as a normal heuristic.
leastTrustedConstraint :: Heuristic
leastTrustedConstraint =  Voting [voteTheLeastTrusted]
                        
voteTheLeastTrusted :: Vote
voteTheLeastTrusted = Vote name function
    where
        name = "Elect the least trusted constraint"
        function :: ErrorState -> Maybe VoteInfo
        function e@(ErrorState g@(Graph l _ _ _) ast node minErr inf)
                   = let minErr = minimalError e
                         minim = leastTrusted minErr
                         (h, rc, _, low, cl, _) = getEndNodes e
                      in case minim of
                             [x@([l], _, u, _)] -> case ast M.! (fst l) of
                                                    (TFrag (App _ t1 t2) _ _) ->
                                                      Just $ VoteConstraint 5 x $ 
                                                      "Error in application: \n" ++ (show $ ast M.! (fst l)) ++
                                                      "\nThe function: " ++ (show t1) ++
                                                      "\nExpected an argument protected at at most level: " ++ (show low) ++
                                                      "\nBut the given argument: " ++ (show t2) ++
                                                      "\nIs protected at level: " ++ show h ++ " because of (sub-)expression: " ++ rc ++ "."
                                                    (TFrag (Protect _ t le) _ _) -> 
                                                     let (nl, _, _, _) = oneStepLeft e x
                                                      in Just $ VoteConstraint 5 x $
                                                      "Error in protect of expression:\n" ++ (show $ ast M.! (fst l)) ++
                                                      "\nThe expression: " ++  (show $ ast M.! (fst $ head nl)) ++ " is protected at level: " ++ (show h) ++
                                                      "\nBecause of (sub-)expression: " ++ show rc ++ "." ++
                                                      "\nBut '" ++ cl ++ "' expected an expression that is protected at at most level: " ++ show low ++ "."
                                                    (TFrag (Declass _ t le) _ _) ->
                                                     let (nl, _, _, _) = oneStepRight e x
                                                      in
                                                      Just $ VoteConstraint 5 x $
                                                      "Error in declassify of expression:\n" ++ (show $ ast M.! (fst l)) ++
                                                      "\nThe expression: " ++ (show $ ast M.! (fst $ head nl)) ++ " is protected at level: " ++ (show low) ++
                                                      "\nYou try to declassify to level: " ++ show le ++
                                                      "\nBut a value protected at at leat level: " ++ show h ++" is expected."
                                                    t -> Just $ VoteConstraint 5 x $ error $ "Unexpected construct in voteleastconstraint\nFound expression: " ++ show t
                                                                                             ++ "\nAdd an alternative for this construct to the heuristic."
                             _   -> Nothing 
                             
leastTrusted :: ConstraintEnvironment -> ConstraintEnvironment
leastTrusted c = let groups = L.groupBy (\(_,_,_,w) (_,_,_,w') -> w == w') c
                  in L.minimumBy (\((_,_,_,w):_) ((_,_,_,w'):_) -> compare w w') groups
    