{-# LANGUAGE FlexibleContexts #-}
module Heuristics.ApplyHeuristics where
    
import Heuristics.HeuristicTypes
import Control.Monad.Writer
import Control.Monad.Error
import qualified Data.Map as M
import Data.Maybe
import Syntax
import Type.Annotation
import Config


applyHeuristics :: Config -> Heuristics -> ErrorState -> HeuristicResult
applyHeuristics c hs e = do
                        logMsg "Starting Heuristic phase"
                        logMsg $ "Applying " ++ (show $ length hs) ++ " heuristics"
                        logMsg "Applying heuristics on the following minimal error set:"
                        mapM (logConstraintWithFragment $ astFragments e) $ minimalError e
                        --sequence $ map (logMsg . show) $ minimalError e
                        foldl (>>=) (return e) (map (applyHeuristic c) hs)

logConstraintWithFragment :: (MonadWriter [String] m) => M.Map Int ASTFragment -> Constraint -> m ()
logConstraintWithFragment ast c@(points, _, _,_) = do
                                                    logMsg (" -Constraint: " ++ show c ++ ". From:")
                                                    mapM_ (logMsg . p) (map fst points) 
                                                    
    where
        p :: Int -> String
        p i = (++) "   # " $ show $ ast M.! i 

applyHeuristic :: Config -> Heuristic -> ErrorState -> HeuristicResult
applyHeuristic c (Filter n f) e = do
                                    logMsg line
                                    logMsg $ "Apply heuristic: " ++ n
                                    let r = f e
                                    case r of
                                        (Left i) -> do
                                                     logMsg (show i)
                                                     case test c of
                                                        True -> do
                                                                  logMsg $ "Heuristic: " ++ n ++ "would blame the mentioned constraint."
                                                                  logMsg "Ignoring the result and moving on to the next heuristic."
                                                                  return e
                                                        False -> result i
                                        (Right err') -> do
                                                         logMsg (show $ info err')
                                                         logMsg "Not a singleton moving to next heuristic"
                                                         return err'     
applyHeuristic c (Voting vs) e = do
                                    logMsg line
                                    logMsg $ "Voting with " ++ (show $ length vs) ++ " heuristics"
                                    results <- lift $ sequence $ map (runVote e) vs
                                    case bestResult results of
                                        Nothing -> do
                                                    logMsg "Vote did not select a constraint"
                                                    return e
                                        (Just v@(VoteConstraint l c s))  -> result $ BlamedConstraint c s
                                       
bestResult :: [Maybe VoteInfo] -> Maybe VoteInfo
bestResult vs = foldr f Nothing vs
 where 
     f :: Maybe VoteInfo -> Maybe VoteInfo -> Maybe VoteInfo 
     f Nothing                           r                                   = r
     f (Just v)                          Nothing                             = Just v
     f (Just v@(VoteConstraint l _ _)) (Just v'@(VoteConstraint l' _ _)) = if (l' > l) then Just v' else Just v

runVote :: ErrorState -> Vote -> Writer Log (Maybe VoteInfo)
runVote err (Vote n f) = do
                                logMsg $ " - " ++ n 
                                let res = f err
                                case res of
                                    Nothing -> return Nothing
                                    (Just v@(VoteConstraint l c m)) -> do
                                                                          logMsg $ "Selected constraint: " ++ (show c) ++ "\n"
                                                                                         ++ "With level: " ++ (show l) ++ "\n"
                                                                                         ++ "Message: " ++ m
                                                                          return res   
     