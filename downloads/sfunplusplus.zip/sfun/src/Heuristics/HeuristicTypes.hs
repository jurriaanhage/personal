{-# LANGUAGE  FlexibleContexts #-}
module Heuristics.HeuristicTypes where
 
import qualified Data.Map as M
import qualified Data.Set as S
import Control.Monad.Writer
import Control.Monad.Error

import Graph.Graph
import Type.Annotation
import Syntax

type HeuristicResult = ErrorT Info (Writer Log) ErrorState

runHeuristicResult :: HeuristicResult -> (Either Info ErrorState, Log)
runHeuristicResult n = runWriter $ runErrorT n

result :: Info -> HeuristicResult
result i = ErrorT $ return $ Left i

type Log = [String]

--type HeuristicResult = Writer Log (Either Info ErrorState)
  
data ErrorState = ErrorState { graph :: Graph (Annotation, Annotation),
                               astFragments :: M.Map Int ASTFragment,
                               nodeContains :: M.Map Int (S.Set Int),
                               minimalError :: ConstraintEnvironment,
                               info :: [(Constraint, Info)] }
 deriving Show

data Info = Info String
          | BlamedConstraint Constraint String
            
 deriving Show
instance Error Info where
    noMsg = error "This function should not be used Heuristics.hs noMsg"
    strMsg = error "This function should not be used Heuristics.hs strMsg"

data VoteInfo = VoteConstraint Int Constraint String

data Vote = Vote String (ErrorState -> Maybe VoteInfo)
  
type Heuristics = [Heuristic]
   
data Heuristic = Filter String (ErrorState -> Either Info ErrorState)
               | Voting [Vote] 
               
line :: String
line = "--------------------------------------------------"   

logMsg :: (MonadWriter [t] m) => t -> m ()
logMsg s = tell [s]