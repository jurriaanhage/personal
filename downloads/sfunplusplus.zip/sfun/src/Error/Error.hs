module Error.Error where

import Data.Either

import Type.Lattice
import Type.Annotation
import Graph.Graph
import Syntax.SyntaxBase
import qualified Control.Monad.Error as E

type Computation a = Either Error a

isSuccess :: Computation a -> Bool
isSuccess (Left _) = False
isSuccess (Right _) = True

intoError :: Computation a -> Error -> Computation a
intoError (Right _) e  = Left e
intoError (Left e1) e2 = Left $ case e1 of   
                                 (MultipleErrors es) -> (MultipleErrors (e2:es))
                                 _                   -> (MultipleErrors [e1, e2])
                                 
err :: Error -> Computation a
err = Left

data Error
    = OutOfRange (Graph (Annotation, Annotation, Bool)) Ident
    | MultipleErrors [Error]
    | GraphOutOfRange [Error] (Graph (Annotation, Annotation, Bool))
    | IllegalConstraint Lattice ConstraintEnvironment
     deriving (Show)
     
instance E.Error Error
     
successFulComputation :: Computation a -> a
successFulComputation (Right a) = a

