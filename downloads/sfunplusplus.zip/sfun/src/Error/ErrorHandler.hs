module Error.ErrorHandler where

import qualified Data.Map as M
import qualified Data.List as L
import qualified Data.Set as S    

import Config
import Graph.Graph
import Type.Annotation
import Syntax.SyntaxBase
import Error.Error
import Syntax
import Graph.MinUnsat
import Graph.GraphDot
import Heuristics.HeuristicTypes
import Heuristics.ApplyHeuristics
import Heuristics.Heuristics


exceptionHandler :: Config -> SecurityException -> IO ()
exceptionHandler c (SecurityException m n g cEnv e) = do
                                                    errorM <- errorHandler c m n g cEnv e
                                                    putStrLn errorM

errorHandler :: Config -> M.Map Int ASTFragment -> M.Map Int (S.Set Int)-> Graph (Annotation, Annotation) -> ConstraintEnvironment -> Error -> IO String
errorHandler c astMap nodes g cEnv err = case err of
                                    (OutOfRange gr i) -> return ("Value for variable: " ++ i ++ " out of range. " ++ (show $ getResultValue gr i))
                                    (MultipleErrors e) -> undefined --return $ foldr (\e r-> r ++ "\n" ++ (errorHandler astMap g cEnv e)) "" e
                                    (GraphOutOfRange es gr@(Graph l _ _ _)) -> do
                                                                                let minSet = minUnsat l cEnv
                                                                                let errState = ErrorState g astMap nodes minSet []
                                                                                let (r, msgs) = runHeuristicResult $ applyHeuristics c heuristics errState
                                                                                if debug c then putStrLn $ unlines msgs else return ()
                                                                                writeGraph gr
                                                                                writeErrorGraph minSet
                                                                                case (r) of
                                                                                    (Left (BlamedConstraint _ m)) -> return m
                                                                                    (Right _)                     -> return $ "Illegal constraints arising from: \n" ++ (flip printASTFragments astMap $ getNodes minSet) 
                                    (IllegalConstraint l cs) -> return $ (++) "Illegal constraint arising from: \n" $ printASTFragments (concatMap (\(i, _, _, _) -> map fst i) cs) astMap

getNodes :: ConstraintEnvironment -> [Int]
getNodes c = L.nub $ concatMap (\(i, _, _, _) -> map fst i) c

printASTFragments :: [Int] -> M.Map Int ASTFragment -> String
printASTFragments (i:is) m = show (M.lookup i m) ++ "\n" ++ (printASTFragments is m)
printASTFragments [] _     = ""
 
tryFixError :: Error -> Graph a -> ConstraintEnvironment -> ConstraintEnvironment
tryFixError (OutOfRange gr i) g cEnv = undefined
    
    
constraintOn :: Ident -> ConstraintEnvironment -> ConstraintEnvironment
constraintOn i (c@(p, l, u, _):cs) | isVar i l || isVar i u = c : (constraintOn i cs)
                                   | otherwise              = constraintOn i cs
constraintOn _ []                                           = []

isVar :: Ident -> Annotation -> Bool
isVar i (SecVar j) | i == j    = True
                   | otherwise = False
isVar _ _                      = False

orderByWeight :: ConstraintEnvironment -> ConstraintEnvironment
orderByWeight = L.sortBy f
    where
        f (w1, _, _, _) (w2, _, _, _) = compare (length w1) (length w2)