module Parser.Parser (scan, scanParseTerm, scanParseDecl, scanParseModule, tm) where

import qualified UU.Scanner as S (scan)
import qualified UU.Parsing as P (parse)
import UU.Scanner.TokenParser -- (pParens_pCommas, pConid, pVarid, pInteger, pKey, pParens)
import UU.Scanner.Token (Token)
import UU.Scanner.Position (Pos (..))
import UU.Parsing hiding (parse)

import Parser.ParserUtil
import Syntax.SyntaxBase
import Syntax
import Syntax.Operator

scanParseTerm :: String -> IO Term
scanParseTerm = (parseIO $ tm) . (scan "")

scanParseDecl :: String -> IO Decl
scanParseDecl = (parseIO $ pDecl) . (scan "")

scanParseModule :: String -> String -> IO Module
scanParseModule fileName = (parseIO $ pModule) . (scan fileName)

scan :: String -> String -> [Token]
scan fileName = S.scan ["let", "in", "fn", "fun", "if", "then", "else"
                       , "module", "import", "True", "False"
                       , "Int", "Bool", "Cons", "Nil", "fst", "snd", "null", "hd", "tl"
                       , "declassify", "protect", "List"]
                       ["+", "-", "*", "/", "%", "^", "&", "|", "<", ">", "=<", ">=", "==", "="
                       , "!=", "=>", "::", "->", "!", "@", "=>"]
                       "(),.{}"
                       "+-*/%^&|=><!:@"
                       (Pos 1 1 fileName)

pImport :: TParser Import
pImport = Import <$> pKeyPos "import" <*> pConid

pModule :: TParser Module
pModule =  Module <$> pKeyPos "module" <*> pConid <*> pList pImport <*> pList pDecl
       <|> Module genPos "Main" <$> pList pImport <*> pList_ng pDecl

pDecl :: TParser Decl
pDecl = (\(i,p) d -> Decl p i d) <$> pVaridPos <* pKey "=" <*> tm

tm :: TParser Term
tm = tmOr

{-
Operators:
Level 1 ::
Level 2 Right associative ||
Level 3 Right associative &&
Level 4 == <= >= != > <
Level 6 Left associative + -
Level 7 Left associative * / %
Level 8 Right associative ^


-}

tmOr :: TParser Term
tmOr = pChainr_ng opOr tmAnd
    where  
        opOr = pAny id
           [ (\p -> Op p (LOp Or)) <$> pKeyPos "|"]

tmAnd :: TParser Term
tmAnd = pChainr_ng opAnd tmEq
    where  
        opAnd = pAny id
           [ (\p -> Op p (LOp And)) <$> pKeyPos "&"]

tmEq :: TParser Term
tmEq = tmAdd <|> (\l (op, pos) r -> Op pos op  l r) <$> tmAdd <*> opRel <*> tmAdd
    where
        opRel = pAny id
            [ (\p -> ((ROp Gt), p)) <$> pKeyPos ">"
            , (\p -> ((ROp Geq), p)) <$> pKeyPos ">="
            , (\p -> ((ROp Eq), p)) <$> pKeyPos "=="
            , (\p -> ((ROp Lt), p)) <$> pKeyPos "<"
            , (\p -> ((ROp Leq), p)) <$> pKeyPos "=<"
            , (\p -> ((ROp Neq), p)) <$> pKeyPos "!="
            ]

tmAdd :: TParser Term
tmAdd = pChainl_ng opAdd tmMul --flip AOp <$> tmMul <*> opAdd <*> tmMul
    where
        opAdd = pAny id
            [ (\p -> Op p (AOp Add)) <$> pKeyPos "+"
            , (\p -> Op p (AOp Sub)) <$> pKeyPos "-"
            ]

tmMul :: TParser Term
tmMul = pChainl_ng opMul tmPow
    where
        opMul = pAny id
            [ (\p -> Op p (AOp Mul)) <$> pKeyPos "*"
            , (\p -> Op p (AOp Div)) <$> pKeyPos "/"
            , (\p -> Op p (AOp Mod)) <$> pKeyPos "%"
            ]

tmPow :: TParser Term
tmPow = pChainr_ng opPow tmUnary
    where
        opPow = pAny id
            [ (\p -> Op p (AOp Pow)) <$> pKeyPos "^" ]

tmUnary :: TParser Term
tmUnary = pAny id
            [ (\p -> UnOp p (ULop Not)) <$> pKeyPos "!" <*> tmUnary
            , tmFun]
    
            
tmFun :: TParser Term
tmFun =  tmApp
     <|> Fn <$> pKeyPos "fn" <*> pVarid <* pKey "=>" <*> tm
     <|> Fun <$> pKeyPos "fun" <*> pVarid <*> pVarid <* pKey "=>" <*> tm
     <|> Let <$> pKeyPos "let" <*> pDecl <* pKey "in" <*> tm
     <|> If <$> pKeyPos "if" <*> tm <* pKey "then" <*> tm <* pKey "else" <*> tm
     <|> Fst <$> pKeyPos "fst" <*> tm
     <|> Snd <$> pKeyPos "snd" <*> tm
     <|> Null <$> pKeyPos "null" <*> tm
     <|> Head <$> pKeyPos "hd" <*> tm
     <|> Tail <$> pKeyPos "tl" <*> tm
     <|> Declass <$> pKeyPos "declassify" <*> tm <*> pSimpleLevel
     <|> Protect <$> pKeyPos "protect" <*> tm <*> pSimpleLevel
     <|> Cons <$> pKeyPos "Cons" <*> tm <*> tm
     <|> Tuple <$> pOParenPos <*> tm <* pKey "," <*> tm <* pCParen 

tmApp :: TParser Term
tmApp = pChainl_ng (pSucceed (\t1 t2 -> App (getPos t1) t1 t2)) tmAtom

tmAtom :: TParser Term
tmAtom =  (\(v, p) -> Const p (CInt $ read v)) <$> pIntegerPos
      <|> (\p -> Const p (CBool True)) <$> pKeyPos "True"
      <|> (\p -> Const p (CBool False)) <$> pKeyPos "False"
      <|> Nil <$> pKeyPos "Nil"
      <|> (\(v, p) -> Var p v) <$> pVaridPos
      <|> pParens tmOr

pVariable :: TParser USecurityLevel
pVariable = (\(i, p) -> UAnnVar p i) <$> pVaridPos

pSimpleLevel :: TParser USecurityLevel
pSimpleLevel = (\(c,p) -> USimpleLevel p c) <$> pConidPos
              <|> pVariable