{-# LANGUAGE FlexibleContexts #-}
module Parser.ParserUtil where
    
import UU.Scanner.TokenParser -- (pParens_pCommas, pConid, pVarid, pInteger, pKey, pParens)
import UU.Scanner.Token (Token)
import UU.Scanner.Position (Pos (..))
import UU.Parsing hiding (parse)
import Syntax
    
genPos = Pos (-1::Int) (-1::Int) ""

type TParser a = Parser Token a

type AnnotationParsers = (TParser USecurityLevel, TParser USecurityLevel)

pCurly_pCommas :: IsParser p Token => p a -> p [a]
pCurly_pCommas = pCurly . pCommas
