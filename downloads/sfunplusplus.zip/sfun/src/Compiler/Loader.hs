module Compiler.Loader (loadModule, InteractiveEnv) where

import Control.Monad (when)
import Data.List (intercalate, intersect, nub)
import qualified Data.Set as S (elems)
import System.Directory (doesFileExist)
import System.FilePath.Posix (dropFileName, splitFileName, dropExtension, takeBaseName)
import qualified Data.Map as M
import qualified Data.Set as S

import Syntax
import Parser.Parser
import Parser.ParserUtil
import Type.TypeEnvironment (TypeEnvironment)
import Compiler.Evaluator (eval, EvalResultEnv)

import Util
import Config

type FileName = String

type InteractiveEnv = (EvalResultEnv, TypeEnvironment, Int, Int, M.Map Int ASTFragment, M.Map Int (S.Set Int))

loadModule :: Config -> Int -> Int -> FilePath -> FileName -> IO InteractiveEnv
loadModule opts ids supply path file = do
  ms' <- loadModules path file []
  let ms = reverse $ nub $ reverse ms'
  return $ foldr f ([], [], supply, ids, M.empty, M.empty) ms
  where
    f :: Module -> InteractiveEnv -> InteractiveEnv
    f m@(Module _ x is ds) (ve, tye, supply, ids, frags, nodeCont) =
      let sem    = wrap_Module (sem_Module m) (Inh_Module frags' ids supply tye (currentLattice opts) nodeCont')
          frags' = M.union frags $ nodeTable_Syn_Module sem
          nodeCont' = M.union nodeCont $ nodeContains_Syn_Module sem
          vals   = foldr evalDecl ve (reverse ds)
          tyEnv  = reverse $ gamma_Syn_Module sem
          supply' = freshVars_Syn_Module sem
          ids'    = freshIDs_Syn_Module sem
      in (vals, tyEnv, supply', ids', frags', nodeCont')
    evalDecl :: Decl -> EvalResultEnv -> EvalResultEnv 
    evalDecl (Decl _ x tm)    env = (x, eval tm env) : env

loadModules :: FilePath -> FileName -> [FileName] -> IO [Module]
loadModules path file done = do
  m@(Module _ x is ds) <- loadOneModule path file
  let fs = map (\(Import _ x) -> x) is
  let conflicts = intersect done fs
  when (not (null conflicts))
       (error $ "Cyclic dependencies are not allowed.\n"
              ++ "Already imported: " ++ show done ++ "\n"
              ++ "Importing " ++ show conflicts ++ " from module " ++ file)
  mss <- sequence $ map (\f -> loadModules path f (file:done)) fs
  return (m : concat mss)

loadOneModule :: FilePath -> FileName -> IO Module
loadOneModule path file = do
  mfn <- resolveFile path file
  let fn = maybe (error $ "Module '" ++ file ++ "' not found") id mfn
  src <- readFile fn
  let src'= unlines . map (takeWhile (/='#')) . lines $ src
  scanParseModule file src'

resolveFile :: FilePath -> FileName -> IO (Maybe FilePath)
resolveFile path file = do
  let f1 = path ++ file ++ ".sf"
  let f2 = "../examples/" ++ file ++ ".sf"
  b1 <- doesFileExist f1
  b2 <- doesFileExist f2
  return $ if b1 then Just f1 else if b2 then Just f2 else Nothing

