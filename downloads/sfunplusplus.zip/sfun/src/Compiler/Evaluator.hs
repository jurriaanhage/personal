{-# LANGUAGE GADTs #-}
module Compiler.Evaluator where

import Control.Monad.Error ()
import qualified Control.Monad.Error.Class as L (Error (..), throwError) 

import Syntax
import Syntax.SyntaxBase
import Syntax.Operator

data Value  where
  VInt  :: Int -> Value
  VBool :: Bool -> Value
  VList :: [Value] -> Value
  VPair :: Value -> Value -> Value
  VFn   :: EvalResultEnv -> Ident -> Term -> Value
  VFun  :: EvalResultEnv -> Ident -> Ident -> Term -> Value

instance Show Value where
  show (VInt i)       = show i
  show (VBool b)      = show b
  show (VList l)      = show l
  show (VPair l r)    = "(" ++ (show l) ++ "," ++ (show r) ++ ")"
  show (VFn e x t)    = "fn " ++ x ++ " -> ..."
  show (VFun _ f x _) = "fun " ++ f ++ " " ++ x ++ " -> ..."

type EvalResult = Either String Value
type EvalResultEnv = [(Ident, EvalResult)]



eval :: Term -> EvalResultEnv -> EvalResult
eval (Const _ (CInt i))           env = return $ VInt i
eval (Const _ (CBool b))          env = return $ VBool b
eval (Var _ x)                    env = case lookup x env of
                                         (Just r) -> r
                                         Nothing  -> L.throwError $ "'" ++ x ++ "' is an unbound variable."
eval (Fn _ x t)                   env = return $ VFn env x t
eval (Fun _ f x t)                env = return $ VFun env f x t
eval (App _ t1 t2)                  env = do
                                         let rf = eval t1 env
                                         let rx = eval t2 env
                                         vf <- rf
                                         case vf of
                                            (VFn  env' x t)   -> eval t ((x, rx) : env')
                                            (VFun env' f x t) -> eval t ((x, rx) : (f, rf) : env')
                                            _                 -> L.throwError $ "Cannot apply argument to non fn or fun."

eval (If _ t1 t2 t3)              env = do
                                         v1 <- eval t1 env
                                         case v1 of
                                            (VBool b) -> if b then eval t2 env else eval t3 env
                                            _         -> L.throwError $ "Predicate to if must be a boolean."
eval (Let _ (Decl _ x t1) t2) env = do
                                           let r = eval t1 env
                                           eval t2 ((x, r) : env)
eval (Op _ op t1 t2)              env = do
                                         v1 <- eval t1 env
                                         v2 <- eval t2 env
                                         case (v1, v2) of
                                          (VInt i1, VInt i2) ->
                                            case op of
                                              AOp Add -> Right $ VInt  (i1 + i2)
                                              AOp Sub -> Right $ VInt  (i1 - i2)
                                              AOp Mul -> Right $ VInt  (i1 * i2)
                                              AOp Div -> Right $ VInt  (i1 `div` i2)
                                              AOp Mod -> Right $ VInt  (i1 `mod` i2)
                                              AOp Pow -> Right $ VInt  (i1^i2)
                                              ROp Gt  -> Right $ VBool (i1 > i2)
                                              ROp Geq -> Right $ VBool (i1 >= i2)
                                              ROp Eq  -> Right $ VBool (i1 == i2)
                                              ROp Lt  -> Right $ VBool (i1 < i2)
                                              ROp Leq -> Right $ VBool (i1 <= i2)
                                              ROp Neq -> Right $ VBool (i1 /= i2)
                                              _       -> L.throwError $ "Both provided arguments where integers but the operator expects booleans"
                                          (VBool b1, VBool b2) ->
                                            case op of
                                              LOp And -> Right $ VBool (b1 && b2)
                                              LOp Or  -> Right $ VBool (b1 || b2)
                                              _       -> L.throwError $ "Both provided arguments where boolean but the operator expects integers"
                                          (_, _) ->
                                            L.throwError $ "Both arguments to'"
                                              ++ show op ++ "' need to be an Int,"
                                              ++ " both arguments aren't."
eval (UnOp _ op t)                env = do
                                         v <- eval t env
                                         case v of
                                          VBool b ->
                                            case op of
                                             ULop Not -> Right $ VBool (not b)
                                          _       -> L.throwError $ "Unary operators only expect booleans"
eval (Fst _ t)                    env = do
                                         v <- eval t env
                                         case v of
                                          VPair l r ->
                                            do
                                                return l
                                          _         -> L.throwError $ "Not a pair"
eval (Snd _ t)                    env = do
                                         v <- eval t env
                                         case v of
                                          VPair l r ->
                                            do
                                                return r
                                          _         -> L.throwError $ "Not a pair"
eval (Null _ t)                   env = do
                                         v <- eval t env
                                         case v of
                                          VList l -> return $ VBool (null l)
                                          _       -> L.throwError $ "Not a list"
eval (Head _ t)                   env = do
                                         v <- eval t env
                                         case v of
                                          VList l -> return $ head l
                                          _       -> L.throwError $ "Not a list"
eval (Tail _ t)                   env = do
                                         v <- eval t env
                                         case v of
                                          VList l -> return $ VList (tail l)
                                          _       -> L.throwError $ "Not a list"
eval (Declass _ t _)              env = eval t env
eval (Protect _ t _)              env = eval t env
eval (Cons _ t1 t2)               env = do
                                         v1 <- eval t1 env
                                         v2 <- eval t2 env
                                         case v2 of
                                          VList l -> return $ VList (v1:l)
                                          _       -> L.throwError $ "Tail is not a list"
eval (Nil _)                      env = return $ VList []
eval (Tuple _ t1 t2)              env = do
                                         v1 <- eval t1 env
                                         v2 <- eval t2 env
                                         return $ VPair v1 v2

