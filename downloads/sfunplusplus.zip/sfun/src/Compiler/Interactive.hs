module Compiler.Interactive where

import Control.Monad (foldM, when)
import Data.List (intercalate, isPrefixOf, findIndex)
import Data.Maybe (fromJust, listToMaybe)
import qualified Data.Map as M
import qualified Data.Set as S
import Compiler.FakeWindowsReadline
import System.Exit (exitWith, ExitCode (..))
import System.IO (hFlush, stdout)

import Control.DeepSeq

import Compiler.Loader (loadModule, InteractiveEnv)
import Compiler.Evaluator (eval, Value (..), EvalResultEnv)
import Parser.Parser (scanParseTerm, scanParseDecl, scanParseModule)
import Parser.ParserUtil
import Type.Type
import Type.TypeUtil
import Syntax.SyntaxBase
import Type.Annotation
import Type.TypeEnvironment
import Graph.GraphDot
import Syntax
import Graph.Graph
import Util
import Config

type FileName = String

asciiArt :: String
asciiArt = intercalate "\n"
           [ "                _/_/_/_/                          _/          _/     "
           , "       _/_/_/  _/        _/    _/  _/_/_/        _/          _/      "
           , "    _/_/      _/_/_/    _/    _/  _/    _/  _/_/_/_/_/  _/_/_/_/_/   "
           , "       _/_/  _/        _/    _/  _/    _/      _/          _/        "
           , "  _/_/_/    _/          _/_/_/  _/    _/      _/          _/         "
           , " Utrecht University and Tübingen University 2011, sFun++ Interactive"]
           
right :: Either String Value -> Value
right (Left  s) = error s
right (Right v) = v

trim :: String -> String
trim s = reverse $ ltrim (reverse $ ltrim s)
  where
    ltrim (' ':s) = ltrim s
    ltrim s       = s
  
interactive :: Config -> FilePath -> FileName -> IO ()
interactive opts path file = do
  putStrLn asciiArt
  ienv <- if file == ""
          then return ([], [], 1, 0, M.empty, M.empty)
          else loadModule opts 0 1 path file
  --putStrLn $ (\(_, _, _, _, m) -> show m) ienv
  --actually a nasty hack to ensure that the environment is evalutated completely...
  deepseq (show ienv) $ interactive' opts path ienv

interactive' :: Config -> FilePath -> InteractiveEnv -> IO ()
interactive' opts path ienv = do
  setCompletionEntryFunction (Just (tabComplete ienv))
  line <- readline "> "
  case line of
    (Nothing)          -> interactive' opts path ienv
    (Just "")          -> interactive' opts path ienv
    (Just (':' : cmd)) -> do
      ienv' <- handleCmd opts path cmd ienv
      addHistory (':' : cmd)
      interactive' opts path ienv'
    (Just line)        -> do
      addHistory line
      evaluateTerm opts path [line] ienv
      interactive' opts path ienv

tabComplete :: InteractiveEnv -> String -> IO [String]
tabComplete (env, _, _, _, _, _) s = do
  case s of
    ""       -> return []
    (':':ss) -> return $ map (':':) $ filter (isPrefixOf ss) (map fst cmds)
    ss       -> return $ filter (isPrefixOf ss) $ map fst env

handleCmd :: Config -> FilePath -> String -> InteractiveEnv -> IO InteractiveEnv
handleCmd opts path cmd ienv = do
  if null cmd
   then return ienv
   else do
     let first = head $ words cmd
     let cmds' = filter (isPrefixOf first) (map fst cmds)
     when (null cmds') (putStrLn $ "No command '" ++ cmd ++ "'")
     when (length cmds' > 1)
          (putStrLn $ "Ambiguous command. Possibilities "
                    ++ intercalate ", " (map (\s -> "'" ++ s ++ "'") cmds'))
     if length cmds' == 1
      then fromJust (lookup (head cmds') cmds) opts path (tail $ words cmd) ienv
      else return ienv

cmds :: [(String, Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv)]
cmds = [ ("?", help)
       , ("module", importModule)
       , ("environment", showEnvironment)
       , ("let", letBind)
       , ("parse", parseTerm)
       , ("evaluate", evaluateTerm)
       , ("typeinfer", typeInferTerm)
       , ("dotFiles", envToDot)
       --, ("check", typeCheckTerm)
       , ("quit", quit)
       ]

help ::  Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
help _ _ _ ienv = do
  putStrLn "Possible commands:"
  putStrLn $ intercalate ", " (map fst cmds)
  return ienv

importModule :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
importModule opts path fns ienv = if null fns
                             then return ienv
                             else foldM f ienv fns
  where
   f :: InteractiveEnv -> FileName -> IO InteractiveEnv
   f (ve, tye, supply, ids, frags, cont) fn = do
                                    (ve', tye', supply', ids', frags', cont') <- loadModule opts ids supply path fn
                                    return (ve' ++ ve, tye' ++ tye, supply', ids', M.union frags frags', M.union cont cont')

envToDot :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
envToDot _ _ _ ienv@(env, tyEnv, _, _, _, _) = do
        mapM_ toDot tyEnv
        return ienv 
    where
        toDot (x, (t, a, g, _)) = writeGraphFile x a g t


showEnvironment :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
showEnvironment _ _ _ ienv@(env, tyEnv, _, _, _, _) = do
  mapM_ f (reverse env)
  return ienv
  where
    f (x, _) = do
      let (ty, ann, g, _) = case lookup x tyEnv of
                            (Just a) -> a
                            Nothing -> error "Jikes something is wrong in interactive.hs line:132"
      putStrLn $ x ++ " :: " ++ syntax ty ++ "@" ++ syntax ann

letBind :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
letBind opts _ tms ienv@(env, tye, supply, ids, frags, cont) = do
  tms' <- scanParseDecl (unwords tms)
  let (x, tm) = case tms' of
                       (Decl _ x tm)    -> (x, tm)
  let val = eval tm env
  let (ty', ann', supply', ids', frags', cont') = typeInfer opts tm tye frags cont supply ids
  return ((x, val):env, (x, (ty', ann', error "Interactive letBind, need to implement this", isPolyVariant ty')):tye, supply', ids', M.union frags frags', M.union cont cont')

parseTerm :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
parseTerm _ _ tms ienv = do
  tms' <- (scanParseTerm $ unwords tms) 
  print tms'
  return ienv

evaluateTerm :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
evaluateTerm _ _ tms ienv@(env, _, _, _, _, _) = do
  tm <- scanParseTerm $ unwords tms
  either putStrLn print (eval tm env)
  return ienv

typeInferTerm :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
typeInferTerm opts _ tms ienv@(_, tye, supply, ids, frags, cont) = do
  tms' <- (scanParseTerm (unwords tms))
  let (ty, ann, supply', ids', frags', cont') = typeInfer opts tms' tye frags cont supply ids
  putStrLn $ syntax ty ++ "@" ++ syntax ann
  return ienv

typeInfer :: Config -> Term ->  TypeEnvironment -> M.Map Int ASTFragment -> M.Map Int (S.Set Int) -> Int -> Int -> (TypeScheme, Annotation, Int, Int, M.Map Int ASTFragment, M.Map Int (S.Set Int))
typeInfer opts t env frags cont supply ids = let sem = wrap_Term (sem_Term t) (Inh_Term frags ids supply env (currentLattice opts) cont)
                                                 ty  = ty_Syn_Term sem
                                                 phi = phi_Syn_Term sem
                                                 cSet = cSet_Syn_Term sem
                                                 supply' = freshVars_Syn_Term sem
                                                 ids' = freshIDs_Syn_Term sem
                                                 frags' = nodeTable_Syn_Term sem
                                                 cont' = nodeContains_Syn_Term sem
                                                 (tySch, _, _, _, _, _) = gen' frags cont env phi ty (emptyGraph (currentLattice opts)) cSet
                                              in (tySch, phi, supply', ids', frags', cont')
                                                    
quit :: Config -> FilePath -> [String] -> InteractiveEnv -> IO InteractiveEnv
quit _ _ _ ienv = do
  exitWith ExitSuccess
  return ienv

