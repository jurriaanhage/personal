module Compiler.FakeWindowsReadline where

import System.IO

readline :: String -> IO (Maybe String)
readline s = do
  putStr s
  hFlush stdout
  s' <- getLine
  return $ Just s'

addHistory :: String -> IO ()
addHistory _ = return ()

setCompletionEntryFunction :: Maybe (String -> IO [String]) -> IO ()
setCompletionEntryFunction _ = return ()

