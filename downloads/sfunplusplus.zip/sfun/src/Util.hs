module Util where

import Type.Lattice    
--Needed by ag system for the supply of unique vars
nextUnique :: Int -> (Int, Int)
nextUnique u = (u+1, u)

-- currentLattice' :: Lattice
-- currentLattice' = otherLattice