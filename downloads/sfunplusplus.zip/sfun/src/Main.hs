module Main where

import System.Console.GetOpt
import System.Environment
import System.FilePath.Posix (dropFileName, takeBaseName)

--import Evaluator
import Compiler.Interactive
import Compiler.Loader (loadModule)
import Parser.Parser
import Syntax
import Syntax.SyntaxBase
import Error.ErrorHandler 
import qualified Control.Exception as E
import qualified Data.Map as M
import Type.Lattice

import Config

defaultConfig :: Config
defaultConfig = Config {
                currentLattice     = simpleLattice,
                mode        = TypeInfer, -- Interactive,
                debug       = False,
                test        = False
              }

options :: [OptDescr (Config -> Config)]
options = [ --Option ['i'] ["interactive"]
            --       (NoArg (\o -> o {mode = Interactive}))
            --       "Launch the interactive shell."
            --, 
            Option ['e'] ["echo"]
                   (NoArg (\o -> o {mode = Echo}))
                   "Print program to screen."
          , Option ['p'] ["parse"]
                   (NoArg (\o -> o {mode = Parse}))
                   "Parse program, print AST."
          , Option ['n'] ["pretty"]
                    (NoArg (\o -> o {mode = Pretty}))
                       "Parse program, pretty print AST."
          , Option ['t', 'y'] ["typeinfer"]
                   (NoArg (\o -> o {mode = TypeInfer}))
                   "Type infer program, print the types and constraints."
          , Option ['d'] ["debug"]
                    (NoArg (\o -> o {debug = True}))
                    "Print debugging information from heuristics."
          , Option ['h'] ["testMode"]
                    (NoArg (\o -> o {debug = True, test = True}))
                    "Heuristic test mode, all heuristics are executed."
          , Option ['l'] ["lattice"]
                    (ReqArg (\s o -> case s of
                                        "1" -> o {currentLattice = simpleLattice}
                                        "2" -> o {currentLattice = simpleLattice'}
                                        -- ) "1,2")
                                        "3" -> o {currentLattice = otherLattice}) "1,2,3")
                    "1 for Low-High lattice (default), 2 for Low-Medium-High lattice, 3 for Low,Medium,W1,W2,High lattice"
--                    "1 for Low-High lattice (default), 2 for Low-Medium-High lattice"
          ]

processArgs :: String -> [String] -> IO (Config, [String])
processArgs progName args =
  case getOpt Permute options args of
    (oargs, nonopts, []    ) -> return (foldl (flip ($)) defaultConfig oargs, nonopts)
    (_    , _      , errors) -> ioError $ userError $ "\n" ++ (concat errors) ++ usageInfo header options
  where
    header = "\nUsage: " ++ progName
             ++ " [OPTION...] [FILES], with the following options:"

main :: IO ()
main = 
    do
        args <- getArgs
        progName <- getProgName
        (opts, fileNames) <- processArgs progName args
        E.catch (compiler opts fileNames) (exceptionHandler opts)

            
compiler :: Config -> [String] -> IO ()
compiler opts fileNames = do
                            let fileName = if null fileNames then "" else head fileNames
                            let path = dropFileName fileName
                            let file = takeBaseName fileName
                            src <- if null fileName then return "" else readFile fileName
                            let src'= unlines . map (takeWhile (/='#')) . lines $ src
                            ast <- scanParseModule file src'
                            seq ast $ putStrLn "Parsing done..."
                            let (_ids, _unique,_,_,f,pretty,_m) = sem_Module ast f 0 1 [] (currentLattice opts) M.empty
                            case mode opts of
                                Echo        -> putStrLn src
                                Parse       -> print ast
                                Pretty      -> putStrLn pretty
                                TypeInfer   -> do
                                                (_, tyEnv, _supply, _, _f, _) <- loadModule opts 0 1 path file
                                                putStrLn $ syntax tyEnv
                                Interactive -> interactive opts path file
                                Annotate -> undefined
                                TypeCheck -> undefined

                            

