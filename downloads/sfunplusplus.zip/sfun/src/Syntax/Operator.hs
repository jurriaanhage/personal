module Syntax.Operator where

import Data.Map (Map, insert, empty)
import qualified Data.Map as M

import Syntax.SyntaxBase
import Type.Type

data ArithOp
    = Add
    | Sub
    | Mul
    | Div
    | Mod
    | Pow
    deriving (Show, Eq, Read, Ord)

data RelOp
    = Gt
    | Geq
    | Eq
    | Lt
    | Leq
    | Neq
    deriving (Show, Eq, Read, Ord)

data LogicOp
    = And
    | Or
    deriving (Show, Eq, Read, Ord)

data LogicUnOp
    = Not
    deriving (Show, Eq, Read, Ord)

data Op
    = ROp RelOp
    | AOp ArithOp
    | LOp LogicOp
    deriving (Show, Eq, Read, Ord)

data UnaryOp
     = ULop LogicUnOp
    deriving (Show, Eq, Read, Ord) 

instance Syntax Op where
  syntax (ROp Gt)  = ">"
  syntax (ROp Geq) = ">="
  syntax (ROp Eq)  = "=="
  syntax (ROp Lt)  = "<"
  syntax (ROp Leq) = "=<"
  syntax (ROp Neq) = "!="
  syntax (AOp Add) = "+"
  syntax (AOp Sub) = "-"
  syntax (AOp Mul) = "*"
  syntax (AOp Div) = "/"
  syntax (AOp Mod) = "%"
  syntax (AOp Pow) = "^"
  syntax (LOp And) = "&"
  syntax (LOp Or)  = "|"

instance Syntax UnaryOp where
    syntax (ULop Not) = "!"
        
--Environment for binary operators
type OperatorEnvironment = Map Op Type

--These function make the assumption that they are given the types of binary functions
fstArgType :: Type -> Type
fstArgType = domain

sndArgType :: Type -> Type
sndArgType = domain . coDomain

resultType :: Type -> Type
resultType = coDomain . coDomain

--Lookup function for the type of a binary operator
binOpTy :: Op -> Type
binOpTy o = case (M.lookup o binOpEnv) of
             (Just t) -> t
             Nothing  -> error ("Operator: " ++ (syntax o) ++ " not found.")

--It doesn't matter what the annotations on an operator are, you should not ask for them...
binOpEnv :: OperatorEnvironment
binOpEnv = 
    insert (ROp Gt)  (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $
    insert (ROp Geq) (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $
    insert (ROp Eq)  (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $
    insert (ROp Lt)  (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $
    insert (ROp Leq) (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $
    insert (ROp Neq) (TyFn TyInt undefined (TyFn TyInt undefined TyBool undefined) undefined) $ 
    insert (AOp Add) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (AOp Sub) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (AOp Mul) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (AOp Div) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (AOp Mod) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (AOp Pow) (TyFn TyInt undefined (TyFn TyInt undefined TyInt undefined) undefined)  $
    insert (LOp And) (TyFn TyBool undefined (TyFn TyBool undefined TyBool undefined) undefined) $   
    insert (LOp Or)  (TyFn TyBool undefined (TyFn TyBool undefined TyBool undefined) undefined)
    empty

--Type for unary operator environment
type UOperatorEnvironment = Map UnaryOp Type

unaOpTy :: UnaryOp -> Type
unaOpTy u = case (M.lookup u unaOpEnv) of
                (Just t) -> t
                Nothing -> error ("Operator: " ++ (syntax u) ++ " not found.")

unaOpEnv :: UOperatorEnvironment
unaOpEnv =
    insert (ULop Not) (TyFn TyBool undefined TyBool undefined)
    empty

