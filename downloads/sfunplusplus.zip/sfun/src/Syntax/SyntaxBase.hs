module Syntax.SyntaxBase where
    
import Data.Set as S

-- This is similar to the Show class.
-- Syntax class is needed because we also want deriving Show
class Syntax a where
  syntax :: a -> String

type Ident  = String

data Const = CInt Int
           | CBool Bool
  deriving (Show, Eq, Read)

instance Syntax Const where
  syntax (CInt x)      = show x
  syntax (CBool True)  = "True"
  syntax (CBool False) = "False"
  
data NodeType = NConst
              | NVar
              | NInstV
              | NFn
              | NFun
              | NAppArg
              | NAppFn
              | NAppRes
              | NIfCond
              | NIfBranch
              | NLetGen
              | NLetBody
              | NLetDecl
              | NOp
              | NUnOp
              | NFstEl
              | NFstTup
              | NSndEl
              | NSndTup
              | NNull
              | NHeadEl
              | NHeadTl
              | NTail
              | NDeclassIn
              | NDeclassOut
              | NProtectIn
              | NProtectOut
              | NConsHd
              | NConsTl
              | NNil
              | NTuple
    deriving (Show, Eq)
