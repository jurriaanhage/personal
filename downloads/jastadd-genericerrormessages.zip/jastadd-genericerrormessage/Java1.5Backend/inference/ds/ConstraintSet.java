/**
 * 
 */
package inference.ds;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import AST.Program;
import AST.TypeDecl;

public class ConstraintSet {
	// List of tuples (U,V) where U is used in U <: T and V is the source of U
	public DistinctArrayList supertypeConstraints = new DistinctArrayList(5);
	// All type from the source code. Used by heuristics to suggest fixes
	// public ArrayList<Tuple> allSupertypeConstraints = new
	// ArrayList<Tuple>(5);
	public ArrayList<Tuple> allSupertypeConstraints =
			new DistinctTypePosArrayList(5);

	// List of tuples (U,V) where U is used in T <: U and V is the source of U
	public DistinctArrayList subtypeConstraints = new DistinctArrayList(5);
	// All type from the source code. Used by heuristics to suggest fixes
	public ArrayList<Tuple> allSubtypeConstraints =
			new DistinctTypePosArrayList(5);

	// List of tuples (U,V) where U is used in U = T and V is the source of U
	public DistinctArrayList equaltypeConstraints = new DistinctArrayList(5);
	// All type from the source code. Used by heuristics to suggest fixes
	public ArrayList<Tuple> allEqualtypeConstraints =
			new DistinctTypePosArrayList(5);

	// Set of T's bounds. The bounds contain no un-inferred type variables
	public Set<TypeDecl> boundConstraints = new HashSet<TypeDecl>();

	// The type that a type variable is instantiated to
	public TypeDecl typeArgument;

	// Remember original type (T=U)
	public Tuple equalTuple;
	private boolean hasSubtypeConstraint = false;

	// { (implied, loc) }
	private HashMap<TypeDecl, Set<String>> equalUniqExprTypeMap =
			new HashMap<TypeDecl, Set<String>>();
	private HashMap<TypeDecl, Set<String>> subUniqExprTypeMap =
			new HashMap<TypeDecl, Set<String>>();
	private HashMap<TypeDecl, Set<String>> supUniqExprTypeMap =
			new HashMap<TypeDecl, Set<String>>();

	// { (implied, int) }
	private HashMap<TypeDecl, Integer> equalTypeStats =
			new HashMap<TypeDecl, Integer>();
	private HashMap<TypeDecl, Integer> subTypeStats =
			new HashMap<TypeDecl, Integer>();
	private HashMap<TypeDecl, Integer> supTypeStats =
			new HashMap<TypeDecl, Integer>();

	// ------------------------------------------------------------------------
	// adding constraints
	// ------------------------------------------------------------------------
	public void addSupertypeConstraints(Tuple t) {
		supertypeConstraints.add(t);
		allSupertypeConstraints.add(t.clone());
		// updateStats(t.implied);
		updateStats(t, supUniqExprTypeMap);
	}

	public void addSubtypeConstraints(Tuple t) {		
		subtypeConstraints.add(t);
		allSubtypeConstraints.add(t.clone());
		// updateStats(t.implied);
		updateStats(t, subUniqExprTypeMap);
	}

	public void addEqualtypeConstraints(Tuple t) {
		equaltypeConstraints.add(t);
		allEqualtypeConstraints.add(t.clone());
		// updateStats(t.implied);
		updateStats(t, equalUniqExprTypeMap);
	}

	// ------------------------------------------------------------------------
	// auxiliary methods
	// ------------------------------------------------------------------------
	private void updateStats(Tuple tu,
			final Map<TypeDecl, Set<String>> exprTypeMap) {
		String sourceExpr = tu.initial.getSourceFileAndLocation();
		if (sourceExpr != null) {
			if (Program.hasOption(Program._distinctTypes))
				sourceExpr += tu.getPositionList().toString();

			TypeDecl impliedType = tu.implied;
			if (exprTypeMap.containsKey(impliedType)) {
				Set<String> locSet = exprTypeMap.get(impliedType);
				locSet.add(sourceExpr);
			} else {
				Set<String> locs = new HashSet<String>();
				locs.add(sourceExpr);
				exprTypeMap.put(impliedType, locs);
			}
		}
	}

	public Map<TypeDecl, Integer> typeStatistics() {
		if (equalTypeStats.isEmpty()) {
			for (TypeDecl td : equalUniqExprTypeMap.keySet()) {
				equalTypeStats.put(td, equalUniqExprTypeMap.get(td).size());
				// System.out.println(td.simpleName() + ":= " +
				// typeStats.get(td));
			}
		}

		return equalTypeStats;
	}

	public Map<TypeDecl, Integer> subtypeStatistics() {
		if (subTypeStats.isEmpty()) {
			for (TypeDecl td : subUniqExprTypeMap.keySet()) {
				subTypeStats.put(td, subUniqExprTypeMap.get(td).size());
				// System.out.println(td.simpleName() + ":= "
				// + subTypeStats.get(td));
			}
		}

		return subTypeStats;
	}

	public Map<TypeDecl, Integer> supertypeStatistics() {
		if (supTypeStats.isEmpty()) {
			for (TypeDecl td : supUniqExprTypeMap.keySet()) {
				supTypeStats.put(td, supUniqExprTypeMap.get(td).size());
				// System.out.println(td.simpleName() + ":= "
				// + supTypeStats.get(td));
			}
		}

		return supTypeStats;
	}

	public boolean hasSubtypeConstraintsFromInv() {
		return hasSubtypeConstraint;
	}
	
	public void setSubtypeConstraintsFromInv(Boolean value) {
		hasSubtypeConstraint = value;
	}

	@Override
	public ConstraintSet clone() {
		ConstraintSet cset = new ConstraintSet();
		cset.supertypeConstraints = supertypeConstraints.clone();
		cset.subtypeConstraints = subtypeConstraints.clone();
		cset.equaltypeConstraints = equaltypeConstraints.clone();
		cset.typeArgument = (TypeDecl) typeArgument;
		// if stats are empty then fill them up.
		if (subTypeStats.isEmpty())
			subtypeStatistics();
		cset.subTypeStats = (HashMap<TypeDecl, Integer>) subTypeStats.clone();
		if (supTypeStats.isEmpty())
			supertypeStatistics();
		cset.supTypeStats = (HashMap<TypeDecl, Integer>) supTypeStats.clone();
		// TODO may have to clone bounds as well.
		// cset.boundConstraints = boundConstraints;
		cset.allEqualtypeConstraints =
				new DistinctTypePosArrayList(allEqualtypeConstraints);
		cset.allSubtypeConstraints =
				new DistinctTypePosArrayList(allSubtypeConstraints);
		cset.allSupertypeConstraints =
				new DistinctTypePosArrayList(allSupertypeConstraints);
		return cset;
	}

	@SuppressWarnings("serial")
	class DistinctTypePosArrayList extends ArrayList<Tuple> {

		public DistinctTypePosArrayList() {
			super();
		}

		public DistinctTypePosArrayList(int initialCapacity) {
			super(initialCapacity);
		}

		public DistinctTypePosArrayList(Collection<? extends Tuple> c) {
			super(c);
		}

		@Override
		public boolean add(Tuple t) {
			if (contains(t))
				return false;
			else
				return super.add(t);
		}

		@Override
		public boolean contains(Object t) {
			if (t instanceof Tuple) {
				Tuple UW = (Tuple) t;
				for (int i = 0; i < size(); i++) {
					if (get(i).implied.fullName().equals(UW.implied.fullName())
							&& get(i).initial.fullName()
									.equals(UW.initial.fullName())) {
						String thisImpliedLoc = get(i).getImpliedLocation();
						String otherImpliedLoc = UW.getImpliedLocation();
						String thisInialLoc =
								get(i).initial.getSourceFileAndLocation();
						String otherInialLoc =
								UW.initial.getSourceFileAndLocation();

						if (thisImpliedLoc.equals(otherImpliedLoc)
								&& thisInialLoc.equals(otherInialLoc))
							return true;
					}
				}
			}
			return false;
		}
	}
}
