package inference.ds;

import java.util.LinkedList;

import AST.TypeDecl;

/**
 * This class is used to relate the types suggested by heuristics for faulty
 * types to a positions in a source file.
 * 
 * @author Drako
 * 
 * @param <T>
 *            entity for which a repair was proposed, e.g. type variable or
 *            error message.
 */
public class RepairEntry<T> {

	// Entity for which a repair is computed.
	final public T repairedEntity;
	// Type to which var should be instantiated to
	final protected TypeDecl type;
	// position in parameterize type, actually just indices.
	final protected LinkedList subPosition;
	// file name and position in the source file.
	final protected String position;

	public RepairEntry(T var, TypeDecl type, Tuple tu) {
		super();
		this.repairedEntity = var;
		this.subPosition = tu.getPositionList();
		this.position = tu.initial.getSourceFileAndLocation();
		this.type = type;
	}

	/**
	 * This repair entry is in conflict with the repair entry <code>rp</code>
	 * if the positions are equal, but the types are different.
	 * 
	 * @param rp
	 * @return
	 */
	public boolean conflictsWith(RepairEntry rp) {
		return position.equals(rp.position)
				&& subPosition.equals(rp.subPosition) ? type != rp.type : false;
	}
}
