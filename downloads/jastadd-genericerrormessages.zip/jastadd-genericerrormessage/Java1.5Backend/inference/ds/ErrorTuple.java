/**
 * 
 */
package inference.ds;

import AST.TypeDecl;

/**
 * @author Drako
 * 
 */
public class ErrorTuple {
	private int participation;
	private Tuple orig;
	private int confidence;
	private boolean runHeuristic;

	public ErrorTuple(Tuple orig) {
		this.orig = orig;
		participation = 0;
	}

	public TypeDecl getType() {
		return orig.implied;
	}

	public TypeDecl getTypeSource() {
		return orig.initial;
	}

	@Override
	public String toString() {
		return orig.toString();
	}

	public void participate() {
		participation++;
	}

	// this should be used only if the majority heuristic was run.
	public int getParticipation() {
		if (runHeuristic)
			return participation;
		else
			return -1;
	}

	public int getConfidence() {
		return confidence;
	}

	public void runHeuristic() {
		runHeuristic = true;
	}

	public void setConfidence(int value) {
		confidence = value;
	}

	@Override
	public boolean equals(Object o) {
		if (o != null && o instanceof ErrorTuple) {
			ErrorTuple other = (ErrorTuple) o;
			return getType().equals(other.getType())
					&& getTypeSource().equals(other.getTypeSource());
		}
		return false;
	}

	public boolean equalTuple(Object o) {
		if (o != null && o instanceof Tuple) {
			Tuple tu = (Tuple) o;
			return tu.equals(orig);
		}
		return equals(o);
	}

	public void simpleName(StringBuilder buf) {
		orig.simpleName(buf);
	}
	
	public Tuple getOrigTuple(){
		return orig;
	}

}
