/**
 * 
 */
package inference.ds;

import java.util.Iterator;
import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * Wrapper for solutions/substitutions return by the class EqualityGroupSolver.
 * 
 * @author Osiris
 */
public class Solution {

	// mapping from a type variable to an inferred type.
	private Map<TypeVariable, TypeDecl> subst;
	// sum of number of times the types in subst are used. A high score
	// corresponds to minimal amount of edits.
	private int score;

	/**
	 * @param subts
	 */
	public Solution(Map<TypeVariable, TypeDecl> subts) {
		this.subst = subts;
	}

	/**
	 * Provide an iterable view of the type variables in subst.
	 * 
	 * @return
	 */
	public Iterable<TypeVariable> iterate() {
		return new Iterable<TypeVariable>() {

			public Iterator<TypeVariable> iterator() {
				return subst.keySet().iterator();
			}

		};
	}

	/**
	 * Return the inferred type for the type variable var.
	 * 
	 * @param var
	 * @return
	 */
	public TypeDecl getType(TypeVariable var) {
		return subst.get(var);
	}

	/**
	 * @return
	 */
	public int score() {
		return score;
	}

	/**
	 * @param score
	 */
	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * Return this solution as a simple mapping from type variable to inferred
	 * types.
	 * 
	 * @return
	 */
	public Map<? extends TypeVariable, ? extends TypeDecl> substitution() {
		return subst;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		buf.append("{");
		boolean init = true;
		for (TypeVariable var : subst.keySet()) {
			if (init) {
				init = false;
			} else {
				buf.append(", ");
			}
			buf.append(var.shortName());
			buf.append(":");
			buf.append(subst.get(var).shortName());
		}
		buf.append("}");
		return buf.toString();
	}
}
