package inference.ds;

import inference.error_messages.AbstractErrorMsg;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SkippedEqTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.TypeParamBoundError;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import AST.TypeVariable;

public class ErrorSet {
	private TypeVariable typeVariable;

	// parameter errors
	private EqTypeErrorMsg equalityError;
	private List<SupTypeErrorMsg> supertypeErrorList;
	private List<SubTypeErrorMsg> subtypeErrorList;
	private List<SkippedEqTypeErrorMsg> equalErrorList;

	// bound errors
	private List<PrBoundTypeErrorMsg> preBoundErrorList;
	private List<PoBoundTypeErrorMsg> postBoundErrorList;
	private List<GlbTypeErrorMsg> glbErrorList;

	// Parameterized specific errors.
	private List<TypeParamBoundError> argBoundErrorList;

	public ErrorSet(TypeVariable typeVariable) {
		this.typeVariable = typeVariable;

		this.supertypeErrorList = new ArrayList<SupTypeErrorMsg>(5);
		this.subtypeErrorList = new ArrayList<SubTypeErrorMsg>(5);
		this.subtypeErrorList = new ArrayList<SubTypeErrorMsg>(5);
		this.equalErrorList = new LinkedList<SkippedEqTypeErrorMsg>();

		this.preBoundErrorList = new ArrayList<PrBoundTypeErrorMsg>(5);
		this.postBoundErrorList = new ArrayList<PoBoundTypeErrorMsg>(5);
		this.glbErrorList = new ArrayList<GlbTypeErrorMsg>(5);

		this.argBoundErrorList = new ArrayList<TypeParamBoundError>(5);
	}

	public void addErrorMsg(AbstractErrorMsg typeError) {
		if (typeError instanceof PrBoundTypeErrorMsg) {
			preBoundErrorList.add((PrBoundTypeErrorMsg) typeError);
		} else if (typeError instanceof EqTypeErrorMsg) {
			equalityError = (EqTypeErrorMsg) typeError;
		} else if (typeError instanceof SupTypeErrorMsg) {
			supertypeErrorList.add((SupTypeErrorMsg) typeError);
		} else if (typeError instanceof SubTypeErrorMsg) {
			subtypeErrorList.add((SubTypeErrorMsg) typeError);
		} else if (typeError instanceof GlbTypeErrorMsg) {
			glbErrorList.add((GlbTypeErrorMsg) typeError);
		} else if (typeError instanceof PoBoundTypeErrorMsg) {
			postBoundErrorList.add((PoBoundTypeErrorMsg) typeError);
		} else if (typeError instanceof TypeParamBoundError) {
			argBoundErrorList.add((TypeParamBoundError) typeError);
		} else if (typeError instanceof SkippedEqTypeErrorMsg) {
			equalErrorList.add((SkippedEqTypeErrorMsg) typeError);
		}
	}

	/*
	 * Getters
	 */

	public TypeVariable getTypeVariable() {
		return typeVariable;
	}

	public EqTypeErrorMsg getEqualityErrors() {
		return equalityError;
	}

	public List<SupTypeErrorMsg> getSupertypeErrorList() {
		return supertypeErrorList;
	}

	public List<SubTypeErrorMsg> getSubtypeErrorList() {
		return subtypeErrorList;
	}

	public List<PrBoundTypeErrorMsg> getPreBoundErrorList() {
		return preBoundErrorList;
	}

	public List<PoBoundTypeErrorMsg> getPostBoundErrorList() {
		return postBoundErrorList;
	}

	public List<GlbTypeErrorMsg> getGlbErrorList() {
		return glbErrorList;
	}

	public List<TypeParamBoundError> getArgBoundErrorList() {
		return argBoundErrorList;
	}

	public List<SkippedEqTypeErrorMsg> getEqualErrorList() {
		return equalErrorList;
	}

}
