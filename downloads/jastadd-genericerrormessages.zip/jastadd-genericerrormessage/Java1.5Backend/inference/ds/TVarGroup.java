/**
 * 
 */
package inference.ds;

import inference.error_messages.EqTypeErrorMsg;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * Wrapper for type variables that belong together because of their bound
 * dependencies and their inferred types.
 * 
 * @author Osiris
 */
public class TVarGroup {

	private Set<TypeVariable> varSet;
	private Map<TypeVariable, Map<TypeDecl, Integer>> typeStatsMap;
	private List<Solution> solutionList;
	private int lowestCost = Integer.MAX_VALUE;
	private int lowestCostCounter;

	/**
	 * @param varSet
	 */
	public TVarGroup(final Set<TypeVariable> varSet) {
		this.varSet = varSet;
		this.typeStatsMap =
				new HashMap<TypeVariable, Map<TypeDecl, Integer>>(varSet.size());
	}

	/**
	 * Set the type statistics collected during constraint collection. This
	 * method must be called first after creating an instance of this class to
	 * calculate the solutions scores.
	 * 
	 * @param var
	 * @param typeStats
	 */
	public void addTypeStats(final TypeVariable var,
			final Map<TypeDecl, Integer> typeStats) {
		typeStatsMap.put(var, typeStats);
	}

	/**
	 * Return an iterator that allows traverse the solutions of this group in
	 * forward and backward direction.
	 * 
	 * @return
	 */
	public ListIterator<? extends Solution> solutionIterator() {
		return solutionList.listIterator();
	}

	/**
	 * Return iterable view of the solutions, that can be used for the foreach
	 * loops.
	 * 
	 * @return
	 */
	public Iterable<? extends Solution> iterateSolutions() {
		return new Iterable<Solution>() {

			public Iterator<Solution> iterator() {
				return solutionList.iterator();
			}
		};
	}

	/**
	 * Return whether this type variable group has one optimal solution.
	 * 
	 * @return
	 */
	public boolean hasOneBestSolution() {
		return lowestCostCounter == 1;
	}

	/**
	 * Return the best/optimal solution.
	 * 
	 * @return
	 */
	public Solution bestSolution() {
		for (Solution solu : solutionList)
			if (solu.score() == lowestCost)
				return solu;
		return new Solution(new HashMap(0));
	}

	/**
	 * Return the best/optimal score.
	 * 
	 * @return
	 */
	public int highestScore() {
		// return highestScore;
		return lowestCost;
	}

	/**
	 * Check whether the parameter var is a member of this type variable group.
	 * 
	 * @param var
	 * @return
	 */
	public boolean constaintsTVar(TypeVariable var) {
		return varSet.contains(var);
	}

	/**
	 * Return all the member of this type variable group.
	 * 
	 * @return
	 */
	public Set<TypeVariable> memberVars() {
		return varSet;
	}

	/**
	 * Check whether any member of this type variable group has an empty domain.
	 * 
	 * @param typeGroup
	 * @param doms
	 * @return
	 */
	public final boolean hasEmptyDomain(Map<TypeVariable, List<TypeDecl>> doms) {
		for (TypeVariable var : varSet)
			if (doms.get(var).isEmpty())
				return true;
		return false;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		buf.append("[");
		boolean init = true;
		for (TypeVariable var : varSet) {
			if (init) {
				init = false;
			} else {
				buf.append(",");
			}
			buf.append(var.shortName());
		}
		buf.append("]");
		return buf.toString();
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;

		if (o instanceof Set)
			return o.equals(varSet);

		if (o instanceof TVarGroup)
			return this == o;

		return false;
	}

	@Override
	public int hashCode() {
		return varSet.hashCode();
	}

	public boolean isSolvable() {
		return solutionList != null && !solutionList.isEmpty();
	}

	/**
	 * Set the solutions corresponding to this type group and calculate the
	 * score of each solution, the score of a best solution and number of best
	 * solutions.
	 * 
	 * @param solutions
	 * @param eqErrors
	 * @param localSolution
	 */
	public void calcBestSolution(final List<Solution> solutions,
			final Map<TypeVariable, EqTypeErrorMsg> eqErrors,
			final boolean localSolution) {
		solutionList = solutions;
		if (localSolution)
			computeLocalSolutions(eqErrors);
		else
			computeDistinctSolutions(eqErrors);
	}

	/**
	 * Compute costs of solutions that are do not localize the changes.
	 * 
	 * @param eqErrors
	 * @see inference.ds.TVarGroup#calcBestSolution(List&lt;Solution&gt;,
	 *      Map&lt;TypeVariable, EqTypeErrorMsg&gt;, boolean)
	 */
	private void computeDistinctSolutions(
			final Map<TypeVariable, EqTypeErrorMsg> eqErrors) {
		for (Solution sol : solutionList) {
			int costs = 0;
			for (TypeVariable var : sol.iterate()) {
				// to prevent any null exceptions
				if (!eqErrors.containsKey(var))
					continue;
				EqTypeErrorMsg msg = eqErrors.get(var);
				for (Tuple tu : msg.getSourceTypes()) {
					TypeDecl srcType = tu.implied;
					costs += srcType.costsToConverTo(sol.getType(var));
				}
			}
			sol.setScore(costs);
			if (costs < lowestCost)
				lowestCost = costs;
		}

		for (Solution sol : solutionList) {
			if (sol.score() == lowestCost)
				lowestCostCounter++;
			if (lowestCostCounter > 1)
				break;
		}
	}

	/**
	 * Compute costs of solutions that are localize the changes.
	 * 
	 * @param eqErrors
	 * @see inference.ds.TVarGroup#calcBestSolution(List&lt;Solution&gt;,
	 *      Map&lt;TypeVariable, EqTypeErrorMsg&gt;, boolean)
	 */
	private void computeLocalSolutions(
			final Map<TypeVariable, EqTypeErrorMsg> eqErrors) {
		for (Solution sol : solutionList) {
			int costs = 0;
			for (TypeVariable var : sol.iterate()) {
				// to prevent any null exceptions
				if (!eqErrors.containsKey(var))
					continue;
				Map<TypeDecl, Integer> varStats = typeStatsMap.get(var);
				EqTypeErrorMsg msg = eqErrors.get(var);
				for (ErrorTuple etu : msg.getEqTypeValues()) {
					Tuple tu = etu.getOrigTuple();
					TypeDecl srcType = tu.implied;
					// costs times number of times to need to perform a type
					// change
					if (varStats.containsKey(srcType))
						costs +=
								srcType.costsToConverTo(sol.getType(var))
										* varStats.get(srcType);
				}
			}
			sol.setScore(costs);
			if (costs < lowestCost)
				lowestCost = costs;
		}

		for (Solution sol : solutionList) {
			if (sol.score() == lowestCost)
				lowestCostCounter++;
			if (lowestCostCounter > 1)
				break;
		}
	}
}
