/**
 * 
 */
package inference.ds;

import java.util.LinkedList;

import AST.Expr;
import AST.TypeDecl;

public class Tuple {
	public TypeDecl implied;

	public TypeDecl initial;

	private LinkedList positionList;
	private TypeDecl formalParam;

	public Tuple(TypeDecl implied, TypeDecl initial) {
		this.implied = implied;
		this.initial = initial;
	}

	@Override
	public boolean equals(Object o) {
		if (o != null && o instanceof Tuple) {
			Tuple other = (Tuple) o;
			return implied.equals(other.implied)
					&& initial.equals(other.initial);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return initial.hashCode() + implied.hashCode();
	}

	@Override
	public String toString() {
		return "(" + implied.fullName() + ", " + initial.fullName() + ")";
	}

	public void simpleName(StringBuilder buf) {
		// if initial was a primitive type then unboxed the implied type that
		// was autoboxed.
		if (initial.isPrimitiveType())
			buf.append(implied.unboxed().shortName());
		else {
			if (implied.isWildcard()) {
				buf.append("`");
				buf.append(implied.shortName());
				buf.append("'");
			} else {
				buf.append(implied.shortName());
			}
		}

		// implied type == initial type
		if (equalTypes()) {
			if (!initial.isFromDeclaredStmt()) {
				Expr ex = initial.getSourceExpr();
				// print only if expr is not a type access, like in par calls.
				if (ex != null && !ex.isTypeAccess()) {
					buf.append(" of the expression `");
					buf.append(ex.toString());
					buf.append("'");
				}
			}
		}
		// implied type =/= initial type
		else {
			if (!initial.isFromDeclaredStmt()) {
				Expr ex = initial.getSourceExpr();
				// print only if expr is not a type access, like in par calls.
				if (ex != null && !ex.isTypeAccess()) {
					buf.append(" from the expression `");
					buf.append(ex.toString());
					buf.append("'");
				}
			} else {
				buf.append(" in ");
				if (initial.hasParameterizedSuperType()) {
					buf.append("the supertype ");
					buf.append(initial.getParameterizedSuperType().shortName());
					buf.append(" of ");
					buf.append(initial.shortName());
				} else {
					buf.append(initial.shortName());
				}
			}
		}

		String initialLocation = initial.getSourceLocation();
		if (initialLocation != null && initialLocation != "") {
			buf.append(" on ");
			buf.append(initialLocation);
			if (!initial.hasParameterizedSuperType()) {
				String impliedLocation =
						initial.getSourceLocation(getPositionList());
				if (impliedLocation != null && implied != initial) {
					buf.append("(");
					buf.append(impliedLocation);
					buf.append(")");
				}
			}
		}
	}

	public String simpleName() {
		StringBuilder buf = new StringBuilder();
		simpleName(buf);
		return buf.toString();
	}

	private boolean equalTypes() {
		if (initial.isPrimitiveType())
			return initial.boxingConversionTo(implied);
		return initial == implied;
	}

	@Override
	public Tuple clone() {
		TypeDecl initialCopy = (TypeDecl) initial.copy();
		initialCopy.setSourceExpr(initial.getSourceExpr());
		Tuple copy = new Tuple(implied, initialCopy);
		copy.positionList = positionList;
		copy.formalParam = formalParam;
		return copy;
	}

	public LinkedList getPositionList() {
		return positionList;
	}

	public void setPositionList(LinkedList positionList) {
		this.positionList = positionList;
	}

	public String getImpliedLocation() {
		String loc = initial.getSourceLocation(getPositionList());
		return loc == null ? "" : loc;
	}
	
	public void setFormalParam(TypeDecl value) {
		formalParam = value;
	}
	
	public TypeDecl getFormalParam() {
		return formalParam;
	}

	public final boolean equivalent(Tuple t) {
		return t == null ? false : implied.fullName()
				.equals(t.implied.fullName())
				&& initial.fullName().equals(t.initial.fullName());
	}
}