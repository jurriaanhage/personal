/**
 * 
 */
package inference.ds;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import AST.AbstractWildcardType;
import AST.TypeDecl;

@SuppressWarnings("serial")
public class DistinctArrayList extends ArrayList<Tuple> {
	
	public DistinctArrayList() {
		super();
	}

	public DistinctArrayList(int initialCapacity) {
		super(initialCapacity);
	}

	@Override
	public boolean add(Tuple t) {
		// add wildcards without any exception
		if (t.implied instanceof AbstractWildcardType)
			return super.add(t);

		if (contains(t))
			return false;
		else
			return super.add(t);
	}

	@Override
	public boolean contains(Object t) {
		if (t instanceof Tuple) {
			Tuple UW = (Tuple) t;
			for (int i = 0; i < size(); i++) {
				if (get(i).implied.equals(UW.implied)
						&& get(i).initial.equals(UW.initial)) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public DistinctArrayList clone() {
		DistinctArrayList ret = new DistinctArrayList();
		for (Tuple item : this) {
			ret.add(item);
		}
		return ret;
	}

	/**
	 * Return an iterator over the implied types.
	 * 
	 * @return
	 */
	public Iterator<TypeDecl> impliedIterator() {
		return new Iterator<TypeDecl>() {
			private Iterator<Tuple> iter = iterator();

			public boolean hasNext() {
				return iter.hasNext();
			}

			public TypeDecl next() {
				return iter.next().implied;
			}

			public void remove() {
				throw new UnsupportedOperationException(
						"This is a read-only view!");
			}
		};
	}

	/**
	 * Return an Iterable view over the implied types.
	 * 
	 * @return
	 */
	public Iterable<TypeDecl> impliedView() {
		return new Iterable<TypeDecl>() {

			public Iterator<TypeDecl> iterator() {
				return impliedIterator();
			}

		};
	}

	/**
	 * Return an iterator of the unique implied types.
	 * 
	 * @return
	 */
	public Iterator<TypeDecl> uniqueImpliedIterator() {
		final Set<TypeDecl> uniqSet = new HashSet<TypeDecl>(size());
		for (int i = 0; i < size(); i++) {
			uniqSet.add(get(i).implied);
		}

		return new Iterator<TypeDecl>() {

			private Iterator<TypeDecl> iter = uniqSet.iterator();

			public boolean hasNext() {
				return iter.hasNext();
			}

			public TypeDecl next() {
				return iter.next();
			}

			public void remove() {
				throw new UnsupportedOperationException(
						"This is a read-only view!");
			}
		};
	}

	/**
	 * Return only the unique implied types view.
	 * 
	 * @return
	 */
	public Iterable<TypeDecl> uniqueImpliedView() {
		return new Iterable<TypeDecl>() {

			public Iterator<TypeDecl> iterator() {
				return uniqueImpliedIterator();
			}

		};
	}

	/**
	 * Return whether the parameter type is member of any tuple in this list.
	 * 
	 * @param type
	 * @return
	 */
	public boolean containsImpliedType(TypeDecl type) {
		for (Tuple uw : this)
			if (type == uw.implied)
				return true;

		return false;
	}
}