package inference.solvers;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.Tuple;

import java.util.ArrayList;
import java.util.List;

import AST.NullType;
import AST.TypeDecl;
import AST.TypeVariable;

public class CompleteSolver extends BasicSolver {

	protected TypeDecl contextType;
	protected TypeDecl returnType;

	protected ConstraintsMapBuilder builder;

	private TypeDecl inferredType;

	/**
	 * @param builder
	 *            constraints collector
	 * @param contextType
	 *            type acquired from the context
	 * @param returnType
	 *            return type whose type variables should be replaced with the
	 *            inferred types.
	 */
	public CompleteSolver(ConstraintsMapBuilder builder, TypeDecl contextType,
			TypeDecl returnType) {

		super(builder);
		this.builder = builder;
		this.contextType = contextType;
		this.returnType = returnType;
	}

	@Override
	public boolean inferTypes() {
		typeCheck(typeVariables, false);
		// infer the type of remaining type variables
		resolveUnresolvedConstraints();
		for (TypeVariable T : checkVarBounds.keySet()) {
			postCheckTypeBounds(T);
		}
		// empty the unchecked bounds
		checkVarBounds.clear();
		// add after checks
		afterCheck();
		if (!errMan.reportErrors()) {
			inferredType = instantiateParType(returnType);
		}
		return errMan.reportErrors();
	}

	/**
	 * see JLS section 15.12.2.8
	 * 
	 * @return
	 */
	protected void resolveUnresolvedConstraints() {
		// collect the type vars that need to be inferred
		List<TypeVariable> tvars = new ArrayList<TypeVariable>();
		for (TypeVariable T : typeVariables) {
			ConstraintSet constraintSet = constraintsMap.get(T);
			if (constraintSet.typeArgument == null
					&& constraintSet.equaltypeConstraints.isEmpty()
					&& constraintSet.supertypeConstraints.isEmpty())
				tvars.add(T);
		}

		if (!tvars.isEmpty())
			inferringUnresolvedTypeArguments(tvars);

	}

	/**
	 * see JLS section 15.12.2.8
	 * 
	 * @param tvars
	 *            type that still need to be inferred.
	 */
	private void inferringUnresolvedTypeArguments(List<TypeVariable> tvars) {
		// prepare context
		if (contextType.isUnboxedPrimitive())
			contextType = contextType.boxed();
		if (contextType.isVoid() || contextType instanceof NullType) {
			contextType = contextType.typeObject();
		}
		// replace type vars the method return type
		TypeDecl Rprime = instantiateParType(returnType);
		// add an extra constraint where context <: retutn_type
		this.builder.setConstraintsMap(constraintsMap);
		// initial constraints
		this.builder.convertibleFrom(contextType, Rprime);
		// additional constraints to make sure that the inferred type will
		// satisfy the bounds. JLS second bullet.
		for (TypeVariable T : tvars) {
			for (int i = 0; i < T.getNumTypeBound(); i++) {
				TypeDecl bound = instantiateParType(T.getTypeBound(i).type());
				// if a type of bound is already a part of the constraints, then
				// don't add it.
				if (!isBoundIncludedInSubtypes(T, bound))
					this.builder.convertibleFrom(bound, T);
			}
		}
		typeCheck(tvars, true);
		// if there are any typevars not inferred yet, then set them to be
		// object
		for (TypeVariable T : tvars) {
			if (constraintsMap.get(T).typeArgument == null) {
				constraintsMap.get(T).typeArgument = contextType.typeObject();
			}
		}

	}

	private boolean isBoundIncludedInSubtypes(TypeVariable T, TypeDecl bound) {
		for (Tuple UW : constraintsMap.get(T).subtypeConstraints)
			if (UW.implied.subtype(bound))
				return true;
		return false;
	}

	public TypeDecl getInferredType() {
		return inferredType;
	}
}
