/**
 * 
 */
package inference.solvers;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.TypeCheckErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.TypeParamBoundError;

import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class ParAccessSolver extends CompleteSolver {

	protected Map<TypeVariable, TypeDecl> typeArgumentMap;
	private TypeCheckErrorManager checkOnlyErrorManager;
	private boolean typeArgBoundsChecked = false;

	/**
	 * @param builder
	 * @param compUnit
	 * @param contextType
	 * @param returnType
	 */
	public ParAccessSolver(ConstraintsMapBuilder builder, TypeDecl contextType,
			TypeDecl returnType, Map<TypeVariable, TypeDecl> typeArgs) {
		super(builder, contextType, returnType);
		this.typeArgumentMap = typeArgs;
		this.checkOnlyErrorManager = new TypeCheckErrorManager(typeVariables);
	}

	/**
	 * Called to check whether constraints are satisfied by the given type
	 * arguments.
	 * 
	 * @return
	 */
	public boolean checkTypes() {
		if (typeArgBoundsChecked) {
			checkTypeArgumentConstraints();
		}
		fillMissingConstraints();
		afterCheck();
		return checkOnlyErrorManager.reportErrors();
	}

	/**
	 * Verify whether the given type arguments satisfy the bounds
	 * 
	 * @return
	 */
	public boolean checkTypeArgumentBoundErrors() {
		for (TypeVariable T : typeArgumentMap.keySet()) {
			TypeDecl V = typeArgumentMap.get(T);
			for (int i = 0; i < T.getNumTypeBound(); i++) {
				TypeDecl bound = T.getTypeBound(i).type();
				bound = bound.instantiateParType(typeArgumentMap);
				if (!V.subtype(bound))
					checkOnlyErrorManager.addErrorMsg(new TypeParamBoundError(
							T, V, bound));

			}
		}
		return checkOnlyErrorManager.hasTypeParamBoundErrors();
	}

	/**
	 * Return error messages produced while checking the constraints
	 * 
	 * @param buf
	 */
	public void getCheckErrors(StringBuilder buf) {
		checkOnlyErrorManager.fetchErrorMsgs(buf);
	}

	/**
	 * Check all the collected constraints.
	 */
	protected void checkTypeArgumentConstraints() {
		checkTypeArgumentEqualityConstraints();
		checkTypeArgumentSupertypeConstraints();
		checkTypeArgumentSubtypeConstraints();
	}

	/**
	 * Check the equality constraints.
	 */
	protected void checkTypeArgumentEqualityConstraints() {
		for (TypeVariable T : constraintsMap.keySet()) {
			DistinctArrayList equalityConsraints =
					constraintsMap.get(T).equaltypeConstraints;
			EqTypeErrorMsg msg = new EqTypeErrorMsg(T);
			TypeDecl V = typeArgumentMap.get(T);
			for (int i = 0; i < equalityConsraints.size(); i++) {
				Tuple UW = equalityConsraints.get(i);
				// U =/= V
				if (!sameTypes(V, UW.implied))
					msg.addConflictingType(new ErrorTuple(UW));
			}
			if (msg.reportError()) {
				msg.addConflictingType(new ErrorTuple(new Tuple(V, V)));
				checkOnlyErrorManager.addErrorMsg(msg);
			}
		}
	}

	/**
	 * Check supertype constraints.
	 */
	protected void checkTypeArgumentSupertypeConstraints() {
		for (TypeVariable T : constraintsMap.keySet()) {
			DistinctArrayList supertypeConstraints =
					constraintsMap.get(T).supertypeConstraints;
			for (int i = 0; i < supertypeConstraints.size(); i++) {
				Tuple UW = supertypeConstraints.get(i);
				TypeDecl V = typeArgumentMap.get(T);
				if (!UW.implied.subtype(V)) {
					// U </: T[T/V] => U </: V
					SupTypeErrorMsg msg = new SupTypeErrorMsg(T, V, UW);
					msg.setProvidedType(true);
					checkOnlyErrorManager.addErrorMsg(msg);
				}
			}
		}
	}

	/**
	 * Check subtype constraints
	 */
	protected void checkTypeArgumentSubtypeConstraints() {
		for (TypeVariable T : constraintsMap.keySet()) {
			DistinctArrayList subtypeConstraints =
					constraintsMap.get(T).subtypeConstraints;
			for (int i = 0; i < subtypeConstraints.size(); i++) {
				TypeDecl V = typeArgumentMap.get(T);
				Tuple UW = subtypeConstraints.get(i);
				if (!V.subtype(UW.implied)) {
					SubTypeErrorMsg msg = new SubTypeErrorMsg(T, V, UW);
					msg.setProvidedType(true);
					checkOnlyErrorManager.addErrorMsg(msg);
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.BasicSolver#afterCheck()
	 */
	@Override
	protected void afterCheck() {
		performAfterChecks(typeArgumentMap, checkOnlyErrorManager);
		for (TypeCheckErrorMsg msg : checkOnlyErrorManager.getCheckErrorList())
			msg.setProvidedType(true);
	}

	/*
	 * Don't run the heuristics
	 */
	@Override
	public boolean inferTypes() {
		// check is collected consist of only T <: U
		typeCheck(typeVariables, false);

		// infer the type of remaining type variables
		resolveUnresolvedConstraints();

		// add after checks to InferenceErrorManager not the
		// TypeCheckErrorManager.
		super.afterCheck();

		// pass inferred types to the error manager
		checkOnlyErrorManager.setInferredTypeArguments(inferredTypeArguments());
		checkOnlyErrorManager.setTypeArguments(typeArgumentMap);

		return errMan.reportErrors();
	}

	/**
	 * if type variable has no constraints then use the provided type arguments
	 * to be able to perform after-checks
	 */
	private void fillMissingConstraints() {
		for (Map.Entry<TypeVariable, ConstraintSet> kv : constraintsMap
				.entrySet()) {
			ConstraintSet set = kv.getValue();
			if (set.equaltypeConstraints.isEmpty()
					&& set.subtypeConstraints.isEmpty()
					&& set.supertypeConstraints.isEmpty()) {
				set.typeArgument = typeArgumentMap.get(kv.getKey());
			}
		}
	}
}
