package inference.solvers;

import inference.ConstraintsMapBuilder;
import inference.ConstraintsMapBuilder.PositionedType;
import inference.ds.ConstraintSet;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.heuristics.BoundGlbSubtyping;
import inference.heuristics.BoundSuperWildcard;
import inference.heuristics.CxtReturnInvariance;
import inference.heuristics.EqualityTypeWarning;
import inference.heuristics.ExtendsFinal;
import inference.heuristics.LowerBoundSubtyping;
import inference.heuristics.MaximalEquality;
import inference.heuristics.OppositeWildcards;
import inference.heuristics.MaximalSubtyping;
import inference.heuristics.SuperObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import AST.GenericMethodDecl;
import AST.MethodAccess;
import AST.NullType;
import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

public class MethodSolver extends CompleteSolver implements ISolver {

	private Map<TypeVariable, ConstraintSet> originalConstraintsMap;
	private final List<? extends TypeDecl> formalParameterList;
	private final List<PositionedType> actualParameterList;

	public MethodSolver(ConstraintsMapBuilder builder, MethodAccess invoc,
			GenericMethodDecl decl) {

		super(builder, invoc.assignConvertedType(), decl.type());
		// make a copy of the constraints for the heuristics
		originalConstraintsMap =
				new HashMap<TypeVariable, ConstraintSet>(constraintsMap.size());
		copyConstraints(constraintsMap, originalConstraintsMap);
		this.formalParameterList = builder.getFormalParameters();
		this.actualParameterList = builder.getActualParameters();
	}

	public boolean inferTypes(boolean useheuristics) {
		if (useheuristics)
			return inferTypes();
		else
			return super.inferTypes();

	}

	@Override
	public boolean inferTypes() {
		if (Program.hasOption(Program._ptc)) {
			printConstraints();
			printChecks();
		}

		if (super.inferTypes()) {
			// check if collected constraint consist of only T <: U
			boolean onlySubtypeConstraints = onlySubtypeConstraints();
			countSubtypeConstraints();
			new MaximalEquality(this).analyse();
			// if subtype constraints were not checked for a glb, then start the
			// heuristic
			if (errMan.checkForGlbBoundErrors())
				new LowerBoundSubtyping(this).analyse();
			// start heuristic only is there a T that has other conastraints
			// than just subtype constraints.
			if (!onlySubtypeConstraints) {
				// run heuristic only if a useful type type
				if (!(contextType instanceof NullType || contextType.isVoid()))
					new CxtReturnInvariance(this).analyse();
			} else {
				new BoundGlbSubtyping(this).analyse();
			}
			// T'bound <: ? sup bound
			new BoundSuperWildcard(this).analyse();
			// start heuristic only if errors were found
			if (errMan.hasAfterCheckErrors())
				new OppositeWildcards(this).analyse();
			// start super object heuristic
			new SuperObject(this).analyse();
			// start extends final heuristic
			if (!Program.hasOption(Program._disableFinal))
				new ExtendsFinal(this).analyse();
			// warn the user about future errors.
			new EqualityTypeWarning(copyConstraints(), errMan).analyse();
			// experimental heuristic
			new MaximalSubtyping(this).analyse();
		} else if (Program.hasOption(Program._ptc))
			printInferredTypes();

		return errMan.reportErrors();
	}

	private boolean onlySubtypeConstraints() {
		for (TypeVariable T : typeVariables) {
			if (constraintsMap.get(T).equaltypeConstraints.isEmpty()
					&& constraintsMap.get(T).supertypeConstraints.isEmpty())
				return true;
		}
		return false;
	}

	// TODO you might have to remove me!!
	protected void countSubtypeConstraints() {
		for (TypeVariable T : typeVariables) {
			errMan.setNumOfSubtypeConstraints(T,
					constraintsMap.get(T).subtypeConstraints.size());
		}
	}

	public Map<TypeVariable, ConstraintSet> copyConstraints() {
		Map<TypeVariable, ConstraintSet> copy =
				new HashMap<TypeVariable, ConstraintSet>(originalConstraintsMap
						.size());
		copyConstraints(originalConstraintsMap, copy);
		return copy;
	}

	public Map<TypeVariable, ConstraintSet> copyCurrentConstraints() {
		Map<TypeVariable, ConstraintSet> copy =
				new HashMap<TypeVariable, ConstraintSet>(constraintsMap.size());
		copyConstraints(constraintsMap, copy);
		return copy;
	}

	public final static void copyConstraints(
			Map<TypeVariable, ConstraintSet> src,
			Map<TypeVariable, ConstraintSet> dst) {
		for (TypeVariable T : src.keySet()) {
			dst.put(T, src.get(T).clone());
		}
	}

	/**
	 * Print the inferred type for each type variable.
	 */
	public void printInferredTypes() {
		System.out.println("Inferred types:");
		for (Map.Entry<TypeVariable, TypeDecl> kv : inferredTypeArguments()
				.entrySet())
			System.out.println("  " + kv.getKey().shortName() + ":= "
					+ kv.getValue().simpleName());
	}

	// ------------------------------------------------------------------------
	// Implementation of ISolver interfae
	// ------------------------------------------------------------------------

	public TypeDecl getContextType() {
		return contextType;
	}

	public Map<TypeVariable, ConstraintSet> getCurrentConstraints(boolean copy) {
		return copy ? copyCurrentConstraints() : constraintsMap;
	}

	public Map<TypeVariable, ConstraintSet> getOriginalConstraints() {
		return copyConstraints();
	}

	public TypeDecl getReturnType() {
		return returnType;
	}

	public Map<TypeDecl, List<Tuple>> getSubTypeChecks() {
		return subtypeAfterChecks;
	}

	public Map<TypeDecl, List<Tuple>> getSuperTypeChecks() {
		return supertypeAfterChecks;
	}

	public ITypeErrorManager getTypeErrorManager() {
		return errMan;
	}

	public List<? extends TypeDecl> getFormalParameters() {
		return formalParameterList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.solvers.ISolver#getActualParameters()
	 */
	public List<PositionedType> getActualParameters() {
		ArrayList<PositionedType> actuals =
				new ArrayList<PositionedType>(actualParameterList.size());
		for (PositionedType pt : actualParameterList)
			actuals.add(pt.copy());

		return actuals;
	}
}
