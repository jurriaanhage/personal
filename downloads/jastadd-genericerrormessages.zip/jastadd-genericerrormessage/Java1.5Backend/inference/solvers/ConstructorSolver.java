/**
 * 
 */
package inference.solvers;

import inference.ConstraintsMapBuilder;

import java.util.Map;

import AST.ClassInstanceExpr;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class ConstructorSolver extends ParAccessSolver {

	/**
	 * @param builder
	 * @param inv
	 * @param typeArgs
	 */
	public ConstructorSolver(ConstraintsMapBuilder builder,
			ClassInstanceExpr inv, Map<TypeVariable, TypeDecl> typeArgs) {

		super(builder, inv.assignConvertedType(), inv.type(), typeArgs);
	}
}
