/**
 * 
 */
package inference.solvers;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.ErrorSet;
import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.InferenceErrorManager;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SkippedEqTypeErrorMsg;
import inference.error_messages.SubErrorCheckMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.SupErrorCheckMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.AbstractWildcardType;
import AST.ClassDecl;
import AST.GLBType;
import AST.GenericClassDecl;
import AST.GenericInterfaceDecl;
import AST.InterfaceDecl;
import AST.LUBType;
import AST.Modifiers;
import AST.ParClassDecl;
import AST.ParInterfaceDecl;
import AST.ParTypeDecl;
import AST.TypeAccess;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.VarTypeDecl;

/**
 * @author Drako
 * 
 */
@SuppressWarnings("unchecked")
public class BasicSolver {

	// constraints collected for the type variables
	protected Map<TypeVariable, ConstraintSet> constraintsMap;

	protected InferenceErrorManager errMan;

	// type variables that have bounds not checked yet
	protected Map<TypeVariable, List<TypeDecl>> checkVarBounds;

	protected List<TypeVariable> typeVariables;

	// ? <: T or ? <: X<T>
	protected Map<TypeDecl, List<Tuple>> supertypeAfterChecks;

	// T <: ? or X<T> <: T
	protected Map<TypeDecl, List<Tuple>> subtypeAfterChecks;

	// Mapping type variables to their inferred type
	Map<TypeVariable, TypeDecl> inferredArgs;

	public BasicSolver(ConstraintsMapBuilder builder) {
		constraintsMap = builder.getConstraintsMap();
		typeVariables = builder.getTypeVariableList();
		supertypeAfterChecks = builder.getSupertypeAfterChecks();
		subtypeAfterChecks = builder.getSubtypeAfterChecks();
		errMan = new InferenceErrorManager(typeVariables);
		checkVarBounds =
				new HashMap<TypeVariable, List<TypeDecl>>(typeVariables.size());
		this.inferredArgs = new HashMap<TypeVariable, TypeDecl>();
		setSourceofSubtypeConstraints();
	}

	private void setSourceofSubtypeConstraints() {
		for (TypeVariable T : constraintsMap.keySet())
			if (constraintsMap.get(T).subtypeConstraints.size() > 0)
				constraintsMap.get(T).setSubtypeConstraintsFromInv(true);
	}

	public InferenceErrorManager getErrorManager() {
		return errMan;
	}

	public Map<TypeVariable, ConstraintSet> getConstraintsMap() {
		return constraintsMap;
	}

	public void printOrderedTypeVariables() {
		for (TypeVariable var : typeVariables) {
			System.out.println(var.fullName() + ": " + var.getOrder());
		}
	}

	public void printConstraints() {
		System.err.println("Current constraints:");
		for (TypeVariable T : typeVariables) {
			ConstraintSet set = constraintsMap.get(T);
			printConstraints(set.supertypeConstraints, T, " :> ");
			printConstraints(set.subtypeConstraints, T, " <: ");
			printConstraints(set.equaltypeConstraints, T, " = ");
		}
	}

	private static final void printConstraints(Collection<Tuple> col,
			TypeDecl T, String sym) {
		for (Tuple UW : col) {
			System.err.println("  " + T.fullName() + sym
					+ UW.implied.fullName());
		}
	}

	public void printChecks() {
		System.out.println("Supertype checks:");
		for (TypeDecl var : supertypeAfterChecks.keySet()) {
			for (Tuple sub : supertypeAfterChecks.get(var))
				System.out.println("  " + sub.implied.simpleName() + " <: "
						+ var.simpleName());
		}
		System.out.println("Subtype checks:");
		for (TypeDecl var : subtypeAfterChecks.keySet()) {
			for (Tuple sup : subtypeAfterChecks.get(var))
				System.out.println("  " + var.simpleName() + " <: "
						+ sup.implied.simpleName());
		}
	}

	/**
	 * Return a list of the inferred types.
	 * 
	 * @return
	 */
	public List typeArguments() {
		ArrayList list = new ArrayList(typeVariables.size());
		for (Iterator iter = typeVariables.iterator(); iter.hasNext();) {
			TypeVariable T = (TypeVariable) iter.next();
			ConstraintSet set = constraintsMap.get(T);
			list.add(set.typeArgument);
		}
		return list;
	}

	/*
	 * 1- Get the type var T with the highest order. 2- Check the that values of
	 * T satisfy the bound 2.1 - if not T.equalSet.isEmpty(): forall val in
	 * T.equalSet forall bound in T.bounds val <: bound else if not
	 * T.superSet.isEmpty(): forall val in T.superSet forall bound in T.bounds
	 * val <: bound
	 * 
	 * 
	 * 3- For T <: U constraints, check that U's have a glb 4- Solve T = U
	 * constraints 5- Solve U <: T constraints 6- Solve T <: U constraints
	 */
	/**
	 * Start the inference process
	 * 
	 * @return true is if the inference fails, and false if it succeeds.
	 */
	public boolean inferTypes() {
		// if ((Program._debug & Program._trace) == Program._trace)
		// System.out.println("Begin basic type checking...");

		typeCheck(typeVariables, true);
		for (TypeVariable T : checkVarBounds.keySet()) {
			postCheckTypeBounds(T);
		}
		// empty the unchecked bounds
		checkVarBounds.clear();
		afterCheck();

		return errMan.reportErrors();
	}

	/**
	 * Check whether constraints the were ignored by the inference are
	 * satisfied.
	 */
	protected void afterCheck() {
		if (supertypeAfterChecks.isEmpty() && subtypeAfterChecks.isEmpty())
			return;
		// substitution env
		Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>();
		for (TypeVariable T : typeVariables) {
			subst.put(T, constraintsMap.get(T).typeArgument);
		}

		performAfterChecks(subst, errMan);
	}

	/**
	 * Substitute type variables in the constraints that were not dealt with by
	 * the inference with new types in subst then solve these constraints.
	 * Perform this step only if type variables in check are correctly inferred.
	 * 
	 * @param subst
	 *            a substitution that maps each type variable to a type.
	 * @param erman
	 *            an error manager to add errors to.
	 */
	protected void performAfterChecks(Map<TypeVariable, TypeDecl> subst,
			TypeErrorManager erman) {
		// check ? <: T or ? <: X<T>
		for (TypeDecl sup : supertypeAfterChecks.keySet()) {
			if (!areInferred(sup.getTypeVariables(), constraintsMap))
				continue;
			TypeDecl new_sup = sup.instantiateParType(subst);
			for (Tuple UW : supertypeAfterChecks.get(sup)) {
				// if (!UW.implied.subtype(new_sup))
				if (!UW.implied.parSubtype(new_sup))
					erman.addErrorMsg(new SupErrorCheckMsg(UW, new_sup, sup,
							partiallyInferredTypeArguments()));
			}
		}
		// check T <: ? or X<T> <: ?
		for (TypeDecl sub : subtypeAfterChecks.keySet()) {
			if (!areInferred(sub.getTypeVariables(), constraintsMap))
				continue;
			TypeDecl new_sub = sub.instantiateParType(subst);
			for (Tuple UW : subtypeAfterChecks.get(sub)) {
				// if (!new_sub.subtype(UW.implied))
				if (!new_sub.parSubtype(UW.implied))
					erman.addErrorMsg(new SubErrorCheckMsg(UW, new_sub, sub,
							partiallyInferredTypeArguments()));
			}
		}
	}

	/**
	 * Perform the actual inference for the type variables in typeVars. The
	 * parameter calcGLB indicates whether the solver should calculate the
	 * greatest lower bound for the type variables.
	 * 
	 * @param typeVars
	 * @param calcGLB
	 */
	protected void typeCheck(List<TypeVariable> typeVars, boolean calcGLB) {
		HashSet<TypeVariable> excludedVars = new HashSet<TypeVariable>();
		for (TypeVariable T : typeVars) {
			if (!excludedVars.contains(T))
				preCheckTypeBounds(T);
			boolean proceed = resolveEqulaityConstraints(T);
			if (proceed) {
				proceed = resolveSupertypeConstraints(T);
				if (proceed)
					proceed = resolveSubtypeConstraints(T, calcGLB);

			} else {
				excludedVars.addAll(T.dependingTypeVariables(typeVars));
			}
		}

	}

	/**
	 * Verify that the inferred type for the type variable T satisfies the
	 * bounds that could not be checked at first by preCheckTypeBounds.
	 * 
	 * @param T
	 */
	protected void postCheckTypeBounds(TypeVariable T) {
		TypeDecl U = constraintsMap.get(T).typeArgument;
		for (TypeDecl bound : checkVarBounds.get(T)) {
			TypeDecl instBound = instantiateParType(bound);
			if (!U.subtype(instBound)) {
				errMan.addErrorMsg(new PoBoundTypeErrorMsg(T, U, bound));
			}
		}
	}

	/**
	 * verify that input values used to calculate a type variable satisfy the
	 * bounds of that variable.
	 * 
	 * @param T
	 */
	private void preCheckTypeBounds(TypeVariable T) {
		ConstraintSet set = constraintsMap.get(T);

		// check the equal constraints.
		if (set.equaltypeConstraints.size() > 0) {
			for (int i = 0; i < set.equaltypeConstraints.size(); i++) {
				Tuple UW = set.equaltypeConstraints.get(i);
				for (int j = 0; j < T.getNumTypeBound(); j++) {
					TypeDecl bound = T.getTypeBound(j).type();
					preCheckBound(T, bound, UW);
				}
			}
		}
		// check subtype constraints if there is no equal constraints
		else if (set.supertypeConstraints.size() > 0) {
			for (int i = 0; i < set.supertypeConstraints.size(); i++) {
				Tuple UW = set.supertypeConstraints.get(i);
				// TypeDecl U = UW.implied;
				for (int j = 0; j < T.getNumTypeBound(); j++) {
					TypeDecl bound = T.getTypeBound(j).type();
					preCheckBound(T, bound, UW);
				}
			}
		}
	}

	/**
	 * Solve the Ti = Ui constraints.
	 * 
	 * @param T
	 */
	private boolean resolveEqulaityConstraints(TypeVariable T) {
		ConstraintSet set = constraintsMap.get(T);
		if (set.equaltypeConstraints.size() == 1) {
			TypeDecl impliedType = set.equaltypeConstraints.get(0).implied;
			if (impliedType instanceof VarTypeDecl) {
				TypeVariable impliedVar =
						((VarTypeDecl) impliedType).originalTypeVariable();
				if (typeVariables.contains(impliedVar) && T != impliedVar) {
					set.equalTuple = set.equaltypeConstraints.get(0);
					replaceAllConstraints(T.captureTypeVariables(), impliedType
							.skolemize());
					set.equaltypeConstraints.clear();
					return false;
				}
			}

			impliedType = impliedType.skolemize();
			if (T.captureTypeVariables() != impliedType) {
				replaceEqualityConstraints(T.captureTypeVariables(),
											impliedType);

				set.typeArgument = impliedType;
				// T was not inferred from super- or sub-type constraints
				// T was inferred though propagation
				if (!(set.supertypeConstraints.isEmpty() && set.subtypeConstraints
						.isEmpty())) {
					if (set.equalTuple != null)
						errMan.addErrorMsg(new SkippedEqTypeErrorMsg(T,
								impliedType, set.equalTuple));
				}
			} else {
				// infer from super- or sub-type constraints, or from cxt.
				set.equaltypeConstraints.clear();
			}

		} else if (set.equaltypeConstraints.size() > 1) {
			EqTypeErrorMsg eem = new EqTypeErrorMsg(T);
			for (int i = 0; i < set.equaltypeConstraints.size(); i++) {
				Tuple UWi = set.equaltypeConstraints.get(i);
				boolean addUwi = false;
				for (int j = i + 1; j < set.equaltypeConstraints.size(); j++) {
					Tuple UWj = set.equaltypeConstraints.get(j);
					// Types must be exactly the same
					if (!sameTypes(UWi.implied, UWj.implied)) {
						addUwi = true;
						eem.addConflictingType(new ErrorTuple(UWj));
					}
				}
				if (addUwi)
					eem.addConflictingType(new ErrorTuple(UWi));
			}
			if (eem.reportError()) {
				// add the source type for repair heuristics.
				HashSet<Tuple> noDups =
						new HashSet<Tuple>(eem.getEqTypeValues().size());
				for (ErrorTuple et : eem.getEqTypeValues()) {
					// do not add wildcards until they are filtered.
					if (et.getType() instanceof AbstractWildcardType)
						noDups.add(et.getOrigTuple());
					else
						for (Tuple uw : set.allEqualtypeConstraints)
							if (uw.equivalent(et.getOrigTuple()))
								eem.addConflictingSourceType(uw);

				}
				for (Tuple tu : noDups)
					for (Tuple uw : set.allEqualtypeConstraints)
						if (uw.equivalent(tu))
							eem.addConflictingSourceType(uw);
				errMan.addErrorMsg(eem);
				return false;
			} else {
				Tuple eqTuple = set.equaltypeConstraints.get(0);
				set.typeArgument = eqTuple.implied.skolemize();
			}
		}
		return true;
	}

	/**
	 * slove U <: T
	 * 
	 * @param T
	 * @return
	 */
	private boolean resolveSupertypeConstraints(TypeVariable T) {
		ConstraintSet set = constraintsMap.get(T);
		if (set.typeArgument == null) {
			if (set.supertypeConstraints.isEmpty())
				return true;

			TypeDecl lub = set.supertypeConstraints.get(0).implied;
			// since LUB is buggy, perform a lub operation only if there more
			// than one constraints.
			if (set.supertypeConstraints.size() > 1) {
				ArrayList<TypeDecl> decls = new ArrayList<TypeDecl>();
				for (int i = 0; i < set.supertypeConstraints.size(); i++) {
					decls.add(set.supertypeConstraints.get(i).implied);
				}
				lub = T.lookupLUBType(decls).lub();
			}
			set.typeArgument = lub;
			if (set.equalTuple != null) {
				if (set.equalTuple.implied != lub)
					errMan.addErrorMsg(new SkippedEqTypeErrorMsg(T, lub,
							set.equalTuple));
			}

		} else {
			for (int i = 0; i < set.supertypeConstraints.size(); i++) {
				Tuple UW = set.supertypeConstraints.get(i);
				if (!UW.implied.subtype(set.typeArgument)) {
					SupTypeErrorMsg errMsg =
							new SupTypeErrorMsg(T, set.typeArgument, UW);
					errMan.addErrorMsg(errMsg);
				}
			}
		}
		return true;
	}

	/**
	 * solve T <: U
	 * 
	 * @param T
	 * @return
	 */
	private boolean resolveSubtypeConstraints(TypeVariable T, boolean calcGLB) {
		ConstraintSet set = constraintsMap.get(T);

		if (set.typeArgument == null) {
			if (calcGLB && set.subtypeConstraints.size() > 0) {
				set.typeArgument = glb(T, set.subtypeConstraints);
				// (T <: X)'s must be from the parameters
				if (set.equalTuple != null && !set.typeArgument.isUnknown()
						&& set.hasSubtypeConstraintsFromInv())
					errMan.addErrorMsg(new SkippedEqTypeErrorMsg(T,
							set.typeArgument, set.equalTuple));
			}
		} else {
			for (int i = 0; i < set.subtypeConstraints.size(); i++) {
				Tuple UW = set.subtypeConstraints.get(i);
				if (!set.typeArgument.subtype(UW.implied)) {
					errMan.addErrorMsg(new SubTypeErrorMsg(T, set.typeArgument,
							UW));
				}
			}
		}
		return true;
	}

	/**
	 * @param T
	 * @param bound
	 * @param UW
	 * @param errmsgs
	 */
	private void preCheckBound(TypeVariable T, TypeDecl bound, Tuple UW) {
		final TypeDecl formalBound = bound;
		// if bound is typevar its inferred type is used
		if (bound instanceof TypeVariable) {
			bound = instantiateParType(bound);
			if (bound == null) {
				throw new RuntimeException("\n** Value of " + bound.name()
						+ " was not Inferred **\n");
			} else if (bound instanceof TypeVariable) {
				addPostBoundCheck(T, bound);
				return;
			}
		}
		// ParTypeDecl substitute(X<T>)
		else if (bound.isParameterizedType()) {
			// ignore bounds that contains T
			Set<TypeVariable> vars = bound.getTypeVariables();
			if ((vars.contains(T))) {
				addPostBoundCheck(T, bound);
				return;
			} else if (vars.size() > 0)
				bound = instantiateParType(bound);
		}
		if (!UW.implied.subtype(bound)) {
			PrBoundTypeErrorMsg bndErrorMsg =
					new PrBoundTypeErrorMsg(T, UW, bound);
			bndErrorMsg.setFormalBound(formalBound);
			errMan.addErrorMsg(bndErrorMsg);
		}
		constraintsMap.get(T).boundConstraints.add(bound);
	}

	/**
	 * Add bound to a T's list of bounds that need be check after everything is
	 * inferred.
	 * 
	 * @param T
	 * @param bound
	 */
	private void addPostBoundCheck(TypeVariable T, TypeDecl bound) {
		if (checkVarBounds.containsKey(T)) {
			checkVarBounds.get(T).add(bound);
		} else {
			List<TypeDecl> boundList = new LinkedList<TypeDecl>();
			boundList.add(bound);
			checkVarBounds.put(T, boundList);
		}
	}

	/**
	 * Replace type variables in the given typeDecl with the inferred types.
	 * 
	 * @param typeDecl
	 * @return
	 */
	protected TypeDecl instantiateParType(TypeDecl typeDecl) {
		if (!typeDecl.involvesTypeParameters())
			return typeDecl;

		// return TypeDecl
		TypeDecl retType = null;
		if (typeDecl instanceof TypeVariable) {
			if (constraintsMap.containsKey(typeDecl))
				retType = constraintsMap.get(typeDecl).typeArgument;

			// return the type that was given to prevent null exception
			retType = retType == null ? typeDecl : retType;
		}
		// create a type access
		else if (typeDecl instanceof InterfaceDecl) {
			// get the generic interface
			// GenericInterfaceDecl gid = (GenericInterfaceDecl)
			// bound.genericTypeDecl();
			GenericInterfaceDecl gid =
					(GenericInterfaceDecl) typeDecl.genericDecl();
			// create a new parameterized interface
			ParInterfaceDecl pid = new ParInterfaceDecl();
			pid.setModifiers((Modifiers) gid.getModifiers().fullCopy());
			pid.setID(gid.getID());
			// create a list of type arguments.
			pid
					.setArgumentList(createNewArgumentList(((ParInterfaceDecl) typeDecl)));
			// add the parameterized interface to the generic parent
			gid.addParTypeDecl(pid);
			retType = pid;
		} else if (typeDecl instanceof ClassDecl) {
			// get the generic class
			// GenericClassDecl gcd = (GenericClassDecl)
			// bound.genericTypeDecl();
			GenericClassDecl gcd = (GenericClassDecl) typeDecl.genericDecl();
			// create an new paramterized class
			ParClassDecl pcd = new ParClassDecl();
			pcd.setModifiers((Modifiers) gcd.getModifiers().fullCopy());
			pcd.setID(gcd.getID());
			// create a list of arguments
			pcd.setArgumentList(createNewArgumentList((ParClassDecl) typeDecl));
			// add the paramterized class to the genreic parent
			gcd.addParTypeDecl(pcd);
			retType = pcd;
		}
		return retType;
	}

	/**
	 * Return a list of parType's type parameters, where type variables are
	 * substituted by their inferred value
	 * 
	 * @param parType
	 * @param argList
	 */
	private AST.List createNewArgumentList(ParTypeDecl parType) {
		AST.List argList = new AST.List();
		for (int i = 0; i < parType.getNumArgument(); i++) {
			TypeDecl typeArg = parType.getArgument(i).type();
			// if typeArg is a type var then use it's inferred type.
			if (typeArg instanceof TypeVariable) {
				ConstraintSet bset = constraintsMap.get(typeArg);
				TypeAccess acs = (TypeAccess) parType.getArgument(i);
				if (bset != null && bset.typeArgument != null)
					acs = bset.typeArgument.createBoundAccess();
				argList.add(acs);
			}
			// if typeArg is a param type then replace it with a new param type
			// where type vars are replaced with thier inffered type
			else if (typeArg.isParameterizedType()) {
				TypeDecl new_typeArg = instantiateParType(typeArg);
				argList.add(new_typeArg.createBoundAccess());
			}
			// non-parameterized types
			else {
				argList.add(parType.getArgument(i));
			}
		}
		return argList;
	}

	/**
	 * Verify the two types decl1 and decl2 are exaclty the same type.
	 * 
	 * @param decl1
	 * @param decl2
	 * @return
	 */
	protected boolean sameTypes(TypeDecl decl1, TypeDecl decl2) {
		if (decl1 instanceof AbstractWildcardType
				|| decl2 instanceof AbstractWildcardType)
			return false;
		return decl1.fullName().equals(decl2.fullName());

	}

	public Map<TypeDecl, List<Tuple>> getSupertypeAfterChecksMap() {
		return supertypeAfterChecks;
	}

	public Map<TypeDecl, List<Tuple>> getSubtypeAfterChecksMap() {
		return subtypeAfterChecks;
	}

	public void getErrors(StringBuilder buf) {
		errMan.fetchErrorMsgs(buf);
	}

	protected Map<TypeVariable, TypeDecl> inferredTypeArguments() {
		if (!errMan.reportErrors() && inferredArgs.isEmpty())
			for (TypeVariable T : typeVariables)
				inferredArgs.put(T, constraintsMap.get(T).typeArgument);

		return inferredArgs;
	}

	protected final Map<TypeVariable, TypeDecl> partiallyInferredTypeArguments() {
		Map<TypeVariable, TypeDecl> inferredTypes =
				new HashMap<TypeVariable, TypeDecl>();
		for (TypeVariable T : typeVariables)
			if (!(constraintsMap.get(T).typeArgument == null || constraintsMap
					.get(T).typeArgument.isUnknown()))
				inferredTypes.put(T, constraintsMap.get(T).typeArgument);

		return inferredTypes;
	}

	public static final boolean areInferred(final Set<TypeVariable> vars,
			Map<TypeVariable, ConstraintSet> constraintsMap) {
		for (TypeVariable var : vars) {
			if (constraintsMap.get(var).typeArgument == null
					|| constraintsMap.get(var).typeArgument.isUnknown())
				return false;
		}
		return true;
	}

	private void replaceEqualityConstraints(TypeDecl before, TypeDecl after) {
		for (TypeVariable T : typeVariables) {
			ConstraintSet set = (ConstraintSet) constraintsMap.get(T);
			replaceEqualityConstraint(set, before, after);
		}
	}

	private void replaceEqualityConstraint(ConstraintSet set, TypeDecl before,
			TypeDecl after) {
		if (set.equaltypeConstraints.size() == 1) {
			Tuple UW = set.equaltypeConstraints.get(0);
			if (UW.implied == before) {
				set.equalTuple = UW.clone();
				UW.implied = after;
			}

		}
	}

	private void replaceAllConstraints(TypeDecl before, TypeDecl after) {
		for (TypeVariable T : typeVariables) {
			ConstraintSet set = (ConstraintSet) constraintsMap.get(T);
			replaceEqualityConstraint(set, before, after);
			replaceConstraints(set, set.supertypeConstraints, before, after);
			replaceConstraints(set, set.subtypeConstraints, before, after);
		}
	}

	private void replaceConstraints(ConstraintSet set,
			DistinctArrayList constraints, TypeDecl before, TypeDecl after) {
		for (Tuple UW : constraints) {
			if (UW.implied == before) {
				set.equalTuple = UW.clone();
				UW.implied = after;
			}
		}
	}

	// ------------------------------------------------------------------------
	// new glb
	// ------------------------------------------------------------------------
	/**
	 * Compute the greatest lower bound of types.
	 * 
	 * @param T
	 * @param typeTuples
	 * @return
	 */
	private TypeDecl glb(final TypeVariable T,
			final DistinctArrayList typeTuples) {
		TypeDecl retType = T.unknownType();
		TypeDecl cls = mostSpecificSuperClass(typeTuples);
		if (cls == null) {
			// find which classes may have caused the error.
			DistinctArrayList classTuples = new DistinctArrayList();
			for (Tuple UW : typeTuples) {
				// Type variables are included because VarTypeDecl extends
				// ClassDel
				if (UW.implied instanceof ClassDecl
						|| UW.implied instanceof LUBType
						|| UW.implied instanceof GLBType)
					classTuples.add(UW);
			}
			checkClassCompatibility(T, classTuples);
		} else {
			List<Tuple> intersectInterfaceList = new LinkedList<Tuple>();
			List<Tuple> allInterfaceList = new LinkedList<Tuple>();
			for (Tuple UW : typeTuples) {
				addInterfaces(intersectInterfaceList, allInterfaceList, UW);
			}

			// remove all interfaces that are not most specific.
			greatestLowerBoundTuples(intersectInterfaceList);
			// check for interface compatibility.
			if (checkInterfaceCompatibility(T, allInterfaceList)
					&& checkClassInterfaceCompatibility(T, cls,
														intersectInterfaceList)) {
				greatestLowerBoundTuples(typeTuples);
				retType = lookupGLBType(T, typeTuples);
			}
		}
		return retType;
	}

	/**
	 * Collect all the interfaces that are implemented by the implied type in
	 * the tuple UW.
	 * 
	 * @param intersectInterfaceList
	 * @param allInterfaceList
	 * @param UW
	 */
	private void addInterfaces(List<Tuple> intersectInterfaceList,
			List<Tuple> allInterfaceList, Tuple UW) {
		if (UW.implied.isInterfaceDecl()) {
			intersectInterfaceList.add(UW);
			allInterfaceList.add(UW);
		} else if (UW.implied instanceof VarTypeDecl) {
			VarTypeDecl varTD = ((VarTypeDecl) UW.implied);
			// add the interfaces created for type variables to
			// interface list to be check for compatibility
			intersectInterfaceList.add(new Tuple(varTD.originalTypeVariable()
					.toInterface(), varTD));
			// add the bounds of the type variable that are interfaces.
			for (Iterator iter = varTD.implementedInterfaces().iterator(); iter
					.hasNext();) {
				TypeDecl interfa = (TypeDecl) iter.next();
				allInterfaceList.add(new Tuple(interfa, varTD));
			}
		} else if (UW.implied instanceof LUBType) {
			for (Iterator iter = UW.implied.implementedInterfaces().iterator(); iter
					.hasNext();) {
				InterfaceDecl interfa = (InterfaceDecl) iter.next();
				allInterfaceList.add(new Tuple(interfa, UW.implied));
			}
		} else if (UW.implied instanceof GLBType) {
			for (Iterator iter = UW.implied.implementedInterfaces().iterator(); iter
					.hasNext();) {
				InterfaceDecl interfa = (InterfaceDecl) iter.next();
				allInterfaceList.add(new Tuple(interfa, UW.implied));
			}
		}
	}

	/**
	 * Look the greatest lower bound of the implied type in list typeTuples
	 * 
	 * @param type
	 * @param typeTuples
	 * @return
	 */
	private final static TypeDecl lookupGLBType(TypeDecl type,
			DistinctArrayList typeTuples) {
		ArrayList<TypeDecl> bounds = new ArrayList<TypeDecl>(typeTuples.size());
		for (Tuple tu : typeTuples) {
			bounds.add(tu.implied);
		}
		greatestLowerBounds(bounds);
		if (bounds.size() == 1)
			return bounds.get(0);
		return type.lookupGLBType(bounds);
	}

	/**
	 * Check whether all implemented interfaces are not in conflict with each
	 * other, e.g. List&lt;Integer&gt; and List&lt;Number&gt;.
	 * 
	 * @param T
	 * @param ifaceTupleList
	 * @return
	 */
	private boolean checkInterfaceCompatibility(TypeVariable T,
			List<Tuple> ifaceTupleList) {
		boolean consistent = true;
		for (int i = 0; i < ifaceTupleList.size(); i++) {
			// all parametric super interfaces of i-th interface
			HashSet<ParInterfaceDecl> superIfaces1 =
					ConstraintsMapBuilder
							.parameterizedSupertypes(ifaceTupleList.get(i).implied);
			for (int j = i + 1; j < ifaceTupleList.size(); j++) {
				// all parametric super interfaces of j-th interface
				HashSet<ParInterfaceDecl> superIfaces2 =
						ConstraintsMapBuilder
								.parameterizedSupertypes(ifaceTupleList.get(j).implied);
				if (detectInterfaceConflict(superIfaces1, superIfaces2)) {
					consistent = false;
					errMan.addErrorMsg(new GlbTypeErrorMsg(T, ifaceTupleList
							.get(i), ifaceTupleList.get(j)));
				}
			}
		}
		return consistent;
	}

	/**
	 * Check whether two sets of interfaces are compatible or not. An example of
	 * two incompatible interfaces is: List<Int> and List<Str>
	 * 
	 * @param iSet
	 * @param jSet
	 * @return true if there any interfaces in iSet and jSet that are
	 *         incompatible, and false otherwise
	 */
	private boolean detectInterfaceConflict(HashSet<ParInterfaceDecl> iSet,
			HashSet<ParInterfaceDecl> jSet) {
		for (ParInterfaceDecl iface1 : iSet) {
			for (ParInterfaceDecl iface2 : jSet) {
				if (iface1.genericDecl() == iface2.genericDecl()
						&& iface1 != iface2 && !iface1.sameArgument(iface2)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Check whether all implemented interfaces by the class cls are not in
	 * conflict with each other, e.g. List&lt;Integer&gt; and
	 * List&lt;Number&gt;.
	 * 
	 * @param t
	 * @param cls
	 * @param ifaceList
	 * @return
	 */
	private boolean checkClassInterfaceCompatibility(TypeVariable t,
			TypeDecl cls, List<Tuple> ifaceList) {
		boolean consistent = true;
		Set<? extends InterfaceDecl> implementedInterfaces =
				cls.implementedInterfaces();
		for (InterfaceDecl impInterface : implementedInterfaces) {
			if (impInterface instanceof ParInterfaceDecl) {
				ParInterfaceDecl impParIface = (ParInterfaceDecl) impInterface;
				for (Tuple UW : ifaceList) {
					TypeDecl iface = UW.implied;
					if (iface instanceof ParInterfaceDecl) {
						ParInterfaceDecl parIface = (ParInterfaceDecl) iface;
						if (parIface != impParIface
								&& parIface.genericDecl() == impParIface
										.genericDecl()
								&& !parIface.sameArgument(impParIface)) {
							consistent = false;
							break;
						}
					}
				}
			}
		}
		return consistent;
	}

	/**
	 * See JLS section 4.9 about Intersection Types
	 * <p>
	 * For each <i>T<sub>i</sub></i>, 1 &le; i &le; n, let <i>C<sub>i</sub></i>
	 * be the most specific class or array type such that <i>T<sub>i</sub></i>
	 * &lt;: <i>C<sub>i</sub></i> Then there must be some <i>T<sub>k</sub></i>
	 * &lt;: <i>C<sub>k</sub></i> such that <i>C<sub>k</sub></i> &lt;:
	 * <i>C<sub>i</sub></i> for any <i>i</i>, 1 &le; i &le; n, or a
	 * compile-time error occurs.
	 * 
	 * @param T
	 * @param types
	 * @return the most specific class that all elements in <i>types</i> are a
	 *         subtype of. Or null if no such class exists.
	 */
	public final static TypeDecl mostSpecificSuperClass(final List<Tuple> types) {
		List<TypeDecl> csList = new LinkedList<TypeDecl>();
		for (Tuple UW : types)
			csList.add(mostSpecificSuperClass(UW.implied));

		// find Tk with Ck
		greatestLowerBounds(csList);
		if (csList.size() == 1) {
			// OK
			return csList.get(0);
		} else {
			// Ck does not exist.
			return null;
		}
	}

	/**
	 * Return most specific superclass of t.
	 * 
	 * @param t
	 * @return
	 */
	private final static TypeDecl mostSpecificSuperClass(final TypeDecl t) {
		HashSet<TypeDecl> superTypes = new HashSet<TypeDecl>();
		addSuperClasses(t, superTypes);

		if (superTypes.isEmpty())
			return t.typeObject();
		// use this if typeObject becomes deprecated.
		// return (ClassDecl) compilationUnit.lookupType("java.lang", "Object");

		List<TypeDecl> result = new ArrayList<TypeDecl>(superTypes.size());
		result.addAll(superTypes);
		greatestLowerBounds(result);

		if (result.size() == 1)
			return result.get(0);
		else
			return t.typeObject();
	}

	/**
	 * Add the superclasses (<i>C<sub>i</sub></i>) of <i>t</i> to the set
	 * <i>result</i>.
	 * <ul>
	 * <li>If <i>t</i> is a class, then <i>C<sub>i</sub></i> is t itself.</li>
	 * <li>If <i>t</i> is a type variable, then <i>C<sub>i</sub></i> is the
	 * first class encountered in it bounds</li>
	 * <li>It <i>t</i> is an intersection type, then <i>C<sub>i</sub></i>
	 * is class that is a member of the intersection, otherwise it's Object</li>
	 * </ul>
	 * 
	 * @param t
	 * @param result
	 */
	private static final void addSuperClasses(final TypeDecl t,
			final Set<TypeDecl> result) {
		if (t == null)
			return;

		// captured TypeVariable
		if (t instanceof VarTypeDecl) {

			VarTypeDecl vtd = (VarTypeDecl) t;
			if (vtd.hasSuperTypeVar()) {
				addSuperClasses(vtd.getSuperTypeVar(), result);
			} else
				result.add(t.typeObject());
		}
		// class
		else if (t.isClassDecl() && !result.contains(t)) {
			result.add(t);
		}
		// type variable, probably called from from 1st if case.
		else if (t.isTypeVariable()) {
			TypeVariable var = (TypeVariable) t;
			for (int i = 0; i < var.getNumTypeBound(); i++)
				addSuperClasses(var.getTypeBound(i).type(), result);
		}
		// intersection type
		else if (t instanceof LUBType || t instanceof GLBType) {
			result.add(t);
		}
		// interface
		else if (t.isInterfaceDecl())
			result.add(t.typeObject());

	}

	/**
	 * Find out more about subtype relation between classes.
	 * 
	 * @param T
	 * 
	 * @param classTuples
	 * @return
	 */
	private boolean checkClassCompatibility(TypeVariable T,
			DistinctArrayList classTuples) {
		boolean consistent = true;
		for (int i = 0; i < classTuples.size(); i++) {
			TypeDecl U = classTuples.get(i).implied;
			for (int j = i + 1; j < classTuples.size(); j++) {
				TypeDecl V = classTuples.get(j).implied;
				if (!(U.instanceOf(V) || V.instanceOf(U))) {
					errMan.addErrorMsg(new GlbTypeErrorMsg(T, classTuples
							.get(i), classTuples.get(j)));
					consistent = false;
				}
			}
		}
		return consistent;
	}

	/**
	 * Remove all tuples who implied type is not most specific from the list
	 * typeList.
	 * 
	 * @param typeList
	 */
	public static final void greatestLowerBoundTuples(List<Tuple> typeList) {
		for (int i = 0; i < typeList.size(); i++) {
			if (null == typeList.get(i))
				continue;
			TypeDecl U = typeList.get(i).implied;
			for (int j = i + 1; j < typeList.size(); j++) {
				if (typeList.get(j) == null)
					continue;
				TypeDecl V = typeList.get(j).implied;
				if (U.instanceOf(V))
					typeList.set(j, null);
				else if (V.instanceOf(U))
					typeList.set(i, null);
			}
		}
		// filter null's
		removeNullValues(typeList);
	}

	/**
	 * Remove all types that are not most specific from the list typeList.
	 * 
	 * @param typeList
	 */
	public static final void greatestLowerBounds(
			List<? extends TypeDecl> typeList) {
		for (int i = 0; i < typeList.size(); i++) {
			TypeDecl U = typeList.get(i);
			for (int j = i + 1; j < typeList.size(); j++) {
				TypeDecl V = typeList.get(j);
				if (U == null || V == null)
					continue;
				if (U.instanceOf(V))
					typeList.set(j, null);
				else if (V.instanceOf(U))
					typeList.set(i, null);
			}
		}
		// filter null's
		removeNullValues(typeList);
	}

	/**
	 * Remove null values from the given list
	 * 
	 * @param types
	 */
	public static final void removeNullValues(List<?> types) {
		ArrayList<Object> filter = new ArrayList<Object>(1);
		filter.add(null);
		types.removeAll(filter);
	}

	// ------------------------------------------------------------------------
	// For testing
	// ------------------------------------------------------------------------
	public Collection<? extends ErrorSet> getErrorSet() {
		return errMan.getErrorSet();
	}

	public List<TypeCheckErrorMsg> getCheckErrorList() {
		return errMan.getCheckErrorList();
	}

	public Map<TypeVariable, List<MessageExtension>> getExtensions() {
		return errMan.getExtensions();
	}

}
