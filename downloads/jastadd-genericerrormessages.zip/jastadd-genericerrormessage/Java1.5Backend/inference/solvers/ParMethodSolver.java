/**
 * 
 */
package inference.solvers;

import inference.ConstraintsMapBuilder;

import java.util.HashMap;
import java.util.List;
import AST.GenericMethodDecl;
import AST.MethodAccess;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
// public class ParMethodSolver extends MethodSolver {
public class ParMethodSolver extends ParAccessSolver {

	/**
	 * @param builder
	 * @param methodAccess
	 * @param decl
	 * @param typeArguments
	 */
	public ParMethodSolver(ConstraintsMapBuilder builder,
			MethodAccess methodAccess, GenericMethodDecl decl,
			List<TypeDecl> typeArguments) {
		// super(builder, methodAccess, decl);
		super(builder, methodAccess.assignConvertedType(), decl.type(), null);

		// bind each type arg to type param to use them as substitution.
		typeArgumentMap = new HashMap<TypeVariable, TypeDecl>();
		for (int i = 0; i < decl.getNumTypeParameter(); i++) {
			typeArgumentMap.put(decl.getTypeParameter(i), typeArguments.get(i));
		}
	}

}
