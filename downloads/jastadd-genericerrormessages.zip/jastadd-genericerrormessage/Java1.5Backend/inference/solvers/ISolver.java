/**
 * 
 */
package inference.solvers;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;

import java.util.List;
import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public interface ISolver {
	/**
	 * Return a current type constraints or a copy of it.
	 * 
	 * @param copy
	 * @return
	 */
	public Map<TypeVariable, ConstraintSet> getCurrentConstraints(boolean copy);

	/**
	 * Return a copy of the original type constraints.
	 * 
	 * @return
	 */
	public Map<TypeVariable, ConstraintSet> getOriginalConstraints();

	/**
	 * Return supertype after-checks.
	 * 
	 * @return
	 */
	public Map<TypeDecl, List<Tuple>> getSuperTypeChecks();

	/**
	 * Return subtype after-checks.
	 * 
	 * @return
	 */
	public Map<TypeDecl, List<Tuple>> getSubTypeChecks();

	/**
	 * Return error manager
	 * 
	 * @return
	 */
	public ITypeErrorManager getTypeErrorManager();

	/**
	 * Return the type from the assignment.
	 * 
	 * @return
	 */
	public TypeDecl getContextType();

	/**
	 * Return the return type of the method.
	 * 
	 * @return
	 */
	public TypeDecl getReturnType();

	/**
	 * Return the list of formal parameters.
	 * 
	 * @return
	 */
	public List<? extends TypeDecl> getFormalParameters();

	/**
	 * Return a copy of the actual parameters.
	 * 
	 * @return
	 */
	public List<ConstraintsMapBuilder.PositionedType> getActualParameters();

}
