/**
 * 
 */
package inference.error_messages;

import inference.ds.Tuple;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when a type expression involving a type
 * variable is not a supertype of certain type expression in the after check
 * constraints.
 * 
 * @author Drako
 * 
 */
public class SupErrorCheckMsg extends TypeCheckErrorMsg {

	// private Map<TypeVariable, DistinctArrayList> superObjectHints;

	/**
	 * actualTuype <: formerType
	 * 
	 * @param actualTuype
	 * @param inferredFormerType
	 * @param formerType
	 * @param inferredTypeArgs
	 */
	public SupErrorCheckMsg(final Tuple actualTuype,
			final TypeDecl inferredFormerType, final TypeDecl formerType,
			final Map<TypeVariable, TypeDecl> inferredTypeArgs) {
		super(actualTuype, inferredFormerType, formerType, inferredTypeArgs);
	}

	// public void addSuperObjectFix(TypeVariable var, DistinctArrayList vals) {
	// if (superObjectHints == null)
	// superObjectHints = new HashMap<TypeVariable, DistinctArrayList>();
	// superObjectHints.put(var, vals);
	// }

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder("The type ");
		buf.append(formalType.simpleName());
		buf.append(", where ");
		Set<TypeVariable> tvs = formalType.getTypeVariables();
		if (tvs.size() > 1) {
			buf.append(":");
			for (TypeVariable tv : tvs) {
				buf.append("\n   - ");
				buf.append(tv.shortName());
				if (isProvidedType())
					buf.append(" was set to be ");
				else
					buf.append(" was inferred to be ");
				quoteTypeName(buf, inferredTypesMap.get(tv));
			}
		} else {
			TypeVariable tv = tvs.iterator().next();
			buf.append(tv.shortName());
			if (isProvidedType())
				buf.append(" was set to be ");
			else
				buf.append(" was inferred to be ");
			quoteTypeName(buf, inferredTypesMap.get(tv));
		}
		buf.append(" is not a supertype of ");
		actualTuple.simpleName(buf);
		buf.append(".");
		/*
		 * if (isReversible()) { buf.append(". However ");
		 * buf.append(actualTuple.implied.nameWithFlippedWildcards());
		 * buf.append(" is a subtype of "); buf.append(formalType.simpleName()); }
		 * else if (superObjectHints != null) { buf.append(". However
		 * replacing"); if (superObjectHints.size() == 1 &&
		 * superObjectHints.values().iterator().next().size() == 1) {
		 * buf.append(" ");
		 * superObjectHints.values().iterator().next().get(0).simpleName( buf); }
		 * else for (TypeVariable T : superObjectHints.keySet()) { for (Tuple tu :
		 * superObjectHints.get(T)) { buf.append("\n - "); tu.simpleName(buf); } }
		 * buf.append(" with Object may solve the type conflict."); }
		 */

		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	public int highestPriority() {
		if (highestPriority == unset)
			if (extensions != null && !extensions.isEmpty()) {
				Collections.sort(extensions,
						TypeErrorManager.priorityComparator);
				highestPriority =
						HEURISTICS_PRIORITY.get(extensions.get(0).heuristic());
			}
		return highestPriority;
	}

	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public boolean reducedSuperObject() {
		if (extensions != null)
			for (MessageExtension msgEx : extensions) {
				if (msgEx instanceof TypeChangeExt) {
					TypeChangeExt chEx = (TypeChangeExt) msgEx;
					return "Object".equals(chEx.replacement());
				}
			}
		return false;
	}
}
