/**
 * 
 */
package inference.error_messages;

import java.util.Iterator;
import java.util.List;

import AST.Expr;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when inferred type leads a type variable to
 * be in conflict with its declared bound(s)
 * 
 * @author Drako
 * 
 */
public class PoBoundTypeErrorMsg extends TypeErrorMsg {

	// inferred type for T
	private final TypeDecl inferredType, bound;

	public PoBoundTypeErrorMsg(final TypeVariable t,
			final TypeDecl inferredType, final TypeDecl bound) {
		super(t);
		this.inferredType = inferredType;
		this.bound = bound;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		if (inferredType instanceof LUBType)
			printLUB(buf);
		else if (inferredType instanceof GLBType)
			printGLB(buf);
		else {
			buf.append("The inferred type ");
			buf.append(inferredType.simpleName());
			buf.append(" is not a subtype of ");
			buf.append(T.name());
			buf.append("'s upper bound ");
			buf.append(bound.shortName());
			buf.append(" in `");
			buf.append(T.simpleName());
			buf.append("`.");
		}

		return buf.toString();
	}

	/**
	 * Print the types that lead to inferring the lub.
	 * 
	 * @param buf
	 */
	private void printLUB(StringBuilder buf) {
		LUBType lub = (LUBType) inferredType;
		int i = 0;
		final int last = lub.baseTypes().size() - 1;
		buf.append("The type");
		if (last > 0)
			buf.append("s ");
		else
			buf.append(' ');
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (!type.subtype(bound)) {
				if (i > 0) {
					if (i < last)
						buf.append(",");
					else
						buf.append(" and ");
				}
				buf.append(type.shortName());
			}
		}

		Expr ex = inferredType.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}

		if (last > 0)
			buf.append(" are not subtypes of ");
		else
			buf.append(" is not a subtype of ");
		buf.append(T.name());
		buf.append("'s upper bound ");
		buf.append(bound.shortName());
		buf.append(" in `");
		buf.append(T.simpleName());
		buf.append("`.");
	}

	/**
	 * Print the types that lead to inferring the glb.
	 * 
	 * @param buf
	 */
	private void printGLB(StringBuilder buf) {
		GLBType glb = (GLBType) inferredType;
		final int last = glb.getNumTypeBound() - 1;
		buf.append("The type");
		if (last > 0)
			buf.append("s ");
		else
			buf.append(' ');
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (!type.subtype(bound)) {
				if (i > 0)
					buf.append(" and ");
				buf.append(type.shortName());
			}
		}

		Expr ex = inferredType.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}

		if (last > 0)
			buf.append(" are not subtypes of ");
		else
			buf.append(" is not a subtype of ");
	}

	public TypeDecl getBound() {
		return bound;
	}

	public String getBoundType() {
		return bound.shortName();
	}

	public String getInferredType() {
		return inferredType.shortName();
	}

	public String joinMessages(List<PoBoundTypeErrorMsg> msgList) {
		StringBuilder buf = new StringBuilder();
		if (inferredType instanceof LUBType)
			printLUB(buf);
		else if (inferredType instanceof GLBType)
			printGLB(buf);
		else {
			buf.append("The inferred type ");
			buf.append(inferredType.simpleName());
			buf.append(" is not a subtype of ");
			buf.append(T.name());
			buf.append("'s upper bounds: ");			
		}
		buf.append(bound.simpleName());
		for (int i = 0; i < msgList.size(); i++) {
			if (i + 1 < msgList.size())
				buf.append(", ");
			else
				buf.append(" and ");
			buf.append(msgList.get(i).getBound().simpleName());
		}
		buf.append(" in `");
		buf.append(T.simpleName());
		buf.append("`.");
		return buf.toString();
	}
}
