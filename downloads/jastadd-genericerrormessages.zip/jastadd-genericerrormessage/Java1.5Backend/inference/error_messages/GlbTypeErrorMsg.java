/**
 * 
 */
package inference.error_messages;

import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.GLBTypeChangeExt;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.Collections;

import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when T <: U<sub>0</sub> ... T<: U<sub>n</sub>
 * and &exist;i, j: U<sub>i</sub> &lt;/: U<sub>j</sub>
 * 
 * @author Drako
 * 
 */
public class GlbTypeErrorMsg extends TypeErrorMsg {
	private final ErrorTuple UWi;
	private final ErrorTuple UWj;
	private Integer highestPriority = unset;

	public GlbTypeErrorMsg(final TypeVariable t, final Tuple wi, final Tuple wj) {
		super(t);
		UWi = new ErrorTuple(wi);
		UWj = new ErrorTuple(wj);
	}

	public ErrorTuple fstErrorTuple() {
		return UWi;
	}

	public ErrorTuple sndErorrTuple() {
		return UWj;
	}

	public TypeDecl getFstType() {
		return fstErrorTuple().getType();
	}

	public TypeDecl getSndType() {
		return sndErorrTuple().getType();
	}

	public TypeDecl getFstTypeSource() {
		return fstErrorTuple().getTypeSource();
	}

	public TypeDecl getSndTypeSource() {
		return sndErorrTuple().getTypeSource();
	}

	public boolean contains(Tuple t) {
		// return UWi.equals(t) || UWj.equals(t);
		return UWi.equalTuple(t) || UWj.equalTuple(t);
	}

	@Override
	public boolean equals(Object o) {
		if (o instanceof GlbTypeErrorMsg) {
			GlbTypeErrorMsg msg = (GlbTypeErrorMsg) o;
			return fstErrorTuple().equals(msg.fstErrorTuple())
					&& sndErorrTuple().equals(msg.sndErorrTuple());
		}
		return false;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder("The types ");
		if (fstErrorTuple().getType() instanceof LUBType)
			printLUBTuple(buf, fstErrorTuple().getOrigTuple());
		else
			fstErrorTuple().simpleName(buf);
		buf.append(" and ");
		if (sndErorrTuple().getType() instanceof LUBType)
			printLUBTuple(buf, sndErorrTuple().getOrigTuple());
		else
			sndErorrTuple().simpleName(buf);
		buf.append(" do not share a common subtype.");
		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	/**
	 * Print the type that lead to inferring the lub.
	 * 
	 * @param buf
	 */
	/*private void printLUBTuple(StringBuilder buf, Tuple tu) {
		LUBType lub = (LUBType) tu.implied;
		int i = 0, last = lub.baseTypes().size() - 1;
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (i > 0)
				if (i < last)
					buf.append(",");
				else
					buf.append(" and ");
			buf.append(type.shortName());
		}

		Expr ex = tu.initial.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}
	}*/

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.type_errors.TypeErrorMsg#highestPriority()
	 */
	public int highestPriority() {
		if (highestPriority == unset)
			if (extensions != null && !extensions.isEmpty()) {
				Collections.sort(extensions,
									TypeErrorManager.priorityComparator);
				highestPriority =
						HEURISTICS_PRIORITY.get(extensions.get(0).heuristic());
			}
		return highestPriority;
	}

	// ------------------------------------------------------------------------
	// Just for testing
	// ------------------------------------------------------------------------
	public String getErrorCandidate() {
		if (extensions != null)
			for (MessageExtension msgEx : extensions)
				if (msgEx instanceof GLBTypeChangeExt)
					return ((GLBTypeChangeExt) msgEx).wrongType();
		return "";
	}
}
