/**
 * 
 */
package inference.error_messages;

import inference.ds.Tuple;

import java.util.Iterator;

import AST.Expr;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
abstract public class TypeErrorMsg extends AbstractErrorMsg {

	protected final TypeVariable T;

	public TypeErrorMsg(final TypeVariable t) {
		T = t;
	}

	public TypeVariable getTypeVariable() {
		return T;
	}

	/**
	 * Print the types that lead to inferring the lub in tu.
	 * 
	 * @param buf
	 */
	protected void printLUBTuple(StringBuilder buf, Tuple tu) {
		LUBType lub = (LUBType) tu.implied;
		int i = 0;
		final int last = lub.baseTypes().size() - 1;
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (i > 0)
				if (i < last)
					buf.append(",");
				else
					buf.append(" and ");
			buf.append(type.shortName());
		}

		Expr ex = tu.initial.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}
	}

	/**
	 * Print the types that lead to inferring the glb in tu.
	 * 
	 * @param buf
	 * @param tu
	 */
	protected void printGLBTuple(StringBuilder buf, Tuple tu) {
		GLBType glb = (GLBType) tu.implied;
		final int last = glb.getNumTypeBound() - 1;
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (i > 0) {
				if (i < last)
					buf.append(", ");
				else
					buf.append(" and ");
			}
			quoteTypeName(buf, type);
		}

		Expr ex = tu.initial.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}
	}
}
