/**
 * 
 */
package inference.error_messages;

import inference.ds.Tuple;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.error_messages.heuristic_messages.WildcardFlipExt;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import AST.Expr;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardSuperType;

/**
 * This error message is generated when a certain type that is used to infer an
 * type variable is not a subtype of the type variable's declared bounds.
 * 
 * @author Drako
 * 
 */
public class PrBoundTypeErrorMsg extends TypeErrorMsg {
	private final Tuple UW;

	private final TypeDecl bound;
	private TypeDecl formalBound;

	private Integer highestPriority = unset;

	public PrBoundTypeErrorMsg(final TypeVariable t, final Tuple uw,
			final TypeDecl bound) {
		super(t);
		UW = uw;
		this.bound = bound;
	}

	public TypeDecl getBound() {
		return bound;
	}

	public TypeDecl getTypeValue() {
		return UW.implied;
	}

	public TypeDecl getSourceTypeValue() {
		return UW.initial;
	}

	public boolean isTypeSuperWildcard() {
		return UW.implied instanceof WildcardSuperType;
	}

	public void setFormalBound(TypeDecl bound) {
		this.formalBound = bound;
	}

	public TypeDecl getFormalBound() {
		return formalBound == null ? getBound() : formalBound;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		if (UW.implied instanceof LUBType)
			printLUB(buf);
		else if (UW.implied instanceof GLBType)
			printGLB(buf);
		else {
			buf.append("The type ");
			UW.simpleName(buf);
			buf.append(" is not a subtype of ");
		}
		buf.append(T.fullName());
		buf.append("'s upper bound ");
		buf.append(bound.shortName());
		buf.append(" in `");
		buf.append(T.simpleName());
		buf.append("`.");
		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	/**
	 * Print the types that lead to inferring the lub.
	 * 
	 * @param buf
	 */
	private void printLUB(StringBuilder buf) {
		LUBType lub = (LUBType) UW.implied;
		int i = 0;
		final int last = lub.baseTypes().size() - 1;
		buf.append("The type");
		if (last > 0)
			buf.append("s ");
		else
			buf.append(' ');
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (!type.subtype(bound)) {
				if (i > 0)
					buf.append(" and ");
				buf.append(type.shortName());
			}
		}

		Expr ex = UW.initial.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}

		if (last > 0)
			buf.append(" are not subtypes of ");
		else
			buf.append(" is not a subtype of ");
	}

	/**
	 * Print the types that lead to inferring the glb.
	 * 
	 * @param buf
	 */
	private void printGLB(StringBuilder buf) {
		GLBType glb = (GLBType) UW.implied;
		final int last = glb.getNumTypeBound() - 1;
		buf.append("The type");
		if (last > 0)
			buf.append("s ");
		else
			buf.append(' ');
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (!type.subtype(bound)) {
				if (i > 0)
					buf.append(" and ");
				buf.append(type.shortName());
			}
		}

		Expr ex = UW.initial.getSourceExpr();
		if (ex != null) {
			buf.append(" from the expression `");
			buf.append(ex.toString());
			buf.append("' on ");
			buf.append(ex.location());
			buf.append(":");
			buf.append(Expr.getColumn(ex.getStart()));
		}

		if (last > 0)
			buf.append(" are not subtypes of ");
		else
			buf.append(" is not a subtype of ");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.type_errors.TypeErrorMsg#highestPriority()
	 */
	public int highestPriority() {
		if (highestPriority == unset)
			if (extensions != null && !extensions.isEmpty()) {
				Collections.sort(extensions,
						TypeErrorManager.priorityComparator);
				highestPriority =
						HEURISTICS_PRIORITY.get(extensions.get(0).heuristic());
			}
		return highestPriority;
	}

	/**
	 * Print the bound conflicts of a type as a single error message.
	 * 
	 * @param msgList
	 * @return
	 */
	public String joinMessages(List<PrBoundTypeErrorMsg> msgList) {
		StringBuilder buf = new StringBuilder("The type ");
		if (UW.implied instanceof LUBType) {
			printLUB(buf);
		} else {
			UW.simpleName(buf);
			buf.append(" is not a subtype of ");
		}
		buf.append(T.fullName());
		buf.append("'s upper bounds: ");
		buf.append(bound.simpleName());
		for (int i = 0; i < msgList.size(); i++) {
			if (i + 1 < msgList.size())
				buf.append(", ");
			else
				buf.append(" and ");
			buf.append(msgList.get(i).getBound().simpleName());
		}
		buf.append(" in `");
		buf.append(T.simpleName());
		buf.append("`.");
		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	// ------------------------------------------------------------------------
	// for testing
	// ------------------------------------------------------------------------
	public boolean isInputTypeDeclared() {
		return UW.initial.isFromDeclaredStmt();
	}

	public LinkedList<String> getFixCandidates() {
		int highestPrior = highestPriority();
		LinkedList<String> fixList = new LinkedList<String>();
		if (extensions != null)
			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPrior)
					if (msgEx instanceof WildcardFlipExt) {
						fixList.add(((WildcardFlipExt) msgEx).getCorrectType());
					}
				if (msgEx instanceof TypeChangeExt) {
					fixList.add(((TypeChangeExt) msgEx).replacement());
				}
			}
		return fixList;
	}
}
