package inference.error_messages;

import inference.ds.Tuple;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.WildcardFlipExt;

import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
abstract public class TypeCheckErrorMsg extends AbstractErrorMsg {
	protected final Tuple actualTuple;
	protected final TypeDecl inferredFormalType;
	protected final TypeDecl formalType;
	protected final Map<TypeVariable, TypeDecl> inferredTypesMap;
	protected Integer highestPriority = unset;

	/**
	 * @param actualTuype
	 *            type given by the programmer
	 * @param inferredFormerType
	 *            formal type where type variables where replaced by their
	 *            inferred type
	 * @param formerType
	 *            formal type with type without type variable substitution
	 * @param inferredTypeArgs
	 *            mapping of type variables to their inferred type
	 */
	public TypeCheckErrorMsg(final Tuple actualTuype,
			final TypeDecl inferredFormerType, final TypeDecl formerType,
			final Map<TypeVariable, TypeDecl> inferredTypeArgs) {
		this.actualTuple = actualTuype;
		this.inferredFormalType = inferredFormerType;
		this.formalType = formerType;
		this.inferredTypesMap = inferredTypeArgs;
	}

	public Tuple getActualTuple() {
		return actualTuple;
	}

	public TypeDecl getInferredFormalType() {
		return inferredFormalType;
	}

	public TypeDecl getFormalType() {
		return formalType;
	}

	public boolean isReversible() {
		if (extensions == null)
			return false;

		for (MessageExtension msgEx : extensions)
			if (msgEx instanceof WildcardFlipExt)
				return true;

		return false;
	}

	public String getReversedWildcard() {
		if (extensions == null)
			return "";

		for (MessageExtension msgEx : extensions)
			if (msgEx instanceof WildcardFlipExt)
				return ((WildcardFlipExt) msgEx).getCorrectType();

		return "";
	}
}
