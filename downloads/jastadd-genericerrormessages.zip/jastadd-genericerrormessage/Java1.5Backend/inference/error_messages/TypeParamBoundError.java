/**
 * 
 */
package inference.error_messages;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when a user-provided type parameter is not
 * within the bounds of it's corresponding type variable.
 * 
 * @author Drako
 * 
 */
public class TypeParamBoundError extends TypeErrorMsg {

	private final TypeDecl givenType;
	private final TypeDecl bound;

	/**
	 * @param t
	 */
	public TypeParamBoundError(final TypeVariable t, final TypeDecl type,
			final TypeDecl bound) {
		super(t);
		this.givenType = type;
		this.bound = bound;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder("The given type ");
		buf.append(givenType.simpleName());
		buf.append(" is not a subtype of ");
		buf.append(T.shortName());
		buf.append("'s bound ");
		buf.append(bound.shortName());
		buf.append(".");
		return buf.toString();
	}

}
