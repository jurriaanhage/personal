/**
 * 
 */
package inference.error_messages.heuristic_messages;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Osiris
 * 
 */
public class GLBTypeChangeExt extends AbstractExtension {

	private final TypeDecl wrongType;
	private final TypeVariable tpVar;

	/**
	 * @param heuristic
	 */
	public GLBTypeChangeExt(TypeDecl wrongType, TypeVariable var,
			Class heuristic) {
		super(heuristic);
		this.wrongType = wrongType;
		this.tpVar = var;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.type_errors.heuristic_messages.MessageExtenstion#hint(java.lang.StringBuilder)
	 */
	public void hint(StringBuilder buf) {
		buf.append(" Most likely ");
		buf.append(wrongType.shortName());
		buf
				.append(" needs to be replaced with a subtype of the following type");
		if (tpVar.getNumTypeBound() > 1)
			buf.append("s: ");
		else
			buf.append(": ");
		for (int i = 0; i < tpVar.getNumTypeBound(); i++) {
			if (i > 0)
				buf.append(", ");
			buf.append(tpVar.getTypeBound(i).simpleName());
		}
		buf.append(".");
	}
	
	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public String wrongType() {
		return wrongType.shortName();
	}

}
