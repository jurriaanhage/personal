/**
 * 
 */
package inference.error_messages.heuristic_messages;

import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_messages.AbstractErrorMsg;
import inference.error_messages.heuristic_messages.AbstractExtension;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Drako
 * 
 */
public class WarningExt extends AbstractExtension {

	private Set<Tuple> conflictingTypes;
	private List<ErrorTuple> equalityTypes;

	/**
	 * @param heuristic
	 * @param equalityTypes
	 */
	public WarningExt(Class heuristic, List<ErrorTuple> equalityTypes) {
		this(heuristic, new HashSet<Tuple>(4), equalityTypes);
	}

	/**
	 * @param heuristic
	 * @param conflitingTypes
	 * @param equalityTypes
	 */
	public WarningExt(Class heuristic, final Set<Tuple> conflitingTypes,
			final List<ErrorTuple> equalityTypes) {
		super(heuristic);
		this.conflictingTypes =
				conflitingTypes == null ? new HashSet<Tuple>(4)
						: conflitingTypes;
		this.equalityTypes = equalityTypes;
	}

	public void addType(Tuple tu) {
		conflictingTypes.add(tu);
	}

	public boolean isReady() {
		return !conflictingTypes.isEmpty() && !equalityTypes.isEmpty();
	}

	public void hint(StringBuilder buf) {
		buf.append("\n\n  [Warning]: The types ");
		
		for (int i = 0; i < equalityTypes.size(); i++) {
			if (i > 0) {
				if (i + 1 < equalityTypes.size())
					buf.append(", ");
				else
					buf.append(" and ");
			}
			AbstractErrorMsg.quoteTypeName(buf, equalityTypes.get(i).getType());
		}
		
		buf.append(" will cause a type conflict with");
		if (conflictingTypes.size() == 1) {
			buf.append(" ");
			conflictingTypes.iterator().next().simpleName(buf);
		} else {
			buf.append(":");
			for (Tuple tu : conflictingTypes) {
				buf.append("\n - ");
				tu.simpleName(buf);
			}
		}
	}

}
