/**
 * 
 */
package inference.error_messages.heuristic_messages;

import inference.ds.Tuple;
import inference.error_messages.TypeErrorMsg;

import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import AST.TypeDecl;

/**
 * This message extension is used to replace certain types with other types.
 * 
 * @author Drako
 * 
 */
public class MultipleTypeChangeExt extends AbstractExtension implements
		MessageExtension {
	final Map<TypeDecl, Set<Tuple>> replacements;

	public MultipleTypeChangeExt(final Map<TypeDecl, Set<Tuple>> changes,
			Class heuristic) {
		super(heuristic);
		this.replacements = changes;
	}

	public void hint(StringBuilder buf) {
		if (replacements.isEmpty())
			return;

		buf.append(" However, replacing ");
		if (replacements.size() == 1) {
			Entry<TypeDecl, Set<Tuple>> kv =
					replacements.entrySet().iterator().next();
			if (kv.getValue().size() == 1) {
				buf.append("the type ");

				Tuple replaceable = kv.getValue().iterator().next();
				addReplaceableType(buf, replaceable);
				buf.append(" with ");
				buf.append(kv.getKey().shortName());
				buf.append(" may solve the type conflict.");
			} else {
				buf.append("the types:");
				listChanges(buf, kv);
				buf.append("\n    may solve the type conflict.");
			}

		} else {
			buf.append("the types:");
			for (Map.Entry<TypeDecl, Set<Tuple>> kv : replacements.entrySet()) {
				listChanges(buf, kv);
			}
			buf.append("\n    may solve the type conflict.");
		}
	}

	private void listChanges(StringBuilder buf, Entry<TypeDecl, Set<Tuple>> kv) {
		for (Tuple uw : kv.getValue()) {
			buf.append("\n    - ");
			addReplaceableType(buf, uw);
			buf.append(" with ");
			buf.append(kv.getKey().shortName());
		}
	}

	private void addReplaceableType(StringBuilder buf, Tuple replaceable) {
		TypeErrorMsg.quoteTypeName(buf, replaceable.implied);
		String loc = replaceable.getImpliedLocation();
		if (!"".equals(loc)) {
			buf.append(" on ");
			buf.append(loc);
		}
	}
}
