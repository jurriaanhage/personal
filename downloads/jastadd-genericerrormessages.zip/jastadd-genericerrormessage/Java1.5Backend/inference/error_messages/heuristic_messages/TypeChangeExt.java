/**
 * 
 */
package inference.error_messages.heuristic_messages;

import inference.ds.Tuple;
import inference.error_messages.TypeErrorMsg;
import inference.error_messages.heuristic_messages.AbstractExtension;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.LinkedList;

import AST.TypeDecl;

/**
 * This message extension is used to replace certain types with another type.
 * 
 * @author Drako
 * 
 */
public class TypeChangeExt extends AbstractExtension implements
		MessageExtension {
	final LinkedList<Tuple> replaceables;
	final TypeDecl fixCandidate;

	public TypeChangeExt(final TypeDecl fix, Class heuristic) {
		super(heuristic);
		replaceables = new LinkedList<Tuple>();
		this.fixCandidate = fix;
	}

	public void addReplaceable(Tuple t) {
		replaceables.add(t);
	}

	public void hint(StringBuilder buf) {
		if (fixCandidate == null || replaceables.isEmpty())
			return;

		buf.append(" However, replacing ");
		if (replaceables.size() == 1) {
			TypeErrorMsg.quoteTypeName(buf, replaceables.get(0).implied);
			String loc = replaceables.get(0).getImpliedLocation();
			if (!"".equals(loc)) {
				buf.append(" on ");
				buf.append(loc);
			}
			buf.append(" with ");
		} /*
			 * else if (replaceables.size() == 2) {
			 * TypeErrorMsg.quoteTypeName(buf, replaceables.get(0).implied);
			 * buf.append(" and "); TypeErrorMsg.quoteTypeName(buf,
			 * replaceables.get(1).implied); buf.append(" with "); }
			 */else {
			for (Tuple uw : replaceables) {
				buf.append("\n    - ");
				TypeErrorMsg.quoteTypeName(buf, uw.implied);
				String loc = uw.getImpliedLocation();
				if (!"".equals(loc)) {
					buf.append(" on ");
					buf.append(loc);
				}
			}
			buf.append("\n    with ");
		}
		buf.append(fixCandidate.shortName());
		buf.append(" may solve the type conflict.");
	}

	/**
	 * Return whether this message extension is ready for addition. If the list
	 * replaceables is empty, then this message should not be added to message.
	 * 
	 * @return
	 */
	public boolean isReady() {
		return !replaceables.isEmpty();
	}

	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public String replacement() {
		return fixCandidate.shortName();
	}
}
