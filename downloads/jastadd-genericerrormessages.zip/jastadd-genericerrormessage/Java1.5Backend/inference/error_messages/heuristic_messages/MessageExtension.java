/**
 * 
 */
package inference.error_messages.heuristic_messages;

/**
 * @author Drako
 *
 */
public interface MessageExtension {
	public Class heuristic();
	public String hint();
	public void hint(StringBuilder buf);
}
