/**
 * 
 */
package inference.error_messages.heuristic_messages;

/**
 * @author Drako
 * 
 */
public abstract class AbstractExtension implements MessageExtension {

	protected final Class heuristic;

	public AbstractExtension(Class heuristic) {
		this.heuristic = heuristic;
	}

	public Class heuristic() {
		return heuristic;
	}
	
	public String hint() {
		StringBuilder buf = new StringBuilder();
		hint(buf);
		return buf.toString();
	}
}
