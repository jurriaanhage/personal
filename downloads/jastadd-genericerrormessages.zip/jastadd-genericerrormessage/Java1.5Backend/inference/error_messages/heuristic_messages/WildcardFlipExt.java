/**
 * 
 */
package inference.error_messages.heuristic_messages;

import AST.TypeDecl;

/**
 * @author Drako
 * 
 */
public class WildcardFlipExt extends AbstractExtension implements
		MessageExtension {

	private TypeDecl moddedWildcard, targetWildcard;

	/**
	 * 
	 */
	public WildcardFlipExt(final Class heuristic, final TypeDecl modWildcard,
			final TypeDecl targetWildcard) {
		super(heuristic);
		this.moddedWildcard = modWildcard;
		this.targetWildcard = targetWildcard;
	}

	public void hint(StringBuilder buf) {
		buf.append(" However ");
		if (moddedWildcard.isWildcard()) {
			buf.append("`");
			buf.append(moddedWildcard.simpleName());
			buf.append("'");
		} else
			buf.append(moddedWildcard.simpleName());
		buf.append(" is a subtype of ");
		buf.append(targetWildcard.simpleName());
		buf.append("");
	}

	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public String getCorrectType() {
		return moddedWildcard.simpleName();
	}
}
