/**
 * 
 */
package inference.error_messages;

import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import AST.AbstractWildcardType;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * Error message that is generated when T = U<sub>0</sub> ... T = U<sub>n</sub>
 * and &exist;i, j: U<sub>i</sub> &ne; U<sub>j</sub>
 * 
 * @author Drako
 * 
 */
/**
 * @author Drako
 * 
 */
public class EqTypeErrorMsg extends TypeErrorMsg {
	private List<ErrorTuple> eqTypeValues;
	private Integer highestPriority = unset;
	// TODO change me to protected
	public List<Tuple> sourceTypeValues;

	public EqTypeErrorMsg(final TypeVariable t) {
		super(t);
		this.eqTypeValues = new ArrayList<ErrorTuple>(4);
		this.sourceTypeValues = new ArrayList<Tuple>(6);
	}

	public void addConflictingType(ErrorTuple tuple) {
		// always add wilcards
		if (!eqTypeValues.contains(tuple)
				|| (tuple.getType() instanceof AbstractWildcardType)) {
			eqTypeValues.add(tuple);
		}
	}

	public void addConflictingSourceType(Tuple tuple) {
		sourceTypeValues.add(tuple);
	}

	public boolean reportError() {
		return eqTypeValues.size() > 0;
	}

	public List<ErrorTuple> getEqTypeValues() {
		return eqTypeValues;
	}

	public List<Tuple> getSourceTypes() {
		if (sourceTypeValues.isEmpty())
			for (ErrorTuple et : eqTypeValues)
				sourceTypeValues.add(et.getOrigTuple());
		return sourceTypeValues;
	}

	@Override
	public String toString() {
		return createMessageList();
	}

	/**
	 * construct the error message to be reported to the user.
	 * 
	 * @return
	 */
	public String createMessageList() {
		StringBuilder buf = new StringBuilder("The type variable ");
		buf.append(getTypeVariable().shortName());
		buf.append(" is invariant, but ");
		if (allSameWildcard()) {
			String strWild = eqTypeValues.get(0).getType().shortName();
			buf.append("the type `");
			buf.append(strWild);
			buf.append("' is not.");
		} else {
			buf.append("the types:");
			// for (ErrorTuple et : eqTypeValues) {
			// buf.append("\n - ");
			// if (et.getType() instanceof LUBType)
			// printLUB(buf, et.getOrigTuple());
			// else
			// et.simpleName(buf);
			// }
			// print source types instead of inference types
			for (Tuple tu : sourceTypeValues) {
				buf.append("\n  - ");
				if (tu.implied instanceof LUBType)
					printLUBTuple(buf, tu);
				else if (tu.implied instanceof GLBType)
					printGLBTuple(buf, tu);
				else
					tu.simpleName(buf);
			}
			buf.append("\n  are not the same type.");
		}

		// TODO move warning somewhere else, like type error manager and
		// activate through command-line option

		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	public boolean allSameWildcard() {
		Iterator<ErrorTuple> iter = eqTypeValues.iterator();
		TypeDecl w = iter.next().getType();
		while (iter.hasNext()) {
			if (w != iter.next().getType())
				return false;
		}
		return true;
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.type_errors.TypeErrorMsg#highestPriority()
	 */
	public int highestPriority() {
		if (highestPriority == unset)
			if (extensions != null && !extensions.isEmpty()) {
				Collections.sort(extensions,
						TypeErrorManager.priorityComparator);
				highestPriority =
						HEURISTICS_PRIORITY.get(extensions.get(0).heuristic());
			}
		return highestPriority;
	}

	

	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public List<String> getFixCandidates() {
		int highestPrior = highestPriority();
		LinkedList<String> fixList = new LinkedList<String>();
		if (extensions != null)
			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPrior)
					if (msgEx instanceof TypeChangeExt) {
						fixList.add(((TypeChangeExt) msgEx).replacement());
					}
			}
		return fixList;
	}

	/*
	 * public void groupTuples(){ Map<TypeDecl, List<TypeDecl>> groups = new
	 * HashMap<TypeDecl, List<TypeDecl>>(); for (ErrorTuple ertu :
	 * eqTypeValues) { if(groups.containsKey(ertu.getTypeSource()))
	 * groups.get(ertu.getTypeSource()).add(ertu.getType()); else{ List<TypeDecl>
	 * l = new ArrayList<TypeDecl>(); groups.put(ertu.getTypeSource(), l);
	 * l.add(ertu.getType()); } }
	 * System.out.println("^=============================^"); for (TypeDecl k :
	 * groups.keySet()) { for (TypeDecl v : groups.get(k)) {
	 * System.out.println(v.shortName()+ " - "); } System.out.println(" in " +
	 * k.shortName()); } System.out.println("^=============================^"); }
	 */
}
