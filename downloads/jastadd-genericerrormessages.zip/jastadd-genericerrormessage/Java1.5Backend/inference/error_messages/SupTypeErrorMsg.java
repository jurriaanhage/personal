/**
 * 
 */
package inference.error_messages;

import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when the inferred type for a certain type
 * variable is not a supertype of some type expression in the supertype
 * constraints.
 * <p>
 * Example: T = Integer &amp;&amp; Number &lt;: T
 * 
 * @author Drako
 * 
 */
public class SupTypeErrorMsg extends TypeErrorMsg {
	private final Tuple UW;
	private final TypeDecl typeValue;
	private final ErrorTuple ertu;
	private int highestPriority = unset;

	public SupTypeErrorMsg(final TypeVariable t, final TypeDecl v,
			final Tuple uw) {
		super(t);
		UW = uw;
		typeValue = v;
		ertu = new ErrorTuple(uw);
	}

	public ErrorTuple getErrorTuple() {
		return ertu;
	}

	@Override
	public String toString() {
		// U <: T --> U <: T[V] -> U <: V
		StringBuilder buf = new StringBuilder("The type ");
		if (UW.implied instanceof LUBType)
			printLUBTuple(buf);
		else if (UW.implied instanceof GLBType)
			printGLBTuple(buf);
		else {
			UW.simpleName(buf);
			if (isProvidedType())
				buf.append(" is not a subtype of the provided type for ");
			else
				buf.append(" is not a subtype of the inferred type for ");
		}
		buf.append(T.name());
		if (typeValue instanceof LUBType)
			printLUB(buf);
		else if (typeValue instanceof GLBType)
			printGLB(buf);
		else {
			buf.append(": ");
			quoteTypeName(buf, typeValue);
		}
		buf.append(".");

		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

	/**
	 * Print the types that lead to inferring the lub in UW.
	 * 
	 * @param buf
	 */
	private void printLUBTuple(StringBuilder buf) {
		buf.insert(8, 's');
		printLUBTuple(buf, UW);

		if (isProvidedType())
			buf.append(" are not subtypes of the provided type for ");
		else
			buf.append(" are not subtypes of the inferred type for ");
	}

	/**
	 * Print the types that lead to inferring the lub.
	 * 
	 * @param buf
	 */
	private void printLUB(StringBuilder buf) {
		LUBType lub = (LUBType) typeValue;
		buf.append(", which is an intersection of types ");
		int i = 0;
		final int last = lub.baseTypes().size() - 1;
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (i > 0) {
				if (i < last)
					buf.append(", ");
				else
					buf.append(" and ");
			}
			quoteTypeName(buf, type);
		}
	}

	/**
	 * Print the types that lead to inferring the glb.
	 * 
	 * @param buf
	 */
	private void printGLB(StringBuilder buf) {
		GLBType glb = (GLBType) typeValue;
		buf.append(", which is an intersection of types ");

		final int last = glb.getNumTypeBound() - 1;
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (i > 0) {
				if (i < last)
					buf.append(", ");
				else
					buf.append(" and ");
			}
			quoteTypeName(buf, type);
		}
	}

	/**
	 * Print the types that lead to inferring the glb in UW.
	 * 
	 * @param buf
	 * @param tu
	 */
	private void printGLBTuple(StringBuilder buf) {
		buf.insert(8, 's');
		printGLBTuple(buf, UW);

		if (isProvidedType())
			buf.append(" are not subtypes of the provided type for ");
		else
			buf.append(" are not subtypes of the inferred type for ");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.type_errors.TypeErrorMsg#highestPriority()
	 */
	public int highestPriority() {
		if (highestPriority == unset)
			if (extensions != null && !extensions.isEmpty()) {
				Collections.sort(extensions,
						TypeErrorManager.priorityComparator);
				highestPriority =
						HEURISTICS_PRIORITY.get(extensions.get(0).heuristic());
			}
		return highestPriority;
	}

	// ------------------------------------------------------------------------
	// unit testing
	// ------------------------------------------------------------------------
	public String getInferredType() {
		return typeValue.shortName();
	}

	public String getSubType() {
		return UW.implied.shortName();
	}

	public List<String> getFixCandidates() {
		int highestPrior = highestPriority();
		LinkedList<String> fixList = new LinkedList<String>();
		if (extensions != null)
			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPrior)
					if (msgEx instanceof TypeChangeExt) {
						fixList.add(((TypeChangeExt) msgEx).replacement());
					}
			}
		return fixList;
	}
}
