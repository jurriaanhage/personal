/**
 * 
 */
package inference.error_messages;

import java.util.Iterator;

import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when the inferred type for a certain type
 * variable is not a subtype of some type expression in the subtype constraints. *
 * <p>
 * Example: T = Number &amp;&amp; T &lt;: Integer
 * 
 * @author Drako
 * 
 */
public class SubTypeErrorMsg extends TypeErrorMsg {
	private final Tuple UW;
	private final TypeDecl typeValue;
	private final ErrorTuple ertu;

	/**
	 * @param t
	 */
	public SubTypeErrorMsg(final TypeVariable t, final TypeDecl v,
			final Tuple uw) {
		super(t);
		UW = uw;
		typeValue = v;
		ertu = new ErrorTuple(uw);
	}

	public ErrorTuple getErrorTuple() {
		return ertu;
	}

	public Tuple getOrigTuple() {
		return UW;
	}

	public TypeDecl getInferredType() {
		return typeValue;
	}

	@Override
	public String toString() {
		// T <: U --> T[V] <: U -> V <: U
		StringBuilder buf = new StringBuilder("The type ");
		if (UW.implied instanceof LUBType)
			printLUBTuple(buf);
		else if (UW.implied instanceof GLBType)
			printGLBTuple(buf);
		else {
			UW.simpleName(buf);
			if (isProvidedType())
				buf.append(" is not a supertype of the provided type for ");
			else
				buf.append(" is not a supertype of the inferred type for ");
		}
		buf.append(T.shortName());
		if (typeValue instanceof LUBType)
			printLUB(buf);
		else if (typeValue instanceof GLBType)
			printGLB(buf);
		else {
			buf.append(": ");
			quoteTypeName(buf, typeValue);
		}
		buf.append(".");
		return buf.toString();
	}

	/**
	 * Print the types that lead to inferring the lub.
	 * 
	 * @param buf
	 */
	private void printLUB(StringBuilder buf) {
		LUBType lub = (LUBType) typeValue;
		buf.append(", which is an intersection of types ");
		int i = 0;
		int last = lub.baseTypes().size() - 1;
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (i > 0) {
				if (i < last)
					buf.append(", ");
				else
					buf.append(" and ");
			}
			quoteTypeName(buf, type);
		}
	}

	/**
	 * Print the types that lead to inferring the lub in UW.
	 * 
	 * @param buf
	 */
	private void printLUBTuple(StringBuilder buf) {
		buf.insert(8, 's');
		printLUBTuple(buf, UW);

		if (isProvidedType())
			buf.append(" are not subtypes of the provided type for ");
		else
			buf.append(" are not subtypes of the inferred type for ");
	}

	/**
	 * Print the types that lead to inferring the glb.
	 * 
	 * @param buf
	 */
	private void printGLB(StringBuilder buf) {
		GLBType glb = (GLBType) typeValue;
		buf.append(", which is an intersection of types ");

		final int last = glb.getNumTypeBound() - 1;
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (i > 0) {
				if (i < last)
					buf.append(", ");
				else
					buf.append(" and ");
			}
			quoteTypeName(buf, type);
		}
	}

	/**
	 * Print the types that lead to inferring the glb in UW.
	 * 
	 * @param buf
	 * @param tu
	 */
	private void printGLBTuple(StringBuilder buf) {
		buf.insert(8, 's');
		printGLBTuple(buf, UW);

		if (isProvidedType())
			buf.append(" are not subtypes of the provided type for ");
		else
			buf.append(" are not subtypes of the inferred type for ");
	}

	// ------------------------------------------------------------------------
	// For testing
	// ------------------------------------------------------------------------
	/**
	 * T <: U
	 * 
	 * @return U
	 */
	public String getSuperType() {
		return UW.implied.shortName();
	}
}
