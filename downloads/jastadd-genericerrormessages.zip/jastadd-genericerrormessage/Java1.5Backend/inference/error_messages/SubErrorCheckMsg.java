package inference.error_messages;

import java.util.Map;
import java.util.Set;

import inference.ds.Tuple;
import inference.error_messages.heuristic_messages.MessageExtension;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This error message is generated when a type expression involving a type
 * variable is not a subtype of certain type expression in the after check
 * constraints.
 * 
 * @author Drako
 * 
 */
public class SubErrorCheckMsg extends TypeCheckErrorMsg {

	/**
	 * formerType <: actualTuype
	 * 
	 * @param actualTuype
	 * @param inferredFormerType
	 * @param inferredTypeArgs
	 * @param sub
	 */
	public SubErrorCheckMsg(final Tuple actualTuype,
			final TypeDecl inferredFormerType, final TypeDecl formerType,
			final Map<TypeVariable, TypeDecl> inferredTypeArgs) {
		super(actualTuype, inferredFormerType, formerType, inferredTypeArgs);
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder("The type ");
		buf.append(formalType.simpleName());
		buf.append(", where ");
		Set<TypeVariable> tvs = formalType.getTypeVariables();
		if (tvs.size() > 1) {
			buf.append(":");
			for (TypeVariable tv : tvs) {
				buf.append("\n   -");
				buf.append(tv.shortName());
				if (isProvidedType())
					buf.append(" was set to be ");
				else
					buf.append(" was inferred to be ");
				buf.append(inferredTypesMap.get(tv).shortName());
			}
		} else {
			TypeVariable tv = tvs.iterator().next();
			buf.append(tv.shortName());
			if (isProvidedType())
				buf.append(" was set to be ");
			else
				buf.append(" was inferred to be ");
			buf.append(inferredTypesMap.get(tv).shortName());
		}
		buf.append(" is not a subtype of ");
		actualTuple.simpleName(buf);
		// ---
		if (!suppressedExtenstion() && extensions != null
				&& !extensions.isEmpty()) {

			for (MessageExtension msgEx : extensions) {
				if (HEURISTICS_PRIORITY.get(msgEx.heuristic()) == highestPriority())
					msgEx.hint(buf);
			}
		}
		// ---
		return buf.toString();
	}

}
