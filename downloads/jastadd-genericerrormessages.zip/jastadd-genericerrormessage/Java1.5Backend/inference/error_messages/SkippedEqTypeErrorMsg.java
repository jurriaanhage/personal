package inference.error_messages;

import java.util.Iterator;

import inference.ds.Tuple;
import AST.GLBType;
import AST.LUBType;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class SkippedEqTypeErrorMsg extends TypeErrorMsg {
	private Tuple sourceType;
	private TypeDecl inferredType;
	private boolean shortTypes = true;

	public SkippedEqTypeErrorMsg(final TypeVariable t,
			final TypeDecl inferredType, final Tuple sourceType) {
		super(t);
		this.inferredType = inferredType;
		this.sourceType = sourceType;
	}

	@Override
	public String toString() {
		if (shortTypes)
			return printPartialTypes();
		else
			return printWholeTypes();
	}

	public String printPartialTypes() {
		StringBuilder buf = new StringBuilder("The type ");
		sourceType.simpleName(buf);
		buf.append(" is not equal to the inferred type for ");
		buf.append(T.shortName());
		if (inferredType instanceof LUBType)
			printLUB(buf, (LUBType) inferredType);
		else if (inferredType instanceof GLBType)
			printGLB(buf, (GLBType) inferredType);
		else {
			buf.append(": ");
			buf.append(inferredType.shortName());
		}
		buf.append(".");
		return buf.toString();
	}

	public String printWholeTypes() {
		StringBuilder buf = new StringBuilder("The type ");
		buf.append(sourceType.initial.shortName());
		buf.append(" is not a subtype of ");
		buf.append(sourceType.getFormalParam().shortName());
		buf.append(", where ");
		buf.append(T.shortName());
		buf.append(" is inferred to be: ");
		if (inferredType instanceof LUBType)
			printLUB(buf, (LUBType) inferredType);
		else if (inferredType instanceof GLBType)
			printGLB(buf, (GLBType) inferredType);
		else {
			buf.append(inferredType.shortName());
		}
		buf.append(".");
		return buf.toString();
	}

	private void printLUB(StringBuilder buf, LUBType lub) {
		if (shortTypes)
			buf.append(", which an intersection of ");
		else
			buf.append(" an intersection of ");
		int i = 0;
		final int last = lub.baseTypes().size() - 1;
		for (Iterator iter = lub.baseTypes().iterator(); iter.hasNext(); i++) {
			TypeDecl type = (TypeDecl) iter.next();
			if (i > 0)
				if (i < last)
					buf.append(",");
				else
					buf.append(" and ");
			buf.append(type.shortName());
		}
	}

	private void printGLB(StringBuilder buf, GLBType glb) {
		if (shortTypes)
			buf.append(", which an intersection of ");
		else
			buf.append(" an intersection of ");
		final int last = glb.getNumTypeBound() - 1;
		for (int i = 0; i < glb.getNumTypeBound(); i++) {
			TypeDecl type = glb.getTypeBound(i).type();
			if (i > 0)
				if (i < last)
					buf.append(",");
				else
					buf.append(" and ");
			buf.append(type.shortName());
		}
	}
}
