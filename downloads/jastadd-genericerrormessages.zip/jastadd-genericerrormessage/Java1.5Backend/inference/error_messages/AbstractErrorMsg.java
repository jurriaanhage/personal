/**
 * 
 */
package inference.error_messages;

import inference.error_managers.TypeErrorManager;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import AST.TypeDecl;

/**
 * @author Drako
 * 
 */
public abstract class AbstractErrorMsg {

	public static final int unset = -1;
	protected static final Map<Class, Integer> HEURISTICS_PRIORITY =
			TypeErrorManager.heuristicsPriority;
	protected boolean suppressExts = false;
	protected List<MessageExtension> extensions;
	protected boolean providedType = false;

	/**
	 * Return the the highest priority of a heuristic that were applied on this
	 * message.
	 * 
	 * @return
	 */
	public int highestPriority() {
		return 0;
	}

	/**
	 * Disable the addition of hint this error message if the parameter pr is
	 * greater the highest priority of the heuristics applied to this message.
	 * 
	 * @param pr
	 */
	public void surpressExtensions(int pr) {
		suppressExts = pr > highestPriority();
	}

	/**
	 * Return whether message extensins were suppressed.
	 * 
	 * @return
	 */
	public boolean suppressedExtenstion() {
		return suppressExts;
	}

	public void addExtension(MessageExtension msgEx) {
		if (extensions == null)
			extensions = new LinkedList<MessageExtension>();
		extensions.add(msgEx);
	}

	/**
	 * Add quotes (`') to the wildcard types.
	 * 
	 * @param buf
	 * @param type
	 */
	public static final void quoteTypeName(StringBuilder buf, TypeDecl type) {
		if (type.isWildcard()) {
			buf.append("`");
			buf.append(type.shortName());
			buf.append("'");
		} else
			buf.append(type.shortName());
	}

	protected boolean isProvidedType() {
		return providedType;
	}

	public void setProvidedType(boolean value) {
		providedType = value;
	}

}
