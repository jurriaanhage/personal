package inference;

import inference.ds.ConstraintSet;
import inference.ds.Tuple;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import AST.AbstractWildcardType;
import AST.ArrayDecl;
import AST.ClassDecl;
import AST.GLBType;
import AST.GenericTypeDecl;
import AST.InterfaceDecl;
import AST.LUBType;
import AST.ParTypeDecl;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardExtendsType;
import AST.WildcardSuperType;

public class ConstraintsMapBuilder {

	// type variables that need to be inferred
	private List<TypeVariable> typeVariableList;

	// constraints collected for the type variables
	private Map<TypeVariable, ConstraintSet> constraintsMap;

	// constraints to check after inference is completed
	// ? <: T or ? <: X<T>
	private Map<TypeDecl, List<Tuple>> supertypeAfterChecks;

	// T <: ? or X<T> <: T
	private Map<TypeDecl, List<Tuple>> subtypeAfterChecks;

	// List of formal parameters
	private List<TypeDecl> formalParameterList;
	// List of actual parameters
	private List<PositionedType> actualParameterList;

	// field to indicate whether, a super or sub check should be add.
	final static byte _SUB_CHECK = 1;
	final static byte _SUPER_CHECK = 2;
	private byte checkKind = 0;

	private boolean sorted = false;

	public ConstraintsMapBuilder() {
		this.typeVariableList = new ArrayList<TypeVariable>(3);
		this.constraintsMap = new HashMap<TypeVariable, ConstraintSet>();
		this.supertypeAfterChecks = new HashMap<TypeDecl, List<Tuple>>();
		this.subtypeAfterChecks = new HashMap<TypeDecl, List<Tuple>>();
		this.formalParameterList = new LinkedList<TypeDecl>();
		this.actualParameterList = new LinkedList<PositionedType>();
	}

	// Declared in GenericMethodsInference.jrag at line 98
	public void addTypeVariable(TypeVariable T) {
		if (!typeVariableList.contains(T)) {
			T.updateOrder();
			typeVariableList.add(T);
			constraintsMap.put(T, new ConstraintSet());
		}
	}

	public void sortTypeVariables() {
		if (typeVariableList.size() > 1 && !sorted)
			Collections.sort(typeVariableList, new Comparator<TypeVariable>() {
				public int compare(TypeVariable v1, TypeVariable v2) {
					return v2.getOrder() - v1.getOrder();
				}
			});
	}

	TypeDecl origF;

	// Declared in GenericMethodsInference.jrag at line 338
	public final void convertibleTo(TypeDecl A, TypeDecl F) {
		origF = F;
		checkKind = _SUPER_CHECK;
		convertibleTo(A, A, F, new LinkedList<Integer>());
		checkKind = 0;
		// record formal and actual params
		formalParameterList.add(F);
		actualParameterList.add(new PositionedType(A, A
				.getSourceFileAndLocation()));
	}

	private void convertibleTo(TypeDecl orig, TypeDecl A, TypeDecl F,
			LinkedList<Integer> posList) {
		// If F does not involve a type parameter Tj then con constraint is
		// implied on Tj
		if (!F.involvesTypeParameters())
			return;
		// If A is the type of null, no constraint is implied on Tj.
		if (A.isNull())
			return;
		// If A is a primitive type, then A is converted to a reference type U
		// via boxing conversion
		// and this algorithm is applied recursively to the constraint U << F.
		if (A.isUnboxedPrimitive()) {
			TypeDecl U = A.boxed();
			// convertibleTo(U, F);
			convertibleTo(orig, U, F, posList);
		}
		// If F = Tj, then the constrint Tj :> A is implied
		else if (F instanceof TypeVariable) {
			if (typeVariableList.contains(F)) {
				Tuple t = new Tuple(A, orig);
				t.setPositionList(posList);
				addSupertypeConstraint(F, t);
			}
		}
		// If F = U[], where the type U involves Tj, then if A is an array type
		// V[]
		// or a type variable with an upper bound that is an array type V[],
		// where V is a reference type, this algorithm is applied recursively
		// to the constraint V << U
		else if (F.isArrayDecl()) {
			// System.out.println("convertibleTo array decl");
			TypeDecl U = ((ArrayDecl) F).componentType();
			if (!U.involvesTypeParameters())
				return;
			if (A.isArrayDecl()) {
				TypeDecl V = ((ArrayDecl) A).componentType();
				if (V.isReferenceType()) {
					// convertibleTo(V, U);
					convertibleTo(orig, V, U, posList);
				}
			} else if (A.isTypeVariable()) {
				TypeVariable t = (TypeVariable) A;
				for (int i = 0; i < t.getNumTypeBound(); i++) {
					TypeDecl typeBound = t.getTypeBound(i).type();
					if (typeBound.isArrayDecl()
							&& ((ArrayDecl) typeBound).componentType()
									.isReferenceType()) {
						TypeDecl V = ((ArrayDecl) typeBound).componentType();
						// convertibleTo(V, U);
						convertibleTo(orig, V, U, posList);
					}
				}
			}
		} else if (F instanceof ParTypeDecl && !F.isRawType()) {
			for (Iterator iter = parameterizedSupertypes(A).iterator(); iter
					.hasNext();) {
				ParTypeDecl PF = (ParTypeDecl) F;
				ParTypeDecl PA = (ParTypeDecl) iter.next();
				if (PF.genericDecl() == PA.genericDecl()) {
					LinkedList<Integer> prevPosList =
							(LinkedList<Integer>) posList.clone();
					for (int i = 0; i < PF.getNumArgument(); i++) {
						TypeDecl T = PF.getArgument(i).type();
						if (T.involvesTypeParameters()) {
							if (!T.isWildcard()) {
								TypeDecl U = T;
								TypeDecl V = PA.getArgument(i).type();
								// constraintEqual(V, U);
								// set the parameterized supertype as source
								orig.setParameterizedSuperType((TypeDecl) PA);
								posList.add(i);
								constraintEqual(orig, V, U, posList);
							} else if (T instanceof WildcardExtendsType) {
								TypeDecl U =
										((WildcardExtendsType) T).getAccess()
												.type();
								TypeDecl S = PA.getArgument(i).type();
								if (!S.isWildcard()) {
									TypeDecl V = S;
									// convertibleTo(V, U);
									posList.add(i);
									convertibleTo(orig, V, U, posList);
								} else if (S instanceof WildcardExtendsType) {
									TypeDecl V =
											((WildcardExtendsType) S)
													.getAccess().type();
									// convertibleTo(V, U);
									posList.add(i);
									convertibleTo(orig, V, U, posList);
								}
								// DONE added after check
								else if (S instanceof WildcardSuperType) {
									// supertype to checks also
									// addSuperCheck(origF == null ? F : origF,
									// new Tuple(orig, orig));
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
								}

							} else if (T instanceof WildcardSuperType) {
								TypeDecl U =
										((WildcardSuperType) T).getAccess()
												.type();
								TypeDecl S = PA.getArgument(i).type();
								if (!S.isWildcard()) {
									TypeDecl V = S;
									// convertibleFrom(V, U);
									posList.add(i);
									convertibleFrom(orig, V, U, posList);
								} else if (S instanceof WildcardSuperType) {
									TypeDecl V =
											((WildcardSuperType) S).getAccess()
													.type();
									// convertibleFrom(V, U);
									posList.add(i);
									convertibleFrom(orig, V, U, posList);
								}
								// DONE added WildcardExtendsType
								else if (S instanceof WildcardExtendsType) {
									// addSuperCheck(origF == null ? F : origF,
									// new Tuple(orig, orig));
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
								}

							}
							posList = (LinkedList<Integer>) prevPosList.clone();
						}
					}
				}
			}
		}
	}

	public final void convertibleFrom(TypeDecl A, TypeDecl F) {
		// System.out.println("ConvertibleFrom called with " + A.fullName()
		// + " and " + F.fullName() );
		origF = F;
		checkKind = _SUB_CHECK;
		convertibleFrom(A, A, F, new LinkedList<Integer>());
		checkKind = 0;
	}

	private void convertibleFrom(TypeDecl orig, TypeDecl A, TypeDecl F,
			LinkedList<Integer> posList) {
		// System.out.println("ConvertibleFrom called with " + A.fullName() +
		// "(" + A.getClass().getName() + ")" + " and " + F.fullName() + "(" +
		// F.getClass().getName() + ")");
		// If F does not involve a type parameter Tj then con constraint is
		// implied on Tj
		if (!F.involvesTypeParameters())
			return;
		// If A is the type of null, no constraint is implied on Tj.
		else if (A.isNull())
			return;
		else if (F instanceof TypeVariable) {
			if (typeVariableList.contains(F)) {
				Tuple t = new Tuple(A, orig);
				t.setPositionList(posList);
				addSubtypeConstraint(F, t);
			}
		} else if (F.isArrayDecl()) {
			TypeDecl U = ((ArrayDecl) F).componentType();
			if (A.isArrayDecl()) {
				TypeDecl V = ((ArrayDecl) A).componentType();
				// convertibleFrom(V, U);
				convertibleFrom(orig, V, U, posList);
			} else if (A.isTypeVariable()) {
				TypeVariable t = (TypeVariable) A;
				for (int i = 0; i < t.getNumTypeBound(); i++) {
					TypeDecl typeBound = t.getTypeBound(i).type();
					if (typeBound.isArrayDecl()
							&& ((ArrayDecl) typeBound).componentType()
									.isReferenceType()) {
						TypeDecl V = ((ArrayDecl) typeBound).componentType();
						// convertibleFrom(V, U);
						convertibleFrom(orig, V, U, posList);
					}
				}
			}
		} else if (F instanceof ParTypeDecl && !F.isRawType()
				&& A instanceof ParTypeDecl && !A.isRawType()) {
			ParTypeDecl PF = (ParTypeDecl) F;
			ParTypeDecl PA = (ParTypeDecl) A;
			TypeDecl G = PF.genericDecl();
			TypeDecl H = PA.genericDecl();
			LinkedList<Integer> prevPosList =
					(LinkedList<Integer>) posList.clone();
			for (int i = 0; i < PF.getNumArgument(); i++) {
				TypeDecl T = PF.getArgument(i).type();
				if (T.involvesTypeParameters()) {
					// If F has the form G<...,U,...> where U is a type
					// expression that involves Tj
					if (!T.isWildcard()) {
						TypeDecl U = T;
						if (G.instanceOf(H)) {
							if (H != G) {
								for (Iterator iter =
										parameterizedSupertypes(F).iterator(); iter
										.hasNext();) {
									TypeDecl V = (TypeDecl) iter.next();
									if (((ParTypeDecl) V).genericDecl() == H) {
										if (F.instanceOf(V)) {
											// convertibleFrom(A, V);
											posList.add(i);
											convertibleFrom(orig, A, V, posList);
										}
									}
								}
							} else if (PF.getNumArgument() == PA
									.getNumArgument()) {
								TypeDecl X = PA.getArgument(i).type();
								if (!X.isWildcard()) {
									TypeDecl W = X;
									// constraintEqual(W, U);
									// set the parameterized supertype as source
									orig
											.setParameterizedSuperType((TypeDecl) PA);
									posList.add(i);
									constraintEqual(orig, W, U, posList);
								} else if (X instanceof WildcardExtendsType) {
									TypeDecl W =
											((WildcardExtendsType) X)
													.getAccess().type();
									// convertibleFrom(W, U);
									posList.add(i);
									convertibleFrom(orig, W, U, posList);
								} else if (X instanceof WildcardSuperType) {
									TypeDecl W =
											((WildcardSuperType) X).getAccess()
													.type();
									// convertibleTo(W, U);
									posList.add(i);
									convertibleTo(orig, W, U, posList);
								}
							}
						}
					} else if (T instanceof WildcardExtendsType) {
						TypeDecl U =
								((WildcardExtendsType) T).getAccess().type();
						if (G.instanceOf(H)) {
							if (H != G) {
								for (Iterator iter =
										parameterizedSupertypes(F).iterator(); iter
										.hasNext();) {
									TypeDecl V = (TypeDecl) iter.next();
									if (((ParTypeDecl) V).genericDecl() == H) {
										// replace type argument Un with ?
										// extends Un in V
										ArrayList list = new ArrayList();
										for (int j = 0; j < ((ParTypeDecl) V)
												.getNumArgument(); j++)
											list.add(((ParTypeDecl) V)
													.getArgument(j).type()
													.asWildcardExtends());
										V =
												((GenericTypeDecl) H)
														.lookupParTypeDecl(list);
										// convertibleFrom(A, V);
										posList.add(i);
										convertibleFrom(orig, A, V, posList);
									}
								}
							} else if (PF.getNumArgument() == PA
									.getNumArgument()) {
								TypeDecl X = PA.getArgument(i).type();
								if (X instanceof WildcardExtendsType) {
									TypeDecl W =
											((WildcardExtendsType) X)
													.getAccess().type();
									// convertibleFrom(W, U);
									posList.add(i);
									convertibleFrom(orig, W, U, posList);
								}
								// DONE added after check
								else if (X instanceof WildcardSuperType) {
									// addSubCheck(origF == null ? F : origF,
									// new Tuple(orig, orig));
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
								}
								// G<? extends T> <: G<X>
								else if (!X.isWildcard())
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
							}
						}
					} else if (T instanceof WildcardSuperType) {
						TypeDecl U = ((WildcardSuperType) T).getAccess().type();
						if (G.instanceOf(H)) {
							if (H != G) {
								for (Iterator iter =
										parameterizedSupertypes(F).iterator(); iter
										.hasNext();) {
									TypeDecl V = (TypeDecl) iter.next();
									if (((ParTypeDecl) V).genericDecl() == H) {
										// replace type argument Un with ? super
										// Un in V
										ArrayList list = new ArrayList();
										for (int j = 0; j < ((ParTypeDecl) V)
												.getNumArgument(); j++)
											list.add(((ParTypeDecl) V)
													.getArgument(j).type()
													.asWildcardExtends());
										V =
												((GenericTypeDecl) H)
														.lookupParTypeDecl(list);
										// convertibleFrom(A, V);
										posList.add(i);
										convertibleFrom(orig, A, V, posList);
									}
								}
							} else if (PF.getNumArgument() == PA
									.getNumArgument()) {
								TypeDecl X = PA.getArgument(i).type();
								if (X instanceof WildcardSuperType) {
									TypeDecl W =
											((WildcardSuperType) X).getAccess()
													.type();
									// convertibleTo(W, U);
									posList.add(i);
									convertibleTo(orig, W, U, posList);
								}
								// DONE added after-check
								else if (X instanceof WildcardExtendsType) {
									// addSubCheck(origF == null ? F : origF,
									// new Tuple(orig, orig));
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
								}
								// G<? super T> <: G<X>
								else if (!X.isWildcard()) {
									addConstraintCheck(origF == null ? F
											: origF, new Tuple(orig, orig));
								}

							}
						}
					}
					posList = (LinkedList<Integer>) prevPosList.clone();
				}
			}

		}
		// DONE add after check
		else if (A instanceof AbstractWildcardType) {
			// addSubCheck(F, new Tuple(A, orig));
			addConstraintCheck(F, new Tuple(A, orig));
		}
	}

	// public void constraintEqual(TypeDecl A, TypeDecl F) {
	private void constraintEqual(TypeDecl orig, TypeDecl A, TypeDecl F,
			LinkedList<Integer> posList) {
		// System.out.println("ConstraintEqual called with " + A.fullName() +
		// "(" + A.getClass().getName() + ")" + " and " + F.fullName() + "(" +
		// F.getClass().getName() + ")");
		// If F does not involve a type parameter Tj then con constraint is
		// implied on Tj
		if (!F.involvesTypeParameters())
			return;
		// If A is the type of null, no constraint is implied on Tj.
		else if (A.isNull())
			return;
		else if (F instanceof TypeVariable) {
			if (typeVariableList.contains(F)) {
				// addEqualConstraint(F, A);
				Tuple t = new Tuple(A, orig);
				t.setPositionList(posList);
				addEqualConstraint(F, t);
			}
		} else if (F.isArrayDecl()) {
			TypeDecl U = ((ArrayDecl) F).componentType();
			if (A.isArrayDecl()) {
				TypeDecl V = ((ArrayDecl) A).componentType();
				// constraintEqual(V, U);
				constraintEqual(orig, V, U, posList);
			} else if (A.isTypeVariable()) {
				TypeVariable t = (TypeVariable) A;
				for (int i = 0; i < t.getNumTypeBound(); i++) {
					TypeDecl typeBound = t.getTypeBound(i).type();
					if (typeBound.isArrayDecl()
							&& ((ArrayDecl) typeBound).componentType()
									.isReferenceType()) {
						TypeDecl V = ((ArrayDecl) typeBound).componentType();
						// constraintEqual(V, U);
						constraintEqual(orig, V, U, posList);
					}
				}
			}
		} else if (F instanceof ParTypeDecl && !F.isRawType()) {
			if (A instanceof ParTypeDecl && !A.isRawType()) {
				ParTypeDecl PF = (ParTypeDecl) F;
				ParTypeDecl PA = (ParTypeDecl) A;
				if (PF.genericDecl() == PA.genericDecl()) {
					LinkedList<Integer> prevPosList =
							(LinkedList<Integer>) posList.clone();
					for (int i = 0; i < PF.getNumArgument(); i++) {
						TypeDecl T = PF.getArgument(i).type();
						if (T.involvesTypeParameters()) {
							if (!T.isWildcard()) {
								TypeDecl U = T;
								TypeDecl V = PA.getArgument(i).type();
								// constraintEqual(V, U);
								// set the parameterized supertype as source
								orig.setParameterizedSuperType((TypeDecl) PA);
								posList.add(i);
								constraintEqual(orig, V, U, posList);
							} else if (T instanceof WildcardExtendsType) {
								TypeDecl U =
										((WildcardExtendsType) T).getAccess()
												.type();
								TypeDecl S = PA.getArgument(i).type();
								if (S instanceof WildcardExtendsType) {
									TypeDecl V =
											((WildcardExtendsType) S)
													.getAccess().type();
									// constraintEqual(V, U);
									posList.add(i);
									constraintEqual(orig, V, U, posList);
								}
							} else if (T instanceof WildcardSuperType) {
								TypeDecl U =
										((WildcardSuperType) T).getAccess()
												.type();
								TypeDecl S = PA.getArgument(i).type();
								if (S instanceof WildcardSuperType) {
									TypeDecl V =
											((WildcardSuperType) S).getAccess()
													.type();
									// constraintEqual(V, U);
									posList.add(i);
									constraintEqual(orig, V, U, posList);
								}
							}
						}
						posList = (LinkedList<Integer>) prevPosList.clone();
					}
				}
			}
		}
	}

	// Declared in GenericMethodsInference.jrag at line 295
	// made public and satic to be used whenever necessary.
	public static HashSet parameterizedSupertypes(TypeDecl t) {
		HashSet result = new HashSet();
		addParameterizedSupertypes(t, new HashSet(), result);
		return result;
	}

	// Declared in GenericMethodsInference.jrag at line 300
	private static void addParameterizedSupertypes(TypeDecl t,
			HashSet processed, HashSet result) {
		if (!processed.contains(t)) {
			processed.add(t);
			if (t.isParameterizedType() && !t.isRawType())
				result.add(t);
			for (Iterator iter = directSupertypes(t).iterator(); iter.hasNext();) {
				TypeDecl typeDecl = (TypeDecl) iter.next();
				addParameterizedSupertypes(typeDecl, processed, result);
			}
		}
	}

	private static HashSet directSupertypes(TypeDecl t) {
		if (t instanceof ClassDecl) {
			ClassDecl type = (ClassDecl) t;
			HashSet set = new HashSet();
			if (type.hasSuperclass())
				set.add(type.superclass());
			for (int i = 0; i < type.getNumImplements(); i++)
				set.add(type.getImplements(i).type());
			return set;
		} else if (t instanceof InterfaceDecl) {
			InterfaceDecl type = (InterfaceDecl) t;
			HashSet set = new HashSet();
			for (int i = 0; i < type.getNumSuperInterfaceId(); i++)
				set.add(type.getSuperInterfaceId(i).type());
			return set;
		} else if (t instanceof TypeVariable) {
			TypeVariable type = (TypeVariable) t;
			HashSet set = new HashSet();
			for (int i = 0; i < type.getNumTypeBound(); i++)
				set.add(type.getTypeBound(i).type());
			return set;
		} else if (t instanceof LUBType) {
			LUBType type = (LUBType) t;
			HashSet set = new HashSet();
			for (int i = 0; i < type.getNumTypeBound(); i++) {
				set.add(type.getTypeBound(i).type());
			}
			return set;
		} else if (t instanceof GLBType) {
			GLBType type = (GLBType) t;
			HashSet set = new HashSet();
			for (int i = 0; i < type.getNumTypeBound(); i++) {
				set.add(type.getTypeBound(i).type());
			}
			return set;
		} else
			throw new Error("Operation not supported for " + t.fullName()
					+ ", " + t.getClass().getName());
	}

	private void addSupertypeConstraint(TypeDecl T, Tuple A) {
		ConstraintSet set = constraintsMap.get(T);
		A.setFormalParam(origF);
		set.addSupertypeConstraints(A);
	}

	private void addSubtypeConstraint(TypeDecl T, Tuple A) {
		ConstraintSet set = constraintsMap.get(T);
		A.setFormalParam(origF);
		set.addSubtypeConstraints(A);
	}

	private void addEqualConstraint(TypeDecl T, Tuple A) {
		ConstraintSet set = constraintsMap.get(T);
		A.setFormalParam(origF);
		set.addEqualtypeConstraints(A);
	}

	/*
	 * Wildcard type-checking
	 */
	private void addConstraintCheck(TypeDecl var, Tuple apar) {
		if (checkKind == _SUPER_CHECK)
			addSuperCheck(var, apar);
		else if (checkKind == _SUB_CHECK)
			addSubCheck(var, apar);
	}

	private void addSuperCheck(TypeDecl supVar, Tuple sub) {
		if (supertypeAfterChecks.containsKey(supVar)) {
			// don't add a check more that once.
			// Example: the check
			// Map<? super Integer, ? extends Number> << Map<? extends T, ?
			// super T>
			// consists of two subchecks '? super Integer' << '? extends T' and
			// '? extends Number' << '? super Number'. But only top-level check
			// should be added to list.
			if (!supertypeAfterChecks.get(supVar).contains(sub))
				supertypeAfterChecks.get(supVar).add(sub);
		} else {
			List<Tuple> args = new ArrayList<Tuple>();
			args.add(sub);
			supertypeAfterChecks.put(supVar, args);
		}
	}

	private void addSubCheck(TypeDecl subVar, Tuple sup) {
		if (subtypeAfterChecks.containsKey(subVar)) {
			// don't add a check more that once.
			// @see addSuperCheck
			if (!subtypeAfterChecks.get(subVar).contains(sup))
				subtypeAfterChecks.get(subVar).add(sup);
		} else {
			List<Tuple> args = new ArrayList<Tuple>();
			args.add(sup);
			subtypeAfterChecks.put(subVar, args);
		}
	}

	// ------------------------------------------------------------------------
	// getters
	// ------------------------------------------------------------------------
	public List<TypeVariable> getTypeVariableList() {
		sortTypeVariables();
		return typeVariableList;
	}

	public List<TypeVariable> getUnorderedTypeVariableList() {
		return typeVariableList;
	}

	public Map<TypeVariable, ConstraintSet> getConstraintsMap() {
		sortTypeVariables();
		return constraintsMap;
	}

	public Map<TypeDecl, List<Tuple>> getSupertypeAfterChecks() {
		return supertypeAfterChecks;
	}

	public Map<TypeDecl, List<Tuple>> getSubtypeAfterChecks() {
		return subtypeAfterChecks;
	}

	public List<? extends TypeDecl> getFormalParameters() {
		return formalParameterList;
	}

	public List<PositionedType> getActualParameters() {
		return actualParameterList;
	}

	// ------------------------------------------------------------------------
	// Setters
	// ------------------------------------------------------------------------

	public void setConstraintsMap(
			Map<TypeVariable, ConstraintSet> constraintsMap) {
		this.constraintsMap = constraintsMap;
	}

	public void setTypeVaraibles(List<TypeVariable> varList) {
		setTypeVaraibles(varList, false);
	}

	public void setTypeVaraibles(List<TypeVariable> varList,
			boolean newConstraints) {
		// variables may no bet ordered.
		this.sorted = false;
		this.typeVariableList = varList;

		if (newConstraints) {
			for (TypeVariable T : typeVariableList)
				constraintsMap.put(T, new ConstraintSet());
		}
	}

	public void setSupertypeAfterChecks(Map<TypeDecl, List<Tuple>> checks) {
		this.supertypeAfterChecks = checks;
	}

	public void setSubtypeAfterChecks(Map<TypeDecl, List<Tuple>> checks) {
		this.subtypeAfterChecks = checks;
	}

	public static class PositionedType {
		public TypeDecl type;
		public String pos;

		public PositionedType(TypeDecl type, String pos) {
			this.type = type;
			this.pos = pos;
		}

		public PositionedType copy() {
			return new PositionedType(type, pos);
		}
	}
}
