/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardExtendsType;

/**
 * @author Osiris
 * 
 */
public class ExtendsFinal extends WildcardReduction {

	/**
	 * @param solver
	 */
	public ExtendsFinal(final ISolver solver) {
		this(solver.getOriginalConstraints(), solver.getTypeErrorManager(),
				solver.getContextType(), solver.getReturnType());
	}

	/**
	 * @param constraints
	 *            original constraints
	 * @param errMan
	 * @param contextType
	 * @param returnType
	 */
	public ExtendsFinal(final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan, final TypeDecl contextType,
			final TypeDecl returnType) {
		super("Extends Final type", constraints, errMan, contextType, returnType);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {
		Set<TypeVariable> eqVarSet = new HashSet<TypeVariable>(3);
		Map<TypeVariable, DistinctArrayList> checkMap =
				new HashMap<TypeVariable, DistinctArrayList>(3);
		// case 1:

		// 1 - look for equality errors with '? extends Final'
		// 2 - replace in constraints '? extends Final' with Final.
		// 3 - start inference again, if no errors found include a hint.

		analyseEqualityErrors(eqVarSet);

		// case 2:

		// 1 - look for supertype error with T='? extends Final'
		// 2 - replace in constraints '? extends Final' with Final
		// 3 - start inference again, if no errors found include a hint.

		analyseSupertypeErrors(checkMap);

		if (!eqVarSet.isEmpty() || !checkMap.isEmpty()) {
			ConstraintsMapBuilder builder = new ConstraintsMapBuilder();
			builder.setTypeVaraibles(new ArrayList<TypeVariable>(constraints
					.keySet()));
			builder.setConstraintsMap(constraints);

			CompleteSolver solver =
					new CompleteSolver(builder, contextType, returnType);
			solver.inferTypes();

			// remove type variable that (still) cause bound errors
			Set<TypeVariable> erTypeVarSet =
					findSourceOfBoundErrors(solver, eqVarSet, checkMap.keySet());
			eqVarSet.removeAll(erTypeVarSet);

			for (TypeVariable T : eqVarSet) {
				TypeDecl typeArg = constraints.get(T).typeArgument;
				EqTypeErrorMsg eqMsg = errMan.getEqualityErrors().get(T);
				// eqMsg.setFixCandidate(new ErrorTuple(
				// new Tuple(typeArg, typeArg)));

				TypeChangeExt msgEx = new TypeChangeExt(typeArg, getClass());
				// Replaced with the code below
				// for (ErrorTuple et : eqMsg.getEqTypeValues())
				// msgEx.addReplaceable(et.getOrigTuple());
				for (Tuple uw : eqMsg.getSourceTypes())
					msgEx.addReplaceable(uw);
				if (msgEx.isReady())
					eqMsg.addExtension(msgEx);
			}

			// remove type variable that (still) cause bound errors
			for (TypeVariable var : erTypeVarSet)
				checkMap.remove(var);

			Map<TypeVariable, List<SupTypeErrorMsg>> supertypeErrors =
					errMan.getSupertypeErrors();
			for (TypeVariable var : supertypeErrors.keySet()) {
				for (SupTypeErrorMsg msg : supertypeErrors.get(var)) {
					// msg.setFinalHint(checkMap.get(var));
					if (checkMap.get(var) != null) {
						TypeDecl typeArg =
								((WildcardExtendsType) checkMap.get(var).get(0).implied)
										.extendsType();
						TypeChangeExt msgEx =
								new TypeChangeExt(typeArg, getClass());
						for (Tuple uw : checkMap.get(var)) {
							msgEx.addReplaceable(uw);
						}
						if (msgEx.isReady())
							msg.addExtension(msgEx);
					}
				}
			}

		}
	}

	/**
	 * Collect all type variables with a type equality conflict, where all the
	 * conflicting types are <code>'? extends FinalType'</code>.
	 * 
	 * @param eqVarSet
	 */
	private void analyseEqualityErrors(Set<TypeVariable> eqVarSet) {
		Map<TypeVariable, EqTypeErrorMsg> equalErrors =
				errMan.getEqualityErrors();
		for (TypeVariable var : equalErrors.keySet()) {
			if (allWildExtendFinal(equalErrors.get(var))) {
				DistinctArrayList equalConstraints =
						constraints.get(var).equaltypeConstraints;
				TypeDecl finalType =
						((WildcardExtendsType) equalConstraints.get(0).implied)
								.extendsType();
				equalConstraints.clear();
				equalConstraints.add(new Tuple(finalType, finalType));
				eqVarSet.add(var);
			}
		}
	}

	/**
	 * Check whether all types in <code>msg</code> are of the form
	 * <code>'? super FinalType'</code>
	 * 
	 * @param msg
	 *            equality error message
	 * @return <code>true</code> if all types are of the form
	 *         <code>'? super FinalType'</code>.
	 */
	private final boolean allWildExtendFinal(EqTypeErrorMsg msg) {
		if (msg == null)
			return false;
		for (ErrorTuple et : msg.getEqTypeValues()) {
			if (!isWildExtendFinal(et.getType()))
				return false;
		}
		return true;
	}

	/**
	 * Check whether <code>type</code> is final type.
	 * 
	 * @param type
	 * @return <code>true</code> if <code>type</code> is final.
	 */
	private boolean isWildExtendFinal(TypeDecl type) {
		if (type == null)
			return false;
		else if (type instanceof WildcardExtendsType)
			return ((WildcardExtendsType) type).extendsType().isFinal();

		return false;
	}

	/**
	 * Look for error of the form U </: T, where U is a final type and T is
	 * inferred to be a bounded extends wildcard of the same final type, (i.e. '?
	 * extends U').
	 * 
	 * @param checkMap
	 */
	private void analyseSupertypeErrors(
			final Map<TypeVariable, DistinctArrayList> checkMap) {
		Map<TypeVariable, List<SupTypeErrorMsg>> supertypeErrors =
				errMan.getSupertypeErrors();
		for (TypeVariable var : supertypeErrors.keySet()) {
			for (SupTypeErrorMsg msg : supertypeErrors.get(var)) {
				DistinctArrayList equalConstraints =
						constraints.get(var).equaltypeConstraints;
				TypeDecl finalType = msg.getErrorTuple().getType();
				// T must be '? extent Final' and finalType must Final
				if (!equalConstraints.isEmpty()
						&& isFinalExtendsWildFinal(finalType, equalConstraints
								.get(0).implied)) {

					WildcardExtendsType we =
							(WildcardExtendsType) equalConstraints.get(0).implied;
					if (finalType == we.extendsType()) {
						// add '? extends Final' to checkMap to be replaced by
						// Final.
						checkMap.put(var, equalConstraints.clone());
						equalConstraints.clear();
						equalConstraints.add(new Tuple(finalType, finalType));
					}
				}
			}
		}
	}

	private boolean isFinalExtendsWildFinal(final TypeDecl finalType,
			final TypeDecl wildFinal) {
		return (finalType.isFinal() && isWildExtendFinal(wildFinal));
	}

}
