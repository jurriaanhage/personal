/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.RepairEntry;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SupErrorCheckMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.MultipleTypeChangeExt;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.solvers.BasicSolver;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.ParTypeDecl;
import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 * Exploit TypeX<T> = ReturnType<T>
 * 
 */
public class CxtReturnInvariance extends AbstractHeuristic {

	private final ITypeErrorManager errMan;
	private final TypeDecl cxtType, returnType;
	private final Map<TypeVariable, ConstraintSet> invokeConstraints;
	private final Map<TypeDecl, List<Tuple>> superAfterChecks, subAfterChecks;

	/**
	 * @param solver
	 */
	public CxtReturnInvariance(final ISolver solver) {		
		this(solver.getCurrentConstraints(false), solver.getTypeErrorManager(),
				solver.getContextType(), solver.getReturnType(), solver
						.getSuperTypeChecks(), solver.getSubTypeChecks());
	}

	/**
	 * @param cxtType
	 * @param returnType
	 * @param invConstraints
	 * @param errMan
	 */
	public CxtReturnInvariance(
			final Map<TypeVariable, ConstraintSet> invConstraints,
			final ITypeErrorManager errMan, final TypeDecl cxtType,
			final TypeDecl returnType,
			final Map<TypeDecl, List<Tuple>> superChecks,
			final Map<TypeDecl, List<Tuple>> subChecks) {
		super("Context invariance");
		this.errMan = errMan;
		this.cxtType = cxtType.isUnboxedPrimitive() ? cxtType.boxed() : cxtType;
		this.invokeConstraints = invConstraints;
		this.returnType = returnType;
		this.superAfterChecks = superChecks;
		this.subAfterChecks = subChecks;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {
		if (returnType instanceof ParTypeDecl
				|| returnType.isParameterizedType()) {
			ParTypeDecl pR = (ParTypeDecl) returnType;
			Set<TypeVariable> varSet = pR.getTypeVariables();
			HashMap<TypeVariable, Set<TypeVariable>> boundVars =
					new HashMap<TypeVariable, Set<TypeVariable>>(4);
			collectVarsInOthersConflict(varSet, boundVars, errMan);
			boolean returnVarsInConflict = varsAreInConflict(varSet);
			if (!returnVarsInConflict && boundVars.isEmpty())
				return;
			// add type variables
			final ConstraintsMapBuilder builder = new ConstraintsMapBuilder();
			builder.setTypeVaraibles(new ArrayList<TypeVariable>(varSet), true);
			// add constraints
			builder.convertibleFrom(cxtType, returnType);
			// check that type variable in the return type have equality
			// constraints
			Map<TypeVariable, ConstraintSet> contextConstraints =
					builder.getConstraintsMap();
			for (TypeVariable var : varSet)
				if (contextConstraints.get(var).equaltypeConstraints.isEmpty())
					return;
			// add after checks
			builder.setSupertypeAfterChecks(superAfterChecks);
			builder.setSubtypeAfterChecks(subAfterChecks);
			// augment constraintsMap with constraint from invokeConstraints.
			for (Map.Entry<TypeVariable, ConstraintSet> kv : invokeConstraints
					.entrySet()) {
				// override supertype and subtype constraints in
				// contextConstraints with those in invokeConstraints
				if (contextConstraints.containsKey(kv.getKey())) {
					ConstraintSet cSet = contextConstraints.get(kv.getKey());
					// do not override super type constraints if tvar is
					// inferred from supertypes
					if (!kv.getValue().equaltypeConstraints.isEmpty())
						cSet.supertypeConstraints =
								kv.getValue().supertypeConstraints;
					else
						cSet.supertypeConstraints.clear();
					cSet.subtypeConstraints = kv.getValue().subtypeConstraints;
				}
				// add all the constraints to contextConstraints.
				else {
					builder.getUnorderedTypeVariableList().add(kv.getKey());
					kv.getValue().typeArgument = null;
					contextConstraints.put(kv.getKey(), kv.getValue());
				}
			}

			CompleteSolver solver =
					new CompleteSolver(builder, cxtType, returnType);

			if (solver.inferTypes()) {
				// if strict is on suppress all hints
				if (Program.hasOption(Program._veryStrictMode)) {
					varSet.clear();
					boundVars.clear();
				} else {
					varSet.removeAll(findSourceOfBoundErrors(solver, varSet));
					// vars that are directly responsible for after-check
					// errors.
					Set<TypeVariable> varsWithCheckErrors =
							findSourceOfAfterCheckError(solver);
					varSet.removeAll(varsWithCheckErrors);
					// eliminate boundVars with errors
					for (TypeVariable var : varsWithCheckErrors)
						boundVars.remove(var);
					for (TypeVariable var : findSourceOfBoundErrors(solver,
							boundVars.keySet()))
						boundVars.remove(var);
				}
			}
			// After removing type variables that caused bound and after-check
			// errors, check whether remaining type variables cause not errors
			// at all.
			if (returnVarsInConflict && varSet.size() > 0
					&& !varsAreInConflict(varSet, solver.getErrorManager()))
				addErrorRepairs(varSet, contextConstraints);

			// if vars from the return type had errors, then we cannot correct
			// other vars that depend on them.
			if (varSet.size() > 0
					&& boundVars.size() > 0
					&& !varsAreInConflict(boundVars.keySet(), solver
							.getErrorManager()))
				addErrorRepairs(boundVars, contextConstraints);

		}
	}

	/**
	 * Check whether the type variables in the set <code>varSet</code> are
	 * involved in a type conflict.
	 * 
	 * @param varSet
	 * @return
	 */
	private boolean varsAreInConflict(final Set<TypeVariable> varSet) {
		return varsAreInConflict(varSet, errMan);
	}

	/**
	 * Check whether the type variables in the set <code>varSet</code> are
	 * involved in a type conflict given the error manager <code>errMan</code>.
	 * 
	 * @param varSet
	 * @param errMan
	 * @return
	 */
	private boolean varsAreInConflict(final Set<TypeVariable> varSet,
			ITypeErrorManager errMan) {
		for (TypeVariable var : varSet)
			if (errMan.hasErrors(var))
				return true;
		// check whether a type variable is involved in after-check errors.
		Set<TypeVariable> afterVarSet = new HashSet<TypeVariable>(4);
		for (TypeCheckErrorMsg checkError : errMan.getCheckErrorList())
			afterVarSet.addAll(checkError.getFormalType().getTypeVariables());

		for (TypeVariable var : varSet)
			if (afterVarSet.contains(var))
				return true;
		return false;
	}

	/**
	 * Propose possible fixes for errors by replacing the types in equality or
	 * supertype constraints with types from the context.
	 * 
	 * @param varSet
	 * @param cxtConstraints
	 */
	private void addErrorRepairs(Set<TypeVariable> varSet,
			Map<TypeVariable, ConstraintSet> cxtConstraints) {

		// cache repair suggestions to check for inconsistencies.
		final List<VarRepairEntry> repairCache =
				new LinkedList<VarRepairEntry>();
		// delay adding message extensions until consistency check is performed.
		final Map<TypeVariable, MessageExtension> extensionCache =
				new HashMap<TypeVariable, MessageExtension>(6);

		for (TypeVariable T : varSet) {
			TypeDecl newType = cxtConstraints.get(T).typeArgument;
			if (!invokeConstraints.get(T).equaltypeConstraints.isEmpty()) {
				TypeChangeExt msgEx = new TypeChangeExt(newType, getClass());
				for (Tuple uw : invokeConstraints.get(T).allEqualtypeConstraints) {
					msgEx.addReplaceable(uw);
					repairCache.add(new VarRepairEntry(T, newType, uw));
				}
				// don't add the extension just yet.
				if (msgEx.isReady())
					extensionCache.put(T, msgEx);
			} else if (!invokeConstraints.get(T).supertypeConstraints.isEmpty()) {
				// partition types to subtypes, supertypes and rest.
				List<Tuple> supertypeList = new ArrayList<Tuple>();
				List<Tuple> restList = new ArrayList<Tuple>();
				partitionTypes(newType,
						invokeConstraints.get(T).allSupertypeConstraints,
						supertypeList, restList);
				if (!supertypeList.isEmpty() || !restList.isEmpty()) {
					TypeChangeExt msgEx =
							new TypeChangeExt(newType, getClass());
					for (Tuple uw : supertypeList) {
						msgEx.addReplaceable(uw);
						repairCache.add(new VarRepairEntry(T, newType, uw));
					}
					for (Tuple uw : restList) {
						msgEx.addReplaceable(uw);
						repairCache.add(new VarRepairEntry(T, newType, uw));
					}
					// don't add the extension just yet.
					if (msgEx.isReady())
						extensionCache.put(T, msgEx);
				}
			}
		}
		addDelayedMsgExtensions(repairCache, extensionCache);
	}

	/**
	 * Partition the types in supertype constraints into three sets: a set of
	 * types that are subtype of newType, a set of types that are supertypes of
	 * newType, and a set of types that are neither subtype nor supertype of
	 * newType.
	 * 
	 * @param newType
	 * @param constraintSet
	 * @param subtypeList
	 * @param supertypeList
	 * @param restList
	 */
	private void partitionTypes(TypeDecl newType,
			final List<Tuple> supertypeConstraints,/* List<Tuple> subtypeList, */
			final List<Tuple> supertypeList, final List<Tuple> restList) {
		for (Tuple UW : supertypeConstraints) {
			// if (UW.implied.subtype(newType))
			// subtypeList.add(UW);
			if (newType.subtype(UW.implied))
				supertypeList.add(UW);
			else if (!UW.implied.subtype(newType))
				restList.add(UW);
		}
	}

	/**
	 * Collect the type variables that are directly responsible for after-check
	 * errors.
	 * 
	 * @param varSet
	 * @param constraints
	 * @return a set of erroneous type variables.
	 */
	private Set<TypeVariable> findSourceOfAfterCheckError(
			final CompleteSolver solver) {
		final Set<TypeVariable> errVarSet = new HashSet<TypeVariable>(3);
		final List<TypeCheckErrorMsg> checkErrs =
				solver.getErrorManager().getCheckErrorList();
		final Map<TypeVariable, ConstraintSet> constraints =
				solver.getConstraintsMap();
		final Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>(constraints.size());
		for (TypeVariable T : constraints.keySet()) {
			TypeDecl inferredType = constraints.get(T).typeArgument;
			if (inferredType != null && !inferredType.isUnknown()) {
				subst.put(T, inferredType);
			}
		}

		for (TypeCheckErrorMsg msg : checkErrs)
			if (msg instanceof SupErrorCheckMsg) {
				// pass a list of indices that will not be checked.
				TypeDecl formalType = msg.getFormalType();
				ParTypeDecl PF = (ParTypeDecl) formalType;
				ArrayList<Integer> excList = new ArrayList<Integer>(3);
				if (BasicSolver.areInferred(PF.getTypeVariables(), constraints)) {
					ParTypeDecl PA = (ParTypeDecl) msg.getActualTuple().implied;
					ArrayList<Integer> idxList =
							PA.containedIn((ParTypeDecl) formalType
									.instantiateParType(subst), excList);
					for (Integer i : idxList)
						errVarSet.addAll(PF.getArgument(i).type()
								.getTypeVariables());
				}
			}
		return errVarSet;
	}

	/**
	 * Check whether the type variables in the set <code>varSet</code> are
	 * involved in a bound conflict of another type variable given the error
	 * manager <code>errMan</code>. If they are, then add them to
	 * <code>boundVars</code>
	 * 
	 * @param varSet
	 * @param errMan
	 */
	private void collectVarsInOthersConflict(final Set<TypeVariable> varSet,
			final Map<TypeVariable, Set<TypeVariable>> boundVars,
			final ITypeErrorManager errMan) {
		Map<TypeVariable, List<PrBoundTypeErrorMsg>> preBndErrors =
				errMan.getPreBoundErrors();
		for (TypeVariable var : preBndErrors.keySet())
			// var should not be in varSet
			if (!varSet.contains(var))
				for (PrBoundTypeErrorMsg msg : preBndErrors.get(var)) {
					Set<TypeVariable> varsInBnd =
							msg.getFormalBound().getTypeVariables();
					varsInBnd.retainAll(varSet);
					if (varsInBnd.size() > 0) {
						if (boundVars.containsKey(var))
							boundVars.get(var).addAll(varsInBnd);
						else
							boundVars.put(var, new HashSet<TypeVariable>(
									varsInBnd));
					}
				}

		Map<TypeVariable, List<PoBoundTypeErrorMsg>> postBndErrors =
				errMan.getPostBoundErrors();
		for (TypeVariable var : postBndErrors.keySet())
			// var should not be in varSet
			if (!varSet.contains(var))
				for (PoBoundTypeErrorMsg msg : postBndErrors.get(var)) {
					Set<TypeVariable> varsInBnd =
							msg.getBound().getTypeVariables();
					varsInBnd.retainAll(varSet);
					if (varsInBnd.size() > 0) {
						if (boundVars.containsKey(var))
							boundVars.get(var).addAll(varsInBnd);
						else
							boundVars.put(var, new HashSet<TypeVariable>(
									varsInBnd));
					}
				}
	}

	/**
	 * Propose possible fixes for errors that are not in the return type by
	 * replacing the types in equality or supertype constraints of the types in
	 * the return type with types from the context.
	 * 
	 * @param boundVars
	 * @param cxtConstraints
	 */
	private void addErrorRepairs(
			final Map<TypeVariable, Set<TypeVariable>> boundVars,
			final Map<TypeVariable, ConstraintSet> cxtConstraints) {

		// cache repair suggestions to check for inconsistencies.
		final List<VarRepairEntry> repairCache =
				new LinkedList<VarRepairEntry>();
		// delay adding message extensions until consistency check is performed.
		final Map<TypeVariable, MessageExtension> extensionCache =
				new HashMap<TypeVariable, MessageExtension>(6);

		for (Map.Entry<TypeVariable, Set<TypeVariable>> kv : boundVars
				.entrySet()) {
			Map<TypeDecl, Set<Tuple>> replacements =
					new HashMap<TypeDecl, Set<Tuple>>(4);
			for (TypeVariable T : kv.getValue()) {
				// prevent a hint from being printed.
				if (errMan.hasErrors(T))
					continue;
				TypeDecl newType = cxtConstraints.get(T).typeArgument;
				replacements.put(newType, new HashSet<Tuple>(4));
				if (!invokeConstraints.get(T).equaltypeConstraints.isEmpty()) {
					replacements.get(newType).addAll(
							invokeConstraints.get(T).allEqualtypeConstraints);
					for (Tuple uw : invokeConstraints.get(T).allEqualtypeConstraints)
						repairCache.add(new VarRepairEntry(kv.getKey(),
								newType, uw));
				}

				else if (!invokeConstraints.get(T).supertypeConstraints
						.isEmpty()) {
					// partition types to supertypes and rest.
					List<Tuple> supertypeList = new ArrayList<Tuple>();
					List<Tuple> restList = new ArrayList<Tuple>();
					partitionTypes(newType,
							invokeConstraints.get(T).allSupertypeConstraints,
							supertypeList, restList);
					if (supertypeList.size() > 0) {
						replacements.get(newType).addAll(supertypeList);
						for (Tuple uw : supertypeList)
							repairCache.add(new VarRepairEntry(kv.getKey(),
									newType, uw));
					}
					if (restList.size() > 0) {
						replacements.get(newType).addAll(restList);
						for (Tuple uw : restList)
							repairCache.add(new VarRepairEntry(kv.getKey(),
									newType, uw));
					}
				}
				if (replacements.get(newType).isEmpty())
					replacements.remove(newType);
			}
			if (replacements.size() > 0) {
				// don't add the extension just yet
				extensionCache.put(kv.getKey(), new MultipleTypeChangeExt(
						replacements, getClass()));
			}
		}

		addDelayedMsgExtensions(repairCache, extensionCache);
	}

	/**
	 * Add delayed message extension after having performed the consistency
	 * check.
	 * 
	 * @param repairCache
	 * @param extensionCache
	 */
	private void addDelayedMsgExtensions(
			final List<VarRepairEntry> repairCache,
			final Map<TypeVariable, MessageExtension> extensionCache) {
		// boolean hasSome = extensionCache.size() > 0;
		detectExprInconsitency(repairCache, extensionCache);
		if (extensionCache.size() > 0) {
			// System.out.println("Still have some left");
			for (Map.Entry<TypeVariable, MessageExtension> kv : extensionCache
					.entrySet())
				errMan.addMsgExtension(kv.getKey(), kv.getValue());
		}
		// if (hasSome)
		// System.out.println("Used to have some");
	}

	final class VarRepairEntry extends RepairEntry<TypeVariable> {
		final private TypeVariable var;

		public VarRepairEntry(TypeVariable var, TypeDecl type, Tuple tu) {
			super(var, type, tu);
			this.var = var;
		}

		public String toString() {
			StringBuilder buf = new StringBuilder(var.simpleName());
			buf.append(": ");
			buf.append(type.simpleName());
			buf.append(" ");
			buf.append(subPosition);
			buf.append(" ");
			buf.append(position);
			return buf.toString();
		}
	}
}
