/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.RepairEntry;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.solvers.BasicSolver;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.GLBTypeFactory;
import AST.ParTypeDecl;
import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * Look for subtype errors when the inferred type is a lub, i.e. no equality
 * constraints, and try to find a type that will satisfy all the constraints.
 * <p>
 * For each type varibale check if glb exists, then check whether glb or lub
 * satisfy more constraints. If lub does, then remove all the types in subtype
 * constraints that are no a supertype of lub. If glb satisfies more constraint
 * then lub, then remove all types in supertype constraints that are subtypes of
 * glb. Otherwise pick the a type that is used the most and remove all the type
 * in supertype constraints that are no a subtype of the chosen type and all the
 * type in subtype constraints that are not a supertype of the chosen type.
 * 
 * Start the inference check once more and verify whether the chosen types can
 * make the call legal, if they do then propose then as potential correction.
 * 
 * @author Drako
 * 
 */
public class MaximalSubtyping extends AbstractHeuristic {

	// used for type stats
	// private final Map<TypeVariable, ConstraintSet> origConstraints;
	// used for purposes that can modify the content of the map.
	private final Map<TypeVariable, ConstraintSet> constraints;
	private final ITypeErrorManager errMan;
	private final TypeDecl cxtType, retType;

	static LowerTypeHierarchy _LowerTypeHierarchy;
	static UpperTypeHierarchy _UpperTypeHierarchy;
	static BestLowerBound _BestLowerBound;
	static BestUpperBound _BestUpperBound;

	/**
	 * @param solver
	 */
	public MaximalSubtyping(final ISolver solver) {
		this(solver.getCurrentConstraints(true), solver.getTypeErrorManager(),
				solver.getContextType(), solver.getReturnType());
	}

	/**
	 * @param constraints
	 *            original constraints
	 * @param errMan
	 * @param cxtType
	 * @param retType
	 */
	public MaximalSubtyping(final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan, final TypeDecl cxtType,
			final TypeDecl retType) {
		super("Repair conflicts between lub and glb");

		// this.origConstraints = constraints;
		this.constraints = constraints;
		this.errMan = errMan;
		this.cxtType = cxtType;
		this.retType = retType;
		_LowerTypeHierarchy = new LowerTypeHierarchy();
		_UpperTypeHierarchy = new UpperTypeHierarchy();
		_BestLowerBound = new BestLowerBound();
		_BestUpperBound = new BestUpperBound();
	}

	@Override
	public void analyse() {
		final Set<TypeVariable> nonEqualTypeVariables =
				new HashSet<TypeVariable>(constraints.size());
		// find type variable that don't have equality constraints
		findTypeVarWithoutEquality(nonEqualTypeVariables);

		// Set of tuple-types that need to be replaced.
		Map<TypeVariable, Set<Tuple>> replaceableTypes =
				new HashMap<TypeVariable, Set<Tuple>>(nonEqualTypeVariables
						.size());

		// find for each TypeVariable the find the max partial solution
		for (TypeVariable tvar : nonEqualTypeVariables) {
			ConstraintSet cSet = constraints.get(tvar);

			ArrayList<TypeDecl> subtypes =
					new ArrayList<TypeDecl>(cSet.subtypeConstraints.size());
			for (TypeDecl type : cSet.subtypeConstraints.impliedView()) {
				subtypes.add(type);
			}
			TypeDecl tvar_glb = GLBTypeFactory.glb(subtypes);
			TypeDecl tvar_lub = cSet.typeArgument;
			// System.out.println(tvar_lub.simpleName());
			replaceableTypes.put(tvar, new HashSet<Tuple>(4));

			if (tvar_glb.isUnknown()) {
				TypeDecl maxGlb = bestLowerBound(cSet);
				if (maxGlb != null) {
					int lub_count =
							countUpperConflict(cSet.subtypeConstraints,
												tvar_lub, cSet
														.subtypeStatistics());
					int glb_count =
							countLowerConflict(cSet.supertypeConstraints,
												maxGlb, cSet
														.supertypeStatistics());
					if (lub_count == glb_count) {
						TypeDecl maxLub = bestUpperBound(cSet);
						if (maxLub != null) {
							lub_count =
									countUpperConflict(
														cSet.subtypeConstraints,
														maxLub,
														cSet
																.subtypeStatistics());

							if (lub_count == glb_count) {
								// do each value separately
								checkAllTypes(replaceableTypes, tvar, cSet);
							} else {
								checkBoundsOnly(replaceableTypes, tvar, cSet,
												maxGlb, maxLub);
							}
						} else {
							// do each value separately
							checkAllTypes(replaceableTypes, tvar, cSet);
						}
					} else {
						checkBoundsOnly(replaceableTypes, tvar, cSet, maxGlb,
										tvar_lub);
					}
				} else {
					// do each value separately
					checkAllTypes(replaceableTypes, tvar, cSet);
				}

			} else {
				// if #glb == #lub, then check if lub is biased.
				if (countLowerConflict(cSet.supertypeConstraints, tvar_glb,
										cSet.supertypeStatistics()) == countUpperConflict(
																							cSet.subtypeConstraints,
																							tvar_lub,
																							cSet
																									.subtypeStatistics())) {
					TypeDecl bestLUB = bestUpperBound(cSet);
					if (bestLUB == null) {
						bestLUB = tvar_lub;
					}
					checkBoundsOnly(replaceableTypes, tvar, cSet, tvar_glb,
									bestLUB);
				} else {
					checkBoundsOnly(replaceableTypes, tvar, cSet, tvar_glb,
									tvar_lub);
				}
			}
			cSet.typeArgument = null;
		}

		ConstraintsMapBuilder builder = new ConstraintsMapBuilder();
		builder.setConstraintsMap(constraints);
		builder.setTypeVaraibles(new ArrayList<TypeVariable>(constraints
				.keySet()));
		CompleteSolver solver = new CompleteSolver(builder, cxtType, retType);

		// remove any type var whose type does not satisfy the bounds.
		if (solver.inferTypes()) {
			Set<TypeVariable> nonFixVars =
					findSourceOfBoundErrors(solver, replaceableTypes.keySet());
			for (TypeVariable var : nonFixVars)
				replaceableTypes.remove(var);
		}

		// to fetch the new inferred types.
		Map<TypeVariable, ConstraintSet> newConstr = solver.getConstraintsMap();
		LinkedList<RepairEntry<TypeVariable>> repairCache =
				new LinkedList<RepairEntry<TypeVariable>>();
		Map<TypeVariable, MessageExtension> extensionCache =
				new HashMap<TypeVariable, MessageExtension>(replaceableTypes
						.size());

		// remove any type variable that is directly responsible for an
		// after-check error.
		if (Program.hasOption(Program._strictMode)) {
			Set<TypeVariable> nonFixVars =
					findSourceOfAfterCheckError(newConstr);
			for (TypeVariable var : nonFixVars)
				replaceableTypes.remove(var);
		}

		for (TypeVariable var : replaceableTypes.keySet()) {
			TypeDecl newType = newConstr.get(var).typeArgument;
			TypeChangeExt msgEx = new TypeChangeExt(newType, getClass());
			for (Tuple uw : replaceableTypes.get(var)) {
				msgEx.addReplaceable(uw);
				repairCache
						.add(new RepairEntry<TypeVariable>(var, newType, uw));
			}
			// Don't add the extension just yet.
			if (msgEx.isReady())
				extensionCache.put(var, msgEx);
		}
		// Now add the extensions.
		detectExprInconsitency(repairCache, extensionCache);
		for (Map.Entry<TypeVariable, MessageExtension> kv : extensionCache
				.entrySet()) {
			errMan.addMsgExtension(kv.getKey(), kv.getValue());
		}

	}

	/**
	 * Check which bound, lower or upper, satisfies more constraints. If a bound
	 * was chosen than remove all type in cSet that conflict with bound, and add
	 * them to replaceableSet.
	 * 
	 * @param replaceableTypes
	 * @param tvar
	 * @param cSet
	 * @param tvar_glb
	 * @param tvar_lub
	 */
	private void checkBoundsOnly(
			final Map<TypeVariable, Set<Tuple>> replaceableTypes,
			final TypeVariable tvar, final ConstraintSet cSet,
			final TypeDecl tvar_glb, final TypeDecl tvar_lub) {

		Map<TypeDecl, Integer> subtypeStats = cSet.subtypeStatistics();
		Map<TypeDecl, Integer> supertypeStats = cSet.supertypeStatistics();

		// test only lub and glb
		int lub_count = 0, glb_count = 0;

		// lub min-conflict
		lub_count =
				countUpperConflict(cSet.subtypeConstraints, tvar_lub,
									subtypeStats);

		// glb min-conflict
		glb_count =
				countLowerConflict(cSet.supertypeConstraints, tvar_glb,
									supertypeStats);

		// blame the type with the max number of conflicts.
		if (lub_count < glb_count) {
			removeSubTypes(tvar_lub, cSet, replaceableTypes.get(tvar));

			// needed in case tvar_lub =/= cSet.typeArgument
			// Keep only types that are <: tvar_lub
			removeSuperTypes(tvar_lub, cSet, replaceableTypes.get(tvar));
		} else if (lub_count > glb_count) {
			removeSuperTypes(tvar_glb, cSet, replaceableTypes.get(tvar));

			// needed in case glb is not global (glb of subset of types.)
			// keep only type :> tvar_glb
			removeSubTypes(tvar_glb, cSet, replaceableTypes.get(tvar));
		} else {
			// System.out.println("Cannot blame any constraint");
			// Jump to majority
			useMajorType(cSet, replaceableTypes.get(tvar));
		}
	}

	/**
	 * find all the type variable whose type was inferred to be a lub and store
	 * them in nonEqualTypeVariables.
	 * 
	 * @param nonEqualTypeVariables
	 */
	private void findTypeVarWithoutEquality(
			Set<TypeVariable> nonEqualTypeVariables) {
		Map<TypeVariable, List<SubTypeErrorMsg>> subtypeErrors =
				errMan.getSubtypeErrors();
		for (Map.Entry<TypeVariable, ConstraintSet> kv : constraints.entrySet()) {
			ConstraintSet cSet = kv.getValue();
			if (cSet.equaltypeConstraints.isEmpty()
					&& !cSet.supertypeConstraints.isEmpty()
					&& subtypeErrors.containsKey(kv.getKey())) {
				nonEqualTypeVariables.add(kv.getKey());
			}
		}
	}

	/**
	 * Return the number of types upp is not a <b>subtype</b> of.
	 * 
	 * @param subtypeConstraints
	 *            list of tuples from subtype constraints.
	 * @param upp
	 * @param subtypeStats
	 * @return
	 */
	private int countUpperConflict(final DistinctArrayList subtypeConstraints,
			final TypeDecl upp, final Map<TypeDecl, Integer> subtypeStats) {
		int lub_count = 0;
		for (TypeDecl type : subtypeConstraints.impliedView()) {
			if (!upp.subtype(type)) {
				if (subtypeStats.containsKey(type))
					lub_count += subtypeStats.get(type);
				else
					lub_count++;
			}
		}
		return lub_count;
	}

	/**
	 * Return the number of types low is not a <b>supertype</b> of.
	 * 
	 * @param supertypeConstraints
	 *            list of tuples from supertype constraints.
	 * @param low
	 * @param supertypeStats
	 * @return
	 */
	private int countLowerConflict(
			final DistinctArrayList supertypeConstraints, final TypeDecl low,
			final Map<TypeDecl, Integer> supertypeStats) {
		int glb_count = 0;
		for (TypeDecl type : supertypeConstraints.uniqueImpliedView()) {
			if (!type.subtype(low)) {
				if (supertypeStats.containsKey(type)) {
					glb_count += supertypeStats.get(type);
				} else {
					glb_count++;
				}
			}
		}
		return glb_count;
	}

	/**
	 * Count the number of constraints in the constraint set
	 * <code>cSet<code> are satisfied by <code>type</code>.
	 * 
	 * @param type
	 *            the TypeDecl for which the number of conflicts is counted.
	 * @param cSet
	 *            the constraints set used to count the conflicts.
	 * @return number of conflicts
	 */
	private int countConflict(TypeDecl type, ConstraintSet cSet) {
		return countLowerConflict(cSet.supertypeConstraints, type, cSet
				.supertypeStatistics())
				+ countUpperConflict(cSet.subtypeConstraints, type, cSet
						.subtypeStatistics());
	}

	/**
	 * Try to find a type in <code>cSet</code> that has a minimal number of
	 * constraint violations.
	 * 
	 * @param replaceableTypes
	 * @param tvar
	 * @param cSet
	 */
	private void checkAllTypes(Map<TypeVariable, Set<Tuple>> replaceableTypes,
			TypeVariable tvar, ConstraintSet cSet) {
		// List of types that occur in subtype and supertype
		// constraints.
		Map<TypeDecl, Integer> allTypes = new HashMap<TypeDecl, Integer>(5);
		for (TypeDecl type : cSet.supertypeConstraints.impliedView())
			allTypes.put(type, countConflict(type, cSet));
		for (TypeDecl type : cSet.subtypeConstraints.impliedView())
			if (!allTypes.containsKey(type))
				allTypes.put(type, countConflict(type, cSet));

		List<TypeDecl> minTypes = minConflict(allTypes);

		if (minTypes.size() == 1) {
			TypeDecl type = minTypes.get(0);
			// replace sups
			removeSuperTypes(type, cSet, replaceableTypes.get(tvar));
			// replace subs
			removeSubTypes(type, cSet, replaceableTypes.get(tvar));
		} else {
			// System.out.println("No single solution");
			// Jump to majority
			useMajorType(cSet, replaceableTypes.get(tvar));
		}
	}

	/**
	 * Return a list of types that have the minimal number of conflicts.
	 * 
	 * @param confMap
	 *            map of types and their corresponding number of conflicts.
	 * @return list of type with minimal number of conflicts.
	 */
	private List<TypeDecl> minConflict(final Map<TypeDecl, Integer> confMap) {
		int min = Collections.min(confMap.values());
		List<TypeDecl> minTypes = new LinkedList<TypeDecl>();
		for (Map.Entry<TypeDecl, Integer> kv : confMap.entrySet())
			if (kv.getValue() == min)
				minTypes.add(kv.getKey());
		return minTypes;
	}

	/**
	 * Remove all the type that are not a subtype of <code>type</code>, and
	 * add the removed types to the parameter replaceableSet.
	 * 
	 * @param type
	 * @param cSet
	 *            the constraint set from which types that are not a subtype of
	 *            the parameter type are removed.
	 * @param replaceableSet
	 *            the set to which the remove type from superTypes is added to.
	 */
	private void removeSuperTypes(final TypeDecl type,
			final ConstraintSet cSet, final Set<Tuple> replaceableSet) {
		final List<Tuple> superTypes = cSet.allSupertypeConstraints;
		final DistinctArrayList inferSuperTypes = cSet.supertypeConstraints;
		for (Iterator<Tuple> iter = superTypes.iterator(); iter.hasNext();) {
			Tuple uw = iter.next();
			if (!uw.implied.subtype(type)) {
				replaceableSet.add(uw);
				iter.remove();
			}
		}
		// it safer to iterate through inferSuperTypes, because types in
		// superTypes may have been cloned.
		for (Iterator<Tuple> iter = inferSuperTypes.iterator(); iter.hasNext();) {
			Tuple uw = iter.next();
			if (!uw.implied.subtype(type))
				iter.remove();
		}
	}

	/**
	 * Remove all the type that are not a supertype of <code>type</code>, and
	 * add the removed types to the parameter replaceableSet.
	 * 
	 * @param type
	 * @param cSet
	 *            the constraint set from which types that are not a supertype
	 *            of the parameter type are removed.
	 * @param replaceableSet
	 *            the set to which the remove type from superTypes is added to.
	 */
	private void removeSubTypes(final TypeDecl type, final ConstraintSet cSet,
			final Set<Tuple> replaceableSet) {
		final List<Tuple> subTypes = cSet.allSubtypeConstraints;
		final DistinctArrayList inferSubTypes = cSet.subtypeConstraints;
		for (Iterator<Tuple> iter = subTypes.iterator(); iter.hasNext();) {
			Tuple uw = iter.next();
			if (!type.subtype(uw.implied)) {
				replaceableSet.add(uw);
				iter.remove();
			}
		}
		// it safer to iterate through inferSubTypes, because types in subTypes
		// may have been cloned.
		for (Iterator<Tuple> iter = inferSubTypes.iterator(); iter.hasNext();) {
			Tuple uw = iter.next();
			if (!type.subtype(uw.implied))
				iter.remove();
		}
	}

	/**
	 * Find a type in <code>cSet</code> that is used more than others, and
	 * remove all the types that are not a subtype of the chosen type from the
	 * supertype constraints, and all the types that are not a supertype of type
	 * from the subtype constraints. Add all the removed types to the set
	 * <code>replaceableSet</code>.
	 * 
	 * @param cSet
	 * @param replaceableSet
	 */
	private void useMajorType(final ConstraintSet cSet,
			final Set<Tuple> replaceableSet) {
		Map<TypeDecl, Integer> typeStats =
				new HashMap<TypeDecl, Integer>(cSet.supertypeStatistics());
		for (Map.Entry<TypeDecl, Integer> kv : cSet.subtypeStatistics()
				.entrySet()) {
			if (typeStats.containsKey(kv.getKey())) {
				typeStats.put(kv.getKey(), kv.getValue()
						+ typeStats.get(kv.getKey()));
			} else {
				typeStats.put(kv.getKey(), kv.getValue());
			}
		}

		int max = Collections.max(typeStats.values());
		List<TypeDecl> candidateList = new LinkedList<TypeDecl>();
		for (TypeDecl type : typeStats.keySet()) {
			if (typeStats.get(type) == max)
				candidateList.add(type);
		}

		if (candidateList.size() == 1) {
			TypeDecl type = candidateList.get(0);
			// replace sups
			removeSuperTypes(type, cSet, replaceableSet);
			// replace subs
			removeSubTypes(type, cSet, replaceableSet);
			// System.out.println("Used a Major");
		}
	}

	/**
	 * Return the best greatest lower bound (glb), or null is glb does not
	 * exist.
	 * 
	 * @param cSet
	 * @return
	 */
	private TypeDecl bestLowerBound(ConstraintSet cSet) {
		Map<TypeDecl, Set<TypeDecl>> glbMap =
				_LowerTypeHierarchy.hierarchyMerge(cSet.subtypeConstraints);
		if (glbMap.size() > 1)
			return _BestLowerBound.bestBound(glbMap, cSet.supertypeConstraints,
												cSet.supertypeStatistics(),
												cSet.subtypeStatistics());

		return null;
	}

	/**
	 * Return the best least upper bound (lub), or null is lub does not exist.
	 * 
	 * @param cSet
	 * @return
	 */
	private TypeDecl bestUpperBound(ConstraintSet cSet) {
		Map<TypeDecl, Set<TypeDecl>> lubMap =
				_UpperTypeHierarchy.hierarchyMerge(cSet.supertypeConstraints);

		if (lubMap.size() > 1)
			return _BestUpperBound.bestBound(lubMap, cSet.subtypeConstraints,
												cSet.subtypeStatistics(), cSet
														.supertypeStatistics());

		return null;
	}

	/**
	 * Collect the type variables that are directly responsible for after-check
	 * errors.
	 * 
	 * @param constraints
	 * @return a set of erroneous type variables.
	 */
	private Set<TypeVariable> findSourceOfAfterCheckError(
			final Map<TypeVariable, ConstraintSet> constraints) {
		final Set<TypeVariable> errVarSet = new HashSet<TypeVariable>(3);
		final List<TypeCheckErrorMsg> checkErrs = errMan.getCheckErrorList();
		Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>(constraints.size());
		for (TypeVariable T : constraints.keySet()) {
			TypeDecl inferredType = constraints.get(T).typeArgument;
			if (inferredType != null && !inferredType.isUnknown()) {
				subst.put(T, inferredType);
			}
		}

		for (TypeCheckErrorMsg msg : checkErrs) {
			// pass a list of indices that will not be checked.
			TypeDecl formalType = msg.getFormalType();
			ParTypeDecl PF = (ParTypeDecl) formalType;
			ArrayList<Integer> excList = new ArrayList<Integer>(0);

			if (BasicSolver.areInferred(PF.getTypeVariables(), constraints)) {
				ParTypeDecl PA = (ParTypeDecl) msg.getActualTuple().implied;
				ArrayList<Integer> idxList =
						PA.containedIn((ParTypeDecl) formalType
								.instantiateParType(subst), excList);
				for (Integer i : idxList)
					errVarSet.addAll(PF.getArgument(i).type()
							.getTypeVariables());

			}

		}
		return errVarSet;
	}

	abstract class TypeHierarchy {
		/**
		 * Group the types in typeList so that all types are merged, depending
		 * on the implementation of onSamePath, with either the lowest type or
		 * the highest type on a path.
		 * 
		 * @param typeList
		 * @return a mapping from the type in a path hierarchy to a set of type
		 *         that belong to the same path.
		 */
		Map<TypeDecl, Set<TypeDecl>> hierarchyMerge(List<Tuple> typeList) {
			Map<TypeDecl, Set<TypeDecl>> hierachyPath =
					new HashMap<TypeDecl, Set<TypeDecl>>(typeList.size());
			Set<Integer> processed = new HashSet<Integer>(typeList.size());
			for (int i = 0; i < typeList.size(); i++) {
				// if alement at index i is already processed, then go the next
				// element.
				if (processed.contains(i))
					continue;

				TypeDecl iType = typeList.get(i).implied;

				if (!hierachyPath.containsKey(iType))
					hierachyPath.put(typeList.get(i).implied,
										new HashSet<TypeDecl>(typeList.size()));

				for (int j = i + 1; j < typeList.size(); j++) {
					if (processed.contains(j) || processed.contains(i))
						continue;

					int k = onSamePath(i, j, typeList);
					TypeDecl parent = null, child = null;
					if (k == i) {
						parent = iType;
						child = typeList.get(j).implied;
						// cache the index j so that it will not be processes
						// again.
						processed.add(j);
					} else if (k == j) {
						parent = typeList.get(j).implied;
						child = iType;
						// cache the index j so that it will not be processes
						// again.
						processed.add(i);
					}
					if (parent != null && child != null) {
						if (hierachyPath.containsKey(parent))
							hierachyPath.get(parent).add(child);
						else {
							Set<TypeDecl> childSet = new HashSet<TypeDecl>();
							childSet.add(child);
							hierachyPath.put(parent, childSet);
						}
						// if child has children of its own, than add them too
						// to the parent.
						if (hierachyPath.containsKey(child))
							hierachyPath.get(parent)
									.addAll(hierachyPath.remove(child));
					}
				}
			}
			return hierachyPath;
		}

		/**
		 * This method should return on of the indices i or j in case of success
		 * and -1 otherwise. If the index i is returned then the type at index j
		 * is included in as child of the type at index i. If j is return then
		 * it's the other way around.
		 * 
		 * @param i
		 *            an index of typeList
		 * @param j
		 *            an index of typeList
		 * @param typeList
		 *            a list of tuples
		 * @return either the parameter i or j in case of success or -1
		 *         otherwise.
		 */
		abstract int onSamePath(int i, int j, List<Tuple> typeList);
	}

	class LowerTypeHierarchy extends TypeHierarchy {

		@Override
		int onSamePath(int i, int j, List<Tuple> typeList) {
			if (typeList.get(i).implied.subtype(typeList.get(j).implied))
				return i;
			if (typeList.get(j).implied.subtype(typeList.get(i).implied))
				return j;
			return -1;
		}
	}

	class UpperTypeHierarchy extends TypeHierarchy {

		@Override
		int onSamePath(int i, int j, List<Tuple> typeList) {
			if (typeList.get(i).implied.subtype(typeList.get(j).implied))
				return j;
			if (typeList.get(j).implied.subtype(typeList.get(i).implied))
				return i;
			return -1;
		}
	}

	abstract class BestBound {
		/**
		 * Find a bound with a minimal amount of conflicts. If there is more
		 * than one choose the on with the largest set of types.
		 * </p>
		 * If we looking for a best lower bound, then: <lu>
		 * <li><i>typeConstraints</i> is the super constraints</li>
		 * <li><i>oppositetypeStats</i> is the supertype statistics</li>
		 * <li><i>typeStats</i> is the subtype statistics</li>
		 * </lu>
		 * 
		 * </p>
		 * If we looking for a best upper bound, then: <lu>
		 * <li><i>typeConstraints</i> is the sub constraints</li>
		 * <li><i>oppositetypeStats</i> is the subtype statistics</li>
		 * <li><i>typeStats</i> is the supertype statistics</li>
		 * </lu>
		 * </p>
		 * 
		 * @param boundMap
		 *            a mapping from a bound to a set of supertype or subtypes.
		 * @param typeConstraints
		 * @param oppositetypeStats
		 *            a mapping from a type to number of types that are either
		 *            its subtype or supertype
		 * @param typeStats
		 *            a mapping from a type to number of types that are either
		 *            its supertype or subtype
		 * @return
		 */
		public TypeDecl bestBound(final Map<TypeDecl, Set<TypeDecl>> boundMap,
				final DistinctArrayList typeConstraints,
				final Map<TypeDecl, Integer> oppositetypeStats,
				final Map<TypeDecl, Integer> typeStats) {
			final Map<TypeDecl, Integer> bestBoundMap =
					new HashMap<TypeDecl, Integer>(boundMap.size());

			// find a bound with maximal number of satisfied constraints.
			for (TypeDecl bound : boundMap.keySet()) {
				int count = 0;
				for (TypeDecl type : typeConstraints.impliedView()) {
					if (satified(type, bound)) {
						if (oppositetypeStats.containsKey(bound))
							count += oppositetypeStats.get(bound);
						else
							count++;
					}
				}
				bestBoundMap.put(bound, count);
			}

			int bestScore = 0;

			for (TypeDecl bestBound : bestBoundMap.keySet()) {
				// a higher number of lives means a lower number of kills
				int liveCount = 0;
				int oldScore = bestBoundMap.get(bestBound);
				// TODO keep one option only
				// consider each type to be unique, thus allowing duplicates
				if (Program.hasOption(Program._distinctTypes)) {
					if (boundMap.get(bestBound).isEmpty())
						liveCount++;
					else
						for (TypeDecl bound : boundMap.get(bestBound)) {
							if (typeStats.containsKey(bound))
								liveCount += typeStats.get(bound);
							else {
								liveCount++;
							}
						}

					// System.out.println(bestBound.simpleName() + " " +
					// liveCount
					// + " lives " + oldScore + " other lives");
				}
				// ignore duplicates.
				else {
					liveCount = boundMap.get(bestBound).size() + 1;

					// System.out.println(bestBound.simpleName() + " " +
					// liveCount
					// + " lives " + oldScore + " other lives");
				}
				// update the score
				bestBoundMap.put(bestBound, oldScore + liveCount);
				if ((oldScore + liveCount) > bestScore)
					bestScore = oldScore + liveCount;
			}

			if (Collections.frequency(bestBoundMap.values(), bestScore) == 1) {
				for (TypeDecl bestbound : bestBoundMap.keySet()) {
					if (bestBoundMap.get(bestbound) == bestScore)
						return bestbound;
				}
			}

			return null;
		}

		abstract boolean satified(TypeDecl type, TypeDecl bound);
	}

	/**
	 * @author Drako
	 * 
	 * Find the best lower bound. A bound that satisfies as much supertypes
	 * constraints as possible and kills as less subtype constraints as possible
	 */
	class BestLowerBound extends BestBound {

		@Override
		boolean satified(TypeDecl type, TypeDecl bound) {
			return type.subtype(bound);
		}
	}

	/**
	 * @author Drako
	 * 
	 * Find the best upper bound. A bound that satisfies as much subtypes
	 * constraints as possible and kills as less supertypes constraints as
	 * possible.
	 */
	class BestUpperBound extends BestBound {

		@Override
		boolean satified(TypeDecl type, TypeDecl bound) {
			return bound.subtype(type);
		}
	}

}
