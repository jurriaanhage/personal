/**
 * 
 */
package inference.heuristics;

import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.heuristic_messages.WarningExt;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * Warn the user that none of the types in the equality constraints will correct
 * the type error. If there is a type in the type constraints that will correct
 * the error, then this type will be proposed by the majority heuristic.
 * 
 * @author Drako
 * 
 */
public class EqualityTypeWarning extends AbstractHeuristic {

	private final Map<TypeVariable, ConstraintSet> constraints;
	private final ITypeErrorManager errMan;

	/**
	 * @param solver
	 */
	public EqualityTypeWarning(final ISolver solver) {
		this(solver.getCurrentConstraints(false), solver.getTypeErrorManager());
	}

	/**
	 * @param constraints
	 *            non-original constraints. No write operations should be
	 *            performed on this constraints.
	 * @param errMan
	 */
	public EqualityTypeWarning(
			final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan) {
		super("equality type warning");
		this.constraints = constraints;
		this.errMan = errMan;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {
		Map<TypeVariable, EqTypeErrorMsg> equalErrors =
				errMan.getEqualityErrors();

		for (TypeVariable var : equalErrors.keySet()) {

			WarningExt msgEx =
					new WarningExt(getClass(),
							unsatisfiedSuperTypeConstraints(var), equalErrors
									.get(var).getEqTypeValues());

			for (Tuple tu : unsatisfiesSubTypeConstraints(var))
				msgEx.addType(tu);

			if (msgEx.isReady())
				equalErrors.get(var).addExtension(msgEx);
		}
	}

	/**
	 * Return the minimal set of supertype tuples that are not satisfied by the
	 * type variable's equality types.
	 * 
	 * @param var
	 * @param superTuples
	 * @return
	 */
	private Set<Tuple> unsatisfiedSuperTypeConstraints(final TypeVariable var) {
		final DistinctArrayList equalConstraints =
				constraints.get(var).equaltypeConstraints;
		//final DistinctArrayList superConstraints =
		//		constraints.get(var).allSupertypeConstraints;
		final ArrayList<Tuple> superConstraints =
			constraints.get(var).allSupertypeConstraints;

		Set<Tuple> superTuples = new HashSet<Tuple>(3);
		boolean init = true;

		for (Tuple tu : equalConstraints) {
			TypeDecl equalType = tu.implied.skolemize();
			Set<Tuple> errSet = new HashSet<Tuple>(superConstraints.size());
			for (Tuple stu : superConstraints)
				if (!stu.implied.subtype(equalType)) {
					errSet.add(stu);
				}
			if (init) {
				superTuples = errSet;
				init = false;
			} else if (superTuples.size() > errSet.size())
				superTuples = errSet;
		}
		return superTuples;
	}

	/**
	 * Return the minimal set of subtype tuples that are not satisfied by the
	 * type variable's equality types.
	 * 
	 * @param var
	 * @param subTuples
	 * @return
	 */
	private Set<Tuple> unsatisfiesSubTypeConstraints(final TypeVariable var) {
		final DistinctArrayList equalConstraints =
				constraints.get(var).equaltypeConstraints;
//		final DistinctArrayList subConstraints =
//				constraints.get(var).subtypeConstraints;
		final ArrayList<Tuple> subConstraints =
			constraints.get(var).allSubtypeConstraints;

		Set<Tuple> subTuples = new HashSet<Tuple>(3);
		boolean init = true;

		for (Tuple tu : equalConstraints) {
			TypeDecl equalType = tu.implied.skolemize();
			Set<Tuple> errSet = new HashSet<Tuple>(subConstraints.size());
			for (Tuple stu : subConstraints)
				if (!equalType.subtype(stu.implied)) {
					errSet.add(stu);
				}

			if (init) {
				subTuples = errSet;
				init = false;
			} else if (subTuples.size() > errSet.size())
				subTuples = errSet;
		}
		return subTuples;
	}

}
