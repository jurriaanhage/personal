/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.WildcardFlipExt;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import AST.ParTypeDecl;
import AST.TypeAccess;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardExtendsType;
import AST.WildcardSuperType;

/**
 * @author Drako
 * 
 */
public class OppositeWildcards extends AbstractHeuristic {

	private final List<TypeCheckErrorMsg> typeCheckErrorList;

	private final Map<TypeVariable, ConstraintSet> constraintsMap;

	private final TypeDecl contextType, returnType;

	/**
	 * @param solver
	 */
	public OppositeWildcards(final ISolver solver) {
		this(solver.getOriginalConstraints(), solver.getTypeErrorManager()
				.getCheckErrorList(), solver.getContextType(), solver
				.getReturnType());
	}

	/**
	 * @param constraintsMap
	 * @param typeCheckErrors
	 * @param compilationUnit
	 * @param contextType
	 * @param returnType
	 */
	public OppositeWildcards(
			final Map<TypeVariable, ConstraintSet> constraintsMap,
			final List<TypeCheckErrorMsg> typeCheckErrors,
			final TypeDecl contextType, final TypeDecl returnType) {
		super("Opposite wildcards");
		this.typeCheckErrorList = typeCheckErrors;
		this.constraintsMap = constraintsMap;
		this.contextType = contextType;
		this.returnType = returnType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {
		ConstraintsMapBuilder builder = new ConstraintsMapBuilder();
		// set the type variables
		List<TypeVariable> varList =
				new ArrayList<TypeVariable>(constraintsMap.size());
		for (TypeVariable tVar : constraintsMap.keySet()) {
			varList.add(tVar);
		}

		for (TypeCheckErrorMsg msg : typeCheckErrorList) {
			for (Iterator iter =
					msg.getFormalType().getTypeVariables().iterator(); iter
					.hasNext();) {
				TypeVariable tVar = (TypeVariable) iter.next();
				if (!varList.contains(tVar)) {
					varList.add(tVar);
				}
			}

			// mark wildcards for bound flipping
			markWildcardForReversing(msg.getActualTuple().implied, msg
					.getFormalType());
		}
		builder.setTypeVaraibles(varList);
		builder.setConstraintsMap(constraintsMap);

		// collect constraints
		for (TypeCheckErrorMsg msg : typeCheckErrorList) {
			TypeDecl origType = msg.getActualTuple().implied;
			TypeDecl flipType = origType.typeWithFlippedWilds(getClass());
			builder.convertibleTo(flipType, msg.getFormalType());
		}

		CompleteSolver solver =
				new CompleteSolver(builder, contextType, returnType);

		if (!solver.inferTypes()) {
			for (TypeCheckErrorMsg msg : typeCheckErrorList) {
				// FIXED by passing the whole formal and actual parameters to
				// the solver as after-checks.
				TypeDecl origType = msg.getActualTuple().implied;
				WildcardFlipExt msgEx =
						new WildcardFlipExt(getClass(), origType
								.typeWithFlippedWilds(getClass()), msg
								.getFormalType());
				msg.addExtension(msgEx);
			}
		}
	}

	/**
	 * Iteratively flip the bounds of wildcards in A until it matches the
	 * wildcards in F.
	 * 
	 * @param A
	 *            actual type
	 * @param F
	 *            former type
	 */
	private void markWildcardForReversing(TypeDecl A, TypeDecl F) {
		if (!(A.isParameterizedType() && F.isParameterizedType()))
			return;

		ParTypeDecl PF = (ParTypeDecl) F;
		ParTypeDecl PA = (ParTypeDecl) A;

		if (PF.getNumArgument() != PA.getNumArgument())
			return;

		for (int i = 0; i < PF.getNumArgument(); i++) {
			TypeDecl FW = PF.getArgument(i).type();
			TypeAccess awAccess = (TypeAccess) PA.getArgument(i);
			TypeDecl AW = awAccess.type();
			// <? ext U>
			if (FW instanceof WildcardExtendsType) {
				TypeDecl U = ((WildcardExtendsType) FW).extendsType();
				// <? ext V>
				if (AW instanceof WildcardExtendsType) {
					TypeDecl V = ((WildcardExtendsType) AW).extendsType();
					markWildcardForReversing(V, U);
				}
				// <? sup V>
				else if (AW instanceof WildcardSuperType) {
					TypeDecl V = ((WildcardSuperType) AW).superType();
					awAccess.setOpposite(getClass(), true);
					markWildcardForReversing(V, U);
				}
			}
			// <? sup U>
			else if (FW instanceof WildcardSuperType) {
				TypeDecl U = ((WildcardSuperType) FW).superType();
				// <? ext V>
				if (AW instanceof WildcardExtendsType) {
					TypeDecl V = ((WildcardExtendsType) AW).extendsType();
					awAccess.setOpposite(getClass(), true);
					markWildcardForReversing(V, U);
				}
				// <? sup V>
				else if (AW instanceof WildcardSuperType) {
					TypeDecl V = ((WildcardSuperType) AW).superType();
					markWildcardForReversing(V, U);
				}
			}
		}
	}
}
