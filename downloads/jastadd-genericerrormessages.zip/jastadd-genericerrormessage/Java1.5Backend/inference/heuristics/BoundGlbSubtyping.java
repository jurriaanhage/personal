package inference.heuristics;

import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.heuristic_messages.GLBTypeChangeExt;
import inference.solvers.ISolver;

import java.util.List;
import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * This heuristic is for class types only, and it's applied only if there is a
 * glb error.
 * <p>
 * If there is a type variable T that has a class as a bound and a class in the
 * subtype constraints that is not a subtype or supertype of T's class bound,
 * then this class is probably the source of the error.
 * 
 * @author Drako
 * 
 */
public class BoundGlbSubtyping extends AbstractHeuristic {

	private final Map<TypeVariable, List<GlbTypeErrorMsg>> errorMap;

	/**
	 * @param solver
	 */
	public BoundGlbSubtyping(final ISolver solver) {
		this(solver.getTypeErrorManager().getGlbErrors());
	}

	/**
	 * @param errorMap
	 */
	public BoundGlbSubtyping(
			final Map<TypeVariable, List<GlbTypeErrorMsg>> errorMap) {
		super("Bounds and Greatest lower bounds heuristic");
		this.errorMap = errorMap;
	}

	@Override
	public void analyse() {
		for (TypeVariable T : errorMap.keySet()) {
			TypeDecl classBound = getClassBound(T);
			if (classBound != null) {
				List<GlbTypeErrorMsg> errorList = errorMap.get(T);
				for (GlbTypeErrorMsg msg : errorList) {
					if (!haveSubtypeRelation(classBound, msg.getFstType())
							&& haveSubtypeRelation(classBound, msg.getSndType())) {
						// msg.setErrorCandidate(msg.fstErrorTuple());
						msg.addExtension(new GLBTypeChangeExt(msg
								.fstErrorTuple().getType(), msg
								.getTypeVariable(), getClass()));
					} else if (haveSubtypeRelation(classBound, msg.getFstType())
							&& !haveSubtypeRelation(classBound, msg
									.getSndType())) {
						// msg.setErrorCandidate(msg.sndErorrTuple());
						msg.addExtension(new GLBTypeChangeExt(msg
								.sndErorrTuple().getType(), msg
								.getTypeVariable(), getClass()));
					}
				}
			}
		}
	}

	private static final boolean haveSubtypeRelation(TypeDecl bound,
			TypeDecl type) {
		return bound.subtype(type) || type.subtype(bound);
	}

	private TypeDecl getClassBound(TypeVariable typeVar) {
		for (int i = 0; i < typeVar.getNumTypeBound(); i++)
			if (typeVar.getTypeBound(i).type().isClassDecl())
				return typeVar.getTypeBound(i).type();

		return null;
	}

}
