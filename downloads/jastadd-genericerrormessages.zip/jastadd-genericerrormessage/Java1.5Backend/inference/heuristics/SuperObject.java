/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.ErrorTuple;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.SupErrorCheckMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.solvers.BasicSolver;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.ParTypeDecl;
import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardExtendsType;
import AST.WildcardSuperType;

/**
 * Replace wildcards `? super Object' with Object since there is no type in Java
 * that is a supertype of Object except for Object itself. This could solve type
 * conflicts such as Map<? super Object, ? super Object> <: Map<T, T>.
 * 
 * @author Drako
 * 
 */
public class SuperObject extends WildcardReduction {

	/**
	 * @param solver
	 */
	public SuperObject(final ISolver solver) {
		this(solver.getOriginalConstraints(), solver.getTypeErrorManager(),
				solver.getContextType(), solver.getReturnType());
	}

	/**
	 * @param constraints
	 *            original constraints
	 * @param errMan
	 * @param contextType
	 * @param returnType
	 */
	public SuperObject(final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan, final TypeDecl contextType,
			final TypeDecl returnType) {
		super("? Super Object", constraints, errMan, contextType, returnType);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {
		Set<TypeVariable> eqVarSet = new HashSet<TypeVariable>(3);
		Map<TypeVariable, DistinctArrayList> checkMap =
				new HashMap<TypeVariable, DistinctArrayList>(3);
		// case 1:

		// 1 - look for equality errors with '? super Object'
		// 2 - replace in constraints '? super Object' with Object.
		// 3 - start inference again, if no errors found include a hint.

		analyseEqualityErrors(eqVarSet);

		// case 2:

		// 1 - look for super-after-checks with T='? super Object'
		// 2 - replace in constraints '? super Object' with Object
		// 3 - start inference again, if no errors found include a hint.

		analyseAfterCheckErrors(checkMap);

		if (!eqVarSet.isEmpty() || !checkMap.isEmpty()) {
			ConstraintsMapBuilder builder = new ConstraintsMapBuilder();
			builder.setTypeVaraibles(new ArrayList<TypeVariable>(constraints
					.keySet()));
			builder.setConstraintsMap(constraints);

			CompleteSolver solver =
					new CompleteSolver(builder, contextType, returnType);
			solver.inferTypes();

			Map<TypeVariable, ConstraintSet> newConstraints =
					solver.getConstraintsMap();
			TypeDecl objType =
					eqVarSet.isEmpty() ? checkMap.keySet().iterator().next()
							.typeObject() : eqVarSet.iterator().next()
							.typeObject();

			// remove all type variable that cause errors even when their type
			// was replaced with Object.
			Set<TypeVariable> erTypeVarSet =
					findSourceOfBoundErrors(solver, eqVarSet, checkMap.keySet());
			eqVarSet.removeAll(erTypeVarSet);

			for (TypeVariable T : eqVarSet) {
				EqTypeErrorMsg eqMsg = errMan.getEqualityErrors().get(T);
				TypeChangeExt msgEx = new TypeChangeExt(objType, getClass());
				// Replaced with code below.
				// for (ErrorTuple et : eqMsg.getEqTypeValues()) {
				// msgEx.addReplaceable(et.getOrigTuple());
				// }
				for (Tuple uw : eqMsg.getSourceTypes())
					msgEx.addReplaceable(uw);
				if (msgEx.isReady())
					eqMsg.addExtension(msgEx);
			}
			for (TypeVariable var : findSourceOfAfterCheckError(newConstraints))
				checkMap.remove(var);

			// if there is nothing to replace, then return.
			if (!checkMap.isEmpty())
				for (TypeCheckErrorMsg msg : errMan.getCheckErrorList())
					if (msg instanceof SupErrorCheckMsg) {
						SupErrorCheckMsg supMsg = (SupErrorCheckMsg) msg;
						Set<TypeVariable> varSet =
								supMsg.getFormalType().getTypeVariables();
						TypeChangeExt msgEx =
								new TypeChangeExt(objType, getClass());
						for (TypeVariable var : varSet)
							if (checkMap.containsKey(var)) {
								for (Tuple uw : checkMap.get(var))
									msgEx.addReplaceable(uw);
							}
						if (msgEx.isReady())
							supMsg.addExtension(msgEx);
					}

		}
	}

	/**
	 * Scan for equality error messages where all the constraints have the form
	 * T='? super Object'. If a message is found replace all the equality
	 * constraints with the constraint T=Object and add the type variable
	 * corresponding to the message to <code>varSet</code>.
	 * 
	 * @param varSet
	 */
	private void analyseEqualityErrors(final Set<TypeVariable> varSet) {
		Map<TypeVariable, EqTypeErrorMsg> equalErrors =
				errMan.getEqualityErrors();
		for (TypeVariable var : constraints.keySet()) {
			if (allSuperWildObject(equalErrors.get(var))) {
				DistinctArrayList equalConstraints =
						constraints.get(var).equaltypeConstraints;
				equalConstraints.clear();
				equalConstraints.add(new Tuple(var.typeObject(), var
						.typeObject()));
				varSet.add(var);
			}
		}
	}

	/**
	 * Check if the equality constraints in the parameter <code>msg</code> are
	 * all of the form '? super Object'.
	 * 
	 * @param msg
	 * @return
	 */
	private boolean allSuperWildObject(EqTypeErrorMsg msg) {
		if (msg == null)
			return false;
		for (ErrorTuple et : msg.getEqTypeValues())
			if (!isSuperObject(et.getType()))
				return false;
		return true;
	}

	/**
	 * Check if <code>type</code> is a wildcard with the type Object as its
	 * lower bound.
	 * 
	 * @param type
	 * @return
	 */
	private final boolean isSuperObject(final TypeDecl type) {
		if (type != null && type instanceof WildcardSuperType)
			return ((WildcardSuperType) type).superType().isObject();

		return false;
	}

	/**
	 * Look for after-checks where '? extends T' is being checked against '?
	 * super Object' and add T and its equality constraints to checkMap, if the
	 * inferred type of T is '? super Object'.
	 * 
	 * @param checkMap
	 */
	private void analyseAfterCheckErrors(
			final Map<TypeVariable, DistinctArrayList> checkMap) {
		List<TypeCheckErrorMsg> checkErrs = errMan.getCheckErrorList();
		for (TypeCheckErrorMsg msg : checkErrs) {
			if (msg instanceof SupErrorCheckMsg) {
				ParTypeDecl PF = (ParTypeDecl) msg.getFormalType();
				ParTypeDecl PA = (ParTypeDecl) msg.getActualTuple().implied;
				PA = promoteType(PA, PF);
				if (PA.genericDecl() == PA.genericDecl())
					for (int i = 0; i < PF.getNumArgument(); i++) {
						if (isExtendTypeVar(PF.getArgument(i).type())
								&& isSuperObject(PA.getArgument(i).type())) {
							TypeVariable T =
									(TypeVariable) ((WildcardExtendsType) PF
											.getArgument(i).type())
											.extendsType();
							DistinctArrayList equalConstraints =
									constraints.get(T).equaltypeConstraints;
							if (allSuperWildObject(equalConstraints)) {
								// types that need to be replaced with Object
								checkMap.put(T, equalConstraints.clone());
								equalConstraints.clear();
								equalConstraints.add(new Tuple(T.typeObject(),
										T.typeObject()));
							}
						}
					}
			}
		}
	}

	/**
	 * Convert a parametrized <code>subtype</code> to a <code>supertype</code>
	 * to guarantee that the number of type parameters are equal.
	 * 
	 * @param type
	 * @param superType
	 * @return
	 */
	public ParTypeDecl promoteType(ParTypeDecl type, ParTypeDecl superType) {
		if (type.genericDecl() == superType.genericDecl())
			return type;

		HashSet<ParTypeDecl> parameterizedSupertypes =
				ConstraintsMapBuilder.parameterizedSupertypes((TypeDecl) type);
		for (ParTypeDecl pt : parameterizedSupertypes)
			if (pt.genericDecl() == superType.genericDecl())
				return pt;

		return type;
	}

	/**
	 * Check if <code>type<code> is a wildcard with a type variable as
	 * its upper bound.
	 * 
	 * @param type
	 * @return
	 */
	private boolean isExtendTypeVar(final TypeDecl type) {
		if (type != null && type instanceof WildcardExtendsType) {
			WildcardExtendsType we = (WildcardExtendsType) type;
			if (we.extendsType() instanceof TypeVariable)
				return true;
		}

		return false;
	}

	/**
	 * Check if the equality constraints in <code>constraints</code> are all
	 * of the form '? super Object'.
	 * 
	 * @param constraits
	 * @return
	 */
	private boolean allSuperWildObject(final DistinctArrayList constraits) {
		for (Tuple et : constraits)
			if (!isSuperObject(et.implied))
				return false;
		return true;
	}

	/**
	 * Collect the type variables that are directly responsible for after-check
	 * errors.
	 * 
	 * @param constraints
	 * @return a set of erroneous type variables.
	 */
	private Set<TypeVariable> findSourceOfAfterCheckError(
			final Map<TypeVariable, ConstraintSet> constraints) {
		final Set<TypeVariable> errVarSet = new HashSet<TypeVariable>(3);
		final List<TypeCheckErrorMsg> checkErrs = errMan.getCheckErrorList();
		Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>(constraints.size());
		for (TypeVariable T : constraints.keySet()) {
			TypeDecl inferredType = constraints.get(T).typeArgument;
			if (inferredType != null && !inferredType.isUnknown()) {
				subst.put(T, inferredType);
			}
		}

		for (TypeCheckErrorMsg msg : checkErrs) {
			if (Program.hasOption(Program._strictMode)) {
				// if strict is on than blame all type var in the formal type.
				errVarSet.addAll(msg.getFormalType().getTypeVariables());
			} else if (msg instanceof SupErrorCheckMsg) {
				// pass a list of indices that will not be checked.
				TypeDecl formalType = msg.getFormalType();
				ParTypeDecl PF = (ParTypeDecl) formalType;
				ArrayList<Integer> excList = new ArrayList<Integer>(3);
				// TYPE VARS are replaced by Object and so is the type in their
				// position in the actual parameters, so I don't need to check
				// them for errors. This just a hack to prevent creating new
				// types where '?super Object' is replaced by 'Object'
				for (int j = 0; j < PF.getNumArgument(); j++) {
					if (PF.getArgument(j).type() instanceof TypeVariable)
						excList.add(j);
				}
				if (BasicSolver.areInferred(PF.getTypeVariables(), constraints)) {
					ParTypeDecl PA = (ParTypeDecl) msg.getActualTuple().implied;
					ArrayList<Integer> idxList =
							PA.containedIn((ParTypeDecl) formalType
									.instantiateParType(subst), excList);
					for (Integer i : idxList)
						errVarSet.addAll(PF.getArgument(i).type()
								.getTypeVariables());

				}

			}
		}
		return errVarSet;
	}
}
