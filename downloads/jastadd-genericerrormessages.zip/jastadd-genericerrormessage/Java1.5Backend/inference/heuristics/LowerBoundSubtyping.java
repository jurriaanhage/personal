/**
 * 
 */
package inference.heuristics;

import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.GlbTypeErrorMsg;
import inference.solvers.ISolver;

import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class LowerBoundSubtyping extends AbstractHeuristic {
	private final Map<TypeVariable, ConstraintSet> constraints;
	private final ITypeErrorManager errMan;

	/**
	 * @param solver
	 */
	public LowerBoundSubtyping(final ISolver solver) {
		this(solver.getCurrentConstraints(false), solver.getTypeErrorManager());
	}

	/**
	 * @param constraints
	 * @param errMan
	 */
	public LowerBoundSubtyping(
			final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan) {
		super("Lower bound subtyping");
		this.constraints = constraints;
		this.errMan = errMan;
	}

	@Override
	public void analyse() {
		Set<TypeVariable> tvars = constraints.keySet();
		for (TypeVariable T : tvars) {
			checkSubTyping(T, constraints.get(T).subtypeConstraints);
		}
	}

	/**
	 * @param T
	 * @param subtypeConstraints
	 */
	private void checkSubTyping(TypeVariable T,
			DistinctArrayList subtypeConstraints) {
		DistinctArrayList classTuples = new DistinctArrayList();
		for (Tuple UW : subtypeConstraints)
			if (UW.implied.isClassDecl())
				classTuples.add(UW);

		// Check for any pair of types that are not in subtype relationship
		for (int i = 0; i < classTuples.size(); i++) {
			TypeDecl U = classTuples.get(i).implied;
			for (int j = i + 1; j < classTuples.size(); j++) {
				TypeDecl V = classTuples.get(j).implied;
				if (!(U.instanceOf(V) || V.instanceOf(U))) {
					errMan.addErrorMsg(new GlbTypeErrorMsg(T,
							classTuples.get(i), classTuples.get(j)));
				}
			}
		}
	}
}
