/**
 * 
 */
package inference.heuristics;

import static inference.solvers.BasicSolver.areInferred;
import inference.ds.ConstraintSet;
import inference.ds.RepairEntry;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.solvers.CompleteSolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.ParTypeDecl;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public abstract class AbstractHeuristic implements Heuristic {

	protected final String name;

	/**
	 * 
	 */
	public AbstractHeuristic(String name) {
		this.name = name;
	}

	public abstract void analyse();

	/**
	 * Return a set of type variables that are directly responsible for a bound
	 * error, and any type variable in eqVarSet and checkVarSet that does not
	 * satisfy its bounds
	 * 
	 * @param solver
	 * @param varSet
	 * @param set
	 * @return
	 */
	protected Set<TypeVariable> findSourceOfBoundErrors(
			final CompleteSolver solver, final Set<TypeVariable> varSet) {
		final Set<TypeVariable> erVarSet = new HashSet<TypeVariable>(3);

		final Map<TypeVariable, List<PrBoundTypeErrorMsg>> preBoundErrors =
				solver.getErrorManager().getPreBoundErrors();
		final Map<TypeVariable, List<PoBoundTypeErrorMsg>> postBoundErrors =
				solver.getErrorManager().getPostBoundErrors();

		final Map<TypeVariable, ConstraintSet> constraints =
				solver.getConstraintsMap();

		final Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>(constraints.size());

		for (TypeVariable T : constraints.keySet()) {
			TypeDecl typeArgument = constraints.get(T).typeArgument;
			if (typeArgument != null && !typeArgument.isUnknown())
				subst.put(T, typeArgument);
		}

		for (TypeVariable T : constraints.keySet())
			if (preBoundErrors.containsKey(T) || postBoundErrors.containsKey(T)) {
				// if the type of the type variable that conflicts with its
				// bound was previously replaced from '? extends Final' to
				// Final, then add to the set.
				if (varSet.contains(T))
					erVarSet.add(T);
				else
					findSourceOfBoundError(T, constraints, erVarSet, subst);
			}

		return erVarSet;
	}

	/**
	 * Add the type variables that caused bound errors for the type variable var
	 * to the set erVarSet.
	 * 
	 * @param var
	 * @param constraints
	 * @param erVarSet
	 * @param subst
	 */
	protected static void findSourceOfBoundError(final TypeVariable var,
			final Map<TypeVariable, ConstraintSet> constraints,
			final Set<TypeVariable> erVarSet,
			final Map<TypeVariable, TypeDecl> subst) {

		final TypeDecl inferredType = constraints.get(var).typeArgument;

		if (inferredType == null || inferredType.isUnknown())
			return;

		for (int i = 0; i < var.getNumTypeBound(); i++) {
			TypeDecl bound = var.getTypeBound(i).type();
			Set boundTVars = bound.getTypeVariables();
			if (bound instanceof ParTypeDecl
					&& areInferred(boundTVars, constraints)) {

				// the inferred type for t must a ParType.
				if (inferredType.isDerivedFrom(bound.genericDecl())) {
					// find the type arguments that cause a type conflict
					ArrayList<Integer> idxList =
							inferredType.containedIn((ParTypeDecl) bound
									.instantiateParType(subst), null);
					// add all the type variables of the type argument that are
					// responsible for a type conflict to erVarSet.
					ParTypeDecl parBound = (ParTypeDecl) bound;
					for (Integer idx : idxList)
						erVarSet.addAll(parBound.getArgument(idx).type()
								.getTypeVariables());
				} else {
					erVarSet.addAll(boundTVars);
				}
			}
		}
	}

	/**
	 * If there are any inconsistencies in <code>repairCache</code>, then
	 * remove the extension containing inconsistent repairs.
	 * 
	 * @param <T>
	 *            entity for which a repair is suggested.
	 * @param repairCache
	 *            list of repairs.
	 * @param extensionCache
	 *            map for repaired entities and their corresponding message
	 *            extension.
	 */
	protected <T> void detectExprInconsitency(
			List<? extends RepairEntry<T>> repairCache,
			Map<T, MessageExtension> extensionCache) {
		int size = repairCache.size();
		for (int i = 0; i < size; i++) {
			RepairEntry rep1 = repairCache.get(i);
			for (int j = i + 1; j < size; j++) {
				RepairEntry rep2 = repairCache.get(j);
				if (rep1.conflictsWith(rep2)) {					
					extensionCache.remove(rep1.repairedEntity);
					// in case var1 is not equal to var2
					extensionCache.remove(rep2.repairedEntity);
				}
			}
		}
	}
}