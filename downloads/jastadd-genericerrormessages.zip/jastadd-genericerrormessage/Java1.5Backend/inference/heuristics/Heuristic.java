/**
 * 
 */
package inference.heuristics;


/**
 * @author Drako
 * 
 */
public interface Heuristic {
	public void analyse();
}
