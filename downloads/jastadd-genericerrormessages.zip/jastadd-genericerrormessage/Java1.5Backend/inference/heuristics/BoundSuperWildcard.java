/**
 * 
 */
package inference.heuristics;

import inference.ConstraintsMapBuilder;
import inference.ConstraintsMapBuilder.PositionedType;
import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.heuristic_messages.WildcardFlipExt;
import inference.solvers.CompleteSolver;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import AST.AbstractWildcardType;
import AST.TypeDecl;
import AST.TypeVariable;
import AST.WildcardSuperType;

/**
 * If a super wildcard was used in an equality constraint, then all the types
 * defined by the expression `? super bouns(s)` must be a subtype of the
 * corresponding type variable's bounds, i.e. if T's bound is U and T = `? super
 * V`, then U must be an Object or an error is issued.
 * 
 * @author Drako
 * 
 */
public class BoundSuperWildcard extends AbstractHeuristic {

	private final Map<TypeVariable, List<PrBoundTypeErrorMsg>> errMap;

	private final Map<TypeVariable, ConstraintSet> constraintsMap;

	private final TypeDecl contextType, returnType;

	private final List<? extends TypeDecl> formalParams;
	private final List<PositionedType> actualParams;

	/**
	 * @param solver
	 */
	public BoundSuperWildcard(final ISolver solver) {
		this(solver.getOriginalConstraints(), solver.getTypeErrorManager()
				.getPreBoundErrors(), solver.getContextType(), solver
				.getReturnType(), solver.getFormalParameters(), solver
				.getActualParameters());
	}

	/**
	 * @param constraintsMap
	 *            original constraints
	 * @param errMap
	 * @param contextType
	 * @param returnType
	 * @param superChecks
	 * @param subChecks
	 * @param actuals
	 * @param formals
	 * 
	 */
	public BoundSuperWildcard(
			final Map<TypeVariable, ConstraintSet> constraintsMap,
			final Map<TypeVariable, List<PrBoundTypeErrorMsg>> errMap,
			final TypeDecl contextType, final TypeDecl returnType,
			final List<? extends TypeDecl> formals,
			final List<PositionedType> actuals) {
		super("Bounds and superwildcars");
		this.errMap = errMap;
		this.constraintsMap = constraintsMap;
		this.contextType = contextType;
		this.returnType = returnType;
		this.formalParams = formals;
		this.actualParams = actuals;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see inference.heuristics.AbstractHeuristic#analyse()
	 */
	@Override
	public void analyse() {

		// flip wildcards
		for (TypeVariable T : errMap.keySet()) {
			List<PrBoundTypeErrorMsg> errs = errMap.get(T);
			TypeDecl sourceType = null;
			DistinctArrayList equaltypeConstraints =
					constraintsMap.get(T).equaltypeConstraints;

			if (equaltypeConstraints.size() == 1)
				sourceType = equaltypeConstraints.get(0).initial;
			if (sourceType == null
					|| !equaltypeConstraints.get(0).implied.isWildcard())
				continue;

			for (PrBoundTypeErrorMsg msg : errs)
				if (msg.isTypeSuperWildcard()) {
					WildcardSuperType w =
							(WildcardSuperType) msg.getTypeValue();
					// revert the wildcard
					w.setOpposite_heur_reversible(getClass(), true);

					for (PositionedType ptype : actualParams)
						if (ptype.pos.equals(sourceType
								.getSourceFileAndLocation())) {
							// get the reversed wildcard
							ptype.type =
									sourceType.flipAllWildcards(getClass());
						}
				}
		}
		// check is inference succeeds
		if (reinferTypes()) {
			// mark candidate for flipping
			for (TypeVariable T : errMap.keySet()) {
				List<PrBoundTypeErrorMsg> errs = errMap.get(T);
				for (PrBoundTypeErrorMsg msg : errs)
					if (msg.isTypeSuperWildcard()) {
						AbstractWildcardType infType =
								(AbstractWildcardType) msg.getTypeValue();
						infType.setOpposite_heur_reversible(getClass(), true);
						WildcardFlipExt msgEx =
								new WildcardFlipExt(getClass(), infType
										.flipAllWildcards(getClass()), msg
										.getBound());
						msg.addExtension(msgEx);
					}
			}
		}
	}

	private boolean reinferTypes() {
		ConstraintsMapBuilder builder = new ConstraintsMapBuilder();

		List<TypeVariable> varList =
				new ArrayList<TypeVariable>(constraintsMap.size());
		for (TypeVariable T : constraintsMap.keySet()) {
			varList.add(T);
		}

		builder.setTypeVaraibles(varList, true);
		for (int i = 0; i < formalParams.size(); i++)
			builder
					.convertibleTo(actualParams.get(i).type, formalParams
							.get(i));

		CompleteSolver solver =
				new CompleteSolver(builder, contextType, returnType);

		return !solver.inferTypes();
	}
}
