/**
 * 
 */
package inference.heuristics;

import inference.ds.ConstraintSet;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.solvers.CompleteSolver;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Osiris
 * 
 */
public abstract class WildcardReduction extends AbstractHeuristic {

	protected final Map<TypeVariable, ConstraintSet> constraints;
	protected final ITypeErrorManager errMan;
	protected final TypeDecl contextType, returnType;

	/**
	 * @param name
	 */
	public WildcardReduction(String name,
			final Map<TypeVariable, ConstraintSet> constraints,
			final ITypeErrorManager errMan, final TypeDecl contextType,
			final TypeDecl returnType) {
		super(name);
		this.constraints = constraints;
		this.errMan = errMan;
		this.contextType = contextType;
		this.returnType = returnType;
	}

	@Override
	public abstract void analyse();

	/**
	 * Return a set of type variables that are directly responsible for a bound
	 * error, and any type variable in <code>eqVarSet</code> and
	 * <code>checkVarSet</code> that does not satisfy its bounds
	 * 
	 * @param solver
	 * @param eqVarSet
	 * @param set
	 * @return
	 */
	protected Set<TypeVariable> findSourceOfBoundErrors(
			final CompleteSolver solver, final Set<TypeVariable> eqVarSet,
			Set<TypeVariable> checkVarSet) {
		final Set<TypeVariable> erVarSet = new HashSet<TypeVariable>(3);

		final Map<TypeVariable, List<PrBoundTypeErrorMsg>> preBoundErrors =
				solver.getErrorManager().getPreBoundErrors();
		final Map<TypeVariable, List<PoBoundTypeErrorMsg>> postBoundErrors =
				solver.getErrorManager().getPostBoundErrors();

		final Map<TypeVariable, ConstraintSet> constraints =
				solver.getConstraintsMap();

		final Map<TypeVariable, TypeDecl> subst =
				new HashMap<TypeVariable, TypeDecl>(constraints.size());

		for (TypeVariable T : constraints.keySet()) {
			TypeDecl typeArgument = constraints.get(T).typeArgument;
			if (typeArgument != null && !typeArgument.isUnknown())
				subst.put(T, typeArgument);
		}

		for (TypeVariable T : constraints.keySet())
			if (preBoundErrors.containsKey(T) || postBoundErrors.containsKey(T)) {
				// if the type of the type variable that conflicts with its
				// bound was previously replaced from '? extends Final' to
				// Final, then add to the set.
				if (eqVarSet.contains(T) || checkVarSet.contains(T))
					erVarSet.add(T);
				// blame all type variables for the error.
				else if (Program.hasOption(Program._strictMode)) {
					for (int i = 0; i < T.getNumTypeBound(); i++) {
						erVarSet.addAll(T.getTypeBound(i).type()
								.getTypeVariables());
					}
				} else
					findSourceOfBoundError(T, constraints, erVarSet, subst);
			}

		return erVarSet;
	}
}
