/**
 * 
 */
package inference.heuristics;

import inference.solvers.BasicSolver;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Osiris
 * 
 */
public class EqualityGroupSolver {

	private Map<TypeVariable, List<TypeDecl>> domains;

	private Map<TypeVariable, List<TypeDecl>> domains_orig;

	private Set<TypeVariable> typeVariableGroup;

	public EqualityGroupSolver(final Set<TypeVariable> typeVariableGroup,
			final Map<TypeVariable, List<TypeDecl>> domains) {
		resetSolver(typeVariableGroup, domains);
	}

	/**
	 * Reset all the fields of this class to reuse it again.
	 * 
	 * @param typeVariableGroup
	 * @param domains
	 */
	public final void resetSolver(final Set<TypeVariable> typeVariableGroup,
			final Map<TypeVariable, List<TypeDecl>> domains) {
		this.typeVariableGroup = typeVariableGroup;
		this.domains_orig = copy(domains);
		this.domains = domains;
	}

	private static Map<TypeVariable, List<TypeDecl>> copy(
			Map<TypeVariable, List<TypeDecl>> domains) {

		Map<TypeVariable, List<TypeDecl>> domains_orig =
				new HashMap<TypeVariable, List<TypeDecl>>(domains.size());
		for (TypeVariable var : domains.keySet())
			domains_orig.put(var, new LinkedList<TypeDecl>(domains.get(var)));
		return domains_orig;
	}

	/**
	 * Return a set of solutions for each type variable.
	 * 
	 * @return
	 */
	public List<Map<TypeVariable, TypeDecl>> solve() {
		int max = 0;
		for (TypeVariable var : typeVariableGroup)
			max = (var.getOrder() > max) ? var.getOrder() : max;

		// Type variable with the highest bound dependency, that do not effect
		// each other.
		List<TypeVariable> roots = new LinkedList<TypeVariable>();
		// Rest of type variables
		List<TypeVariable> others = new LinkedList<TypeVariable>();

		for (TypeVariable var : typeVariableGroup) {
			if (var.getOrder() == max)
				roots.add(var);
			else
				others.add(var);
		}
		// sort the type variables
		Collections.sort(others, new Comparator<TypeVariable>() {
			public int compare(TypeVariable v1, TypeVariable v2) {
				return v2.getOrder() - v1.getOrder();
			}
		});

		// mix the roots
		// [T,R,...,U] -> [ {T:Vt, R:Vr, .. }, ...]
		List<Map<TypeVariable, TypeDecl>> inits = cartesianProducts(roots);

		return computeSolutions(inits, others);
	}

	/**
	 * Compute a list of possible solutions
	 * 
	 * @param substList
	 *            list of partial solutions that need to be extended.
	 * @param varList
	 *            list of type variables.
	 * @return a list of complete solutions
	 */
	private List<Map<TypeVariable, TypeDecl>> computeSolutions(
			List<Map<TypeVariable, TypeDecl>> substList,
			List<TypeVariable> varList) {
		List<Map<TypeVariable, TypeDecl>> solutions =
				new LinkedList<Map<TypeVariable, TypeDecl>>();

		for (Map<TypeVariable, TypeDecl> subst : substList) {
			if (applyFilter(subst, domains, varList)) {
				ListIterator<TypeVariable> iter = varList.listIterator();
				solutionProduct(subst, solutions, iter, varList);
			}
			resetVarDomains(varList);
		}
		return solutions;
	}

	/**
	 * Compute all possible solutions by extending the partial solution subst.
	 * 
	 * @param subst
	 *            a partial solution.
	 * @param solutions
	 *            list of complete solutions
	 * @param iter
	 *            list iterator that allows backtracking.
	 */
	@SuppressWarnings("unchecked")
	private void solutionProduct(Map<TypeVariable, TypeDecl> subst,
			final List<Map<TypeVariable, TypeDecl>> solutions,
			final ListIterator<TypeVariable> iter, final List<TypeVariable> src) {

		if (iter.hasNext()) {
			TypeVariable key = iter.next();
			Set<TypeVariable> dep_vars = key.dependingTypeVariables(src);
			for (TypeDecl val : domains.get(key)) {
				subst.put(key, val);
				if (applyFilter(subst, domains, dep_vars))
					solutionProduct(subst, solutions, iter, src);
				resetVarDomains(dep_vars);
			}
			iter.previous();
		} else {
			Map<TypeVariable, TypeDecl> tmp =
					new HashMap<TypeVariable, TypeDecl>(subst);
			solutions.add(tmp);
		}
	}

	/**
	 * Compute all cartesian products of the type variables in
	 * <code>varList</code>.
	 * 
	 * For example: {T:A, T:B}x{S:C} = [{T:A, S:C}, {T:B, S:C}]
	 * 
	 * @param varList
	 * @return a list of (TypeVariable, TypeDecl)
	 */
	private List<Map<TypeVariable, TypeDecl>> cartesianProducts(
			final List<TypeVariable> varList) {

		List<Map<TypeVariable, TypeDecl>> combis =
				new LinkedList<Map<TypeVariable, TypeDecl>>();
		TypeVariable head = varList.get(0);
		for (TypeDecl val : domains.get(head)) {
			HashMap<TypeVariable, TypeDecl> init =
					new HashMap<TypeVariable, TypeDecl>();
			init.put(head, val);
			ListIterator<TypeVariable> iter = varList.listIterator(1);
			cartesianProduct(init, combis, iter);
		}
		return combis;
	}

	/**
	 * Compute all cartesian products by extending the product
	 * <code>mapping</code> with types of type variables accessible through
	 * <code>iter</code>.
	 * 
	 * @param mapping
	 *            partial product
	 * @param combis
	 *            list of products
	 * @param iter
	 *            list iterator to be able to backtrack.
	 */
	@SuppressWarnings("unchecked")
	private void cartesianProduct(HashMap<TypeVariable, TypeDecl> mapping,
			List<Map<TypeVariable, TypeDecl>> combis,
			ListIterator<TypeVariable> iter) {

		if (iter.hasNext()) {
			TypeVariable key = iter.next();
			for (TypeDecl val : domains.get(key)) {
				mapping.put(key, val);
				cartesianProduct(mapping, combis, iter);
			}
			iter.previous();
		} else {
			combis.add((Map<TypeVariable, TypeDecl>) mapping.clone());
		}
	}

	/**
	 * Check whether all type variables in <code>dep_vars</code> have a type
	 * in their domain that will satisfy its bounds when instantiated with the
	 * partial substitution <code>mapping</code>.
	 * 
	 * @param mapping
	 *            mapping from type variables to types.
	 * @param domains
	 *            mapping from type variables to lists of possible types.
	 * @param dep_vars
	 * @return <code>true</code> if all type variable are within their bounds.
	 */
	private boolean applyFilter(Map<TypeVariable, TypeDecl> mapping,
			Map<TypeVariable, List<TypeDecl>> domains,
			Collection<TypeVariable> dep_vars) {

		for (TypeVariable var : dep_vars) {
			// check if a val from the var's domains satisfies its bounds
			for (int i = 0; i < domains.get(var).size(); i++) {
				if (!withInBounds(mapping, var, domains.get(var).get(i)))
					domains.get(var).set(i, null);
			}
			BasicSolver.removeNullValues(domains.get(var));
			if (domains.get(var).isEmpty())
				return false;
		}

		return true;
	}

	/**
	 * Check whether the type <code>val</code> is subtype of all bounds of the
	 * type variable <code>var</code> when these bound are instantiated with
	 * the type in <code>subst</code>.
	 * 
	 * @param subst
	 * @param var
	 * @param val
	 * @return <code>true</code> if the <code>var</code> is within its
	 *         bounds.
	 */
	private boolean withInBounds(final Map<TypeVariable, TypeDecl> subst,
			final TypeVariable var, final TypeDecl val) {
		for (int i = 0; i < var.getNumTypeBound(); i++) {
			TypeDecl bound =
					var.getTypeBound(i).type().instantiateParType(subst, true);
			if (val.subtype(bound))
				return true;

		}
		return false;
	}

	/**
	 * Restore the original domain of each type variable in dep_vars.
	 * 
	 * @param dep_vars
	 */
	private void resetVarDomains(Collection<TypeVariable> dep_vars) {
		for (TypeVariable var : dep_vars)
			domains.put(var, new LinkedList<TypeDecl>(domains_orig.get(var)));
	}
}
