/**
 * 
 */
package inference.heuristics;

import inference.ds.ConstraintSet;
import inference.ds.DistinctArrayList;
import inference.ds.ErrorTuple;
import inference.ds.RepairEntry;
import inference.ds.Solution;
import inference.ds.TVarGroup;
import inference.ds.Tuple;
import inference.error_managers.ITypeErrorManager;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.error_messages.heuristic_messages.TypeChangeExt;
import inference.solvers.ISolver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import AST.AbstractWildcardType;
import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class MaximalEquality extends AbstractHeuristic {
	private final Map<TypeVariable, ConstraintSet> constraints;

	private final Map<TypeDecl, List<Tuple>> supertypeAfterChecks,
			subtypeAfterChecks;

	private final ITypeErrorManager errMan;
	private Map<EqTypeErrorMsg, MessageExtension> cachedExtensions;
	private LinkedList<EqualityRepairEntry> cachedRepairs;

	/**
	 * @param solver
	 */
	public MaximalEquality(final ISolver solver) {
		this(solver.getCurrentConstraints(false), solver.getSuperTypeChecks(),
				solver.getSubTypeChecks(), solver.getTypeErrorManager());
	}

	/**
	 * @param constraints
	 * @param supertypeAfterChecks
	 * @param subtypeAfterChecks
	 * @param errMan
	 */
	public MaximalEquality(final Map<TypeVariable, ConstraintSet> constraints,
			final Map<TypeDecl, List<Tuple>> supertypeAfterChecks,
			final Map<TypeDecl, List<Tuple>> subtypeAfterChecks,
			final ITypeErrorManager errMan) {
		super("Maximal Equality");
		this.constraints = constraints;
		this.supertypeAfterChecks = supertypeAfterChecks;
		this.subtypeAfterChecks = subtypeAfterChecks;
		this.errMan = errMan;
		// cache message extensions
		cachedExtensions = new HashMap<EqTypeErrorMsg, MessageExtension>(5);
		// cache repairs
		cachedRepairs = new LinkedList<EqualityRepairEntry>();
	}

	@Override
	public void analyse() {
		analyseEqualityConstraints();

		// apply cached solutions after performing expr consistency check.
		detectExprInconsitency(cachedRepairs, cachedExtensions);
		for (Map.Entry<EqTypeErrorMsg, MessageExtension> kv : cachedExtensions
				.entrySet())
			kv.getKey().addExtension(kv.getValue());
	}

	/**
	 * Compute the solutions that require a minimal number of edits to correct
	 * the type conflict. If there is only one best solution, then report it to
	 * the user, otherwise not.
	 */
	@SuppressWarnings("serial")
	private void analyseEqualityConstraints() {
		Map<TypeVariable, EqTypeErrorMsg> eqErrors = errMan.getEqualityErrors();
		if (eqErrors.isEmpty())
			return;
		// select only the types that satisfy the constraints.
		for (TypeVariable T : eqErrors.keySet()) {
			ConstraintSet set = constraints.get(T);
			// T = U
			if (!set.equaltypeConstraints.isEmpty())
				analyseEqualityErrors(eqErrors.get(T).getEqTypeValues(), set);
		}

		// compute the type domains and type groups
		Map<TypeVariable, List<TypeDecl>> doms =
				new HashMap<TypeVariable, List<TypeDecl>>(eqErrors.size());
		Set<TVarGroup> varGroups = new HashSet<TVarGroup>(6) {
			public boolean contains(Object o) {
				for (TVarGroup tvgr : this) {
					if (o == null && tvgr == null)
						return true;

					if (tvgr.equals(o))
						return true;
				}
				return false;
			}
		};

		for (TypeVariable T : constraints.keySet()) {
			// to remove duplicates
			Set<TypeDecl> tmpSet = new HashSet<TypeDecl>();
			if (eqErrors.containsKey(T)) {
				for (ErrorTuple et : eqErrors.get(T).getEqTypeValues())
					if (et.getParticipation() == 0)
						tmpSet.add(et.getType());

			} else {
				tmpSet.add(constraints.get(T).typeArgument);
			}
			// use list instead of set to obtain a forward and backward
			// iterator.
			doms.put(T, new LinkedList<TypeDecl>(tmpSet));
			Set typeVariableGroup = T.typeVariableGroup(constraints.keySet());
			if (!varGroups.contains(typeVariableGroup))
				varGroups.add(new TVarGroup(typeVariableGroup));
		}

		EqualityGroupSolver eqSolver = null;
		// check if a type group has an empty domain. If it does then there is
		// no solution for it. Otherwise, if all types are declared types then
		// start EqualityGroupSolver.
		for (TVarGroup vgroup : varGroups) {
			Set<TypeVariable> typeGroup = vgroup.memberVars();
			if (!vgroup.hasEmptyDomain(doms)
			/* && allSourceTypes(eqErrors, typeGroup) */) {

				// add type statistics to the typeVar group
				for (TypeVariable tvar : typeGroup)
					vgroup.addTypeStats(tvar, constraints.get(tvar)
							.typeStatistics());

				if (eqSolver == null)
					eqSolver = new EqualityGroupSolver(typeGroup, doms);
				else
					eqSolver.resetSolver(typeGroup, doms);

				List<Map<TypeVariable, TypeDecl>> solutions = eqSolver.solve();
				if (solutions.isEmpty())
					continue;
				List<Solution> wrappedSolutions =
						new ArrayList<Solution>(solutions.size());

				for (Map<TypeVariable, TypeDecl> sol : solutions) {
					wrappedSolutions.add(new Solution(sol));
				}
				vgroup.calcBestSolution(wrappedSolutions, eqErrors, !Program
						.hasOption(Program._distinctTypes));
				if (!Program.hasOption(Program._strictMode)) {
					// correct error messages
					if (vgroup.hasOneBestSolution()) {
						Solution solu = vgroup.bestSolution();
						applySolution(eqErrors, solu);
					}

				}
			}
		}
		// do this only when strict is on
		if (Program.hasOption(Program._strictMode)) {
			List<Set<TVarGroup>> joinedTVarGroups = joinTVarGroups(varGroups);
			nextCluster: for (Set<TVarGroup> vgroupSet : joinedTVarGroups) {
				// make sure each group in a cluster has at least one solution.
				for (TVarGroup vg : vgroupSet)
					if (!vg.isSolvable())
						continue nextCluster;
				List<Set<Solution>> checkedSolutions =
						findSolutionForJoindGroup(vgroupSet);

				if (checkedSolutions.size() == 1)
					for (Solution solu : checkedSolutions.get(0))
						applySolution(eqErrors, solu);
			}
		}
	}

	/**
	 * Apply <code>solution</code> to the corresponding equality error
	 * messages.
	 * <p>
	 * Solution is actually not directly applied, but cache first for an
	 * expression inconsistency check.
	 * 
	 * @param eqErrors
	 * @param solution
	 */
	private void applySolution(Map<TypeVariable, EqTypeErrorMsg> eqErrors,
			Solution solution) {

		for (TypeVariable var : solution.iterate()) {
			if (eqErrors.containsKey(var)) {
				EqTypeErrorMsg erMsg = eqErrors.get(var);
				TypeDecl newType = solution.getType(var);
				TypeChangeExt majEx = new TypeChangeExt(newType, getClass());
				// Replaced with the code below!!
				// for (ErrorTuple etu : erMsg.getEqTypeValues())
				// if (etu.getType() != solution.getType(var))
				// majEx.addReplaceable(etu.getOrigTuple());

				// print the type from the source code, not the once used for
				// type-checking.
				for (Tuple uw : erMsg.getSourceTypes())
					if (uw.implied != newType) {
						cachedRepairs.add(new EqualityRepairEntry(erMsg,
								newType, uw));
						majEx.addReplaceable(uw);
					}
				// DONE check for inconsistencies first.
				if (majEx.isReady())
					cachedExtensions.put(erMsg, majEx);
				// erMsg.addExtension(majEx);
			}
		}

	}

	/**
	 * Count how many conflicts are or could be caused by each type in the list
	 * <code>erTupleList</code>.
	 * 
	 * @param eqTypeValues:
	 *            List of equality errors
	 * @param set
	 *            all constraints collected for a certain T
	 */
	private void analyseEqualityErrors(final List<ErrorTuple> erTupleList,
			final ConstraintSet set) {
		for (ErrorTuple UW : erTupleList) {
			UW.runHeuristic();
			// V <: T -> V <: UW.implied
			checkSupertypeConstraints(UW, set.supertypeConstraints);
			// T <: V -> UW.implied <: V
			checkSubtypeConstraints(UW, set.subtypeConstraints);
			// V <: T -> V <: UW.implied
			checkBoundConstraints(UW, set.boundConstraints);
			// if a type is ?, then it is more likely that ? is the source of
			// error.
			if (UW.getType() instanceof AbstractWildcardType) {
				UW.participate();
			}
		}
	}

	/**
	 * Count how many supertype constraints does the type in <code>ertu</code>
	 * violate.
	 * 
	 * @param ertu
	 * @param supertypeConstraints
	 */
	private void checkSupertypeConstraints(ErrorTuple ertu,
			DistinctArrayList supertypeConstraints) {
		for (Tuple UW : supertypeConstraints) {
			if (!UW.implied.subtype(ertu.getType())) {
				ertu.participate();
			}
		}
	}

	/**
	 * Count how many subtype constraints does the type in <code>ertu</code>
	 * violate.
	 * 
	 * @param uw
	 * @param subtypeConstraints
	 */
	private void checkSubtypeConstraints(ErrorTuple ertu,
			DistinctArrayList subtypeConstraints) {
		for (Tuple UW : subtypeConstraints) {
			if (!ertu.getType().subtype(UW.implied)) {
				ertu.participate();
			}
		}
	}

	/**
	 * Count how many bound constraints does the type in
	 * <code>ertu<code> violate.
	 * 
	 * @param ertu
	 * @param boundConstraints
	 */
	private void checkBoundConstraints(ErrorTuple ertu,
			Set<TypeDecl> boundConstraints) {
		for (TypeDecl bound : boundConstraints) {
			if (!ertu.getType().subtype(bound))
				ertu.participate();
		}
	}

	// ------------------------------------------------------------------------
	// new after-check
	// ------------------------------------------------------------------------

	/**
	 * Return the best solutions that satisfy the after-checks.
	 * 
	 * @param groupSet
	 * @return a list of best solution
	 */
	private List<Set<Solution>> findSolutionForJoindGroup(
			final Set<TVarGroup> groupSet) {

		Set<TypeVariable> joinedTVarSet = new HashSet<TypeVariable>(6);
		for (TVarGroup gr : groupSet) {
			joinedTVarSet.addAll(gr.memberVars());
		}

		// collection of supertype after-checks that correspond to the
		// TVarGroups in groupSet.
		Map<TypeDecl, List<Tuple>> superAfterChecks =
				new HashMap<TypeDecl, List<Tuple>>(supertypeAfterChecks.size());
		for (TypeDecl td : supertypeAfterChecks.keySet()) {
			if (joinedTVarSet.containsAll(td.getTypeVariables()))
				superAfterChecks.put(td, supertypeAfterChecks.get(td));
		}

		// collection of subtype after-checks that correspond to the TVarGroups
		// in groupSet.
		Map<TypeDecl, List<Tuple>> subAfterChecks =
				new HashMap<TypeDecl, List<Tuple>>(subtypeAfterChecks.size());
		for (TypeDecl td : subtypeAfterChecks.keySet()) {
			if (joinedTVarSet.containsAll(td.getTypeVariables()))
				subAfterChecks.put(td, subtypeAfterChecks.get(td));
		}

		return findSolutionForJoindGroup(new LinkedList(groupSet),
				superAfterChecks, subAfterChecks);

	}

	/**
	 * Return the best solutions that satisfies the after-checks corresponding
	 * to type variable groups in groupList.
	 * 
	 * @param groupList
	 *            list of type groups.
	 * @param superAfterChecks
	 * @param subAfterChecks
	 * @return a list of best solution
	 */
	private List<Set<Solution>> findSolutionForJoindGroup(
			final List<TVarGroup> groupList,
			final Map<TypeDecl, List<Tuple>> superAfterChecks,
			final Map<TypeDecl, List<Tuple>> subAfterChecks) {

		int bestScore = 0;
		for (TVarGroup tvg : groupList) {
			if (tvg.hasOneBestSolution())
				bestScore += tvg.highestScore();
			else {
				bestScore = -1;
				break;
			}
		}
		List<Set<Solution>> allSolutions = new LinkedList<Set<Solution>>();
		TVarGroup head = groupList.get(0);
		for (Solution sn : head.iterateSolutions()) {
			HashSet<Solution> solutionSet =
					new HashSet<Solution>(groupList.size());
			solutionSet.add(sn);
			ListIterator<TVarGroup> iter = groupList.listIterator(1);
			if (cartesianProduct(solutionSet, iter, allSolutions,
					superAfterChecks, subAfterChecks, bestScore))
				break;
		}
		// filter out the non-optimal solution
		List<Set<Solution>> weakCandidates = new LinkedList<Set<Solution>>();
		for (Set<Solution> sSet : allSolutions) {
			int score = 0;
			for (Solution s : sSet)
				score += s.score();
			if (score < bestScore)
				weakCandidates.add(sSet);
		}
		allSolutions.removeAll(weakCandidates);
		return allSolutions;
	}

	/**
	 * Compute the cartesion product of the solutions in
	 * <code>solutionSet</code> that satisfy the after-checks, but stop when
	 * the best solution is found.
	 * 
	 * @param solutionSet
	 *            partial solution that needs to be extends by solution from
	 *            other type groups.
	 * @param iter
	 *            list iterator that allows backtracking
	 * @param allSolutions
	 *            set to collect the computed solutions
	 * @param superAfterChecks
	 * @param subAfterChecks
	 * @param bestScore
	 * @return the halting condition
	 */
	private boolean cartesianProduct(final HashSet<Solution> solutionSet,
			final ListIterator<TVarGroup> iter,
			final List<Set<Solution>> allSolutions,
			final Map<TypeDecl, List<Tuple>> superAfterChecks,
			final Map<TypeDecl, List<Tuple>> subAfterChecks, final int bestScore) {
		if (iter.hasNext()) {
			for (Solution sn : iter.next().iterateSolutions()) {
				solutionSet.add(sn);
				if (cartesianProduct(solutionSet, iter, allSolutions,
						superAfterChecks, subAfterChecks, bestScore))
					return true;
				solutionSet.remove(sn);
			}
			iter.previous();
		} else {
			Map<TypeVariable, TypeDecl> subst =
					new HashMap<TypeVariable, TypeDecl>(6);
			int score = 0;

			for (Solution s : solutionSet) {
				subst.putAll(s.substitution());
				score += s.score();
			}
			// add a solution only if it checks.
			if (verifyAfterChecks(subst, superAfterChecks, subAfterChecks))
				allSolutions.add((Set<Solution>) solutionSet.clone());
			// return the halting condition, which is when the best solution is
			// found.
			return score == bestScore;
		}
		return false;
	}

	/**
	 * Verify that a substitution satisfies the after-checks corresponding to
	 * the types in its domain.
	 * 
	 * @param subst
	 * @param superAfterChecks
	 * @param subAfterChecks
	 * @return
	 */
	private boolean verifyAfterChecks(final Map<TypeVariable, TypeDecl> subst,
			final Map<TypeDecl, List<Tuple>> superAfterChecks,
			final Map<TypeDecl, List<Tuple>> subAfterChecks) {

		for (TypeDecl sup : superAfterChecks.keySet()) {
			TypeDecl instSup = sup.instantiateParType(subst);
			for (Tuple uw : superAfterChecks.get(sup))
				if (!uw.implied.subtype(instSup))
					return false;

		}

		for (TypeDecl sub : subAfterChecks.keySet()) {
			TypeDecl instSub = sub.instantiateParType(subst);
			for (Tuple uw : subAfterChecks.get(sub))
				if (!instSub.subtype(uw.implied))
					return false;
		}
		return true;
	}

	/**
	 * Return a list that contains sets of type variable groups whose solution
	 * must be combined to verify the after-checks.
	 * 
	 * @param groupSet
	 * @return
	 */
	private List<Set<TVarGroup>> joinTVarGroups(final Set<TVarGroup> groupSet) {
		Set<Set<TVarGroup>> joinGroups = new HashSet<Set<TVarGroup>>(4);
		joinTVarGroups(groupSet, supertypeAfterChecks, joinGroups);
		joinTVarGroups(groupSet, subtypeAfterChecks, joinGroups);
		return new LinkedList<Set<TVarGroup>>(joinGroups);
	}

	/**
	 * @param groupSet
	 * @param AfterChecks
	 * @param joinedGroupsSet
	 */
	private void joinTVarGroups(final Set<TVarGroup> groupSet,
			final Map<TypeDecl, List<Tuple>> AfterChecks,
			final Set<Set<TVarGroup>> joinedGroupsSet) {
		for (TypeDecl sup : AfterChecks.keySet()) {
			Set<TypeVariable> typeArgs = sup.getTypeVariables();
			for (TypeVariable var : typeArgs) {
				Set<TVarGroup> joinedGroup =
						findTVarGroup(var, joinedGroupsSet);
				if (joinedGroup == null) {
					joinedGroup = new HashSet<TVarGroup>(4);
				}
				addAllTVarGroups(typeArgs, groupSet, joinedGroup);
				joinedGroupsSet.add(joinedGroup);
			}
		}
	}

	/**
	 * Return a joined group to which the type variable var belongs to, or null
	 * if no such group exists yet.
	 * 
	 * @param var
	 * @param joinedGroups
	 * @return exiting joined group or null.
	 */
	private Set<TVarGroup> findTVarGroup(final TypeVariable var,
			final Set<Set<TVarGroup>> joinedGroups) {
		for (Set<TVarGroup> grSet : joinedGroups) {
			for (TVarGroup gr : grSet)
				if (gr.constaintsTVar(var))
					return grSet;
		}
		return null;
	}

	/**
	 * Add all type variable groups that the type variables in varSet are a
	 * member of to the set joinedGroup.
	 * 
	 * @param varSet
	 * @param groupSet
	 * @param joinedGroup
	 */
	private void addAllTVarGroups(final Set<TypeVariable> varSet,
			final Set<TVarGroup> groupSet, final Set<TVarGroup> joinedGroup) {
		for (TypeVariable var : varSet) {
			for (TVarGroup gr : groupSet)
				if (gr.constaintsTVar(var)) {
					joinedGroup.add(gr);
					break;
				}
		}
	}

	final class EqualityRepairEntry extends RepairEntry<EqTypeErrorMsg> {
		public EqualityRepairEntry(EqTypeErrorMsg msg, TypeDecl type, Tuple tu) {
			super(msg, type, tu);
		}

		public String toString() {
			StringBuilder buf =
					new StringBuilder(repairedEntity.getTypeVariable()
							.simpleName());
			buf.append(": ");
			buf.append(type.simpleName());
			buf.append(" ");
			buf.append(subPosition);
			buf.append(" ");
			buf.append(position);
			return buf.toString();
		}
	}
}
