/**
 * 
 */
package inference.error_managers;

import inference.ds.ErrorSet;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.TypeParamBoundError;

import java.util.List;
import java.util.Map;

import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class TypeCheckErrorManager extends TypeErrorManager {
	private Map<TypeVariable, TypeDecl> inferredTypeArguments;
	private Map<TypeVariable, TypeDecl> typeArguments;

	public TypeCheckErrorManager(List<TypeVariable> typeVariables) {
		super(typeVariables);
	}

	// -------------------------------------------------------------------------
	// printing error messages
	// -------------------------------------------------------------------------

	@Override
	public void fetchErrorMsgs(StringBuilder buf) {
		for (TypeVariable T : typeVariableList) {
			if (errorMap.containsKey(T)) {
				ErrorSet erSet = errorMap.get(T);
				fetchEqualityErrors(erSet.getEqualityErrors(), buf);
				fetchSuperTypeErrors(erSet.getSupertypeErrorList(), buf);
				fetchSubTypeErrors(erSet, buf);
				fetchTypeParamBoundErrors(erSet, buf);
				if (inferredTypeArguments != null
						&& inferredTypeArguments.containsKey(T)) {
					buf.append("  Perhaps you need to change ");
					TypeDecl userTypeArg = typeArguments.get(T);
					buf.append(userTypeArg.simpleName());
					String loc = userTypeArg.getSourceLocation();
					if (loc != null && loc != "") {
						buf.append(" on ");
						buf.append(loc);
					}
					buf.append(" to ");
					buf.append(inferredTypeArguments.get(T).simpleName());
					buf.append("\n");
				}

			}
		}
		for (TypeCheckErrorMsg msg : checkErrorList) {
			buf.append("  [#] ");
			buf.append(msg.toString());
			buf.append("\n");
		}
	}

	protected void fetchSubTypeErrors(ErrorSet erSet, StringBuilder buf) {
		for (SubTypeErrorMsg msg : erSet.getSubtypeErrorList()) {
			buf.append("  [<] ");
			buf.append(msg);
			buf.append("\n");
		}
	}

	private void fetchTypeParamBoundErrors(ErrorSet erSet, StringBuilder buf) {
		for (TypeParamBoundError msg : erSet.getArgBoundErrorList()) {
			buf.append("  [-|] ");
			buf.append(msg);
			buf.append("\n");
		}
	}

	// -------------------------------------------------------------------------
	// getters
	// -------------------------------------------------------------------------

	public boolean hasTypeParamBoundErrors() {
		for (TypeVariable T : typeVariableSet)
			if (!errorMap.get(T).getArgBoundErrorList().isEmpty())
				return true;

		return false;
	}

	// -------------------------------------------------------------------------
	// setters
	// -------------------------------------------------------------------------

	public void setInferredTypeArguments(
			Map<TypeVariable, TypeDecl> inferredTypeArguments) {
		this.inferredTypeArguments = inferredTypeArguments;
	}

	public void setTypeArguments(Map<TypeVariable, TypeDecl> typeArguments) {
		this.typeArguments = typeArguments;
	}

}
