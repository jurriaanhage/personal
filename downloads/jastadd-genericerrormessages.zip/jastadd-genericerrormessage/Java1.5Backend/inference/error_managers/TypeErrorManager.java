/**
 * 
 */
package inference.error_managers;

import inference.ds.ErrorSet;
import inference.error_messages.AbstractErrorMsg;
import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.SkippedEqTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.TypeErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;
import inference.heuristics.BoundGlbSubtyping;
import inference.heuristics.BoundSuperWildcard;
import inference.heuristics.CxtReturnInvariance;
import inference.heuristics.EqualityTypeWarning;
import inference.heuristics.ExtendsFinal;
import inference.heuristics.MaximalEquality;
import inference.heuristics.OppositeWildcards;
import inference.heuristics.MaximalSubtyping;
import inference.heuristics.SuperObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public abstract class TypeErrorManager {

	protected Map<TypeVariable, ErrorSet> errorMap;
	// only type variables that are in conflict
	protected Set<TypeVariable> typeVariableSet;
	// all the method's type variables
	protected List<TypeVariable> typeVariableList;
	protected List<TypeCheckErrorMsg> checkErrorList;

	// Priority of heuristics.
	public static final PriorityComparator priorityComparator =
			new PriorityComparator();
	public static Map<Class, Integer> heuristicsPriority;
	static {
		heuristicsPriority = new HashMap<Class, Integer>();
		heuristicsPriority.put(MaximalEquality.class, 10);
		heuristicsPriority.put(ExtendsFinal.class, 10);
		heuristicsPriority.put(SuperObject.class, 10);
		heuristicsPriority.put(CxtReturnInvariance.class, 20);
		heuristicsPriority.put(EqualityTypeWarning.class, 19);
		heuristicsPriority.put(MaximalSubtyping.class, 19);
		heuristicsPriority.put(OppositeWildcards.class, 15);
		heuristicsPriority.put(BoundSuperWildcard.class, 10);
		heuristicsPriority.put(BoundGlbSubtyping.class, 10);
	}

	/**
	 * 
	 */
	public TypeErrorManager(List<TypeVariable> typeVariables) {
		this.errorMap = new HashMap<TypeVariable, ErrorSet>();
		this.typeVariableSet = new HashSet<TypeVariable>();
		this.typeVariableList = typeVariables;
		this.checkErrorList = new ArrayList<TypeCheckErrorMsg>();
	}

	// -------------------------------------------------------------------------
	// add error messages
	// -------------------------------------------------------------------------

	public void addErrorMsg(TypeErrorMsg msg) {
		TypeVariable T = msg.getTypeVariable();
		if (errorMap.containsKey(T)) {
			errorMap.get(T).addErrorMsg(msg);
		} else {
			ErrorSet eSet = new ErrorSet(T);
			eSet.addErrorMsg(msg);
			errorMap.put(T, eSet);
			typeVariableSet.add(T);
		}
	}

	public void addErrorMsg(TypeCheckErrorMsg msg) {
		checkErrorList.add(msg);
	}

	// -------------------------------------------------------------------------
	// printing error messages
	// -------------------------------------------------------------------------

	public abstract void fetchErrorMsgs(StringBuilder buf);

	protected void fetchEqualityErrors(AbstractErrorMsg equalityError,
			StringBuilder buf) {
		if (equalityError == null)
			return;

		buf.append("  [*] ");
		buf.append(equalityError);
		buf.append("\n");
	}

	protected void fetchSuperTypeErrors(List<SupTypeErrorMsg> supErrorList,
			StringBuilder buf) {
		fetchTypeErrors(supErrorList, buf);
	}

	protected void fetchSkippedEqualTypeErrors(
			List<SkippedEqTypeErrorMsg> supErrorList, StringBuilder buf) {
		fetchTypeErrors(supErrorList, buf);
	}

	private void fetchTypeErrors(List<? extends AbstractErrorMsg> supErrorList,
			StringBuilder buf) {
		for (AbstractErrorMsg msg : supErrorList) {
			buf.append("  [*] ");
			buf.append(msg);
			buf.append("\n");
		}
	}

	// -------------------------------------------------------------------------
	// getters
	// -------------------------------------------------------------------------
	public Map<TypeVariable, EqTypeErrorMsg> getEqualityErrors() {
		Map<TypeVariable, EqTypeErrorMsg> equalityErrors =
				new HashMap<TypeVariable, EqTypeErrorMsg>();

		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (erSet.getEqualityErrors() != null)
				equalityErrors.put(T, erSet.getEqualityErrors());
		}
		return equalityErrors;
	}

	public Map<TypeVariable, List<SubTypeErrorMsg>> getSubtypeErrors() {
		Map<TypeVariable, List<SubTypeErrorMsg>> subtypeErrors =
				new HashMap<TypeVariable, List<SubTypeErrorMsg>>();

		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getSubtypeErrorList().isEmpty())
				subtypeErrors.put(T, erSet.getSubtypeErrorList());
		}
		return subtypeErrors;
	}

	public Map<TypeVariable, List<SupTypeErrorMsg>> getSupertypeErrors() {
		Map<TypeVariable, List<SupTypeErrorMsg>> supertypeErrors =
				new HashMap<TypeVariable, List<SupTypeErrorMsg>>();

		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getSupertypeErrorList().isEmpty())
				supertypeErrors.put(T, erSet.getSupertypeErrorList());
		}
		return supertypeErrors;
	}

	public Collection<? extends ErrorSet> getErrorSet() {
		return errorMap.values();
	}

	// -------------------------------------------------------------------------
	// auxiliary methods
	// -------------------------------------------------------------------------
	public boolean reportErrors() {
		return !errorMap.isEmpty() || hasAfterCheckErrors();
	}

	public boolean hasAfterCheckErrors() {
		return !checkErrorList.isEmpty();
	}

	public List<TypeCheckErrorMsg> getCheckErrorList() {
		return checkErrorList;
	}

	public boolean hasErrors(TypeVariable var) {
		return typeVariableSet.contains(var);
	}

	static class PriorityComparator implements Comparator<MessageExtension> {

		public int compare(MessageExtension o1, MessageExtension o2) {
			if (heuristicsPriority.containsKey(o1)
					&& heuristicsPriority.containsKey(o2))
				return heuristicsPriority.get(o2) - heuristicsPriority.get(o1);
			else if (heuristicsPriority.containsKey(o1))
				return -1;
			else if (heuristicsPriority.containsKey(o2))
				return 1;
			else
				return 0;
		}
	}
}
