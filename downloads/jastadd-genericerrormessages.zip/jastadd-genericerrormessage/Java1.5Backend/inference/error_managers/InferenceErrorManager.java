/**
 * 
 */
package inference.error_managers;

import inference.ds.ErrorSet;
import inference.error_messages.AbstractErrorMsg;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import AST.Program;
import AST.TypeDecl;
import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public class InferenceErrorManager extends TypeErrorManager implements
		ITypeErrorManager {

	// mapping of (T => # T <: U)
	private Map<TypeVariable, Integer> numOfSubtypeConstraintsMap;
	// mapping of T => [MsgExt]
	private Map<TypeVariable, List<MessageExtension>> globalExt;

	public InferenceErrorManager(List<TypeVariable> typeVariables) {
		super(typeVariables);
		this.numOfSubtypeConstraintsMap = new HashMap<TypeVariable, Integer>();
		globalExt =
				new HashMap<TypeVariable, List<MessageExtension>>(typeVariables
						.size());
	}

	// -------------------------------------------------------------------------
	// getters
	// -------------------------------------------------------------------------

	public Map<TypeVariable, List<PrBoundTypeErrorMsg>> getPreBoundErrors() {
		Map<TypeVariable, List<PrBoundTypeErrorMsg>> preBoundErrors =
				new HashMap<TypeVariable, List<PrBoundTypeErrorMsg>>();
		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getPreBoundErrorList().isEmpty())
				preBoundErrors.put(T, erSet.getPreBoundErrorList());
		}
		return preBoundErrors;
	}

	public Map<TypeVariable, List<GlbTypeErrorMsg>> getGlbErrors() {
		Map<TypeVariable, List<GlbTypeErrorMsg>> glbErrors =
				new HashMap<TypeVariable, List<GlbTypeErrorMsg>>();
		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getGlbErrorList().isEmpty())
				glbErrors.put(T, erSet.getGlbErrorList());
		}
		return glbErrors;
	}

	public Map<TypeVariable, List<PoBoundTypeErrorMsg>> getPostBoundErrors() {
		Map<TypeVariable, List<PoBoundTypeErrorMsg>> postBoundErrors =
				new HashMap<TypeVariable, List<PoBoundTypeErrorMsg>>();

		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getPostBoundErrorList().isEmpty())
				postBoundErrors.put(T, erSet.getPostBoundErrorList());
		}
		return postBoundErrors;
	}

	// -------------------------------------------------------------------------
	// printing error messages
	// -------------------------------------------------------------------------

	/**
	 * returns whether arguments were checked for a greatest lower bound or not.
	 * 
	 * @return <b>true</b> if arguments were not checked and <b>false</b>
	 *         otherwise.
	 */
	public boolean checkForGlbBoundErrors() {
		for (TypeVariable T : typeVariableSet) {
			ErrorSet erSet = errorMap.get(T);
			if (!erSet.getGlbErrorList().isEmpty())
				return false;
		}
		return true;
	}

	@Override
	public void fetchErrorMsgs(StringBuilder buf) {
		for (TypeVariable T : typeVariableList)
			if (errorMap.containsKey(T)) {
				ErrorSet erSet = errorMap.get(T);
				int highPrio = AbstractErrorMsg.unset;
				List<MessageExtension> extList = globalExt.get(T);
				if (extList != null && !extList.isEmpty()) {
					Collections.sort(extList, priorityComparator);
					highPrio =
							heuristicsPriority.get(extList.get(0).heuristic());
				}

				fetchPreBoundErrors(erSet.getPreBoundErrorList(), buf, highPrio);
				fetchGlbErrors(erSet.getGlbErrorList(), buf);
				fetchSkippedEqualTypeErrors(erSet.getEqualErrorList(), buf);
				fetchEqualityErrors(erSet.getEqualityErrors(), buf, highPrio);
				fetchSuperTypeErrors(erSet.getSupertypeErrorList(), buf);
				fetchSubTypeErrors(erSet, buf);
				fetchPostBoundErrors(erSet.getPostBoundErrorList(), buf);
				if (extList != null) {
					for (MessageExtension msgEx : extList) {
						if (heuristicsPriority.get(msgEx.heuristic()) == highPrio) {
							buf.append(" ");
							msgEx.hint(buf);
							buf.append("\n");
						}
					}
				}
			}
		for (TypeCheckErrorMsg msg : checkErrorList) {
			buf.append("  [*] ");
			buf.append(msg.toString());
			buf.append("\n");
		}
	}

	protected void fetchEqualityErrors(AbstractErrorMsg equalityError,
			StringBuilder buf, final int highPrio) {
		if (equalityError == null)
			return;

		equalityError.surpressExtensions(highPrio);
		buf.append("  [*] ");
		buf.append(equalityError);
		if (!equalityError.suppressedExtenstion())
			buf.append("\n");
	}

	private void fetchPreBoundErrors(List<PrBoundTypeErrorMsg> boundErrorList,
			StringBuilder buf, final int highPrio) {
		if (Program.hasOption(Program._collapseAll)) {
			// print each error on a separate line
			for (AbstractErrorMsg msg : boundErrorList) {
				msg.surpressExtensions(highPrio);
				buf.append(" [*] ");
				buf.append(msg);
				buf.append("\n");
			}
		} else if (boundErrorList.size() > 0) {
			// print all errors on a single line
			HashMap<TypeVariable, List<PrBoundTypeErrorMsg>> partitions =
					new HashMap<TypeVariable, List<PrBoundTypeErrorMsg>>(
							boundErrorList.size());
			// group msgs
			for (PrBoundTypeErrorMsg msg : boundErrorList) {
				msg.surpressExtensions(highPrio);
				TypeVariable var = msg.getTypeVariable();
				if (partitions.containsKey(var))
					partitions.get(var).add(msg);
				else {
					LinkedList<PrBoundTypeErrorMsg> erList =
							new LinkedList<PrBoundTypeErrorMsg>();
					erList.add(msg);
					partitions.put(var, erList);
				}
			}
			// print msgs
			for (TypeVariable var : partitions.keySet())
				groupTypePreBoundErrors(partitions.get(var), buf);
		}
	}

	private void groupTypePreBoundErrors(List<PrBoundTypeErrorMsg> errList,
			StringBuilder buf) {
		HashMap<TypeDecl, List<PrBoundTypeErrorMsg>> partitions =
				new HashMap<TypeDecl, List<PrBoundTypeErrorMsg>>();

		for (PrBoundTypeErrorMsg msg : errList) {
			TypeDecl keyType = msg.getTypeValue();
			if (partitions.containsKey(keyType))
				partitions.get(keyType).add(msg);
			else {
				List<PrBoundTypeErrorMsg> msgList =
						new LinkedList<PrBoundTypeErrorMsg>();
				msgList.add(msg);
				partitions.put(keyType, msgList);
			}
		}

		for (TypeDecl keyType : partitions.keySet()) {
			List<PrBoundTypeErrorMsg> erList = partitions.get(keyType);
			PrBoundTypeErrorMsg msg = erList.remove(0);
			buf.append("  [*] ");
			if (erList.isEmpty())
				buf.append(msg);
			else
				buf.append(msg.joinMessages(erList));
			buf.append("\n");
		}
	}

	private void fetchGlbErrors(List<GlbTypeErrorMsg> glbErrorList,
			StringBuilder buf) {
		for (AbstractErrorMsg msg : glbErrorList) {
			buf.append("  [*] ");
			buf.append(msg);
			buf.append("\n");
		}
	}

	protected void fetchSubTypeErrors(ErrorSet erSet, StringBuilder buf) {
		for (SubTypeErrorMsg msg : erSet.getSubtypeErrorList()) {
			buf.append("  [*] ");
			buf.append(msg);
			buf.append("\n");
		}
	}

	private void fetchPostBoundErrors(List<PoBoundTypeErrorMsg> boundList,
			StringBuilder buf) {
		if (Program.hasOption(Program._collapseAll)) {
			for (AbstractErrorMsg msg : boundList) {
				buf.append("  [*] ");
				buf.append(msg);
				buf.append("\n");
			}
		} else {
			// print all errors on a single line
			HashMap<TypeVariable, List<PoBoundTypeErrorMsg>> partitions =
					new HashMap<TypeVariable, List<PoBoundTypeErrorMsg>>(
							boundList.size());
			// group msgs
			for (PoBoundTypeErrorMsg msg : boundList) {
				TypeVariable var = msg.getTypeVariable();
				if (partitions.containsKey(var))
					partitions.get(var).add(msg);
				else {
					LinkedList<PoBoundTypeErrorMsg> erList =
							new LinkedList<PoBoundTypeErrorMsg>();
					erList.add(msg);
					partitions.put(var, erList);
				}
			}
			// print msgs
			for (TypeVariable var : partitions.keySet()) {
				List<PoBoundTypeErrorMsg> erList = partitions.get(var);
				PoBoundTypeErrorMsg msg = erList.remove(0);
				buf.append("  [*] ");
				if (erList.isEmpty())
					buf.append(msg);
				else
					buf.append(msg.joinMessages(erList));
				buf.append("\n");
			}
		}
	}

	// -------------------------------------------------------------------------
	// auxiliary methods
	// -------------------------------------------------------------------------
	public void setNumOfSubtypeConstraints(TypeVariable T, int num) {
		numOfSubtypeConstraintsMap.put(T, num);
	}

	public void addMsgExtension(final TypeVariable var,
			final MessageExtension msgEx) {
		if (globalExt.containsKey(var)) {
			globalExt.get(var).add(msgEx);
		} else {
			LinkedList<MessageExtension> extList =
					new LinkedList<MessageExtension>();
			extList.add(msgEx);
			globalExt.put(var, extList);
		}
	}

	// -------------------------------------------------------------------------
	// For testing
	// -------------------------------------------------------------------------
	public Map<TypeVariable, List<MessageExtension>> getExtensions() {
		return globalExt;
	}

}
