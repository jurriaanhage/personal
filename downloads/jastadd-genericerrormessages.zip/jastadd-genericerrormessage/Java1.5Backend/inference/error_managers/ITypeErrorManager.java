/**
 * 
 */
package inference.error_managers;

import inference.error_messages.EqTypeErrorMsg;
import inference.error_messages.GlbTypeErrorMsg;
import inference.error_messages.PoBoundTypeErrorMsg;
import inference.error_messages.PrBoundTypeErrorMsg;
import inference.error_messages.SubTypeErrorMsg;
import inference.error_messages.SupTypeErrorMsg;
import inference.error_messages.TypeCheckErrorMsg;
import inference.error_messages.TypeErrorMsg;
import inference.error_messages.heuristic_messages.MessageExtension;

import java.util.List;
import java.util.Map;

import AST.TypeVariable;

/**
 * @author Drako
 * 
 */
public interface ITypeErrorManager {
	public Map<TypeVariable, EqTypeErrorMsg> getEqualityErrors();

	public void addErrorMsg(final TypeErrorMsg msg);

	public void addMsgExtension(final TypeVariable var,
			final MessageExtension msgEx);

	public Map<TypeVariable, List<GlbTypeErrorMsg>> getGlbErrors();

	public Map<TypeVariable, List<PrBoundTypeErrorMsg>> getPreBoundErrors();
	public Map<TypeVariable, List<PoBoundTypeErrorMsg>> getPostBoundErrors();

	public List<TypeCheckErrorMsg> getCheckErrorList();

	public Map<TypeVariable, List<SupTypeErrorMsg>> getSupertypeErrors();

	public Map<TypeVariable, List<SubTypeErrorMsg>> getSubtypeErrors();
	
	public boolean hasErrors(TypeVariable var);
}
